import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PinoLogger } from 'nestjs-pino';
import {
  LOCATION_ESTIMATION_REPOSITORY,
  type LocationEstimationRepository,
} from '@application/location/location-estimation.repository';
import { LiveGateway } from '@app/live/live.gateway';
import {
  SingleCellLocationEstimator,
  type SingleCellEstimatorConfiguration,
} from './single-cell-location.estimator';

interface LocationRuntimeConfiguration extends SingleCellEstimatorConfiguration {
  enabled: boolean;
  evidenceMaxAgeMs: number;
}

export interface LocationEstimationSummary {
  candidates: number;
  created: number;
  skipped: number;
}

/** Orchestrates bounded location estimation after normalized UE measurements commit. */
@Injectable()
export class LocationEstimationService {
  private readonly configuration: LocationRuntimeConfiguration;
  private readonly estimator: SingleCellLocationEstimator;

  constructor(
    @Inject(LOCATION_ESTIMATION_REPOSITORY)
    private readonly repository: LocationEstimationRepository,
    private readonly config: ConfigService,
    private readonly live: LiveGateway,
    private readonly logger: PinoLogger,
  ) {
    this.logger.setContext(LocationEstimationService.name);
    this.configuration = this.config.getOrThrow<LocationRuntimeConfiguration>('location');
    this.estimator = new SingleCellLocationEstimator(this.configuration);
  }

  async estimateForTarget(targetId: string, observedAt: Date): Promise<LocationEstimationSummary> {
    if (!this.configuration.enabled) return { candidates: 0, created: 0, skipped: 0 };
    const candidates = await this.repository.findCandidates(
      targetId,
      observedAt,
      this.configuration.evidenceMaxAgeMs,
    );
    let created = 0;
    let skipped = 0;
    for (const candidate of candidates) {
      const estimate = this.estimator.estimate(candidate);
      if (!estimate) {
        skipped += 1;
        continue;
      }
      if (await this.repository.save(estimate)) created += 1;
    }
    if (created > 0) {
      this.live.publish('locations.updated', { targetId, observedAt: observedAt.toISOString(), count: created });
    }
    this.logger.info({ targetId, candidates: candidates.length, created, skipped }, 'Location estimation cycle completed');
    return { candidates: candidates.length, created, skipped };
  }
}
