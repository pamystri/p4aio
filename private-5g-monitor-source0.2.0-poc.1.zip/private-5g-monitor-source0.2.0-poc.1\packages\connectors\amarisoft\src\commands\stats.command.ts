import type { JsonValue } from '@connector-sdk/index';
import type {
  AmarisoftCommandModule,
  AmarisoftParserContext,
  AmarisoftTargetConfiguration,
} from '../amarisoft.types';
import { StatsParser } from '../parsers/stats.parser';
import { MmeStatsParser } from '../parsers/mme-stats.parser';

/** Owns the `stats` request shape and its matching response parser. */
export class StatsCommandModule implements AmarisoftCommandModule {
  readonly logicalOperation = 'stats';
  private readonly parser = new StatsParser();
  private readonly mmeParser = new MmeStatsParser();

  createRequest(configuration: AmarisoftTargetConfiguration): Readonly<Record<string, JsonValue>> {
    return configuration.componentType === 'mme'
      ? { message: 'stats' }
      : { message: 'stats', samples: configuration.stats.samples, rf: configuration.stats.rf };
  }

  parse(payload: JsonValue, context: AmarisoftParserContext, configuration: AmarisoftTargetConfiguration) {
    return configuration.componentType === 'mme'
      ? this.mmeParser.parse(payload, context, configuration)
      : this.parser.parse(payload, context);
  }
}
