# Backend module guide

## Runtime composition

The initial small-network deployment runs one NestJS process. Module boundaries are retained so collection or location work can move into another process later without changing domain or connector contracts.

## Location estimation

`LocationModule` runs after each committed `ue_get` cycle. It reads the newest normalized timing advance, path-loss, SNR, and EPRE observations for each UE/serving-cell pair, then writes immutable `location_estimate` and `location_evidence` records. The initial `single-cell-omni-v1` algorithm uses TA and path loss for range. Because an omnidirectional cell provides no bearing, it uses a stable pseudonymous display bearing and reports a deliberately broad accuracy radius plus a confidence capped at 0.4. Cell coordinates are preferred; site coordinates are a fallback.

Estimator failures are logged independently and never change an already committed collector run to failed. `locations.updated` is published after new estimates commit. The estimator is behind an application repository port so later sector, multi-cell, fingerprinting, or LPP algorithms can replace it without changing the REST or WebSocket envelopes.

## UE inventory and radio correlation

The connector SDK carries two non-metric canonical records. `CanonicalUeInventoryObservation` is emitted by MME/AMF parsers and contains transient in-memory identity, registration, session, IP, and RAN binding information. Persistence immediately HMAC-fingerprints the subscriber identity; plaintext IMSI/SUPI is never written to normalized tables or returned by an API. `CanonicalUeRadioPresence` is emitted by gNB `ue_get` independently of metric availability, so a quiet connected UE can still be marked radio-active.

`ue_registration` and `ue_session` represent MME state. `ue_radio_binding` correlates the MME UE with gNB activity using site, RAN UE key, optional RAN-node key, and timestamps. Registration and radio activity remain separate: a UE may be registered with an assigned IP while radio-idle. The initial PoC assumes at most one unambiguous binding for a RAN UE key within a site; explicit `correlation.ranNodeKey` removes that assumption when more radios are introduced.

## Application modules

### `AppModule`

Composition root. It loads YAML configuration, Pino, the scheduler runtime, persistence, authentication, and the API boundary. The global authentication guard and problem-details exception filter are registered here.

### `ApiModule`

Presentation boundary for REST and WebSocket modules. Controllers may call application services but must not use Prisma directly.

### `MonitoringModule`

Provides validated inventory, current/history telemetry, alarm, collector-status, safe-configuration, and statistics endpoints. It depends only on the `MonitoringQueryRepository` application port; PostgreSQL-specific filtering and aggregation stay in the persistence adapter.

### `AuthModule`

The foundation supports `disabled` mode for local development and a constant-time API-key placeholder for protected environments. Configuration validation rejects disabled authentication in production. This boundary is intended to be replaced or extended with local users/OIDC and RBAC in a later milestone.

### `HealthModule`

Provides public liveness and readiness endpoints. Readiness checks PostgreSQL and scheduler initialization. Detailed target freshness is added with the collector milestone.

### `LiveModule`

Socket.IO namespace `/live`. Clients authenticate in protected mode and explicitly subscribe to allow-listed collection, metric, alarm, and health topics. `LiveGateway.publish` is the post-commit live-event adapter; PostgreSQL remains authoritative.

### `PluginsModule`

Owns the connector registry. It initializes connectors, rejects duplicate IDs, exposes installed manifests, and shuts connectors down cleanly. Amarisoft is registered through a separate integration module so the registry remains vendor-neutral.

### `AmarisoftIntegrationModule`

Constructs and registers the Amarisoft connector, records its manifest version, adapts Pino logging, registers the scheduler handler, resolves target secrets, and commits collection envelopes. The framework-neutral connector package contains the actual WebSocket protocol and parsers.

The registry-driven parsing framework is described in `docs/METRICS_PARSING.md`. It normalizes site, radio, cell, and UE metrics plus domain events while keeping database logic vendor-neutral.

### `RadioTargetsModule`

Creates validated connector targets, lists safe target summaries, exposes connection health, and changes polling intervals without restart. Connector capabilities enforce supported operations and minimum intervals.

### `SchedulerModule`

Runs a bounded, in-process schedule loop suitable for ten radios. PostgreSQL stores schedules. A per-radio active set prevents parallel operations against one target. Poll handlers register with `PollTaskHandlerRegistry`; no collector handler is present yet.

### `SitesModule`

Demonstrates the complete layering pattern: validated controller DTO → application service → repository port → Prisma adapter. New resources should follow the same direction.

## Packages

### `packages/domain`

Framework-light domain types. It must not import NestJS, Prisma, WebSocket, or vendor packages.

### `packages/application`

Use-case ports and injection tokens. The current repository ports cover sites and poll scheduling.

### `packages/connector-sdk`

Stable anti-corruption boundary for all vendors. A connector owns transport, published vendor operations, payload validation, canonical parsing, and error mapping. It cannot access Prisma or publish UI events.

### `packages/persistence-postgres`

Prisma service and repository adapters. It is the only package that should import generated Prisma model types.

## Error handling

`GlobalExceptionFilter` returns `application/problem+json`, exposes validation details for safe 4xx failures, adds the request ID, and suppresses internal exception details. Pino records internal failures with structured correlation fields and configured redaction.

## Configuration

`CONFIG_FILE` selects YAML. `${NAME}` requires an environment variable; `${NAME:-default}` supplies a fallback. Zod rejects invalid values before the application opens a listener. Secrets must be environment-injected or resolved through a future secret provider; they must not be committed in YAML.

## Adding a vendor connector later

1. Create a package outside the core packages.
2. Implement `VendorConnector` and `VendorConnectorSession` from `connector-sdk`.
3. Supply a manifest, JSON configuration schema, capabilities, and fixture tests.
4. Register the connector with `ConnectorRegistryService` at application bootstrap.
5. The existing generic collector path resolves the configured connector, executes a logical operation, and persists its canonical envelope.

Core scheduling and storage must never branch on vendor name.
