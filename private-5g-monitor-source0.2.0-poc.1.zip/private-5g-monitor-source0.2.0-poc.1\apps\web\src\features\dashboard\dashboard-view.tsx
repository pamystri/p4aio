'use client';

import { useMemo } from 'react';
import { Box, Card, CardContent, Grid, Stack, Typography } from '@mui/material';
import DevicesRounded from '@mui/icons-material/DevicesRounded';
import DownloadRounded from '@mui/icons-material/DownloadRounded';
import UploadRounded from '@mui/icons-material/UploadRounded';
import NotificationsRounded from '@mui/icons-material/NotificationsRounded';
import RouterRounded from '@mui/icons-material/RouterRounded';
import { PageHeader } from '@/components/common/page-header';
import { StatCard } from '@/components/common/stat-card';
import { StatusBadge } from '@/components/common/status-badge';
import { EChart, timeSeriesOption } from '@/components/charts/echart';
import { StatePanel } from '@/components/common/state-panel';
import { useApi } from '@/core/api/use-api';
import { queryString } from '@/core/api/client';
import { useCurrentTime } from '@/core/time/use-current-time';
import type { AggregatedMetric, Alarm, CollectorStatus, Page, Statistics } from '@/core/api/types';

const bitrate = (value = 0) => value >= 1_000_000 ? `${(value / 1_000_000).toFixed(1)} Mb/s` : `${(value / 1000).toFixed(0)} kb/s`;

export function DashboardView() {
  const stats = useApi<Statistics>('/statistics'); const collectors = useApi<CollectorStatus[]>('/collectors/status'); const alarms = useApi<Page<Alarm>>('/alarms/current?limit=5');
  const currentTime = useCurrentTime(); const to = new Date(Math.floor(currentTime / 60_000) * 60_000); const from = new Date(to.getTime() - 6 * 60 * 60_000);
  const historyPath = (metric: string) => `/metrics/historical${queryString({ metric, from: from.toISOString(), to: to.toISOString(), aggregation: 'avg', bucket: 'minute', limit: 360, sort: 'asc' })}`;
  const dl = useApi<Page<AggregatedMetric>>(historyPath('radio.ue.dl_bitrate')); const ul = useApi<Page<AggregatedMetric>>(historyPath('radio.ue.ul_bitrate'));
  const trafficOption = useMemo(() => timeSeriesOption([
    { name: 'Downlink', color: '#20bad8', data: (dl.data?.items ?? []).map((point) => [point.bucket, point.value]) },
    { name: 'Uplink', color: '#8b78f6', data: (ul.data?.items ?? []).map((point) => [point.bucket, point.value]) },
  ], 'bit/s'), [dl.data, ul.data]);
  const healthy = collectors.data?.filter((item) => item.enabled && item.lastRunStatus === 'SUCCEEDED').length ?? 0;
  return <><PageHeader eyebrow="Network overview" title="Operations dashboard" description="Current private 5G service health, radio traffic, connected users, and active conditions." />
    <Grid container spacing={2}>{[
      ['Connected UEs', stats.data?.activeUes ?? 0, 'Seen within 5 minutes', DevicesRounded, 'primary'],
      ['Downlink traffic', bitrate(stats.data?.totalDlBitrate), 'Current aggregate', DownloadRounded, 'primary'],
      ['Uplink traffic', bitrate(stats.data?.totalUlBitrate), 'Current aggregate', UploadRounded, 'secondary'],
      ['Current alerts', stats.data?.alarmsLast24Hours ?? 0, 'Warning or higher', NotificationsRounded, (stats.data?.alarmsLast24Hours ?? 0) ? 'warning' : 'success'],
    ].map(([label, value, helper, icon, tone]) => <Grid key={String(label)} size={{ xs: 12, sm: 6, xl: 3 }}><StatCard label={String(label)} value={value as string | number} helper={String(helper)} icon={icon as typeof DevicesRounded} tone={tone as 'primary' | 'secondary' | 'warning' | 'success'} loading={stats.loading} /></Grid>)}</Grid>
    <Grid container spacing={2} sx={{ mt: .2 }}><Grid size={{ xs: 12, xl: 8 }}><Card><CardContent><Stack direction="row" sx={{ justifyContent: "space-between", mb: 1 }}><Box><Typography variant="h2">Network traffic</Typography><Typography variant="caption" color="text.secondary">Six-hour rolling view · one-minute averages</Typography></Box><StatusBadge status={dl.error || ul.error ? 'degraded' : 'live'} /></Stack><StatePanel loading={dl.loading || ul.loading} error={dl.error ?? ul.error} empty={!dl.data?.items.length && !ul.data?.items.length}><EChart option={trafficOption} height={335} ariaLabel="Downlink and uplink network traffic" /></StatePanel></CardContent></Card></Grid>
      <Grid size={{ xs: 12, xl: 4 }}><Card sx={{ height: '100%' }}><CardContent><Stack direction="row" sx={{ justifyContent: "space-between" }}><Box><Typography variant="h2">Collector health</Typography><Typography variant="caption" color="text.secondary">{healthy} of {collectors.data?.length ?? 0} radios healthy</Typography></Box><RouterRounded color={healthy === collectors.data?.length ? 'success' : 'warning'} /></Stack><StatePanel loading={collectors.loading} error={collectors.error} empty={!collectors.data?.length}><Stack spacing={1.2} sx={{ mt: 2 }}>{collectors.data?.slice(0, 6).map((item) => <Box key={item.targetId} sx={{ p: 1.25, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}><Stack direction="row" sx={{ justifyContent: "space-between", alignItems: "center" }}><Box><Typography sx={{ fontSize: 13, fontWeight: 700 }}>{item.targetName}</Typography><Typography variant="caption" color="text.secondary">{item.lastSuccessAt ? `Last poll ${new Date(item.lastSuccessAt).toLocaleTimeString()}` : 'No successful poll'}</Typography></Box><StatusBadge status={item.lastRunStatus} /></Stack></Box>)}</Stack></StatePanel></CardContent></Card></Grid>
      <Grid size={{ xs: 12 }}><Card><CardContent><Stack direction="row" sx={{ justifyContent: "space-between", mb: 1.5 }}><Box><Typography variant="h2">Recent alerts</Typography><Typography variant="caption" color="text.secondary">Latest network and collector conditions</Typography></Box><StatusBadge status={alarms.data?.items.length ? 'warning' : 'healthy'} /></Stack><StatePanel loading={alarms.loading} error={alarms.error} empty={!alarms.data?.items.length}><Grid container spacing={1.2}>{alarms.data?.items.map((alarm) => <Grid key={alarm.id} size={{ xs: 12, md: 6, xl: 4 }}><Box sx={{ p: 1.4, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}><Stack direction="row" sx={{ justifyContent: "space-between" }}><Typography sx={{ fontWeight: 700, fontSize: 13 }}>{alarm.message}</Typography><StatusBadge status={alarm.severity} /></Stack><Typography variant="caption" color="text.secondary">{alarm.category} · {new Date(alarm.occurredAt).toLocaleString()}</Typography></Box></Grid>)}</Grid></StatePanel></CardContent></Card></Grid>
    </Grid></>;
}
