import { Injectable } from '@nestjs/common';
import type {
  LocationEstimationCandidate,
  LocationEstimationRepository,
  PersistedLocationEstimate,
} from '@application/location/location-estimation.repository';
import { PrismaService } from '@persistence/prisma/prisma.service';
import type { Prisma } from '@prisma/client';

const locationMetricKeys = ['initial_ta', 'ul_path_loss', 'pusch_snr', 'epre'] as const;

/** Reads recent normalized radio evidence and atomically persists algorithm output. */
@Injectable()
export class PrismaLocationEstimationRepository implements LocationEstimationRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findCandidates(
    targetId: string,
    observedAt: Date,
    evidenceMaxAgeMs: number,
  ): Promise<LocationEstimationCandidate[]> {
    const rows = await this.prisma.radioObservation.findMany({
      where: {
        radioTargetId: targetId,
        ueId: { not: null },
        cellId: { not: null },
        observedAt: {
          gte: new Date(observedAt.getTime() - evidenceMaxAgeMs),
          lte: new Date(observedAt.getTime() + 1000),
        },
        metricDefinition: { is: { namespace: 'radio.ue', key: { in: [...locationMetricKeys] } } },
      },
      include: {
        metricDefinition: { select: { namespace: true, key: true } },
        ue: { select: { pseudonym: true } },
        cell: {
          select: {
            latitude: true,
            longitude: true,
            radioTarget: { select: { site: { select: { latitude: true, longitude: true } } } },
          },
        },
      },
      orderBy: [{ observedAt: 'desc' }, { id: 'desc' }],
      take: 10_000,
    });

    const groups = new Map<string, LocationEstimationCandidate>();
    const selectedGroupByUe = new Map<string, string>();
    const seenMetric = new Set<string>();
    for (const row of rows) {
      if (!row.ueId || !row.cellId || !row.ue || !row.cell) continue;
      const groupKey = `${row.ueId}:${row.cellId}`;
      const selected = selectedGroupByUe.get(row.ueId);
      if (selected && selected !== groupKey) continue;
      selectedGroupByUe.set(row.ueId, groupKey);
      const metric = `${row.metricDefinition.namespace}.${row.metricDefinition.key}`;
      const metricKey = `${groupKey}:${metric}`;
      if (seenMetric.has(metricKey)) continue;
      seenMetric.add(metricKey);
      if (row.valueDouble === null && row.valueInteger === null) continue;
      const value = row.valueDouble ?? Number(row.valueInteger);
      if (!Number.isFinite(value)) continue;
      let candidate = groups.get(groupKey);
      if (!candidate) {
        candidate = {
          ueId: row.ueId,
          uePseudonym: row.ue.pseudonym,
          servingCellId: row.cellId,
          cellLatitude: row.cell.latitude,
          cellLongitude: row.cell.longitude,
          siteLatitude: row.cell.radioTarget.site.latitude,
          siteLongitude: row.cell.radioTarget.site.longitude,
          observedAt: row.observedAt,
          evidence: [],
        };
        groups.set(groupKey, candidate);
      }
      candidate.evidence.push({ observationId: row.id, metric, value, observedAt: row.observedAt });
    }
    return [...groups.values()];
  }

  async save(estimate: PersistedLocationEstimate): Promise<boolean> {
    return this.prisma.$transaction(async (transaction) => {
      const existing = await transaction.locationEstimate.findFirst({
        where: {
          ueId: estimate.ueId,
          servingCellId: estimate.servingCellId,
          algorithmVersion: estimate.algorithmVersion,
          evidenceWindowEnd: estimate.evidenceWindowEnd,
        },
        select: { id: true },
      });
      if (existing) return false;
      const created = await transaction.locationEstimate.create({
        data: {
          estimatedAt: estimate.estimatedAt,
          ueId: estimate.ueId,
          servingCellId: estimate.servingCellId,
          latitude: estimate.latitude,
          longitude: estimate.longitude,
          horizontalAccuracyM: estimate.horizontalAccuracyM,
          confidence: estimate.confidence,
          method: estimate.method,
          evidenceWindowStart: estimate.evidenceWindowStart,
          evidenceWindowEnd: estimate.evidenceWindowEnd,
          algorithmVersion: estimate.algorithmVersion,
          configurationVersion: 1,
          qualityFlags: estimate.qualityFlags,
          details: estimate.details as unknown as Prisma.InputJsonValue,
        },
        select: { id: true },
      });
      if (estimate.evidence.length > 0) {
        await transaction.locationEvidence.createMany({
          data: estimate.evidence.map((item) => ({
            locationEstimateId: created.id,
            radioObservationId: item.observationId,
            evidenceRole: item.role,
            weight: item.weight,
          })),
          skipDuplicates: true,
        });
      }
      return true;
    });
  }
}
