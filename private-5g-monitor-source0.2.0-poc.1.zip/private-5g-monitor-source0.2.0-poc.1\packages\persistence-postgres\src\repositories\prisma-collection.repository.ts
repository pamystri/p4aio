import { createHash, createHmac } from 'node:crypto';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  CollectionRunStatus,
  ConnectorStatus,
  MetricValueType,
  ParseStatus,
  type Prisma,
} from '@prisma/client';
import type {
  CollectionFailure,
  CollectionRepository,
  CollectionTarget,
} from '@application/collection/collection.repository';
import type { DuePollTask } from '@application/scheduler/poll-schedule.repository';
import type {
  CanonicalMetricObservation,
  CanonicalUeInventoryObservation,
  ConnectorCollectionEnvelope,
  ConnectorManifest,
  JsonPrimitive,
  JsonValue,
} from '@connector-sdk/index';
import { PrismaService } from '@persistence/prisma/prisma.service';

/** Persists one raw response and all derived observations in one transaction. */
@Injectable()
export class PrismaCollectionRepository implements CollectionRepository {
  private readonly pseudonymKey: string;

  constructor(
    private readonly prisma: PrismaService,
    config: ConfigService,
  ) {
    this.pseudonymKey = config.getOrThrow<string>('privacy.pseudonymKey');
  }

  async ensureConnectorInstallation(manifest: ConnectorManifest): Promise<void> {
    await this.prisma.connectorInstallation.upsert({
      where: { connectorKey_version: { connectorKey: manifest.id, version: manifest.version } },
      create: {
        connectorKey: manifest.id,
        version: manifest.version,
        sdkVersion: manifest.sdkVersion,
        manifest: manifest as unknown as Prisma.InputJsonValue,
        packageChecksum: manifest.checksum ?? `builtin:${manifest.version}`,
        status: ConnectorStatus.ENABLED,
      },
      update: {
        sdkVersion: manifest.sdkVersion,
        manifest: manifest as unknown as Prisma.InputJsonValue,
        packageChecksum: manifest.checksum ?? `builtin:${manifest.version}`,
        status: ConnectorStatus.ENABLED,
      },
    });
  }

  async getTarget(id: string): Promise<CollectionTarget | null> {
    const target = await this.prisma.radioTarget.findUnique({
      where: { id },
      include: { connectorInstallation: true },
    });
    if (!target) return null;
    return {
      id: target.id,
      host: target.managementHost,
      port: target.managementPort,
      connectorKey: target.connectorInstallation.connectorKey,
      connectorVersion: target.connectorInstallation.version,
      configuration: target.config as unknown as Readonly<Record<string, JsonValue>>,
      secretReference: target.secretRef ?? undefined,
      configVersion: target.configVersion,
    };
  }

  async startRun(task: DuePollTask, target: CollectionTarget): Promise<string> {
    const run = await this.prisma.collectionRun.create({
      data: {
        pollScheduleId: task.scheduleId,
        radioTargetId: target.id,
        logicalOperation: task.logicalOperation,
        nominalDueAt: task.nominalDueAt,
        startedAt: new Date(),
        status: CollectionRunStatus.RUNNING,
        attempt: 1,
        connectorKey: target.connectorKey,
        connectorVersion: target.connectorVersion,
        configVersion: target.configVersion,
      },
      select: { id: true },
    });
    return run.id;
  }

  async completeRun(
    runId: string,
    target: CollectionTarget,
    envelope: ConnectorCollectionEnvelope,
  ): Promise<void> {
    await this.prisma.$transaction(async (transaction) => {
      const raw = await transaction.rawObservation.create({
        data: {
          collectionRunId: runId,
          radioTargetId: target.id,
          logicalOperation: envelope.logicalOperation,
          sequenceNo: 0,
          observedAt: envelope.observedAt,
          receivedAt: envelope.receivedAt,
          payload: envelope.rawPayload as unknown as Prisma.InputJsonValue,
          payloadText: envelope.rawPayloadText,
          payloadSha256: Buffer.from(envelope.rawPayloadSha256, 'hex'),
          payloadBytes: envelope.rawPayloadBytes,
          parserVersion: envelope.parserVersion,
          parseStatus: envelope.warnings.length > 0 ? ParseStatus.PARTIAL : ParseStatus.PARSED,
          parseDiagnostics: { warnings: envelope.warnings } as unknown as Prisma.InputJsonValue,
        },
        select: { id: true },
      });

      const ueCache = new Map<string, string>();
      const cellCache = new Map<string, string>();
      const definitionCache = new Map<string, string>();
      const targetScope = await transaction.radioTarget.findUniqueOrThrow({
        where: { id: target.id },
        select: { siteId: true },
      });
      await this.persistUeInventory(
        transaction,
        target.id,
        targetScope.siteId,
        envelope.ueInventory,
        envelope.ueInventoryMode,
        envelope.observedAt,
      );
      for (const presence of envelope.ueRadioPresence) {
        const cellId = presence.servingCellKey
          ? await this.cellId(transaction, target.id, presence.servingCellKey, cellCache)
          : undefined;
        await this.correlatedUeId(
          transaction,
          target.id,
          targetScope.siteId,
          presence.ranUeKey,
          presence.ranNodeKey,
          cellId,
          presence.observedAt,
          ueCache,
        );
      }
      for (const observation of envelope.observations) {
        const metricDefinitionId = await this.metricDefinitionId(
          transaction,
          observation,
          definitionCache,
        );
        const servingCell = observation.dimensions['serving_cell_id'];
        const cellId =
          servingCell !== undefined
            ? await this.cellId(transaction, target.id, String(servingCell), cellCache)
            : observation.entityType === 'cell'
              ? await this.cellId(
                  transaction,
                  target.id,
                  observation.externalEntityId,
                  cellCache,
                )
              : undefined;
        const ueId =
          observation.entityType === 'ue'
            ? await this.correlatedUeId(
                transaction,
                target.id,
                targetScope.siteId,
                observation.externalEntityId,
                observation.dimensions['ran_node_key'],
                cellId,
                observation.observedAt,
                ueCache,
              )
            : undefined;
        const values = this.valueColumns(observation.value);
        const canonicalDimensions = this.canonicalJson(observation.dimensions);
        await transaction.radioObservation.create({
          data: {
            observedAt: observation.observedAt,
            metricDefinitionId,
            radioTargetId: target.id,
            cellId,
            ueId,
            rawObservationId: raw.id,
            collectionRunId: runId,
            ...values,
            dimensions: observation.dimensions as unknown as Prisma.InputJsonValue,
            dimensionHash: createHash('sha256').update(canonicalDimensions).digest(),
            qualityFlags: observation.qualityFlags,
            parserVersion: envelope.parserVersion,
          },
        });
      }

      for (const event of envelope.events) {
        const ueId = event.entityType === 'ue'
          ? await this.correlatedUeId(
              transaction,
              target.id,
              targetScope.siteId,
              event.externalEntityId,
              undefined,
              undefined,
              event.occurredAt,
              ueCache,
            )
          : undefined;
        const cellId = event.entityType === 'cell'
          ? await this.cellId(transaction, target.id, event.externalEntityId, cellCache)
          : undefined;
        await transaction.domainEvent.create({
          data: {
            occurredAt: event.occurredAt,
            eventType: event.eventType,
            category: event.category,
            severity: event.severity,
            entityType: event.entityType,
            message: event.message.slice(0, 1024),
            details: event.details as unknown as Prisma.InputJsonValue,
            radioTargetId: target.id,
            cellId,
            ueId,
            rawObservationId: raw.id,
            collectionRunId: runId,
            parserVersion: envelope.parserVersion,
          },
        });
      }

      await transaction.collectionRun.update({
        where: { id: runId },
        data: {
          status:
            envelope.warnings.length > 0
              ? CollectionRunStatus.PARTIAL
              : CollectionRunStatus.SUCCEEDED,
          finishedAt: new Date(),
          parserVersion: envelope.parserVersion,
          attempt: envelope.pollMetadata.attemptCount,
          timings: {
            requestedAt: envelope.pollMetadata.requestedAt.toISOString(),
            responseReceivedAt: envelope.pollMetadata.responseReceivedAt.toISOString(),
            durationMs: envelope.pollMetadata.durationMs,
            metricCount: envelope.pollMetadata.metricCount,
            eventCount: envelope.pollMetadata.eventCount,
            ueInventoryCount: envelope.ueInventory.length,
            ueRadioPresenceCount: envelope.ueRadioPresence.length,
          },
        },
      });
      await transaction.radioTarget.update({
        where: { id: target.id },
        data: { lastSuccessAt: envelope.receivedAt },
      });
    });
  }

  async failRun(runId: string, failure: CollectionFailure): Promise<void> {
    await this.prisma.$transaction(async (transaction) => {
      const finishedAt = new Date();
      const run = await transaction.collectionRun.update({
        where: { id: runId },
        data: {
          status: CollectionRunStatus.FAILED,
          finishedAt,
          errorCategory: failure.category,
          errorCode: failure.code,
          errorMessageRedacted: failure.message.slice(0, 512),
        },
        select: { radioTargetId: true, parserVersion: true },
      });
      await transaction.domainEvent.create({
        data: {
          occurredAt: finishedAt,
          eventType: 'collector.poll_failed',
          category: failure.category,
          severity: failure.category === 'shutdown' ? 'warning' : 'error',
          entityType: 'radio',
          message: failure.message.slice(0, 1024),
          details: { code: failure.code },
          radioTargetId: run.radioTargetId,
          collectionRunId: runId,
          parserVersion: run.parserVersion ?? 'not-parsed',
        },
      });
    });
  }

  private async metricDefinitionId(
    transaction: Prisma.TransactionClient,
    observation: CanonicalMetricObservation,
    cache: Map<string, string>,
  ): Promise<string> {
    const cacheKey = `${observation.metricKey}:${observation.definition.definitionVersion}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;
    const parts = observation.metricKey.split('.');
    const key = parts.pop() ?? observation.metricKey;
    const namespace = parts.join('.') || 'unclassified';
    const valueType = this.metricValueType(observation.value);
    const definition = await transaction.metricDefinition.upsert({
      where: {
        namespace_key_definitionVersion: {
          namespace,
          key,
          definitionVersion: observation.definition.definitionVersion,
        },
      },
      create: {
        namespace,
        key,
        displayName: observation.definition.name,
        description: observation.definition.description,
        entityType: observation.definition.entityType,
        semanticType: observation.definition.semanticType,
        valueType,
        unit: observation.unit,
        aggregation: observation.definition.aggregationType,
        sourceJsonPath: observation.definition.sourceJsonPath,
        category: observation.definition.category,
        displayType: observation.definition.displayType,
        allowedDimensions: Object.keys(observation.dimensions) as Prisma.InputJsonValue,
        canonical: !observation.metricKey.startsWith('vendor.'),
        definitionVersion: observation.definition.definitionVersion,
      },
      update: {},
      select: { id: true },
    });
    cache.set(cacheKey, definition.id);
    return definition.id;
  }

  private async correlatedUeId(
    transaction: Prisma.TransactionClient,
    targetId: string,
    siteId: string,
    ranUeKey: string,
    rawRanNodeKey: JsonPrimitive | undefined,
    servingCellId: string | undefined,
    observedAt: Date,
    cache: Map<string, string>,
  ): Promise<string | undefined> {
    const ranNodeKey = typeof rawRanNodeKey === 'string' ? rawRanNodeKey : undefined;
    const cacheKey = `${ranNodeKey ?? '*'}:${ranUeKey}`;
    const cached = cache.get(cacheKey);
    if (cached) return cached;
    let bindings = await transaction.ueRadioBinding.findMany({
      where: {
        siteId,
        ranUeKey,
        endedAt: null,
        ...(ranNodeKey ? { ranNodeKey } : {}),
      },
      orderBy: { lastMmeSeenAt: 'desc' },
      take: 2,
      select: { id: true, ueId: true },
    });
    if (bindings.length === 0 && ranNodeKey) {
      bindings = await transaction.ueRadioBinding.findMany({
        where: { siteId, ranUeKey, endedAt: null },
        orderBy: { lastMmeSeenAt: 'desc' },
        take: 2,
        select: { id: true, ueId: true },
      });
    }
    if (bindings.length !== 1) return undefined;
    const binding = bindings[0];
    if (!binding) return undefined;
    await transaction.ueRadioBinding.update({
      where: { id: binding.id },
      data: {
        gnbTargetId: targetId,
        servingCellId,
        lastGnbSeenAt: observedAt,
      },
    });
    await transaction.ue.update({ where: { id: binding.ueId }, data: { lastSeenAt: observedAt } });
    cache.set(cacheKey, binding.ueId);
    return binding.ueId;
  }

  private async persistUeInventory(
    transaction: Prisma.TransactionClient,
    mmeTargetId: string,
    siteId: string,
    inventory: readonly CanonicalUeInventoryObservation[],
    mode: 'none' | 'snapshot' | 'delta',
    observedAt: Date,
  ): Promise<void> {
    if (mode === 'none') return;
    if (mode === 'snapshot') {
      await transaction.ueRegistration.updateMany({
        where: { mmeTargetId, registered: true },
        data: { registered: false, endedAt: observedAt },
      });
      await transaction.ueSession.updateMany({
        where: { mmeTargetId, endedAt: null },
        data: { endedAt: observedAt },
      });
      await transaction.ueRadioBinding.updateMany({
        where: { mmeTargetId, endedAt: null },
        data: { endedAt: observedAt },
      });
    }
    for (const item of inventory) {
      const fingerprint = createHmac('sha256', this.pseudonymKey)
        .update(`amarisoft:${item.identityType}:${item.externalIdentity}`)
        .digest();
      const pseudonym = `ue-${fingerprint.toString('hex').slice(0, 16)}`;
      const ue = await transaction.ue.upsert({
        where: {
          identityType_identityFingerprint: {
            identityType: item.identityType,
            identityFingerprint: fingerprint,
          },
        },
        create: {
          pseudonym,
          identityType: item.identityType,
          identityFingerprint: fingerprint,
          lastSeenAt: item.observedAt,
        },
        update: { lastSeenAt: item.observedAt },
        select: { id: true },
      });
      await transaction.ueRegistration.upsert({
        where: { ueId_mmeTargetId: { ueId: ue.id, mmeTargetId } },
        create: {
          ueId: ue.id,
          mmeTargetId,
          registered: item.registered,
          firstSeenAt: item.observedAt,
          lastSeenAt: item.observedAt,
        },
        update: {
          registered: item.registered,
          lastSeenAt: item.observedAt,
          endedAt: item.registered ? null : item.observedAt,
        },
      });
      if (item.ranUeKey) {
        const correlationKey = `${item.ranNodeKey ?? '*'}:${item.ranUeKey}`;
        await transaction.ueRadioBinding.upsert({
          where: { siteId_correlationKey: { siteId, correlationKey } },
          create: {
            ueId: ue.id,
            siteId,
            mmeTargetId,
            ranNodeKey: item.ranNodeKey,
            ranUeKey: item.ranUeKey,
            correlationKey,
            firstSeenAt: item.observedAt,
            lastMmeSeenAt: item.observedAt,
          },
          update: {
            ueId: ue.id,
            mmeTargetId,
            ranNodeKey: item.ranNodeKey,
            ranUeKey: item.ranUeKey,
            lastMmeSeenAt: item.observedAt,
            endedAt: null,
          },
        });
      }
      for (const session of item.sessions) {
        for (const ipAddress of session.ipAddresses) {
          await transaction.ueSession.upsert({
            where: {
              mmeTargetId_ueId_sessionKey_ipAddress: {
                mmeTargetId,
                ueId: ue.id,
                sessionKey: session.sessionKey,
                ipAddress,
              },
            },
            create: {
              ueId: ue.id,
              mmeTargetId,
              sessionKey: session.sessionKey,
              ipAddress,
              dnn: session.dnn,
              firstSeenAt: item.observedAt,
              lastSeenAt: item.observedAt,
            },
            update: { dnn: session.dnn, lastSeenAt: item.observedAt, endedAt: null },
          });
        }
      }
    }
  }

  private async cellId(
    transaction: Prisma.TransactionClient,
    targetId: string,
    externalId: string,
    cache: Map<string, string>,
  ): Promise<string> {
    const cached = cache.get(externalId);
    if (cached) return cached;
    const cell = await transaction.cell.upsert({
      where: { radioTargetId_vendorCellKey: { radioTargetId: targetId, vendorCellKey: externalId } },
      create: {
        radioTargetId: targetId,
        vendorCellKey: externalId,
        displayName: `Cell ${externalId}`,
        technology: 'NR',
      },
      update: { lastSeenAt: new Date() },
      select: { id: true },
    });
    cache.set(externalId, cell.id);
    return cell.id;
  }

  private metricValueType(value: CanonicalMetricObservation['value']): MetricValueType {
    if (typeof value === 'number') return MetricValueType.DOUBLE;
    if (typeof value === 'boolean') return MetricValueType.BOOLEAN;
    if (typeof value === 'string') return MetricValueType.TEXT;
    if (value === null) throw new Error('Null metric values are not supported');
    return MetricValueType.JSON;
  }

  private valueColumns(value: CanonicalMetricObservation['value']): {
    valueDouble?: number;
    valueBoolean?: boolean;
    valueText?: string;
    valueJson?: Prisma.InputJsonValue;
  } {
    if (typeof value === 'number') return { valueDouble: value };
    if (typeof value === 'boolean') return { valueBoolean: value };
    if (typeof value === 'string') return { valueText: value };
    if (value === null) throw new Error('Null metric values are not supported');
    return { valueJson: value as unknown as Prisma.InputJsonValue };
  }

  private canonicalJson(value: Readonly<Record<string, JsonPrimitive>>): string {
    return JSON.stringify(
      Object.fromEntries(Object.entries(value).sort(([left], [right]) => left.localeCompare(right))),
    );
  }
}
