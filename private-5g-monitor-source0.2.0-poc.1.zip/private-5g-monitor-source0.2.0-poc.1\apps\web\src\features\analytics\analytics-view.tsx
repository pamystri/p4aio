'use client';

import { useMemo, useState } from 'react';
import { Card, CardContent, Grid, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { PageHeader } from '@/components/common/page-header';
import { EChart, timeSeriesOption } from '@/components/charts/echart';
import { DataTable, type Column } from '@/components/tables/data-table';
import { useApi } from '@/core/api/use-api';
import { queryString } from '@/core/api/client';
import { useCurrentTime } from '@/core/time/use-current-time';
import type { AggregatedMetric, Page } from '@/core/api/types';

const metrics = ['radio.target.ue_count', 'radio.ue.dl_bitrate', 'radio.ue.ul_bitrate', 'radio.ue.cqi', 'radio.ue.dl_mcs', 'radio.ue.ul_mcs', 'radio.ue.pusch_snr', 'radio.ue.ul_path_loss', 'radio.ue.initial_ta', 'radio.ue.dl_retx', 'radio.ue.ul_retx'];
export function AnalyticsView() {
  const [metric, setMetric] = useState(metrics[0]); const [hours, setHours] = useState(24); const [aggregation, setAggregation] = useState<'avg' | 'max' | 'sum'>('avg');
  const currentTime = useCurrentTime(); const to = new Date(Math.floor(currentTime / 60_000) * 60_000); const from = new Date(to.getTime() - hours * 3600_000); const bucket = hours <= 24 ? 'minute' : hours <= 168 ? 'hour' : 'day';
  const response = useApi<Page<AggregatedMetric>>(`/metrics/historical${queryString({ metric, from: from.toISOString(), to: to.toISOString(), aggregation, bucket, limit: 1000, sort: 'asc' })}`); const rows = useMemo(() => response.data?.items ?? [], [response.data]);
  const option = useMemo(() => timeSeriesOption([{ name: metric.split('.').at(-1) ?? metric, color: '#20bad8', data: rows.map((row) => [row.bucket, row.value]) }], rows[0]?.unit ?? ''), [rows, metric]);
  const columns: Array<Column<AggregatedMetric>> = [{ key: 'bucket', label: 'Time', render: (row) => new Date(row.bucket).toLocaleString(), export: (row) => row.bucket }, { key: 'metric', label: 'Metric', render: (row) => row.metric, export: (row) => row.metric }, { key: 'value', label: 'Aggregated value', render: (row) => <Typography sx={{ fontFamily: "monospace", fontWeight: 700 }}>{row.value.toFixed(2)} {row.unit}</Typography>, export: (row) => row.value }, { key: 'samples', label: 'Samples', render: (row) => row.sampleCount, export: (row) => row.sampleCount }];
  return <><PageHeader eyebrow="Time-series analysis" title="Historical analytics" description="Explore radio and location-evidence trends with database-side time bucketing." />
    <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.2} sx={{ mb: 2 }}><TextField select size="small" label="Metric" value={metric} onChange={(event) => setMetric(event.target.value)} sx={{ minWidth: 270 }}>{metrics.map((value) => <MenuItem key={value} value={value}>{value.replace('radio.ue.', '').replaceAll('_', ' ')}</MenuItem>)}</TextField><TextField select size="small" label="Time range" value={hours} onChange={(event) => setHours(Number(event.target.value))} sx={{ minWidth: 150 }}><MenuItem value={6}>Last 6 hours</MenuItem><MenuItem value={24}>Last 24 hours</MenuItem><MenuItem value={168}>Last 7 days</MenuItem><MenuItem value={720}>Last 30 days</MenuItem></TextField><TextField select size="small" label="Aggregation" value={aggregation} onChange={(event) => setAggregation(event.target.value as typeof aggregation)} sx={{ minWidth: 140 }}><MenuItem value="avg">Average</MenuItem><MenuItem value="max">Maximum</MenuItem><MenuItem value="sum">Sum</MenuItem></TextField></Stack>
    <Grid container spacing={2}><Grid size={{ xs: 12 }}><Card><CardContent><Typography variant="h2">Historical trend</Typography><Typography variant="caption" color="text.secondary">{aggregation} · {bucket} buckets · {rows.length} points</Typography><EChart option={option} height={380} ariaLabel={`${metric} historical trend`} /></CardContent></Card></Grid><Grid size={{ xs: 12 }}><DataTable title="Aggregated observations" rows={rows} columns={columns} loading={response.loading} error={response.error} searchableText={(row) => row.metric} filename="historical-metrics" /></Grid></Grid></>;
}
