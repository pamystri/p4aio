import { Box, Chip } from '@mui/material';

export function StatusBadge({ status }: { status: string | null | undefined }) {
  const normalized = (status ?? 'unknown').toLowerCase();
  const color = ['healthy', 'succeeded', 'connected', 'active', 'registered', 'ok', 'enabled', 'live', 'configured', 'nr', 'gnb', 'mme'].includes(normalized) ? 'success' : ['warning', 'partial', 'degraded', 'estimated', 'high confidence', 'configuration needed', 'idle'].includes(normalized) ? 'warning' : ['failed', 'critical', 'error', 'offline', 'unavailable', 'inactive', 'deregistered'].includes(normalized) ? 'error' : 'default';
  return <Chip size="small" variant="outlined" color={color} label={<Box component="span" sx={{ textTransform: 'capitalize' }}>{normalized.replaceAll('_', ' ')}</Box>} sx={{ height: 25, fontSize: 11 }} />;
}
