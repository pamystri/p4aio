# Amarisoft Remote API connector

## Scope

The connector supports two component roles through the published Amarisoft JSON Remote API over WebSocket:

- `mme` on the configured MME/AMF endpoint (normally port 9000) is authoritative for registered UE inventory, bearer/PDU sessions, and UE IP addresses;
- `gnb` on the configured eNB/gNB endpoint (normally port 9001) is authoritative for radio activity, serving cell, radio metrics, and location evidence.

The logical operations are:

- `ue_get`, sent with configurable `stats`;
- `stats`, sent with configurable `samples` and `rf`.

Amarisoft's vendor-supplied `ws.js` may be present on the gNB host. The monitoring platform does not install, modify, SSH to, or remotely execute that script. It is an independent WebSocket client of the same published API endpoint. No monitoring software runs on the gNB.

## Protocol behavior

One persistent connection is maintained per enabled target and reused across polls. The transport:

1. opens the configured target endpoint (`9000` for MME/AMF or `9001` for eNB/gNB in the standard Amarisoft layout);
2. waits for the server's `ready` startup message;
3. supports the documented challenge-response authentication when a password reference is configured;
4. adds a unique `message_id` to each request;
5. correlates the response by that ID;
6. retains the complete UTF-8 response frame before parsing;
7. uses WebSocket ping/pong for transport health;
8. reconnects with bounded exponential backoff after a close, heartbeat failure, or retryable error.

Authentication calculates the documented HMAC-SHA256 response over `<type>:<password>:<name>` using the server challenge as key. Password values come from the secret resolver and are never logged or stored in target JSON.

References:

- Amarisoft Tech Academy, Remote API examples: <https://tech-academy.amarisoft.com/RemoteAPI.html>
- Amarisoft Remote API startup/message contract: <https://tech-academy.amarisoft.com/lteue.doc>

The licensed `lteenb` documentation shipped with the deployed Amarisoft release remains authoritative. Validate the connector against that exact release before production.

## Command-module extension

Every operation is represented by one `AmarisoftCommandModule`. The module owns:

- the logical operation name;
- request JSON creation;
- its response parser.

`AmarisoftCommandRegistry` resolves modules. Adding a command does not change the connection manager, scheduler, persistence adapter, or controller. Add the module to the connector registry and declare its capability in the manifest.

## Raw response guarantee

For every correlated valid JSON API response, one `raw_observation` row is committed with:

- `payload_text`: exact received UTF-8 frame, retaining whitespace and property order;
- `payload`: JSONB query representation;
- SHA-256 and byte length of the exact text;
- receive/observation times, command, run, target, parser version, and diagnostics.

The raw response and parsed observations commit in one PostgreSQL transaction. A parser error produces a partial run with raw text retained and zero or partial derived observations. WebSocket control frames are health traffic, not Remote API responses, and are not stored.

## Target configuration

Create both targets under the same site. MME/AMF example:

```json
{
  "siteId": "SITE_UUID",
  "connectorKey": "amarisoft",
  "name": "Factory MME",
  "managementHost": "10.20.30.40",
  "managementPort": 9000,
  "enabled": true,
  "secretReference": "env:AMARISOFT_MME_PASSWORD",
  "configuration": {
    "componentType": "mme",
    "transport": "ws",
    "path": "/",
    "origin": "http://monitor.example.internal",
    "tlsRejectUnauthorized": true
  }
}
```

gNB example:

```json
{
  "siteId": "SITE_UUID",
  "connectorKey": "amarisoft",
  "name": "Factory gNB 1",
  "managementHost": "10.20.30.40",
  "managementPort": 9001,
  "enabled": true,
  "secretReference": "env:AMARISOFT_GNB_1_PASSWORD",
  "configuration": {
    "componentType": "gnb",
    "transport": "ws",
    "path": "/",
    "origin": "http://monitor.example.internal",
    "tlsRejectUnauthorized": true,
    "ueGet": { "stats": true },
    "stats": { "samples": true, "rf": true },
    "correlation": {}
  }
}
```

The MME commands deliberately omit the gNB-only `stats`, `samples`, and `rf` request properties. Correlation uses `ran_ue_id` within the site. If multiple RAN nodes can reuse the same identifier, configure the gNB `correlation.ranNodeKey` to match the MME value represented as `ran_id:<value>`.

Only host names, IP addresses, and ports are accepted; arbitrary URL input is not. Use `wss` and certificate verification where the deployed API supports it. Otherwise isolate unencrypted management traffic on a trusted management network or VPN.

## Dynamic polling

Poll schedules are PostgreSQL-backed and read on every scheduler tick. No restart is needed after an interval update.

```http
PUT /api/v1/radio-targets/{targetId}/polling/ue_get
Content-Type: application/json
x-api-key: ...

{
  "intervalSeconds": 2,
  "timeoutMs": 5000,
  "priority": 200,
  "enabled": true
}
```

Configure `stats` independently. The manifest prevents intervals below the connector's safe minimum. The scheduler coalesces missed occurrences and limits global concurrency while the manager can retain one connection for each of the ten radios.

Poll MME `ue_get` at equal or higher priority than gNB `ue_get`. An MME snapshot creates pseudonymized UE records and temporal bindings first; subsequent gNB samples update `lastGnbSeenAt`, serving cell, radio metrics, and location evidence. A UE can therefore remain registered and keep its IP session while its radio state changes from active to idle.

## Connection health

`GET /api/v1/radio-targets/{targetId}/health` opens or reuses the target session and returns `healthy`, `degraded`, or `unavailable`. Operational logs include target UUID, command, message ID, attempt, duration context, disconnect code, retry delay, and collection run ID. Payloads, passwords, permanent UE identities, and secret references are not logged.

## Failure behavior

- Connection, close, and timeout failures are retryable for the read-only operations in this release.
- Authentication, configuration, and unsupported-command errors are not retried.
- Retry count and backoff are bounded by YAML policy.
- One target's reconnect loop does not block the other target connections.
- A graceful application shutdown stops scheduling, rejects pending requests, closes all sockets, and disconnects Prisma.

## Tests

Unit/integration-style tests cover:

- `ue_get` metric and location-input parsing;
- rejection of IMSI as the normal parsed UE key;
- bounded `stats` parsing;
- `message_id` correlation;
- exact response-text preservation;
- reconnect and read-only retry after a dropped socket;
- connector registry behavior and YAML validation from the foundation milestone.
