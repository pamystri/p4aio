import { createHmac, randomUUID } from 'node:crypto';
import WebSocket, { type ClientOptions, type RawData } from 'ws';
import type { JsonValue } from '@connector-sdk/index';
import { AmarisoftConnectorError } from '../amarisoft.errors';
import type {
  AmarisoftConnectionHealthSnapshot,
  AmarisoftConnectionPolicy,
  AmarisoftLogger,
  AmarisoftResponseFrame,
} from '../amarisoft.types';
import { isJsonArray, isJsonRecord } from '../parsers/parser.helpers';

interface ConnectionOptions {
  targetId: string;
  componentType: 'gnb' | 'mme';
  url: string;
  origin?: string;
  tlsRejectUnauthorized: boolean;
  password?: string;
  policy: AmarisoftConnectionPolicy;
}

interface PendingRequest {
  resolve(frame: AmarisoftResponseFrame): void;
  reject(error: Error): void;
  timeout: NodeJS.Timeout;
  removeAbortListener(): void;
  startedAt: number;
  operation: string;
}

interface Deferred<T> {
  promise: Promise<T>;
  resolve(value: T): void;
  reject(error: Error): void;
}

function deferred<T>(): Deferred<T> {
  let resolve!: (value: T) => void;
  let reject!: (error: Error) => void;
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });
  return { promise, resolve, reject };
}

/** Maintains one authenticated, correlated WebSocket session to one gNB. */
export class AmarisoftWebSocketConnection {
  private socket?: WebSocket;
  private connectPromise?: Promise<void>;
  private readyDeferred?: Deferred<void>;
  private reconnectTimer?: NodeJS.Timeout;
  private heartbeatTimer?: NodeJS.Timeout;
  private pongTimeoutTimer?: NodeJS.Timeout;
  private awaitingPongSince?: number;
  private reconnectAttempt = 0;
  private reconnectEnabled = false;
  private closed = false;
  private readonly pending = new Map<string, PendingRequest>();
  private state: AmarisoftConnectionHealthSnapshot['state'] = 'disconnected';
  private connectedAt: Date | null = null;
  private lastMessageAt: Date | null = null;
  private lastPongAt: Date | null = null;
  private consecutiveFailures = 0;
  private lastError: string | null = null;

  constructor(
    private readonly options: ConnectionOptions,
    private readonly logger: AmarisoftLogger,
  ) {}

  async request(
    request: Readonly<Record<string, JsonValue>>,
    timeoutMs: number,
    signal: AbortSignal,
  ): Promise<AmarisoftResponseFrame> {
    this.reconnectEnabled = true;
    await this.ensureConnected(signal);
    if (signal.aborted) throw this.abortedError();

    const messageId = `monitor#${randomUUID()}`;
    const payload = JSON.stringify({ ...request, message_id: messageId });
    const socket = this.socket;
    if (!socket || socket.readyState !== WebSocket.OPEN || this.state !== 'ready') {
      throw new AmarisoftConnectorError('WebSocket is not ready', 'connectivity', true);
    }

    return new Promise<AmarisoftResponseFrame>((resolve, reject) => {
      const onAbort = (): void => {
        this.rejectPending(messageId, this.abortedError());
      };
      signal.addEventListener('abort', onAbort, { once: true });
      const timeout = setTimeout(() => {
        this.rejectPending(
          messageId,
          new AmarisoftConnectorError(
            `Amarisoft request timed out after ${timeoutMs} ms`,
            'timeout',
            true,
          ),
        );
      }, timeoutMs);
      this.pending.set(messageId, {
        resolve,
        reject,
        timeout,
        removeAbortListener: () => signal.removeEventListener('abort', onAbort),
        startedAt: Date.now(),
        operation: typeof request['message'] === 'string' ? request['message'] : 'unknown',
      });

      socket.send(payload, (error) => {
        if (error) {
          this.rejectPending(
            messageId,
            new AmarisoftConnectorError('Failed to send WebSocket request', 'connectivity', true, {
              cause: error,
            }),
          );
        }
      });
      this.logger.debug(
        { targetId: this.options.targetId, messageId, operation: request['message'] },
        'Amarisoft request sent',
      );
    });
  }

  async ensureConnected(signal: AbortSignal): Promise<void> {
    if (this.closed) throw new AmarisoftConnectorError('Connection is shut down', 'shutdown', false);
    if (this.state === 'ready' && this.socket?.readyState === WebSocket.OPEN) return;
    if (!this.connectPromise) {
      this.connectPromise = this.connectInternal().finally(() => {
        this.connectPromise = undefined;
      });
    }
    await this.withAbort(this.connectPromise, signal);
  }

  forceReconnect(reason: string): void {
    if (this.closed) return;
    this.logger.warn({ targetId: this.options.targetId, reason }, 'Forcing Amarisoft reconnect');
    this.socket?.terminate();
  }

  health(): AmarisoftConnectionHealthSnapshot {
    return {
      state: this.state,
      connectedAt: this.connectedAt,
      lastMessageAt: this.lastMessageAt,
      lastPongAt: this.lastPongAt,
      consecutiveFailures: this.consecutiveFailures,
      lastError: this.lastError,
    };
  }

  async close(): Promise<void> {
    if (this.closed) return;
    this.closed = true;
    this.reconnectEnabled = false;
    this.state = 'closed';
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.stopHeartbeat();
    this.rejectAll(new AmarisoftConnectorError('Connector is shutting down', 'shutdown', false));
    const socket = this.socket;
    this.socket = undefined;
    if (!socket || socket.readyState === WebSocket.CLOSED) return;

    await new Promise<void>((resolve) => {
      const timer = setTimeout(() => {
        socket.terminate();
        resolve();
      }, 1000);
      socket.once('close', () => {
        clearTimeout(timer);
        resolve();
      });
      socket.close(1000, 'monitor shutdown');
    });
  }

  private async connectInternal(): Promise<void> {
    this.state = this.reconnectAttempt > 0 ? 'reconnecting' : 'connecting';
    this.readyDeferred = deferred<void>();
    const clientOptions: ClientOptions = {
      handshakeTimeout: this.options.policy.connectTimeoutMs,
      rejectUnauthorized: this.options.tlsRejectUnauthorized,
      ...(this.options.origin ? { origin: this.options.origin } : {}),
    };
    const socket = new WebSocket(this.options.url, clientOptions);
    this.socket = socket;
    socket.on('message', (data, isBinary) => this.handleFrame(data, isBinary));
    socket.on('pong', () => this.handlePong());
    socket.on('close', (code, reason) => this.handleClose(code, reason.toString()));
    socket.on('error', (error) => {
      this.lastError = error.message;
      this.logger.warn(
        { targetId: this.options.targetId, error: error.message },
        'Amarisoft WebSocket error',
      );
    });

    try {
      await this.waitForOpen(socket);
      await this.withTimeout(
        this.readyDeferred.promise,
        this.options.policy.connectTimeoutMs,
        'Timed out waiting for Amarisoft ready handshake',
      );
      this.state = 'ready';
      this.connectedAt = new Date();
      this.consecutiveFailures = 0;
      this.reconnectAttempt = 0;
      this.lastError = null;
      this.startHeartbeat();
      this.logger.info({ targetId: this.options.targetId }, 'Amarisoft WebSocket ready');
    } catch (error) {
      this.consecutiveFailures += 1;
      this.lastError = error instanceof Error ? error.message : 'Unknown connection error';
      socket.terminate();
      const retryable = !(error instanceof AmarisoftConnectorError) || error.retryable;
      if (retryable) this.scheduleReconnect();
      else this.reconnectEnabled = false;
      throw error;
    }
  }

  private waitForOpen(socket: WebSocket): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => {
        cleanup();
        reject(new AmarisoftConnectorError('WebSocket connect timeout', 'timeout', true));
      }, this.options.policy.connectTimeoutMs);
      const onOpen = (): void => {
        cleanup();
        resolve();
      };
      const onError = (error: Error): void => {
        cleanup();
        reject(new AmarisoftConnectorError('WebSocket connection failed', 'connectivity', true, { cause: error }));
      };
      const onClose = (): void => {
        cleanup();
        reject(new AmarisoftConnectorError('WebSocket closed during connection', 'connectivity', true));
      };
      const cleanup = (): void => {
        clearTimeout(timeout);
        socket.off('open', onOpen);
        socket.off('error', onError);
        socket.off('close', onClose);
      };
      socket.once('open', onOpen);
      socket.once('error', onError);
      socket.once('close', onClose);
    });
  }

  private handleFrame(data: RawData, isBinary: boolean): void {
    if (isBinary) {
      this.logger.warn({ targetId: this.options.targetId }, 'Ignored unexpected binary Remote API frame');
      return;
    }
    const rawText = this.rawDataToText(data);
    const receivedAt = new Date();
    this.lastMessageAt = receivedAt;
    let payload: JsonValue;
    try {
      payload = JSON.parse(rawText) as JsonValue;
    } catch (error) {
      this.logger.error(
        { targetId: this.options.targetId, error: error instanceof Error ? error.message : 'parse error' },
        'Received malformed Amarisoft JSON',
      );
      return;
    }

    const messages: readonly JsonValue[] = isJsonArray(payload) ? payload : [payload];
    for (const message of messages) {
      if (!isJsonRecord(message)) continue;
      if (message['message'] === 'ready') {
        if (!this.validateComponent(message)) continue;
        this.readyDeferred?.resolve(undefined);
        continue;
      }
      if (message['message'] === 'authenticate') {
        if (!this.validateComponent(message)) continue;
        if (message['ready'] === true) {
          this.readyDeferred?.resolve(undefined);
          continue;
        }
        if (typeof message['error'] === 'string') {
          this.readyDeferred?.reject(
            new AmarisoftConnectorError(
              `Amarisoft authentication failed: ${message['error']}`,
              'authentication',
              false,
            ),
          );
          continue;
        }
        if (typeof message['challenge'] === 'string') {
          this.respondToChallenge(message);
          continue;
        }
      }
      const messageId = message['message_id'];
      if (typeof messageId !== 'string') continue;
      const pending = this.pending.get(messageId);
      if (!pending) continue;
      this.pending.delete(messageId);
      clearTimeout(pending.timeout);
      pending.removeAbortListener();
      pending.resolve({ rawText, payload: message, receivedAt });
      this.logger.debug(
        {
          targetId: this.options.targetId,
          messageId,
          operation: pending.operation,
          durationMs: Date.now() - pending.startedAt,
          responseBytes: Buffer.byteLength(rawText, 'utf8'),
        },
        'Amarisoft response received',
      );
    }
  }

  private validateComponent(message: { readonly [key: string]: JsonValue }): boolean {
    const type = message['type'];
    if (typeof type !== 'string') return true;
    const normalized = type.toUpperCase();
    const valid = this.options.componentType === 'mme'
      ? normalized === 'MME'
      : normalized === 'ENB' || normalized === 'GNB';
    if (valid) return true;
    this.readyDeferred?.reject(
      new AmarisoftConnectorError(
        `Configured ${this.options.componentType} target connected to Amarisoft component type ${type}`,
        'configuration',
        false,
      ),
    );
    return false;
  }

  private respondToChallenge(message: { readonly [key: string]: JsonValue }): void {
    const password = this.options.password;
    const challenge = message['challenge'];
    const type = message['type'];
    const name = message['name'];
    if (!password || typeof challenge !== 'string' || typeof type !== 'string' || typeof name !== 'string') {
      this.readyDeferred?.reject(
        new AmarisoftConnectorError('Amarisoft authentication requires a configured password', 'authentication', false),
      );
      return;
    }
    const response = createHmac('sha256', challenge)
      .update(`${type}:${password}:${name}`)
      .digest('hex');
    this.socket?.send(
      JSON.stringify({ message: 'authenticate', message_id: `auth#${randomUUID()}`, res: response }),
    );
  }

  private handlePong(): void {
    this.awaitingPongSince = undefined;
    if (this.pongTimeoutTimer) clearTimeout(this.pongTimeoutTimer);
    this.pongTimeoutTimer = undefined;
    this.lastPongAt = new Date();
  }

  private handleClose(code: number, reason: string): void {
    if (this.closed) return;
    this.stopHeartbeat();
    this.state = 'disconnected';
    this.socket = undefined;
    const error = new AmarisoftConnectorError(
      `WebSocket closed (${code}${reason ? `: ${reason}` : ''})`,
      'connectivity',
      true,
    );
    this.readyDeferred?.reject(error);
    this.rejectAll(error);
    this.consecutiveFailures += 1;
    this.lastError = error.message;
    this.logger.warn(
      { targetId: this.options.targetId, code, reason },
      'Amarisoft WebSocket disconnected',
    );
    this.scheduleReconnect();
  }

  private startHeartbeat(): void {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      const socket = this.socket;
      if (!socket || socket.readyState !== WebSocket.OPEN) return;
      if (this.awaitingPongSince !== undefined) return;
      this.awaitingPongSince = Date.now();
      socket.ping();
      this.pongTimeoutTimer = setTimeout(() => {
        this.logger.warn({ targetId: this.options.targetId }, 'Amarisoft heartbeat timed out');
        socket.terminate();
      }, this.options.policy.heartbeatTimeoutMs);
      this.pongTimeoutTimer.unref();
    }, this.options.policy.heartbeatIntervalMs);
    this.heartbeatTimer.unref();
  }

  private stopHeartbeat(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    if (this.pongTimeoutTimer) clearTimeout(this.pongTimeoutTimer);
    this.heartbeatTimer = undefined;
    this.pongTimeoutTimer = undefined;
    this.awaitingPongSince = undefined;
  }

  private scheduleReconnect(): void {
    if (!this.reconnectEnabled || this.closed || this.reconnectTimer) return;
    const ceiling = Math.min(
      this.options.policy.reconnectMaxMs,
      this.options.policy.reconnectMinMs * 2 ** this.reconnectAttempt,
    );
    const delay = Math.max(this.options.policy.reconnectMinMs, Math.round(Math.random() * ceiling));
    this.reconnectAttempt += 1;
    this.state = 'reconnecting';
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = undefined;
      void this.ensureConnected(new AbortController().signal).catch(() => this.scheduleReconnect());
    }, delay);
    this.reconnectTimer.unref();
  }

  private rejectPending(messageId: string, error: Error): void {
    const pending = this.pending.get(messageId);
    if (!pending) return;
    this.pending.delete(messageId);
    clearTimeout(pending.timeout);
    pending.removeAbortListener();
    pending.reject(error);
  }

  private rejectAll(error: Error): void {
    for (const messageId of [...this.pending.keys()]) this.rejectPending(messageId, error);
  }

  private withTimeout<T>(promise: Promise<T>, timeoutMs: number, message: string): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const timeout = setTimeout(
        () => reject(new AmarisoftConnectorError(message, 'timeout', true)),
        timeoutMs,
      );
      void promise.then(
        (value) => {
          clearTimeout(timeout);
          resolve(value);
        },
        (error: unknown) => {
          clearTimeout(timeout);
          reject(error instanceof Error ? error : new Error(String(error)));
        },
      );
    });
  }

  private withAbort<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
    if (signal.aborted) return Promise.reject(this.abortedError());
    return new Promise<T>((resolve, reject) => {
      const onAbort = (): void => reject(this.abortedError());
      signal.addEventListener('abort', onAbort, { once: true });
      void promise.then(
        (value) => {
          signal.removeEventListener('abort', onAbort);
          resolve(value);
        },
        (error: unknown) => {
          signal.removeEventListener('abort', onAbort);
          reject(error instanceof Error ? error : new Error(String(error)));
        },
      );
    });
  }

  private abortedError(): AmarisoftConnectorError {
    return new AmarisoftConnectorError('Operation aborted', 'shutdown', false);
  }

  private rawDataToText(data: RawData): string {
    if (Buffer.isBuffer(data)) return data.toString('utf8');
    if (data instanceof ArrayBuffer) return Buffer.from(data).toString('utf8');
    return Buffer.concat(data).toString('utf8');
  }
}
