'use client';

import { useState } from 'react';
import { MenuItem, Stack, TextField, Typography } from '@mui/material';
import { PageHeader } from '@/components/common/page-header';
import { DataTable, type Column } from '@/components/tables/data-table';
import { StatusBadge } from '@/components/common/status-badge';
import { useApi } from '@/core/api/use-api';
import { queryString } from '@/core/api/client';
import { useCurrentTime } from '@/core/time/use-current-time';
import type { Alarm, Page } from '@/core/api/types';

export function AlertsView() {
  const [view, setView] = useState<'current' | 'historical'>('current'); const [severity, setSeverity] = useState(''); const currentTime = useCurrentTime(); const now = new Date(Math.floor(currentTime / 60_000) * 60_000); const from = new Date(now.getTime() - 30 * 86_400_000);
  const response = useApi<Page<Alarm>>(`/alarms/${view}${queryString({ severity: severity || undefined, from: view === 'historical' ? from.toISOString() : undefined, to: view === 'historical' ? now.toISOString() : undefined, limit: 1000 })}`); const rows = response.data?.items ?? [];
  const columns: Array<Column<Alarm>> = [{ key: 'severity', label: 'Severity', render: (row) => <StatusBadge status={row.severity} />, export: (row) => row.severity }, { key: 'time', label: 'Occurred', render: (row) => new Date(row.occurredAt).toLocaleString(), export: (row) => row.occurredAt }, { key: 'message', label: 'Condition', render: (row) => <Stack><Typography sx={{ fontWeight: 700, fontSize: 13 }}>{row.message}</Typography><Typography variant="caption" color="text.secondary">{row.type}</Typography></Stack>, export: (row) => row.message }, { key: 'category', label: 'Category', render: (row) => row.category, export: (row) => row.category }, { key: 'entity', label: 'Entity', render: (row) => `${row.entityType} · ${(row.ueId ?? row.cellId ?? row.targetId).slice(0, 10)}`, export: (row) => row.ueId ?? row.cellId ?? row.targetId }];
  return <><PageHeader eyebrow="Event management" title="Alerts" description="Current network conditions and searchable historical collector or radio alarms." /><Stack direction="row" spacing={1.2} sx={{ mb: 2 }}><TextField select size="small" label="View" value={view} onChange={(event) => setView(event.target.value as typeof view)} sx={{ minWidth: 150 }}><MenuItem value="current">Current</MenuItem><MenuItem value="historical">Last 30 days</MenuItem></TextField><TextField select size="small" label="Severity" value={severity} onChange={(event) => setSeverity(event.target.value)} sx={{ minWidth: 145 }}><MenuItem value="">All</MenuItem><MenuItem value="warning">Warning</MenuItem><MenuItem value="error">Error</MenuItem><MenuItem value="critical">Critical</MenuItem></TextField></Stack><DataTable title={`${rows.length} ${view} alerts`} rows={rows} columns={columns} loading={response.loading} error={response.error} searchableText={(row) => `${row.message} ${row.type} ${row.category}`} filename={`${view}-alerts`} /></>;
}
