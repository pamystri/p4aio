import type { PlatformPlugin, PluginManifest } from './plugin';

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue =
  | JsonPrimitive
  | readonly JsonValue[]
  | { readonly [key: string]: JsonValue };

export interface ConnectorCapability {
  logicalOperation: string;
  minimumIntervalMs: number;
  supportsStreaming: boolean;
  locationInputs: readonly string[];
}

export interface ConnectorManifest extends PluginManifest {
  kind: 'vendor-connector';
  vendor: string;
  configurationSchema: Readonly<Record<string, JsonValue>>;
  capabilities: readonly ConnectorCapability[];
}

export interface ConnectorTarget {
  targetId: string;
  host: string;
  port: number;
  configuration: Readonly<Record<string, JsonValue>>;
  secretReference?: string;
  credentials?: Readonly<Record<string, string>>;
}

export interface ConnectorExecutionRequest {
  collectionRunId: string;
  logicalOperation: string;
  deadline: Date;
  signal: AbortSignal;
}

export type MetricEntityType = 'site' | 'radio' | 'cell' | 'ue';
export type MetricSemanticType = 'gauge' | 'counter' | 'state';
export type MetricAggregation = 'avg' | 'sum' | 'min' | 'max' | 'last' | 'delta' | 'none';
export type MetricDisplayType = 'number' | 'bitrate' | 'decibel' | 'percentage' | 'counter' | 'identifier';

/** Immutable registry metadata carried with an observation into persistence. */
export interface MetricDefinitionDescriptor {
  name: string;
  description: string;
  unit: string;
  sourceJsonPath: string;
  category: string;
  aggregationType: MetricAggregation;
  displayType: MetricDisplayType;
  entityType: MetricEntityType;
  semanticType: MetricSemanticType;
  definitionVersion: number;
}

export interface CanonicalMetricObservation {
  metricKey: string;
  definition: MetricDefinitionDescriptor;
  unit: string;
  semanticType: MetricSemanticType;
  observedAt: Date;
  entityType: MetricEntityType;
  externalEntityId: string;
  value: JsonPrimitive | Readonly<Record<string, JsonValue>>;
  dimensions: Readonly<Record<string, JsonPrimitive>>;
  qualityFlags: number;
}

export interface CanonicalEvent {
  eventType: string;
  category: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  occurredAt: Date;
  entityType: MetricEntityType;
  externalEntityId: string;
  message: string;
  details: Readonly<Record<string, JsonValue>>;
}

export interface CanonicalUeSession {
  sessionKey: string;
  ipAddresses: readonly string[];
  dnn?: string;
}

/** Privacy-sensitive inventory data carried only from a connector into persistence. */
export interface CanonicalUeInventoryObservation {
  identityType: 'imsi' | 'supi' | 'temporary';
  externalIdentity: string;
  ranUeKey?: string;
  ranNodeKey?: string;
  registered: boolean;
  observedAt: Date;
  sessions: readonly CanonicalUeSession[];
}

export interface CanonicalUeRadioPresence {
  ranUeKey: string;
  ranNodeKey?: string;
  servingCellKey?: string;
  observedAt: Date;
}

export interface PollMetadata {
  requestedAt: Date;
  responseReceivedAt: Date;
  durationMs: number;
  attemptCount: number;
  metricCount: number;
  eventCount: number;
}

export interface ConnectorCollectionEnvelope {
  collectionRunId: string;
  logicalOperation: string;
  observedAt: Date;
  receivedAt: Date;
  rawPayload: JsonValue;
  rawPayloadText: string;
  rawPayloadBytes: number;
  rawPayloadSha256: string;
  parserVersion: string;
  observations: readonly CanonicalMetricObservation[];
  events: readonly CanonicalEvent[];
  ueInventory: readonly CanonicalUeInventoryObservation[];
  ueInventoryMode: 'none' | 'snapshot' | 'delta';
  ueRadioPresence: readonly CanonicalUeRadioPresence[];
  pollMetadata: PollMetadata;
  warnings: readonly string[];
}

export interface ConnectorHealth {
  status: 'healthy' | 'degraded' | 'unavailable';
  checkedAt: Date;
  detail?: string;
}

export interface VendorConnectorSession {
  health(signal: AbortSignal): Promise<ConnectorHealth>;
  execute(request: ConnectorExecutionRequest): Promise<ConnectorCollectionEnvelope>;
  close(): Promise<void>;
}

/**
 * Complete vendor boundary. A new vendor implements this interface and no core
 * service imports vendor-specific commands, payloads, or SDKs.
 */
export interface VendorConnector extends PlatformPlugin {
  readonly manifest: ConnectorManifest;
  validateConfiguration(configuration: Readonly<Record<string, JsonValue>>): Promise<void>;
  openSession(target: ConnectorTarget): Promise<VendorConnectorSession>;
}
