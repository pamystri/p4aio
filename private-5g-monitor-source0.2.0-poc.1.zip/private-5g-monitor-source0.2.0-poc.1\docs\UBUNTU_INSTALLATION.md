# Ubuntu Server 24.04 LTS installation

These instructions install the backend natively under systemd. Docker Compose is an alternative described in the repository README.

## 1. Host prerequisites

Use a dedicated, patched Ubuntu Server 24.04 LTS host. Configure correct NTP, a static management address, and firewall rules allowing:

- inbound TCP 443 from the operator network;
- outbound connections only to configured radio management addresses and published API ports;
- PostgreSQL only on loopback when it is local.

Install PostgreSQL, Nginx, build prerequisites, and Node.js 22 LTS from an organization-approved repository:

```bash
sudo apt update
sudo apt install -y postgresql postgresql-contrib nginx ca-certificates curl build-essential

# Example NodeSource installation. Use an internal mirror when required by policy.
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node --version
npm --version
```

## 2. Service identity and directories

```bash
sudo useradd --system --home /var/lib/private-5g-monitor --create-home \
  --shell /usr/sbin/nologin private5g
sudo install -d -o root -g private5g -m 0750 /etc/private-5g-monitor
sudo install -d -o private5g -g private5g -m 0750 /opt/private-5g-monitor/releases
```

Copy a reviewed release into `/opt/private-5g-monitor/releases/<version>` and point `/opt/private-5g-monitor/current` at it.

## 3. PostgreSQL

Generate a database password and create a least-privileged owner:

```bash
sudo -u postgres psql <<'SQL'
CREATE ROLE private5g LOGIN PASSWORD 'REPLACE_WITH_GENERATED_PASSWORD';
CREATE DATABASE private5g OWNER private5g;
REVOKE ALL ON DATABASE private5g FROM PUBLIC;
SQL
```

Keep PostgreSQL bound to loopback and use `scram-sha-256` authentication. Back up the database off-host.

## 4. Configuration and secret environment

```bash
sudo cp config/production.yaml /etc/private-5g-monitor/production.yaml
sudo sh -c 'umask 077; cat > /etc/private-5g-monitor/private-5g-monitor.env' <<'EOF'
DATABASE_URL=postgresql://private5g:REPLACE_WITH_URL_ENCODED_PASSWORD@127.0.0.1:5432/private5g?schema=public
API_AUTH_KEY=REPLACE_WITH_AT_LEAST_32_RANDOM_CHARACTERS
PSEUDONYM_KEY=REPLACE_WITH_A_DIFFERENT_32_CHARACTER_RANDOM_VALUE
# Optional when target secretReference is env:AMARISOFT_GNB_1_PASSWORD
AMARISOFT_GNB_1_PASSWORD=REPLACE_IF_REMOTE_API_AUTHENTICATION_IS_ENABLED
LOG_LEVEL=info
EOF
sudo chown root:private5g /etc/private-5g-monitor/private-5g-monitor.env
sudo chmod 0640 /etc/private-5g-monitor/private-5g-monitor.env
```

Generate the API key with `openssl rand -base64 48`. Do not put it in shell history or source control.

## 5. Install, verify, migrate, and build

Run from the release directory:

```bash
npm install
npm run prisma:generate
npm run lint
npm test
npm run build
npm run web:lint
npm run web:build

set -a
. /etc/private-5g-monitor/private-5g-monitor.env
set +a
npm run prisma:migrate:deploy
```

The dependency versions are pinned in `package.json`. After the first approved installation, commit the generated `package-lock.json` and use `npm ci` for subsequent reproducible releases.

## 6. systemd

```bash
sudo cp deploy/systemd/private-5g-monitor.service /etc/systemd/system/
sudo cp deploy/systemd/private-5g-monitor-web.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now private-5g-monitor private-5g-monitor-web
sudo systemctl status private-5g-monitor
sudo systemctl status private-5g-monitor-web
sudo journalctl -u private-5g-monitor -f
```

Smoke tests:

```bash
curl --fail http://127.0.0.1:3000/api/v1/health/live
curl --fail http://127.0.0.1:3000/api/v1/health/ready
curl --fail -H "x-api-key: $API_AUTH_KEY" http://127.0.0.1:3000/api/v1/connectors
```

## 7. HTTPS reverse proxy

Edit the server name and certificate paths in `deploy/nginx/private-5g-monitor.conf`, then:

```bash
sudo cp deploy/nginx/private-5g-monitor.conf /etc/nginx/sites-available/private-5g-monitor
sudo ln -s /etc/nginx/sites-available/private-5g-monitor /etc/nginx/sites-enabled/private-5g-monitor
sudo nginx -t
sudo systemctl reload nginx
```

Do not expose port 3000 externally. The production YAML binds it to loopback.
Do not expose port 3001 externally. Nginx serves the dashboard and proxies API/live traffic through the same private HTTPS origin. For an offline map, set `NEXT_PUBLIC_TILE_URL` to the internal tile server before `npm run web:build`.

## 8. Upgrade and rollback

During the explicitly designated PoC phase, release notes may authorize a clean database reset instead of history migration. This exception ends when the final design is accepted. Never run `prisma migrate reset` against a final/production database.

1. Back up PostgreSQL and verify the backup.
2. Install the new release in a new version directory.
3. Run install, generation, tests, build, and `prisma migrate deploy`.
4. Change the `current` symlink atomically and restart the service.
5. Check readiness and logs.

Database migrations are forward-only. Application rollback is allowed only when the previous release is compatible with the migrated schema. Document that compatibility in each release note.

## 9. Backup minimum

- nightly `pg_dump --format=custom` with encryption and an off-host copy;
- periodic restore tests on an isolated database;
- protected copies of YAML, systemd/Nginx files, and secret recovery material;
- alert when the newest successful backup exceeds 26 hours.
