import { MmeUeGetParser } from './mme-ue-get.parser';
import type { AmarisoftTargetConfiguration } from '../amarisoft.types';

const configuration: AmarisoftTargetConfiguration = {
  componentType: 'mme',
  transport: 'ws',
  path: '/',
  tlsRejectUnauthorized: true,
  ueGet: { stats: true },
  stats: { samples: true, rf: true },
  correlation: {},
};

describe('MmeUeGetParser', () => {
  it('extracts private UE inventory, RAN correlation, and bearer IP addresses', () => {
    const result = new MmeUeGetParser().parse(
      {
        utc: 1_700_000_000,
        ue_list: [{
          imsi: '001010123456789',
          ran_id: 2,
          ran_ue_id: 17,
          registered: true,
          bearers: [{ pdu_session_id: 1, dnn: 'internet', ipv4_addr: '10.45.0.7' }],
        }],
      },
      { targetId: 'target', observedAt: new Date('2026-08-03T00:00:00Z') },
      configuration,
    );

    expect(result.observations).toHaveLength(0);
    expect(result.ueInventory).toEqual([expect.objectContaining({
      identityType: 'imsi',
      externalIdentity: '001010123456789',
      ranNodeKey: 'ran_id:2',
      ranUeKey: 'ran_ue_id:17',
      registered: true,
      sessions: [{ sessionKey: 'pdu_session_id:1', ipAddresses: ['10.45.0.7'], dnn: 'internet' }],
    })]);
    expect(result.ueInventoryMode).toBe('snapshot');
  });

  it('does not treat unrelated strings as UE IP addresses', () => {
    const result = new MmeUeGetParser().parse(
      { ue_list: [{ imsi: '00101', ran_ue_id: 1, bearers: [{ gateway: '10.0.0.1' }] }] },
      { targetId: 'target', observedAt: new Date() },
      configuration,
    );
    expect(result.ueInventory[0]?.sessions).toEqual([]);
  });
});
