# Local Web Dashboard

The dashboard is a Next.js, React, Material UI, Apache ECharts, and Leaflet application under `apps/web`. It is designed for the dedicated private-network host and has no database driver or direct PostgreSQL path. All operational data comes from the documented REST API; Socket.IO messages are post-commit refresh signals.

![Representative dashboard design](web-dashboard-representative-snapshot.png)

The image above is a representative design preview matching the implemented visual system. It is not presented as a runtime browser capture because dependencies were intentionally deferred to the Ubuntu installation.

## Routes

- `/` — operational dashboard with KPIs, traffic trends, collector health, and recent alerts.
- `/live-monitoring` — current UE/cell metrics and current-value distribution.
- `/analytics` — selectable historical KPI trends with time range and aggregation.
- `/sites`, `/cells`, `/ues` — searchable and exportable inventory; UEs include MME registration, assigned IPs, and gNB active/idle state.
- `/map` — site and UE estimate map with UE IP, radio state, confidence, accuracy, serving cell, algorithm, and timestamp.
- `/alerts` — current and historical alarm workflow.
- `/settings` — browser-local API connection and refresh settings.
- `/administration` — readiness, connector, scheduler, and radio-target status.

Tables export their current filtered view to CSV, Excel, or PDF. Charts support tooltips and pointer/touch zoom. The layout collapses to a navigation drawer on small screens and preserves full table scrolling.

## Local data boundary

In production, Nginx provides a single local HTTPS origin:

```text
Operator browser -> Nginx :443
                    |-- /              -> Next.js :3001
                    |-- /api/v1/*      -> NestJS :3000
                    |-- /socket.io/*   -> NestJS Socket.IO :3000
```

Ports 3000 and 3001 bind to loopback. PostgreSQL remains on the internal backend network. The API key, when used, is browser-local and never included in an export.

OpenStreetMap is used only as a tile source. Set `NEXT_PUBLIC_TILE_URL` during the web build to point to an approved internal tile service for a fully disconnected installation. No analytics SDK, public CDN, remote font, or cloud application service is used.

## Location compatibility

The UI consumes a stable location envelope: coordinates, accuracy, optional confidence, serving cell, timestamp, method, algorithm version, and opaque details. A future location algorithm can therefore publish estimates without map-component changes.

The first estimator is intentionally conservative. For one omnidirectional cell, the marker bearing is a stable visualization convention rather than a measured direction. The accuracy value represents the directional ambiguity, and the method is exposed as `single_cell_omnidirectional_range`. Operators should calibrate the timing-advance scale and path-loss model in `config/production.yaml` for their radio numerology and indoor environment.

## Build and run

Dependencies are installed later on the Ubuntu host from the monorepo root:

```bash
npm install
npm run web:lint
npm run web:build
PORT=3001 npm run start --workspace @private-5g-monitor/web
```

For native deployment, enable both systemd services and install the supplied Nginx configuration. Docker Compose builds separate backend and web runtime images.
