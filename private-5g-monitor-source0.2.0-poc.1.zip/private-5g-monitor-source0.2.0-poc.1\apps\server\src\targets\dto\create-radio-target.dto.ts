import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsBoolean,
  IsInt,
  IsObject,
  IsOptional,
  IsString,
  IsUUID,
  Matches,
  Max,
  MaxLength,
  Min,
} from 'class-validator';

export class CreateRadioTargetDto {
  @ApiProperty()
  @IsUUID()
  siteId!: string;

  @ApiProperty({ default: 'amarisoft' })
  @IsString()
  connectorKey = 'amarisoft';

  @ApiProperty({ example: 'Factory gNB 1' })
  @IsString()
  @MaxLength(120)
  name!: string;

  @ApiProperty({ example: '10.20.30.40' })
  @IsString()
  @MaxLength(255)
  @Matches(/^[A-Za-z0-9](?:[A-Za-z0-9.:-]*[A-Za-z0-9])?$/)
  managementHost!: string;

  @ApiProperty({ default: 9001, description: 'Normally 9001 for gNB/eNB and 9000 for MME/AMF' })
  @IsInt()
  @Min(1)
  @Max(65535)
  managementPort = 9001;

  @ApiPropertyOptional({ default: false })
  @IsOptional()
  @IsBoolean()
  enabled = false;

  @ApiPropertyOptional({
    type: 'object',
    additionalProperties: true,
    example: { componentType: 'gnb', transport: 'ws', path: '/', ueGet: { stats: true }, stats: { samples: true, rf: true }, correlation: {} },
  })
  @IsOptional()
  @IsObject()
  configuration: Record<string, unknown> = {};

  @ApiPropertyOptional({ example: 'env:AMARISOFT_GNB_1_PASSWORD' })
  @IsOptional()
  @Matches(/^env:[A-Z][A-Z0-9_]*$/)
  secretReference?: string;
}
