# Private 5G Monitor backend foundation

For a complete local Ubuntu deployment walkthrough, start with `INSTALLATION_README.md`.

Vendor-neutral NestJS backend for a small private 5G monitoring and UE-location platform. The Amarisoft connector monitors both MME/AMF inventory on port 9000 and gNB radio telemetry on port 9001 through the published Remote API.

The monorepo also contains a locally hosted Next.js operations dashboard under `apps/web`; it communicates only with the REST and Socket.IO interfaces.

## Included

- NestJS/TypeScript application and explicit API composition module
- YAML configuration with environment interpolation and startup validation
- Pino structured logging, request correlation, redaction, and problem-details errors
- PostgreSQL/Prisma schema and initial migration
- repository port plus Prisma adapter and a working Sites API vertical slice
- generic plug-in and vendor connector contracts
- in-process bounded polling scheduler framework
- Socket.IO live-update gateway
- Swagger/OpenAPI at `/docs`
- liveness and readiness endpoints
- development/API-key authentication placeholder that fails closed in production
- Docker Compose, systemd, Nginx, and Ubuntu 24.04 documentation
- direct Amarisoft JSON-over-WebSocket connector with one managed connection per radio
- `ue_get` and allow-listed `stats` command/parser modules
- reconnect, WebSocket heartbeat, deadlines, read-only retry, health, and graceful shutdown
- exact raw response-text persistence plus parsed metrics in one transaction
- target and dynamic polling REST resources
- registry-driven site, radio, cell, and UE metric normalization, poll metadata, and events
- REST APIs for inventory, current/history telemetry, alarms, collectors, configuration, and statistics
- post-commit live metric/alarm notifications over Socket.IO
- post-`ue_get` single-cell omnidirectional UE range estimation with evidence provenance
- MME-derived UE registration/session inventory, UE IP addresses, and temporal gNB activity correlation
- responsive Material UI dashboard with ECharts analytics, Leaflet/OpenStreetMap location views, dark mode, filtering, and CSV/Excel/PDF export

## Architecture boundaries

```text
HTTP / WebSocket -> application services -> repository and connector ports
                                             |              |
                                      Prisma adapter    vendor connector
```

Core services do not import vendor payloads. The Amarisoft package depends only on the connector SDK and receives logging/connection policy through its application adapter. Connectors do not access PostgreSQL or the UI. See `docs/MODULES.md`, `docs/AMARISOFT_CONNECTOR.md`, `docs/METRICS_PARSING.md`, and `docs/BACKEND_API.md`.

## Local setup when dependencies are available

```bash
cp .env.example .env
# Set DATABASE_URL, API_AUTH_KEY, and PSEUDONYM_KEY.
npm install
npm run prisma:generate
npm run prisma:migrate:deploy
npm run start:dev
```

Open:

- API documentation: `http://localhost:3000/docs`
- liveness: `http://localhost:3000/api/v1/health/live`
- readiness: `http://localhost:3000/api/v1/health/ready`

In the default development YAML, authentication is disabled. Production configuration uses `x-api-key` and refuses to start with a key shorter than 32 characters.

## Verification

```bash
npm run prisma:generate
npm run lint
npm test
npm run build
```

These commands should be executed on the target Ubuntu environment before accepting the release. Dependency installation was intentionally not performed in the source-generation workspace.

## Container deployment

Create a root-readable `.env` with strong `POSTGRES_PASSWORD` and `API_AUTH_KEY`, then:

```bash
docker compose build
docker compose up -d
docker compose ps
```

The application is bound to host loopback on port 3000. Put the supplied Nginx configuration or another approved TLS proxy in front of it.

## Native Ubuntu deployment

Follow `docs/UBUNTU_INSTALLATION.md` for Ubuntu Server 24.04 LTS, PostgreSQL, systemd hardening, Nginx, smoke tests, upgrade, and backup procedures.

## Amarisoft setup sequence

1. Create a site with `POST /api/v1/sites`.
2. Put a password in an environment variable when the Remote API requires authentication.
3. Create an MME target on port 9000 with `configuration.componentType` set to `mme`.
4. Create a gNB target on port 9001 with `configuration.componentType` set to `gnb`.
5. Configure `ue_get` and `stats` independently for both targets using `PUT /api/v1/radio-targets/{id}/polling/{operation}`.
6. Check `GET /api/v1/radio-targets/{id}/health` and the collection-run/raw-observation tables.

The platform connects directly to the published API. It does not invoke Amarisoft's `ws.js` on the gNB.

## Deliberately deferred

- secret-provider implementation beyond environment injection
- local-user/OIDC authentication and full RBAC
- full metric catalog curation beyond connector-created definitions
- sector-bearing, multi-cell multilateration, fingerprinting, and LPP estimators
- alerts and historical query endpoints

Those belong to subsequent milestones; the contracts and persistence entities needed by them are established here.
