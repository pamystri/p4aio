'use client';

import { Stack, Typography } from '@mui/material';
import { PageHeader } from '@/components/common/page-header';
import { DataTable, type Column } from '@/components/tables/data-table';
import { StatusBadge } from '@/components/common/status-badge';
import { useApi } from '@/core/api/use-api';
import type { Cell, Page } from '@/core/api/types';

export function CellsView() {
  const response = useApi<Page<Cell>>('/cells?limit=1000&sort=asc'); const rows = response.data?.items ?? [];
  const columns: Array<Column<Cell>> = [{ key: 'name', label: 'Cell', render: (row) => <Stack><Typography sx={{ fontWeight: 700, fontSize: 13 }}>{row.displayName}</Typography><Typography variant="caption" color="text.secondary">Vendor key {row.vendorCellKey}</Typography></Stack>, export: (row) => row.displayName }, { key: 'tech', label: 'Technology', render: (row) => <StatusBadge status={row.technology} />, export: (row) => row.technology }, { key: 'pci', label: 'PCI', render: (row) => row.pci ?? '—', export: (row) => row.pci }, { key: 'arfcn', label: 'ARFCN', render: (row) => row.arfcn ?? '—', export: (row) => row.arfcn }, { key: 'target', label: 'Radio target', render: (row) => row.targetId.slice(0, 12), export: (row) => row.targetId }, { key: 'seen', label: 'Last seen', render: (row) => new Date(row.lastSeenAt).toLocaleString(), export: (row) => row.lastSeenAt }];
  return <><PageHeader eyebrow="Radio inventory" title="Cells" description="Discovered NR/LTE cells, identifiers, channel configuration, and freshness." /><DataTable title={`${rows.length} discovered cells`} rows={rows} columns={columns} loading={response.loading} error={response.error} searchableText={(row) => `${row.displayName} ${row.vendorCellKey} ${row.technology} ${row.pci}`} filename="cells" /></>;
}
