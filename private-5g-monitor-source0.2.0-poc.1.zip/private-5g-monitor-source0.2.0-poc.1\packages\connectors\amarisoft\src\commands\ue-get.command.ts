import type { JsonValue } from '@connector-sdk/index';
import type {
  AmarisoftCommandModule,
  AmarisoftParserContext,
  AmarisoftTargetConfiguration,
} from '../amarisoft.types';
import { UeGetParser } from '../parsers/ue-get.parser';
import { MmeUeGetParser } from '../parsers/mme-ue-get.parser';

/** Owns the `ue_get` request shape and its matching response parser. */
export class UeGetCommandModule implements AmarisoftCommandModule {
  readonly logicalOperation = 'ue_get';
  private readonly parser = new UeGetParser();
  private readonly mmeParser = new MmeUeGetParser();

  createRequest(configuration: AmarisoftTargetConfiguration): Readonly<Record<string, JsonValue>> {
    return configuration.componentType === 'mme'
      ? { message: 'ue_get' }
      : { message: 'ue_get', stats: configuration.ueGet.stats };
  }

  parse(payload: JsonValue, context: AmarisoftParserContext, configuration: AmarisoftTargetConfiguration) {
    return configuration.componentType === 'mme'
      ? this.mmeParser.parse(payload, context, configuration)
      : this.parser.parse(payload, context, configuration.correlation.ranNodeKey);
  }
}
