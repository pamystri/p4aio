export interface LocationMetricEvidence {
  observationId: bigint;
  metric: string;
  value: number;
  observedAt: Date;
}

export interface LocationEstimationCandidate {
  ueId: string;
  uePseudonym: string;
  servingCellId: string;
  cellLatitude: number | null;
  cellLongitude: number | null;
  siteLatitude: number | null;
  siteLongitude: number | null;
  observedAt: Date;
  evidence: LocationMetricEvidence[];
}

export interface PersistedLocationEstimate {
  ueId: string;
  servingCellId: string;
  estimatedAt: Date;
  latitude: number;
  longitude: number;
  horizontalAccuracyM: number;
  confidence: number;
  method: string;
  algorithmVersion: string;
  evidenceWindowStart: Date;
  evidenceWindowEnd: Date;
  qualityFlags: number;
  details: Readonly<Record<string, unknown>>;
  evidence: ReadonlyArray<{ observationId: bigint; role: string; weight: number }>;
}

export interface LocationEstimationRepository {
  findCandidates(
    targetId: string,
    observedAt: Date,
    evidenceMaxAgeMs: number,
  ): Promise<LocationEstimationCandidate[]>;
  save(estimate: PersistedLocationEstimate): Promise<boolean>;
}

export const LOCATION_ESTIMATION_REPOSITORY = Symbol('LOCATION_ESTIMATION_REPOSITORY');
