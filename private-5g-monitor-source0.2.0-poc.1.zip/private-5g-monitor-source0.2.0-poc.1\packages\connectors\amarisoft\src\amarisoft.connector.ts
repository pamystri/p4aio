import { createHash } from 'node:crypto';
import type {
  ConnectorCollectionEnvelope,
  ConnectorExecutionRequest,
  ConnectorHealth,
  ConnectorManifest,
  ConnectorTarget,
  VendorConnector,
  VendorConnectorSession,
} from '@connector-sdk/index';
import { amarisoftConfigurationJsonSchema, parseAmarisoftTargetConfiguration } from './amarisoft.configuration';
import { AmarisoftConnectorError } from './amarisoft.errors';
import type { AmarisoftConnectionPolicy, AmarisoftLogger } from './amarisoft.types';
import { AmarisoftCommandRegistry } from './commands/command.registry';
import { StatsCommandModule } from './commands/stats.command';
import { UeGetCommandModule } from './commands/ue-get.command';
import { isJsonRecord } from './parsers/parser.helpers';
import { AmarisoftConnectionManager } from './transport/amarisoft-connection.manager';
import type { AmarisoftWebSocketConnection } from './transport/amarisoft-websocket.connection';

const parserVersion = 'amarisoft-parser-3-poc';

/** Vendor plug-in entry point; all Amarisoft knowledge is contained below this boundary. */
export class AmarisoftConnector implements VendorConnector {
  readonly manifest: ConnectorManifest = {
    id: 'amarisoft',
    displayName: 'Amarisoft gNB/eNB Remote API',
    version: '0.2.0-poc.1',
    sdkVersion: '1',
    description: 'Agentless MME/AMF inventory and gNB radio monitoring connector',
    kind: 'vendor-connector',
    vendor: 'Amarisoft',
    configurationSchema: amarisoftConfigurationJsonSchema,
    capabilities: [
      {
        logicalOperation: 'ue_get',
        minimumIntervalMs: 1000,
        supportsStreaming: false,
        locationInputs: ['serving_cell', 'timing_advance', 'path_loss', 'signal_quality'],
      },
      {
        logicalOperation: 'stats',
        minimumIntervalMs: 1000,
        supportsStreaming: false,
        locationInputs: [],
      },
    ],
  };

  private readonly commands = new AmarisoftCommandRegistry([
    new UeGetCommandModule(),
    new StatsCommandModule(),
  ]);
  private readonly manager: AmarisoftConnectionManager;

  constructor(
    private readonly policy: AmarisoftConnectionPolicy,
    private readonly logger: AmarisoftLogger,
  ) {
    this.manager = new AmarisoftConnectionManager(logger);
  }

  async initialize(): Promise<void> {
    this.logger.info({ connectorVersion: this.manifest.version }, 'Amarisoft connector initialized');
  }

  async shutdown(): Promise<void> {
    await this.manager.closeAll();
    this.logger.info({}, 'Amarisoft connector shut down');
  }

  async validateConfiguration(configuration: ConnectorTarget['configuration']): Promise<void> {
    parseAmarisoftTargetConfiguration(configuration);
  }

  async openSession(target: ConnectorTarget): Promise<VendorConnectorSession> {
    const configuration = parseAmarisoftTargetConfiguration(target.configuration);
    const host = target.host.includes(':') && !target.host.startsWith('[') ? `[${target.host}]` : target.host;
    const url = new URL(`${configuration.transport}://${host}:${target.port}${configuration.path}`).toString();
    const connection = await this.manager.get({
      targetId: target.targetId,
      componentType: configuration.componentType,
      url,
      origin: configuration.origin,
      tlsRejectUnauthorized: configuration.tlsRejectUnauthorized,
      password: target.credentials?.['password'],
      policy: this.policy,
    });
    return new AmarisoftConnectorSession(
      target,
      configuration,
      connection,
      this.commands,
      this.policy,
      this.logger,
    );
  }
}

/** Lightweight lease over a connector-managed target connection with bounded read-only retry. */
class AmarisoftConnectorSession implements VendorConnectorSession {
  constructor(
    private readonly target: ConnectorTarget,
    private readonly configuration: ReturnType<typeof parseAmarisoftTargetConfiguration>,
    private readonly connection: AmarisoftWebSocketConnection,
    private readonly commands: AmarisoftCommandRegistry,
    private readonly policy: AmarisoftConnectionPolicy,
    private readonly logger: AmarisoftLogger,
  ) {}

  async health(signal: AbortSignal): Promise<ConnectorHealth> {
    try {
      await this.connection.ensureConnected(signal);
      const snapshot = this.connection.health();
      return {
        status: snapshot.state === 'ready' ? 'healthy' : 'degraded',
        checkedAt: new Date(),
        detail: snapshot.lastError ?? undefined,
      };
    } catch (error) {
      return {
        status: 'unavailable',
        checkedAt: new Date(),
        detail: error instanceof Error ? error.message : 'Unknown connection failure',
      };
    }
  }

  async execute(request: ConnectorExecutionRequest): Promise<ConnectorCollectionEnvelope> {
    const requestedAt = new Date();
    const command = this.commands.resolve(request.logicalOperation);
    const commandPayload = command.createRequest(this.configuration);
    let lastError: Error | undefined;

    for (let attempt = 0; attempt <= this.policy.maxRetries; attempt += 1) {
      if (request.signal.aborted) throw new AmarisoftConnectorError('Operation aborted', 'shutdown', false);
      const remainingMs = request.deadline.getTime() - Date.now();
      if (remainingMs <= 0) {
        throw new AmarisoftConnectorError('Collection deadline exceeded', 'timeout', true, {
          cause: lastError,
        });
      }
      try {
        const frame = await this.connection.request(
          commandPayload,
          Math.min(this.policy.requestTimeoutMs, remainingMs),
          request.signal,
        );
        let observations: ConnectorCollectionEnvelope['observations'] = [];
        let events: ConnectorCollectionEnvelope['events'] = [];
        let ueInventory: ConnectorCollectionEnvelope['ueInventory'] = [];
        let ueInventoryMode: ConnectorCollectionEnvelope['ueInventoryMode'] = 'none';
        let ueRadioPresence: ConnectorCollectionEnvelope['ueRadioPresence'] = [];
        const warnings: string[] = [];
        try {
          const parsed = command.parse(
            frame.payload,
            { targetId: this.target.targetId, observedAt: frame.receivedAt },
            this.configuration,
          );
          observations = parsed.observations;
          events = parsed.events;
          ueInventory = parsed.ueInventory ?? [];
          ueInventoryMode = parsed.ueInventoryMode ?? 'none';
          ueRadioPresence = parsed.ueRadioPresence ?? [];
          warnings.push(...parsed.warnings);
        } catch (error) {
          warnings.push(
            `Parser failure: ${error instanceof Error ? error.message : 'unknown parser error'}`,
          );
        }
        if (isJsonRecord(frame.payload) && typeof frame.payload['error'] === 'string') {
          warnings.push(`Vendor response error: ${frame.payload['error']}`);
        }
        return {
          collectionRunId: request.collectionRunId,
          logicalOperation: request.logicalOperation,
          observedAt: observations[0]?.observedAt ?? ueInventory[0]?.observedAt ?? frame.receivedAt,
          receivedAt: frame.receivedAt,
          rawPayload: frame.payload,
          rawPayloadText: frame.rawText,
          rawPayloadBytes: Buffer.byteLength(frame.rawText, 'utf8'),
          rawPayloadSha256: createHash('sha256').update(frame.rawText, 'utf8').digest('hex'),
          parserVersion,
          observations,
          events,
          ueInventory,
          ueInventoryMode,
          ueRadioPresence,
          pollMetadata: {
            requestedAt,
            responseReceivedAt: frame.receivedAt,
            durationMs: Math.max(0, frame.receivedAt.getTime() - requestedAt.getTime()),
            attemptCount: attempt + 1,
            metricCount: observations.length,
            eventCount: events.length,
          },
          warnings,
        };
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        const retryable = error instanceof AmarisoftConnectorError && error.retryable;
        if (!retryable || attempt >= this.policy.maxRetries) throw lastError;
        this.connection.forceReconnect(lastError.message);
        const delayMs = Math.min(
          this.policy.reconnectMaxMs,
          this.policy.reconnectMinMs * 2 ** attempt,
        );
        this.logger.warn(
          {
            targetId: this.target.targetId,
            operation: request.logicalOperation,
            attempt: attempt + 1,
            delayMs,
            error: lastError.message,
          },
          'Retrying Amarisoft request',
        );
        await this.delay(delayMs, request.signal);
      }
    }
    throw lastError ?? new AmarisoftConnectorError('Amarisoft request failed', 'connectivity', true);
  }

  async close(): Promise<void> {
    // Sessions are lightweight leases. The connector owns and reuses the target connection.
  }

  private delay(milliseconds: number, signal: AbortSignal): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      if (signal.aborted) {
        reject(new AmarisoftConnectorError('Operation aborted', 'shutdown', false));
        return;
      }
      const onAbort = (): void => {
        clearTimeout(timer);
        reject(new AmarisoftConnectorError('Operation aborted', 'shutdown', false));
      };
      const timer = setTimeout(() => {
        signal.removeEventListener('abort', onAbort);
        resolve();
      }, milliseconds);
      signal.addEventListener('abort', onAbort, { once: true });
    });
  }
}
