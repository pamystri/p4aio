import type { JsonValue } from '@connector-sdk/index';
import type { AmarisoftParserContext, AmarisoftTargetConfiguration } from '../amarisoft.types';
import { parseEvents } from './event.parser';
import { isJsonArray, isJsonRecord } from './parser.helpers';
import { parseMmeInventory } from './mme-inventory.parser';

/** Parses the MME/AMF form of `ue_get`; it is inventory, not radio telemetry. */
export class MmeUeGetParser {
  parse(payload: JsonValue, context: AmarisoftParserContext, configuration: AmarisoftTargetConfiguration) {
    if (!isJsonRecord(payload)) {
      return { observations: [], events: [], ueInventory: [], warnings: ['MME ue_get response is not an object'] };
    }
    const ueList = payload['ue_list'];
    if (!isJsonArray(ueList)) {
      return { observations: [], events: parseEvents(payload, context), ueInventory: [], warnings: ['MME ue_get response has no ue_list array'] };
    }
    const parsed = parseMmeInventory(ueList, context, configuration);
    return {
      observations: [],
      events: parseEvents(payload, context),
      ueInventory: parsed.inventory,
      ueInventoryMode: 'snapshot' as const,
      warnings: parsed.warnings,
    };
  }
}
