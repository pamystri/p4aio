import {
  RegistryObservationFactory,
  type CanonicalMetricObservation,
  type JsonValue,
  type MetricRegistry,
} from '@connector-sdk/index';
import type { AmarisoftParserContext, AmarisoftTargetConfiguration } from '../amarisoft.types';
import { amarisoftMetricRegistry } from '../metrics/amarisoft-metric.registry';
import { parseEvents } from './event.parser';
import { parseMmeInventory } from './mme-inventory.parser';
import { asFiniteNumber, isJsonArray, isJsonRecord, responseObservedAt } from './parser.helpers';

const metrics = {
  emm_registered_ue_count: 'radio.target.registered_ue_count',
  ip_rx_bitrate: 'radio.target.ip_rx_bitrate',
  ip_tx_bitrate: 'radio.target.ip_tx_bitrate',
  gtp_rx_bitrate: 'radio.target.gtp_rx_bitrate',
  gtp_tx_bitrate: 'radio.target.gtp_tx_bitrate',
} as const;

/** Parses MME/AMF aggregate statistics and any PDN inventory carried with them. */
export class MmeStatsParser {
  private readonly factory: RegistryObservationFactory;

  constructor(registry: MetricRegistry = amarisoftMetricRegistry) {
    this.factory = new RegistryObservationFactory(registry);
  }

  parse(payload: JsonValue, context: AmarisoftParserContext, configuration: AmarisoftTargetConfiguration) {
    if (!isJsonRecord(payload)) {
      return { observations: [], events: [], ueInventory: [], warnings: ['MME stats response is not an object'] };
    }
    const observedAt = responseObservedAt(payload, context.observedAt);
    const observations: CanonicalMetricObservation[] = [];
    for (const [field, metricName] of Object.entries(metrics)) {
      const value = asFiniteNumber(payload[field]);
      if (value !== undefined) {
        observations.push(this.factory.create({ metricName, observedAt, externalEntityId: context.targetId, value }));
      }
    }
    const pdnList = payload['pdn_list'];
    const parsed = parseMmeInventory(isJsonArray(pdnList) ? pdnList : [], context, configuration);
    return {
      observations,
      events: parseEvents(payload, context),
      ueInventory: parsed.inventory,
      ueInventoryMode: 'delta' as const,
      warnings: parsed.warnings,
    };
  }
}
