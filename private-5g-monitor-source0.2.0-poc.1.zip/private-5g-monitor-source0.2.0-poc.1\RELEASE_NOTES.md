# Private 5G Monitor 0.2.0-poc.1

## Purpose

This proof-of-concept release separates Amarisoft UE inventory from radio telemetry:

- MME/AMF Remote API, normally port 9000, owns UE registration, bearer/PDU-session inventory, and UE IP addresses.
- eNB/gNB Remote API, normally port 9001, owns radio presence, serving cell, throughput, and location evidence.
- Site-scoped temporal bindings correlate the two feeds using the RAN UE identifier and optional RAN-node key.

## User-visible changes

- UE inventory is created only from MME/AMF observations.
- The UE page shows MME registration state, gNB radio state, UE IP addresses, last MME observation, and last gNB activity.
- The map shows UE IP and active/idle state alongside the estimated location.
- Administration identifies each Amarisoft target as `mme` or `gnb`.
- Dashboard active-UE counts come from recent correlated gNB presence rather than generic UE timestamps.

## Persistence

New tables are `ue_registration`, `ue_session`, and `ue_radio_binding`. IP addresses use PostgreSQL `inet`. Subscriber identities are HMAC-fingerprinted before normalized persistence and are never returned by the REST API. Exact raw Remote API responses continue to be retained under the existing raw-response policy.

## PoC compatibility policy

No migration of existing UE history is provided. The database must be reset for this PoC release and the site plus both Amarisoft targets recreated. This destructive policy is authorized only during the proof-of-concept phase; it ends when the final design is accepted.

## Current correlation assumptions

- MME and gNB targets belong to the same site.
- `ran_ue_id` matches between their Remote API responses.
- With one gNB, an omitted RAN-node key is allowed when the site-level RAN UE binding is unambiguous.
- For multiple RAN nodes, set gNB `configuration.correlation.ranNodeKey` to the corresponding MME value formatted as `ran_id:<value>`.
- `uePresence.radioActiveWithinMs` should be at least two or three gNB polling intervals.

## Validation requirement

The source-generation workspace has no Node/npm runtime. Run Prisma generation/validation, unit tests, lint, backend build, web lint, and web build on the Ubuntu host before activating the release.
