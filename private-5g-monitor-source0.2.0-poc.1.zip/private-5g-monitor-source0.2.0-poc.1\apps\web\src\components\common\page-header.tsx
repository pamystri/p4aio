import type { ReactNode } from 'react';
import { Box, Stack, Typography } from '@mui/material';

export function PageHeader({ eyebrow, title, description, actions }: { eyebrow?: string; title: string; description: string; actions?: ReactNode }) {
  return <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ justifyContent: 'space-between', alignItems: { xs: 'flex-start', md: 'center' }, mb: 3 }}>
    <Box>{eyebrow && <Typography variant="overline" color="primary.main">{eyebrow}</Typography>}<Typography variant="h1">{title}</Typography><Typography color="text.secondary" sx={{ mt: .6, maxWidth: 760 }}>{description}</Typography></Box>{actions && <Stack direction="row" spacing={1}>{actions}</Stack>}
  </Stack>;
}
