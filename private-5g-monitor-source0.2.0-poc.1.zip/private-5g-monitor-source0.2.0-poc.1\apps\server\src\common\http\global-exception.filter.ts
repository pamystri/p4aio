import {
  ArgumentsHost,
  Catch,
  HttpException,
  HttpStatus,
  type ExceptionFilter,
} from '@nestjs/common';
import { Logger } from 'nestjs-pino';
import { Prisma } from '@prisma/client';
import type { Request, Response } from 'express';

interface ProblemDetails {
  type: string;
  title: string;
  status: number;
  detail?: string;
  instance: string;
  code: string;
  requestId?: string;
  errors?: unknown;
}

@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  constructor(private readonly logger: Logger) {}

  catch(exception: unknown, host: ArgumentsHost): void {
    const context = host.switchToHttp();
    const request = context.getRequest<Request & { id?: string }>();
    const response = context.getResponse<Response>();
    const status = this.status(exception);
    const exceptionResponse = exception instanceof HttpException ? exception.getResponse() : undefined;
    const objectResponse =
      typeof exceptionResponse === 'object' && exceptionResponse !== null ? exceptionResponse : undefined;
    const message =
      typeof exceptionResponse === 'string'
        ? exceptionResponse
        : this.readStringProperty(objectResponse, 'message');
    const problem: ProblemDetails = {
      type: `urn:private-5g-monitor:error:${this.errorCode(status)}`,
      title: this.title(status),
      status,
      instance: request.originalUrl,
      code: this.errorCode(status),
      requestId: request.id,
    };

    if (status < 500) {
      if (Array.isArray(message)) problem.errors = message;
      else if (message) problem.detail = message;
      else if (this.isUniqueConstraintFailure(exception)) {
        problem.detail = 'A resource with the same unique identifier already exists';
      }
    }

    if (status >= 500) {
      this.logger.error({ err: exception, requestId: request.id }, 'Unhandled request failure');
    }

    response.status(status).type('application/problem+json').json(problem);
  }

  private status(exception: unknown): number {
    if (exception instanceof HttpException) return exception.getStatus();
    if (this.isUniqueConstraintFailure(exception)) return HttpStatus.CONFLICT;
    return HttpStatus.INTERNAL_SERVER_ERROR;
  }

  private isUniqueConstraintFailure(
    exception: unknown,
  ): exception is Prisma.PrismaClientKnownRequestError {
    return exception instanceof Prisma.PrismaClientKnownRequestError && exception.code === 'P2002';
  }

  private readStringProperty(value: object | undefined, key: string): string | string[] | undefined {
    if (!value || !(key in value)) return undefined;
    const candidate = (value as Record<string, unknown>)[key];
    if (typeof candidate === 'string') return candidate;
    if (Array.isArray(candidate) && candidate.every((item) => typeof item === 'string')) {
      return candidate as string[];
    }
    return undefined;
  }

  private title(status: number): string {
    return status >= 500 ? 'Internal server error' : HttpStatus[status] || 'Request failed';
  }

  private errorCode(status: number): string {
    return `HTTP_${status}`;
  }
}
