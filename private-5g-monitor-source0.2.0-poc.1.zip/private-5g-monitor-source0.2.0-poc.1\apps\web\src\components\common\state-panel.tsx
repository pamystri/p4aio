import { Alert, Box, CircularProgress, Typography } from '@mui/material';

export function StatePanel({ loading, error, empty, children }: { loading?: boolean; error?: string | null; empty?: boolean; children: React.ReactNode }) {
  if (loading) return <Box sx={{ minHeight: 220, display: "grid", placeItems: "center" }}><CircularProgress size={28} /></Box>;
  if (error) return <Alert severity="error" variant="outlined">{error}</Alert>;
  if (empty) return <Box sx={{ minHeight: 190, display: "grid", placeItems: "center", textAlign: "center" }}><Box><Typography sx={{ fontWeight: 700 }}>No data available</Typography><Typography variant="body2" color="text.secondary" sx={{ mt: .5 }}>Adjust the filters or wait for the next polling cycle.</Typography></Box></Box>;
  return <>{children}</>;
}
