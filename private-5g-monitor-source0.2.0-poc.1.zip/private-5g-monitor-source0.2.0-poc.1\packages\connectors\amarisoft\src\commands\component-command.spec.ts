import { parseAmarisoftTargetConfiguration } from '../amarisoft.configuration';
import { StatsCommandModule } from './stats.command';
import { UeGetCommandModule } from './ue-get.command';

describe('Amarisoft component-aware commands', () => {
  it('omits gNB-only options when polling the MME API', () => {
    const configuration = parseAmarisoftTargetConfiguration({ componentType: 'mme' });
    expect(new UeGetCommandModule().createRequest(configuration)).toEqual({ message: 'ue_get' });
    expect(new StatsCommandModule().createRequest(configuration)).toEqual({ message: 'stats' });
  });

  it('requests radio measurements from the gNB API', () => {
    const configuration = parseAmarisoftTargetConfiguration({ componentType: 'gnb' });
    expect(new UeGetCommandModule().createRequest(configuration)).toEqual({ message: 'ue_get', stats: true });
    expect(new StatsCommandModule().createRequest(configuration)).toEqual({ message: 'stats', samples: true, rf: true });
  });
});
