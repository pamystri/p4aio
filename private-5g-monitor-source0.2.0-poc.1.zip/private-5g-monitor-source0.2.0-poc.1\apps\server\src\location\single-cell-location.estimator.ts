import { createHash } from 'node:crypto';
import type {
  LocationEstimationCandidate,
  PersistedLocationEstimate,
} from '@application/location/location-estimation.repository';

const earthRadiusM = 6_371_008.8;
const algorithmVersion = 'single-cell-omni-v1';

export interface SingleCellEstimatorConfiguration {
  timingAdvanceMetersPerUnit: number;
  referencePathLossDb: number;
  pathLossExponent: number;
  minimumRangeM: number;
  maximumRangeM: number;
  minimumAccuracyM: number;
}

/**
 * Produces a bounded, explicitly heuristic position from one omnidirectional cell.
 * Range comes from TA/path loss; bearing is stable but synthetic because one omni cell
 * cannot observe direction. The accuracy radius is deliberately large enough to convey that.
 */
export class SingleCellLocationEstimator {
  constructor(private readonly configuration: SingleCellEstimatorConfiguration) {}

  estimate(candidate: LocationEstimationCandidate): PersistedLocationEstimate | null {
    const latitude = candidate.cellLatitude ?? candidate.siteLatitude;
    const longitude = candidate.cellLongitude ?? candidate.siteLongitude;
    if (latitude === null || longitude === null) return null;

    const byMetric = new Map(candidate.evidence.map((item) => [item.metric, item]));
    const timingAdvance = byMetric.get('radio.ue.initial_ta');
    const pathLoss = byMetric.get('radio.ue.ul_path_loss');
    const snr = byMetric.get('radio.ue.pusch_snr');
    const epre = byMetric.get('radio.ue.epre');
    const taRange = timingAdvance && timingAdvance.value >= 0
      ? this.clampRange(timingAdvance.value * this.configuration.timingAdvanceMetersPerUnit)
      : undefined;
    const pathLossRange = pathLoss
      ? this.clampRange(
          10 **
            ((pathLoss.value - this.configuration.referencePathLossDb) /
              (10 * this.configuration.pathLossExponent)),
        )
      : undefined;
    const availableRange = taRange ?? pathLossRange;
    if (availableRange === undefined) return null;

    const rangeM = taRange !== undefined && pathLossRange !== undefined
      ? Math.exp(0.65 * Math.log(Math.max(1, taRange)) + 0.35 * Math.log(Math.max(1, pathLossRange)))
      : availableRange;
    const bearingDeg = this.stableBearing(candidate.uePseudonym, candidate.servingCellId);
    const projected = this.project(latitude, longitude, rangeM, bearingDeg);
    const disagreement = taRange !== undefined && pathLossRange !== undefined
      ? Math.max(taRange, pathLossRange) / Math.max(1, Math.min(taRange, pathLossRange))
      : 1;
    const confidence = this.confidence({
      hasTimingAdvance: taRange !== undefined,
      hasPathLoss: pathLossRange !== undefined,
      snr: snr?.value,
      hasEpre: epre !== undefined,
      disagreement,
    });
    const quantizationM = this.configuration.timingAdvanceMetersPerUnit / 2;
    const horizontalAccuracyM = Math.max(
      this.configuration.minimumAccuracyM,
      2 * rangeM + quantizationM,
    );
    const evidenceWindowStart = new Date(
      Math.min(...candidate.evidence.map((item) => item.observedAt.getTime())),
    );
    const evidenceWindowEnd = new Date(
      Math.max(...candidate.evidence.map((item) => item.observedAt.getTime())),
    );
    const used = candidate.evidence.filter((item) =>
      ['radio.ue.initial_ta', 'radio.ue.ul_path_loss', 'radio.ue.pusch_snr', 'radio.ue.epre'].includes(item.metric),
    );
    return {
      ueId: candidate.ueId,
      servingCellId: candidate.servingCellId,
      estimatedAt: candidate.observedAt,
      latitude: projected.latitude,
      longitude: projected.longitude,
      horizontalAccuracyM,
      confidence,
      method: 'single_cell_omnidirectional_range',
      algorithmVersion,
      evidenceWindowStart,
      evidenceWindowEnd,
      qualityFlags: (candidate.cellLatitude === null || candidate.cellLongitude === null ? 1 : 0) | 2 | (disagreement > 4 ? 4 : 0),
      details: {
        estimatedRangeM: this.round(rangeM),
        timingAdvanceRangeM: taRange === undefined ? null : this.round(taRange),
        pathLossRangeM: pathLossRange === undefined ? null : this.round(pathLossRange),
        displayBearingDeg: bearingDeg,
        bearingSource: 'stable_pseudonymous_display_bearing',
        coordinateSource: candidate.cellLatitude !== null && candidate.cellLongitude !== null ? 'cell' : 'site',
        directionalMeasurementAvailable: false,
        disclaimer: 'Single omnidirectional cell: bearing is not measured; accuracy covers directional ambiguity.',
      },
      evidence: used.map((item) => ({
        observationId: item.observationId,
        role: this.evidenceRole(item.metric),
        weight: this.evidenceWeight(item.metric),
      })),
    };
  }

  private clampRange(value: number): number {
    return Math.min(this.configuration.maximumRangeM, Math.max(this.configuration.minimumRangeM, value));
  }

  private stableBearing(pseudonym: string, cellId: string): number {
    const digest = createHash('sha256').update(`${pseudonym}:${cellId}`).digest();
    return Math.round((digest.readUInt32BE(0) / 0xffff_ffff) * 3599) / 10;
  }

  private project(latitude: number, longitude: number, distanceM: number, bearingDeg: number) {
    const angularDistance = distanceM / earthRadiusM;
    const bearing = (bearingDeg * Math.PI) / 180;
    const latitudeRad = (latitude * Math.PI) / 180;
    const longitudeRad = (longitude * Math.PI) / 180;
    const projectedLatitude = Math.asin(
      Math.sin(latitudeRad) * Math.cos(angularDistance) +
      Math.cos(latitudeRad) * Math.sin(angularDistance) * Math.cos(bearing),
    );
    const projectedLongitude = longitudeRad + Math.atan2(
      Math.sin(bearing) * Math.sin(angularDistance) * Math.cos(latitudeRad),
      Math.cos(angularDistance) - Math.sin(latitudeRad) * Math.sin(projectedLatitude),
    );
    return {
      latitude: (projectedLatitude * 180) / Math.PI,
      longitude: ((((projectedLongitude * 180) / Math.PI) + 540) % 360) - 180,
    };
  }

  private confidence(input: {
    hasTimingAdvance: boolean;
    hasPathLoss: boolean;
    snr?: number;
    hasEpre: boolean;
    disagreement: number;
  }): number {
    let value = 0.12;
    if (input.hasTimingAdvance) value += 0.14;
    if (input.hasPathLoss) value += 0.08;
    if (input.snr !== undefined) value += Math.max(0, Math.min(0.05, ((input.snr + 5) / 35) * 0.05));
    if (input.hasEpre) value += 0.02;
    if (input.disagreement > 4) value -= 0.08;
    return this.round(Math.max(0.05, Math.min(0.4, value)), 3);
  }

  private evidenceRole(metric: string): string {
    if (metric.endsWith('initial_ta')) return 'range_primary';
    if (metric.endsWith('ul_path_loss')) return 'range_secondary';
    return 'quality';
  }

  private evidenceWeight(metric: string): number {
    if (metric.endsWith('initial_ta')) return 0.65;
    if (metric.endsWith('ul_path_loss')) return 0.35;
    return 0.1;
  }

  private round(value: number, digits = 1): number {
    const scale = 10 ** digits;
    return Math.round(value * scale) / scale;
  }
}
