import { alpha, Box, Card, CardContent, Skeleton, Stack, Typography, useTheme, type SvgIconProps } from '@mui/material';
import type { ComponentType } from 'react';

export function StatCard({ label, value, helper, icon: Icon, tone = 'primary', loading = false }: { label: string; value: string | number; helper: string; icon: ComponentType<SvgIconProps>; tone?: 'primary' | 'success' | 'warning' | 'secondary'; loading?: boolean }) {
  const theme = useTheme(); const color = theme.palette[tone].main;
  return <Card sx={{ height: '100%', position: 'relative', overflow: 'hidden', '&:before': { content: '""', position: 'absolute', inset: '0 auto 0 0', width: 3, bgcolor: color } }}><CardContent sx={{ p: 2.2 }}><Stack direction="row" sx={{ justifyContent: "space-between" }}><Box><Typography variant="caption" color="text.secondary" sx={{ fontWeight: 650 }}>{label}</Typography>{loading ? <Skeleton width={90} height={42} /> : <Typography sx={{ fontSize: '1.65rem', fontWeight: 780, letterSpacing: '-.035em', mt: .3 }}>{value}</Typography>}<Typography variant="caption" color="text.secondary">{helper}</Typography></Box><Box sx={{ width: 39, height: 39, borderRadius: 2.2, display: 'grid', placeItems: 'center', bgcolor: alpha(color, .11), color }}><Icon fontSize="small" /></Box></Stack></CardContent></Card>;
}
