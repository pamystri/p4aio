import { Module } from '@nestjs/common';
import { LiveModule } from '@app/live/live.module';
import { PersistenceModule } from '@persistence/persistence.module';
import { LocationEstimationService } from './location-estimation.service';

/** Provides the replaceable single-cell location estimation pipeline. */
@Module({
  imports: [PersistenceModule, LiveModule],
  providers: [LocationEstimationService],
  exports: [LocationEstimationService],
})
export class LocationModule {}
