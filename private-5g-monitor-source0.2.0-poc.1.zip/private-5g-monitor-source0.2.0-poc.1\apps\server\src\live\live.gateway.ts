import { UseGuards } from '@nestjs/common';
import {
  ConnectedSocket,
  MessageBody,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { IsArray, IsIn, ArrayMaxSize } from 'class-validator';
import type { Server, Socket } from 'socket.io';
import { WebSocketAuthenticationGuard } from '@app/auth/ws-auth.guard';

const permittedTopics = ['system.health', 'radio.health', 'collection.completed', 'metrics.updated', 'alarms.updated', 'locations.updated'] as const;
type LiveTopic = (typeof permittedTopics)[number];

class SubscribeRequest {
  @IsArray()
  @ArrayMaxSize(20)
  @IsIn(permittedTopics, { each: true })
  topics!: LiveTopic[];
}

@WebSocketGateway({ namespace: '/live', transports: ['websocket'] })
export class LiveGateway {
  @WebSocketServer()
  private server!: Server;

  @UseGuards(WebSocketAuthenticationGuard)
  @SubscribeMessage('subscribe')
  subscribe(
    @ConnectedSocket() client: Socket,
    @MessageBody() request: SubscribeRequest,
  ): { subscribed: LiveTopic[] } {
    for (const topic of request.topics) void client.join(topic);
    return { subscribed: request.topics };
  }

  publish(topic: LiveTopic, payload: Readonly<Record<string, unknown>>): void {
    this.server.to(topic).emit(topic, {
      schemaVersion: 1,
      occurredAt: new Date().toISOString(),
      payload,
    });
  }
}
