import type { LocationEstimationCandidate } from '@application/location/location-estimation.repository';
import { SingleCellLocationEstimator } from './single-cell-location.estimator';

const observedAt = new Date('2026-08-03T12:00:00.000Z');
const configuration = {
  timingAdvanceMetersPerUnit: 39.0625,
  referencePathLossDb: 38,
  pathLossExponent: 2.7,
  minimumRangeM: 3,
  maximumRangeM: 2000,
  minimumAccuracyM: 25,
};

function candidate(overrides: Partial<LocationEstimationCandidate> = {}): LocationEstimationCandidate {
  return {
    ueId: '11111111-1111-4111-8111-111111111111',
    uePseudonym: 'ue_test_pseudonym',
    servingCellId: '22222222-2222-4222-8222-222222222222',
    cellLatitude: 51.5074,
    cellLongitude: -0.1278,
    siteLatitude: 51.5,
    siteLongitude: -0.12,
    observedAt,
    evidence: [
      { observationId: 1n, metric: 'radio.ue.initial_ta', value: 6, observedAt },
      { observationId: 2n, metric: 'radio.ue.ul_path_loss', value: 61.6, observedAt },
      { observationId: 3n, metric: 'radio.ue.pusch_snr', value: 32.3, observedAt },
    ],
    ...overrides,
  };
}

describe('SingleCellLocationEstimator', () => {
  const estimator = new SingleCellLocationEstimator(configuration);

  it('creates a stable, bounded estimate with an explicit omni uncertainty', () => {
    const first = estimator.estimate(candidate());
    const second = estimator.estimate(candidate());

    expect(first).not.toBeNull();
    expect(first?.latitude).toBe(second?.latitude);
    expect(first?.longitude).toBe(second?.longitude);
    expect(first?.method).toBe('single_cell_omnidirectional_range');
    expect(first?.confidence).toBeLessThanOrEqual(0.4);
    expect(first?.horizontalAccuracyM).toBeGreaterThan(25);
    expect(first?.details['directionalMeasurementAvailable']).toBe(false);
    expect(first?.evidence).toHaveLength(3);
  });

  it('falls back to site coordinates when cell coordinates are absent', () => {
    const estimate = estimator.estimate(candidate({ cellLatitude: null, cellLongitude: null }));

    expect(estimate).not.toBeNull();
    expect(estimate?.qualityFlags && (estimate.qualityFlags & 1)).toBeTruthy();
    expect(estimate?.details['coordinateSource']).toBe('site');
  });

  it('does not invent a position without coordinates or range evidence', () => {
    expect(
      estimator.estimate(
        candidate({ cellLatitude: null, cellLongitude: null, siteLatitude: null, siteLongitude: null }),
      ),
    ).toBeNull();
    expect(
      estimator.estimate(candidate({ evidence: [{ observationId: 3n, metric: 'radio.ue.pusch_snr', value: 20, observedAt }] })),
    ).toBeNull();
  });

  it('clamps extreme timing advance to the configured operating radius', () => {
    const estimate = estimator.estimate(
      candidate({ evidence: [{ observationId: 1n, metric: 'radio.ue.initial_ta', value: 100000, observedAt }] }),
    );

    expect(estimate?.details['estimatedRangeM']).toBe(2000);
  });
});
