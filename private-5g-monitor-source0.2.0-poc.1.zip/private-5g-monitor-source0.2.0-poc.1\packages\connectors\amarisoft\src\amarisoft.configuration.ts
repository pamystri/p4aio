import { z } from 'zod';
import type { JsonValue } from '@connector-sdk/index';
import type { AmarisoftTargetConfiguration } from './amarisoft.types';

const defaultOrigin = 'http://private-5g-monitor.local';

const targetConfigurationSchema = z.object({
  componentType: z.enum(['gnb', 'mme']).default('gnb'),
  transport: z.enum(['ws', 'wss']).default('ws'),
  path: z.string().startsWith('/').default('/'),
  origin: z.string().url().default(defaultOrigin),
  tlsRejectUnauthorized: z.boolean().default(true),
  ueGet: z
    .object({
      stats: z.boolean().default(true),
    })
    .default({ stats: true }),
  stats: z
    .object({
      samples: z.boolean().default(true),
      rf: z.boolean().default(true),
    })
    .default({ samples: true, rf: true }),
  correlation: z
    .object({
      ranNodeKey: z.string().min(1).max(128).optional(),
    })
    .default({}),
});

export const amarisoftConfigurationJsonSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    componentType: { type: 'string', enum: ['gnb', 'mme'], default: 'gnb' },
    transport: { type: 'string', enum: ['ws', 'wss'], default: 'ws' },
    path: { type: 'string', default: '/' },
    origin: { type: 'string', format: 'uri', default: defaultOrigin },
    tlsRejectUnauthorized: { type: 'boolean', default: true },
    ueGet: {
      type: 'object',
      additionalProperties: false,
      properties: { stats: { type: 'boolean', default: true } },
    },
    stats: {
      type: 'object',
      additionalProperties: false,
      properties: {
        samples: { type: 'boolean', default: true },
        rf: { type: 'boolean', default: true },
      },
    },
    correlation: {
      type: 'object',
      additionalProperties: false,
      properties: { ranNodeKey: { type: 'string', maxLength: 128 } },
    },
  },
} as const satisfies Readonly<Record<string, JsonValue>>;

export function parseAmarisoftTargetConfiguration(
  value: Readonly<Record<string, JsonValue>>,
): AmarisoftTargetConfiguration {
  return targetConfigurationSchema.parse(value);
}
