# Backend API

All frontend access goes through the NestJS HTTP or Socket.IO boundaries. Controllers call application services and repository ports; only the PostgreSQL persistence adapter imports Prisma.

The REST base path is `/api/v1`. Interactive OpenAPI documentation is served at `/docs`, with the machine-readable document at `/docs-json`. Protected requests use `x-api-key` when API-key mode is enabled. RBAC is intentionally not included.

## Resources

| Method and path | Purpose | Main filters |
|---|---|---|
| `GET /sites` | Sites | `search`, `cursor`, `limit`, `sort` |
| `GET /sites/{id}` | Site details | UUID path |
| `POST /sites` | Create site | Validated JSON body |
| `GET /cells` | Cells | `siteId`, `targetId`, `search`, page/sort |
| `GET /cells/{id}` | Cell details | UUID path |
| `GET /ues` | Pseudonymized MME-derived UEs, registration/radio state, and current IPs | `siteId`, `targetId`, `search`, page/sort |
| `GET /ues/{id}` | UE details | UUID path |
| `GET /metrics/current` | Latest metric per entity/dimension | Site, target, cell, UE, metric, page |
| `GET /metrics/historical` | Raw or aggregated time series | Scope, metric, `from`, `to`, page/sort, aggregation/bucket |
| `GET /alarms/current` | Latest recent alarm per type/entity | Scope, severity, optional time range |
| `GET /alarms/historical` | Alarm history | Scope, severity, time range, page/sort |
| `GET /health/live` | Process liveness | Public |
| `GET /health/ready` | Database and scheduler readiness | Public |
| `GET /collectors/status` | Target, last run, and polling schedules | `siteId`, `targetId` |
| `GET /locations/current` | Latest algorithm-neutral UE location estimates | `siteId`, `targetId` |

New estimates also produce the authenticated live topic `locations.updated`, containing the target, observation timestamp, and number of committed estimates. The REST response remains the source of truth; clients should refetch it after receiving the notification.
| `GET /configuration` | Secret-free effective configuration and limits | None |
| `GET /statistics` | Inventory, active UE, alarm, failure, and throughput totals | `siteId`, `targetId` |

Existing `/radio-targets`, polling-configuration, and connector endpoints remain available.

## Historical queries

`from` and `to` use ISO-8601 UTC timestamps. Raw history is limited to 90 days per request. Aggregated history is limited to 730 days and requires both:

- `aggregation`: `avg`, `sum`, `min`, or `max`
- `bucket`: `minute`, `hour`, or `day`

Raw endpoints return `{ items, nextCursor }`; clients pass `nextCursor` unchanged. Page size is capped at 1,000. Aggregations execute in PostgreSQL and return the same page envelope with a null cursor.

## Live updates

Connect to Socket.IO namespace `/live` using WebSocket transport. In protected mode send `{ "apiKey": "..." }` as handshake authentication, then emit:

```json
{ "event": "subscribe", "data": { "topics": ["collection.completed", "metrics.updated", "alarms.updated"] } }
```

Every committed polling cycle emits `collection.completed` and `metrics.updated`. `alarms.updated` is emitted when parsed events are committed. Messages include schema version, occurrence time, target/run identifiers, and counts. Notifications are post-commit hints; REST/PostgreSQL remain authoritative after reconnects.

## Validation and errors

Unknown request properties are rejected. UUIDs, cursors, enums, time ranges, search lengths, and page limits are validated. Invalid requests use RFC 7807-style `application/problem+json` responses and include the request correlation ID. Secrets and raw credentials are excluded from configuration responses and structured logs.

## Historical-data performance

- Composite indexes cover UE/cell/metric and descending observation-time access.
- BRIN indexes keep broad time-range scans compact as append-only tables grow.
- Database-side time bucketing prevents transferring raw samples for charts.
- Cursor pagination avoids increasingly expensive SQL offsets.
- Query ranges and page sizes are bounded at the API boundary.
- Current metrics use a bounded latest-value scan suitable for the intended ten-radio private network.
- Raw and normalized retention should be enforced by scheduled partition retention as described in the architecture document.

For substantially larger deployments, partition `radio_observation` and `domain_event` monthly, place aggregate rollups in materialized views, and move live fan-out to Redis or NATS before adding API replicas.
