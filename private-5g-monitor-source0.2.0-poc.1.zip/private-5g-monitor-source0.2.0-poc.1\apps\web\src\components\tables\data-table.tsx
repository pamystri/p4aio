'use client';

import { useMemo, useState, type ReactNode } from 'react';
import { Box, Button, Card, InputAdornment, Menu, MenuItem, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, TextField, Typography } from '@mui/material';
import SearchRounded from '@mui/icons-material/SearchRounded';
import FileDownloadRounded from '@mui/icons-material/FileDownloadRounded';
import { exportCsv, exportExcel, exportPdf, type ExportRow } from '@/core/export/export-data';
import { StatePanel } from '@/components/common/state-panel';

export interface Column<T> { key: string; label: string; render: (row: T) => ReactNode; export?: (row: T) => string | number | boolean | null | undefined }
export function DataTable<T>({ title, rows, columns, loading, error, searchableText, filename = 'network-data' }: { title: string; rows: T[]; columns: Array<Column<T>>; loading?: boolean; error?: string | null; searchableText?: (row: T) => string; filename?: string }) {
  const [search, setSearch] = useState(''); const [anchor, setAnchor] = useState<HTMLElement | null>(null); const [page, setPage] = useState(0); const [rowsPerPage, setRowsPerPage] = useState(25);
  const filtered = useMemo(() => !searchableText || !search ? rows : rows.filter((row) => searchableText(row).toLowerCase().includes(search.toLowerCase())), [rows, search, searchableText]);
  const exportRows = (): ExportRow[] => filtered.map((row) => Object.fromEntries(columns.map((column) => [column.label, column.export?.(row) ?? String(column.render(row) ?? '')])));
  const lastPage = Math.max(0, Math.ceil(filtered.length / rowsPerPage) - 1);
  const visiblePage = Math.min(page, lastPage);
  const visible = filtered.slice(visiblePage * rowsPerPage, visiblePage * rowsPerPage + rowsPerPage);
  return <Card><Box sx={{ px: 2.2, py: 1.7, display: 'flex', gap: 1.5, alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', borderBottom: '1px solid', borderColor: 'divider' }}><Typography variant="h2">{title}</Typography><Box sx={{ display: "flex", gap: 1 }}><TextField size="small" value={search} onChange={(event) => { setSearch(event.target.value); setPage(0); }} placeholder="Search" slotProps={{ input: { startAdornment: <InputAdornment position="start"><SearchRounded fontSize="small" /></InputAdornment> } }} sx={{ width: { xs: 180, sm: 230 } }} /><Button variant="outlined" startIcon={<FileDownloadRounded />} onClick={(event) => setAnchor(event.currentTarget)}>Export</Button><Menu anchorEl={anchor} open={Boolean(anchor)} onClose={() => setAnchor(null)}><MenuItem onClick={() => { exportCsv(exportRows(), filename); setAnchor(null); }}>CSV</MenuItem><MenuItem onClick={() => { void exportExcel(exportRows(), filename); setAnchor(null); }}>Excel</MenuItem><MenuItem onClick={() => { void exportPdf(exportRows(), filename, title); setAnchor(null); }}>PDF</MenuItem></Menu></Box></Box><StatePanel loading={loading} error={error} empty={!filtered.length}><TableContainer sx={{ maxHeight: 590 }}><Table stickyHeader size="small"><TableHead><TableRow>{columns.map((column) => <TableCell key={column.key}>{column.label}</TableCell>)}</TableRow></TableHead><TableBody>{visible.map((row, index) => <TableRow hover key={visiblePage * rowsPerPage + index}>{columns.map((column) => <TableCell key={column.key}>{column.render(row)}</TableCell>)}</TableRow>)}</TableBody></Table></TableContainer><TablePagination component="div" count={filtered.length} page={visiblePage} onPageChange={(_, value) => setPage(value)} rowsPerPage={rowsPerPage} onRowsPerPageChange={(event) => { setRowsPerPage(Number(event.target.value)); setPage(0); }} rowsPerPageOptions={[10, 25, 50, 100]} /></StatePanel></Card>;
}
