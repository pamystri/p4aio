import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { loadYamlConfiguration } from './configuration';

describe('loadYamlConfiguration', () => {
  const originalEnvironment = { ...process.env };

  afterEach(() => {
    process.env = { ...originalEnvironment };
  });

  it('loads YAML and substitutes environment values', () => {
    const directory = mkdtempSync(join(tmpdir(), 'private-5g-config-'));
    const path = join(directory, 'test.yaml');
    writeFileSync(
      path,
      `application: { name: test, environment: test }
server: { host: 127.0.0.1, port: 3000, globalPrefix: api/v1, corsOrigins: [], shutdownGraceMs: 1000 }
database: { url: "\${DATABASE_URL}" }
logging: { level: info, pretty: false }
authentication: { mode: disabled, apiKey: "" }
scheduler: { enabled: false, tickMs: 1000, maxConcurrency: 1, staleRunAfterMs: 1000 }
privacy: { pseudonymKey: "12345678901234567890123456789012" }
location: { enabled: true, evidenceMaxAgeMs: 15000, timingAdvanceMetersPerUnit: 39.0625, referencePathLossDb: 38, pathLossExponent: 2.7, minimumRangeM: 3, maximumRangeM: 2000, minimumAccuracyM: 25 }
uePresence: { radioActiveWithinMs: 15000 }
connectors:
  amarisoft: { connectTimeoutMs: 1000, requestTimeoutMs: 1000, heartbeatIntervalMs: 1000, heartbeatTimeoutMs: 500, reconnectMinMs: 100, reconnectMaxMs: 1000, maxRetries: 1 }
websocket: { path: /live, corsOrigins: [] }
`,
    );
    process.env.CONFIG_FILE = path;
    process.env.DATABASE_URL = 'postgresql://user:pass@localhost:5432/test';

    expect(loadYamlConfiguration().database.url).toBe(process.env.DATABASE_URL);
  });
});
