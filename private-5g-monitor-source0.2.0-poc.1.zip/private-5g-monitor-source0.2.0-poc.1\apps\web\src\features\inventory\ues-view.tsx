'use client';

import { Stack, Typography } from '@mui/material';
import { PageHeader } from '@/components/common/page-header';
import { DataTable, type Column } from '@/components/tables/data-table';
import { StatusBadge } from '@/components/common/status-badge';
import { useApi } from '@/core/api/use-api';
import type { Page, Ue } from '@/core/api/types';

export function UesView() {
  const response = useApi<Page<Ue>>('/ues?limit=1000&sort=desc'); const rows = response.data?.items ?? [];
  const columns: Array<Column<Ue>> = [{ key: 'ue', label: 'UE pseudonym', render: (row) => <Stack><Typography sx={{ fontFamily: "monospace", fontWeight: 750 }}>{row.pseudonym}</Typography><Typography variant="caption" color="text.secondary">{row.id.slice(0, 13)}</Typography></Stack>, export: (row) => row.pseudonym }, { key: 'registration', label: 'MME', render: (row) => <StatusBadge status={row.registrationStatus} />, export: (row) => row.registrationStatus }, { key: 'radio', label: 'Radio', render: (row) => <StatusBadge status={row.radioStatus} />, export: (row) => row.radioStatus }, { key: 'ips', label: 'UE IP address', render: (row) => row.ipAddresses.length ? row.ipAddresses.join(', ') : 'Not assigned', export: (row) => row.ipAddresses.join('; ') }, { key: 'mmeSeen', label: 'Last MME observation', render: (row) => row.lastMmeSeenAt ? new Date(row.lastMmeSeenAt).toLocaleString() : 'Never', export: (row) => row.lastMmeSeenAt ?? '' }, { key: 'radioSeen', label: 'Last radio activity', render: (row) => row.lastRadioSeenAt ? new Date(row.lastRadioSeenAt).toLocaleString() : 'Never', export: (row) => row.lastRadioSeenAt ?? '' }];
  return <><PageHeader eyebrow="User equipment" title="UEs" description="MME-derived UE inventory correlated with current gNB radio activity. Subscriber identities never leave the backend." /><DataTable title={`${rows.filter((row) => row.radioStatus === 'active').length} radio-active of ${rows.filter((row) => row.registrationStatus === 'registered').length} registered UEs`} rows={rows} columns={columns} loading={response.loading} error={response.error} searchableText={(row) => `${row.pseudonym} ${row.id} ${row.ipAddresses.join(' ')}`} filename="ues" /></>;
}
