CREATE TABLE "ue_registration" (
  "id" UUID NOT NULL,
  "ue_id" UUID NOT NULL,
  "mme_target_id" UUID NOT NULL,
  "registered" BOOLEAN NOT NULL DEFAULT true,
  "first_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "last_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "ended_at" TIMESTAMPTZ(6),
  "attributes" JSONB NOT NULL DEFAULT '{}',
  CONSTRAINT "ue_registration_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "ue_session" (
  "id" UUID NOT NULL,
  "ue_id" UUID NOT NULL,
  "mme_target_id" UUID NOT NULL,
  "session_key" TEXT NOT NULL,
  "ip_address" INET NOT NULL,
  "dnn" TEXT,
  "first_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "last_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "ended_at" TIMESTAMPTZ(6),
  "attributes" JSONB NOT NULL DEFAULT '{}',
  CONSTRAINT "ue_session_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "ue_radio_binding" (
  "id" UUID NOT NULL,
  "ue_id" UUID NOT NULL,
  "site_id" UUID NOT NULL,
  "mme_target_id" UUID NOT NULL,
  "gnb_target_id" UUID,
  "serving_cell_id" UUID,
  "ran_node_key" TEXT,
  "ran_ue_key" TEXT NOT NULL,
  "correlation_key" TEXT NOT NULL,
  "first_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "last_mme_seen_at" TIMESTAMPTZ(6) NOT NULL,
  "last_gnb_seen_at" TIMESTAMPTZ(6),
  "ended_at" TIMESTAMPTZ(6),
  CONSTRAINT "ue_radio_binding_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "ue_registration_ue_id_mme_target_id_key" ON "ue_registration"("ue_id", "mme_target_id");
CREATE INDEX "ue_registration_mme_target_id_registered_last_seen_at_idx" ON "ue_registration"("mme_target_id", "registered", "last_seen_at" DESC);
CREATE UNIQUE INDEX "ue_session_mme_target_id_ue_id_session_key_ip_address_key" ON "ue_session"("mme_target_id", "ue_id", "session_key", "ip_address");
CREATE INDEX "ue_session_ue_id_ended_at_last_seen_at_idx" ON "ue_session"("ue_id", "ended_at", "last_seen_at" DESC);
CREATE INDEX "ue_session_ip_address_idx" ON "ue_session"("ip_address");
CREATE UNIQUE INDEX "ue_radio_binding_site_id_correlation_key_key" ON "ue_radio_binding"("site_id", "correlation_key");
CREATE INDEX "ue_radio_binding_site_id_ran_ue_key_last_mme_seen_at_idx" ON "ue_radio_binding"("site_id", "ran_ue_key", "last_mme_seen_at" DESC);
CREATE INDEX "ue_radio_binding_gnb_target_id_last_gnb_seen_at_idx" ON "ue_radio_binding"("gnb_target_id", "last_gnb_seen_at" DESC);

ALTER TABLE "ue_registration" ADD CONSTRAINT "ue_registration_ue_id_fkey" FOREIGN KEY ("ue_id") REFERENCES "ue"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ue_registration" ADD CONSTRAINT "ue_registration_mme_target_id_fkey" FOREIGN KEY ("mme_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ue_session" ADD CONSTRAINT "ue_session_ue_id_fkey" FOREIGN KEY ("ue_id") REFERENCES "ue"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ue_session" ADD CONSTRAINT "ue_session_mme_target_id_fkey" FOREIGN KEY ("mme_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ue_radio_binding" ADD CONSTRAINT "ue_radio_binding_ue_id_fkey" FOREIGN KEY ("ue_id") REFERENCES "ue"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ue_radio_binding" ADD CONSTRAINT "ue_radio_binding_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "site"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ue_radio_binding" ADD CONSTRAINT "ue_radio_binding_mme_target_id_fkey" FOREIGN KEY ("mme_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ue_radio_binding" ADD CONSTRAINT "ue_radio_binding_gnb_target_id_fkey" FOREIGN KEY ("gnb_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ue_radio_binding" ADD CONSTRAINT "ue_radio_binding_serving_cell_id_fkey" FOREIGN KEY ("serving_cell_id") REFERENCES "cell"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
