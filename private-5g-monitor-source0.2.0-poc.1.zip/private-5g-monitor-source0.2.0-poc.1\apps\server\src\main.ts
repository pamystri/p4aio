import 'reflect-metadata';
import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import type { NextFunction, Request, Response } from 'express';
import helmet from 'helmet';
import { Logger } from 'nestjs-pino';
import { AppModule } from '@app/app.module';
import { ConfiguredIoAdapter } from '@app/common/websocket/configured-io.adapter';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule, { bufferLogs: true });
  const config = app.get(ConfigService);
  const logger = app.get(Logger);
  app.useLogger(logger);
  app.flushLogs();

  const apiSecurityHeaders = helmet();
  const swaggerSecurityHeaders = helmet({ contentSecurityPolicy: false });
  app.use((request: Request, response: Response, next: NextFunction) => {
    const securityHeaders =
      request.path === '/docs' || request.path.startsWith('/docs/')
        ? swaggerSecurityHeaders
        : apiSecurityHeaders;
    securityHeaders(request, response, next);
  });
  app.enableCors({
    origin: config.getOrThrow<string[]>('server.corsOrigins'),
    credentials: true,
  });
  app.useWebSocketAdapter(
    new ConfiguredIoAdapter(app, config.getOrThrow<string[]>('websocket.corsOrigins')),
  );
  app.setGlobalPrefix(config.getOrThrow<string>('server.globalPrefix'));
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: false },
    }),
  );
  app.enableShutdownHooks();

  const swaggerConfig = new DocumentBuilder()
    .setTitle('Private 5G Monitor API')
    .setDescription('Vendor-neutral radio monitoring control and telemetry API')
    .setVersion('0.1.0')
    .addApiKey({ type: 'apiKey', in: 'header', name: 'x-api-key' }, 'api-key')
    .addTag('sites', 'Monitored private-network sites')
    .addTag('cells', 'Discovered radio cells')
    .addTag('ues', 'Pseudonymized user equipment')
    .addTag('metrics', 'Current and historical telemetry')
    .addTag('alarms', 'Current and historical operational alarms')
    .addTag('collectors', 'Collector and polling state')
    .addTag('configuration', 'Safe effective configuration')
    .addTag('statistics', 'Dashboard summary statistics')
    .build();
  SwaggerModule.setup('docs', app, SwaggerModule.createDocument(app, swaggerConfig));

  const host = config.getOrThrow<string>('server.host');
  const port = config.getOrThrow<number>('server.port');
  await app.listen(port, host);
  logger.log(`Private 5G Monitor listening on ${host}:${port}`);
}

void bootstrap();
