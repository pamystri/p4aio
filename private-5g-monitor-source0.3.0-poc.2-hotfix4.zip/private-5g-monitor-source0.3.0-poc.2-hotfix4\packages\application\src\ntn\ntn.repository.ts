export const NTN_REPOSITORY = Symbol('NTN_REPOSITORY');

export type EphemerisSourceType = 'TLE' | 'THREE_GPP_POSITION_VELOCITY' | 'THREE_GPP_ORBITAL';
export type EphemerisValidationStatus = 'VALID' | 'INVALID' | 'STALE';

export interface SpaceAssetView {
  id: string;
  name: string;
  noradCatalogId: number | null;
  internationalDesignator: string | null;
  orbitClass: string | null;
  status: string;
  attributes: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
}

export interface EphemerisView {
  id: string;
  spaceAssetId: string;
  sourceType: EphemerisSourceType;
  formatVersion: string | null;
  epochUtc: Date;
  validFrom: Date | null;
  validTo: Date | null;
  referenceFrame: string;
  timeSystem: string;
  rawText: string | null;
  rawJson: Record<string, unknown> | null;
  payloadSha256: Buffer;
  validationStatus: EphemerisValidationStatus;
  validationDiagnostics: Record<string, unknown>;
  active: boolean;
  createdAt: Date;
}

export interface TransparentAssignmentView {
  id: string;
  spaceAssetId: string;
  assetName: string;
  radioTargetId: string;
  targetName: string;
  siteId: string;
  validFrom: Date;
  validTo: Date | null;
  enabled: boolean;
  attributes: Record<string, unknown>;
}

export interface SitePassConfigurationView {
  id: string;
  siteId: string;
  siteName: string;
  siteLatitude: number | null;
  siteLongitude: number | null;
  siteAltitudeM: number | null;
  spaceAssetId: string;
  assetName: string;
  minimumElevationDeg: number;
  predictionHorizonDays: number;
  enabled: boolean;
}

export interface PredictedPassInput {
  aosAt: Date;
  losAt: Date;
  maximumElevationAt: Date;
  maximumElevationDeg: number;
  aosAzimuthDeg: number;
  losAzimuthDeg: number;
  minimumSlantRangeM: number;
  predictionVersion: string;
  details: Record<string, unknown>;
}

export interface PredictedPassView extends PredictedPassInput {
  id: string;
  siteId: string;
  siteName: string;
  spaceAssetId: string;
  assetName: string;
  ephemerisDatasetId: string;
  calculatedAt: Date;
}

export interface CreateEphemerisRecord {
  spaceAssetId: string;
  sourceType: EphemerisSourceType;
  formatVersion?: string;
  epochUtc: Date;
  validFrom?: Date;
  validTo?: Date;
  referenceFrame: string;
  timeSystem: string;
  rawText?: string;
  rawJson?: Record<string, unknown>;
  payloadSha256: Buffer;
  validationStatus: EphemerisValidationStatus;
  validationDiagnostics: Record<string, unknown>;
  active: boolean;
}

export interface NtnRepository {
  createAsset(input: { name: string; noradCatalogId?: number; internationalDesignator?: string; orbitClass?: string; attributes?: Record<string, unknown> }): Promise<SpaceAssetView>;
  listAssets(): Promise<SpaceAssetView[]>;
  findAsset(id: string): Promise<SpaceAssetView | null>;
  createEphemeris(input: CreateEphemerisRecord): Promise<EphemerisView>;
  listEphemerides(assetId: string): Promise<EphemerisView[]>;
  findEphemeris(id: string): Promise<EphemerisView | null>;
  activateEphemeris(assetId: string, datasetId: string): Promise<EphemerisView>;
  activeEphemeris(assetId: string): Promise<EphemerisView | null>;
  createAssignment(input: { spaceAssetId: string; radioTargetId: string; validFrom: Date; validTo?: Date; attributes?: Record<string, unknown> }): Promise<TransparentAssignmentView>;
  listAssignments(): Promise<TransparentAssignmentView[]>;
  upsertPassConfiguration(input: { siteId: string; spaceAssetId: string; minimumElevationDeg: number; predictionHorizonDays: number; enabled: boolean }): Promise<SitePassConfigurationView>;
  listPassConfigurations(): Promise<SitePassConfigurationView[]>;
  replaceFuturePasses(configuration: SitePassConfigurationView, ephemerisDatasetId: string, from: Date, passes: PredictedPassInput[]): Promise<void>;
  listPasses(filters: { siteId?: string; spaceAssetId?: string; from: Date; to: Date; limit: number }): Promise<PredictedPassView[]>;
}
