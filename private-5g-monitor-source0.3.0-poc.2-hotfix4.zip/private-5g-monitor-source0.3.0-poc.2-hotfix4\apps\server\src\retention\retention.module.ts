import { Module } from '@nestjs/common';
import { RetentionController } from './retention.controller';
import { RetentionService } from './retention.service';
import { RetentionWorker } from './retention.worker';

@Module({ controllers: [RetentionController], providers: [RetentionService, RetentionWorker], exports: [RetentionService, RetentionWorker] })
export class RetentionModule {}
