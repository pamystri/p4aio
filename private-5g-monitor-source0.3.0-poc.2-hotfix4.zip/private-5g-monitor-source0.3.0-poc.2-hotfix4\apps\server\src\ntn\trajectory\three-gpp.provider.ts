import { Injectable } from '@nestjs/common';
import type { EphemerisSourceType, EphemerisView } from '@application/ntn/ntn.repository';
import {
  ecefToGeodetic,
  radians,
  type TrajectoryProvider,
  type TrajectoryState,
} from './trajectory-provider';

const gravitationalParameter = 3.986004418e14;
const earthRotationRadPerSecond = 7.2921150e-5;

interface Vector { x: number; y: number; z: number }
interface OrbitalElements {
  semiMajorAxisM: number;
  eccentricity: number;
  inclinationRad: number;
  ascendingNodeRad: number;
  argumentOfPeriapsisRad: number;
  meanAnomalyAtEpochRad: number;
}

/** Propagates decoded 3GPP NTN state-vector or orbital ephemeris in SI units. */
@Injectable()
export class ThreeGppTrajectoryProvider implements TrajectoryProvider {
  supports(sourceType: EphemerisSourceType): boolean {
    return sourceType === 'THREE_GPP_POSITION_VELOCITY' || sourceType === 'THREE_GPP_ORBITAL';
  }

  propagate(ephemeris: EphemerisView, at: Date): TrajectoryState {
    if (!ephemeris.rawJson) throw new Error('3GPP ephemeris has no structured payload');
    const elements = ephemeris.sourceType === 'THREE_GPP_ORBITAL'
      ? readOrbital(ephemeris.rawJson)
      : elementsFromPositionVelocity(ephemeris.rawJson, ephemeris.epochUtc);
    const elapsedSeconds = (at.getTime() - ephemeris.epochUtc.getTime()) / 1000;
    const eciPosition = propagateElements(elements, elapsedSeconds);
    const sidereal = greenwichSiderealTime(at);
    const ecef = rotateZ(eciPosition, -sidereal);
    const geodetic = ecefToGeodetic(ecef);
    const speedMps = Math.sqrt(
      gravitationalParameter *
      (2 / magnitude(eciPosition) - 1 / elements.semiMajorAxisM),
    );
    return {
      timestamp: at,
      ...geodetic,
      speedMps,
      ecefPositionM: ecef,
      sourceType: ephemeris.sourceType,
      sourceRevision: ephemeris.id,
    };
  }
}

function readOrbital(value: Record<string, unknown>): OrbitalElements {
  const orbital = object(value['orbital']);
  const semiMajorAxisM = number(orbital['semiMajorAxisM'], 'orbital.semiMajorAxisM');
  const eccentricity = number(orbital['eccentricity'], 'orbital.eccentricity');
  if (semiMajorAxisM < 6_378_137 || semiMajorAxisM > 100_000_000) throw new Error('3GPP semi-major axis is outside supported Earth-orbit range');
  if (eccentricity < 0 || eccentricity >= 1) throw new Error('3GPP eccentricity must be in [0,1)');
  return {
    semiMajorAxisM,
    eccentricity,
    inclinationRad: radians(number(orbital['inclinationDeg'], 'orbital.inclinationDeg')),
    ascendingNodeRad: radians(number(orbital['longitudeOfAscendingNodeDeg'], 'orbital.longitudeOfAscendingNodeDeg')),
    argumentOfPeriapsisRad: radians(number(orbital['argumentOfPeriapsisDeg'], 'orbital.argumentOfPeriapsisDeg')),
    meanAnomalyAtEpochRad: radians(number(orbital['meanAnomalyDeg'], 'orbital.meanAnomalyDeg')),
  };
}

function elementsFromPositionVelocity(value: Record<string, unknown>, epoch: Date): OrbitalElements {
  const state = object(value['positionVelocity']);
  const positionEcef = vector(object(state['positionM']), 'positionVelocity.positionM');
  const velocityEcef = vector(object(state['velocityMps']), 'positionVelocity.velocityMps');
  const sidereal = greenwichSiderealTime(epoch);
  const position = rotateZ(positionEcef, sidereal);
  const earthCrossPosition = { x: -earthRotationRadPerSecond * positionEcef.y, y: earthRotationRadPerSecond * positionEcef.x, z: 0 };
  const velocity = rotateZ(add(velocityEcef, earthCrossPosition), sidereal);
  const h = cross(position, velocity);
  const hMagnitude = magnitude(h);
  const node = { x: -h.y, y: h.x, z: 0 };
  const nodeMagnitude = magnitude(node);
  const radius = magnitude(position);
  const velocityMagnitude = magnitude(velocity);
  const eccentricityVector = subtract(scale(cross(velocity, h), 1 / gravitationalParameter), scale(position, 1 / radius));
  const eccentricity = magnitude(eccentricityVector);
  const energy = velocityMagnitude ** 2 / 2 - gravitationalParameter / radius;
  const semiMajorAxisM = -gravitationalParameter / (2 * energy);
  if (!Number.isFinite(semiMajorAxisM) || semiMajorAxisM <= 0 || eccentricity >= 1) throw new Error('3GPP state vector does not describe a supported bound Earth orbit');
  const inclinationRad = Math.acos(clamp(h.z / hMagnitude));
  const ascendingNodeRad = nodeMagnitude > 1e-9 ? Math.atan2(node.y, node.x) : 0;
  let argumentOfPeriapsisRad = 0;
  if (nodeMagnitude > 1e-9 && eccentricity > 1e-9) {
    argumentOfPeriapsisRad = Math.acos(clamp(dot(node, eccentricityVector) / (nodeMagnitude * eccentricity)));
    if (eccentricityVector.z < 0) argumentOfPeriapsisRad = 2 * Math.PI - argumentOfPeriapsisRad;
  }
  let trueAnomaly = eccentricity > 1e-9
    ? Math.acos(clamp(dot(eccentricityVector, position) / (eccentricity * radius)))
    : Math.atan2(position.y, position.x) - ascendingNodeRad;
  if (dot(position, velocity) < 0) trueAnomaly = 2 * Math.PI - trueAnomaly;
  const eccentricAnomaly = 2 * Math.atan2(
    Math.sqrt(1 - eccentricity) * Math.sin(trueAnomaly / 2),
    Math.sqrt(1 + eccentricity) * Math.cos(trueAnomaly / 2),
  );
  return {
    semiMajorAxisM,
    eccentricity,
    inclinationRad,
    ascendingNodeRad,
    argumentOfPeriapsisRad,
    meanAnomalyAtEpochRad: normalizeRadians(eccentricAnomaly - eccentricity * Math.sin(eccentricAnomaly)),
  };
}

function propagateElements(elements: OrbitalElements, elapsedSeconds: number): Vector {
  const meanMotion = Math.sqrt(gravitationalParameter / elements.semiMajorAxisM ** 3);
  const meanAnomaly = normalizeRadians(elements.meanAnomalyAtEpochRad + meanMotion * elapsedSeconds);
  let eccentricAnomaly = meanAnomaly;
  for (let iteration = 0; iteration < 12; iteration += 1) {
    eccentricAnomaly -=
      (eccentricAnomaly - elements.eccentricity * Math.sin(eccentricAnomaly) - meanAnomaly) /
      (1 - elements.eccentricity * Math.cos(eccentricAnomaly));
  }
  const xOrbital = elements.semiMajorAxisM * (Math.cos(eccentricAnomaly) - elements.eccentricity);
  const yOrbital = elements.semiMajorAxisM * Math.sqrt(1 - elements.eccentricity ** 2) * Math.sin(eccentricAnomaly);
  const cosNode = Math.cos(elements.ascendingNodeRad);
  const sinNode = Math.sin(elements.ascendingNodeRad);
  const cosPeriapsis = Math.cos(elements.argumentOfPeriapsisRad);
  const sinPeriapsis = Math.sin(elements.argumentOfPeriapsisRad);
  const cosInclination = Math.cos(elements.inclinationRad);
  const sinInclination = Math.sin(elements.inclinationRad);
  return {
    x: (cosNode * cosPeriapsis - sinNode * sinPeriapsis * cosInclination) * xOrbital + (-cosNode * sinPeriapsis - sinNode * cosPeriapsis * cosInclination) * yOrbital,
    y: (sinNode * cosPeriapsis + cosNode * sinPeriapsis * cosInclination) * xOrbital + (-sinNode * sinPeriapsis + cosNode * cosPeriapsis * cosInclination) * yOrbital,
    z: sinPeriapsis * sinInclination * xOrbital + cosPeriapsis * sinInclination * yOrbital,
  };
}

function greenwichSiderealTime(at: Date): number {
  const julianDate = at.getTime() / 86_400_000 + 2_440_587.5;
  const centuries = (julianDate - 2_451_545) / 36_525;
  const degreesValue =
    280.46061837 + 360.98564736629 * (julianDate - 2_451_545) +
    0.000387933 * centuries ** 2 - centuries ** 3 / 38_710_000;
  return radians(((degreesValue % 360) + 360) % 360);
}

function vector(value: Record<string, unknown>, path: string): Vector {
  return { x: number(value['x'], `${path}.x`), y: number(value['y'], `${path}.y`), z: number(value['z'], `${path}.z`) };
}
function object(value: unknown): Record<string, unknown> { if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('3GPP ephemeris object is invalid'); return value as Record<string, unknown>; }
function number(value: unknown, path: string): number { if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error(`${path} must be a finite number`); return value; }
function rotateZ(value: Vector, angle: number): Vector { return { x: Math.cos(angle) * value.x - Math.sin(angle) * value.y, y: Math.sin(angle) * value.x + Math.cos(angle) * value.y, z: value.z }; }
function cross(a: Vector, b: Vector): Vector { return { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x }; }
function dot(a: Vector, b: Vector): number { return a.x * b.x + a.y * b.y + a.z * b.z; }
function magnitude(value: Vector): number { return Math.hypot(value.x, value.y, value.z); }
function add(a: Vector, b: Vector): Vector { return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z }; }
function subtract(a: Vector, b: Vector): Vector { return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z }; }
function scale(value: Vector, factor: number): Vector { return { x: value.x * factor, y: value.y * factor, z: value.z * factor }; }
function clamp(value: number): number { return Math.min(1, Math.max(-1, value)); }
function normalizeRadians(value: number): number { return ((value % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI); }
