import { NtnAssetsView } from '@/features/ntn/ntn-assets-view';
export default function NtnPage() { return <NtnAssetsView />; }
