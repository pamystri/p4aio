CREATE TYPE "EphemerisSourceType" AS ENUM ('TLE', 'THREE_GPP_POSITION_VELOCITY', 'THREE_GPP_ORBITAL');
CREATE TYPE "EphemerisValidationStatus" AS ENUM ('VALID', 'INVALID', 'STALE');

CREATE TABLE "space_asset" (
  "id" UUID NOT NULL,
  "name" TEXT NOT NULL,
  "norad_catalog_id" INTEGER,
  "international_designator" TEXT,
  "orbit_class" TEXT,
  "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "attributes" JSONB NOT NULL DEFAULT '{}',
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "space_asset_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "ephemeris_dataset" (
  "id" UUID NOT NULL,
  "space_asset_id" UUID NOT NULL,
  "source_type" "EphemerisSourceType" NOT NULL,
  "format_version" TEXT,
  "epoch_utc" TIMESTAMPTZ(6) NOT NULL,
  "valid_from" TIMESTAMPTZ(6),
  "valid_to" TIMESTAMPTZ(6),
  "reference_frame" TEXT NOT NULL,
  "time_system" TEXT NOT NULL DEFAULT 'UTC',
  "raw_text" TEXT,
  "raw_json" JSONB,
  "payload_sha256" BYTEA NOT NULL,
  "validation_status" "EphemerisValidationStatus" NOT NULL,
  "validation_diagnostics" JSONB NOT NULL DEFAULT '{}',
  "active" BOOLEAN NOT NULL DEFAULT false,
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ephemeris_dataset_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ephemeris_validity_check" CHECK ("valid_to" IS NULL OR "valid_from" IS NULL OR "valid_to" > "valid_from")
);

CREATE TABLE "ntn_transparent_assignment" (
  "id" UUID NOT NULL,
  "space_asset_id" UUID NOT NULL,
  "radio_target_id" UUID NOT NULL,
  "valid_from" TIMESTAMPTZ(6) NOT NULL,
  "valid_to" TIMESTAMPTZ(6),
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "attributes" JSONB NOT NULL DEFAULT '{}',
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "ntn_transparent_assignment_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ntn_assignment_validity_check" CHECK ("valid_to" IS NULL OR "valid_to" > "valid_from")
);

CREATE TABLE "site_pass_configuration" (
  "id" UUID NOT NULL,
  "site_id" UUID NOT NULL,
  "space_asset_id" UUID NOT NULL,
  "minimum_elevation_deg" DOUBLE PRECISION NOT NULL,
  "prediction_horizon_days" INTEGER NOT NULL,
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "site_pass_configuration_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "site_pass_minimum_elevation_check" CHECK ("minimum_elevation_deg" BETWEEN -5 AND 90),
  CONSTRAINT "site_pass_horizon_check" CHECK ("prediction_horizon_days" BETWEEN 1 AND 90)
);

CREATE TABLE "predicted_pass" (
  "id" UUID NOT NULL,
  "site_id" UUID NOT NULL,
  "space_asset_id" UUID NOT NULL,
  "ephemeris_dataset_id" UUID NOT NULL,
  "aos_at" TIMESTAMPTZ(6) NOT NULL,
  "los_at" TIMESTAMPTZ(6) NOT NULL,
  "maximum_elevation_at" TIMESTAMPTZ(6) NOT NULL,
  "maximum_elevation_deg" DOUBLE PRECISION NOT NULL,
  "aos_azimuth_deg" DOUBLE PRECISION NOT NULL,
  "los_azimuth_deg" DOUBLE PRECISION NOT NULL,
  "minimum_slant_range_m" DOUBLE PRECISION NOT NULL,
  "prediction_version" TEXT NOT NULL,
  "calculated_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "details" JSONB NOT NULL DEFAULT '{}',
  CONSTRAINT "predicted_pass_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "predicted_pass_window_check" CHECK ("los_at" > "aos_at"),
  CONSTRAINT "predicted_pass_elevation_check" CHECK ("maximum_elevation_deg" BETWEEN -90 AND 90),
  CONSTRAINT "predicted_pass_range_check" CHECK ("minimum_slant_range_m" >= 0)
);

CREATE UNIQUE INDEX "space_asset_norad_catalog_id_key" ON "space_asset"("norad_catalog_id");
CREATE INDEX "space_asset_status_name_idx" ON "space_asset"("status", "name");
CREATE UNIQUE INDEX "ephemeris_dataset_space_asset_id_payload_sha256_key" ON "ephemeris_dataset"("space_asset_id", "payload_sha256");
CREATE INDEX "ephemeris_dataset_space_asset_id_active_epoch_utc_idx" ON "ephemeris_dataset"("space_asset_id", "active", "epoch_utc" DESC);
CREATE UNIQUE INDEX "ephemeris_dataset_one_active_per_asset_idx" ON "ephemeris_dataset"("space_asset_id") WHERE "active";
CREATE UNIQUE INDEX "ntn_assignment_asset_target_valid_from_key" ON "ntn_transparent_assignment"("space_asset_id", "radio_target_id", "valid_from");
CREATE INDEX "ntn_assignment_target_enabled_idx" ON "ntn_transparent_assignment"("radio_target_id", "enabled");
CREATE INDEX "ntn_assignment_asset_enabled_idx" ON "ntn_transparent_assignment"("space_asset_id", "enabled");
CREATE UNIQUE INDEX "site_pass_configuration_site_asset_key" ON "site_pass_configuration"("site_id", "space_asset_id");
CREATE INDEX "site_pass_configuration_enabled_site_idx" ON "site_pass_configuration"("enabled", "site_id");
CREATE UNIQUE INDEX "predicted_pass_site_asset_dataset_aos_key" ON "predicted_pass"("site_id", "space_asset_id", "ephemeris_dataset_id", "aos_at");
CREATE INDEX "predicted_pass_site_aos_idx" ON "predicted_pass"("site_id", "aos_at");
CREATE INDEX "predicted_pass_asset_aos_idx" ON "predicted_pass"("space_asset_id", "aos_at");

ALTER TABLE "ephemeris_dataset" ADD CONSTRAINT "ephemeris_dataset_space_asset_id_fkey" FOREIGN KEY ("space_asset_id") REFERENCES "space_asset"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ntn_transparent_assignment" ADD CONSTRAINT "ntn_assignment_space_asset_id_fkey" FOREIGN KEY ("space_asset_id") REFERENCES "space_asset"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ntn_transparent_assignment" ADD CONSTRAINT "ntn_assignment_radio_target_id_fkey" FOREIGN KEY ("radio_target_id") REFERENCES "radio_target"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "site_pass_configuration" ADD CONSTRAINT "site_pass_configuration_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "site"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "site_pass_configuration" ADD CONSTRAINT "site_pass_configuration_space_asset_id_fkey" FOREIGN KEY ("space_asset_id") REFERENCES "space_asset"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "predicted_pass" ADD CONSTRAINT "predicted_pass_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "site"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "predicted_pass" ADD CONSTRAINT "predicted_pass_space_asset_id_fkey" FOREIGN KEY ("space_asset_id") REFERENCES "space_asset"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "predicted_pass" ADD CONSTRAINT "predicted_pass_ephemeris_dataset_id_fkey" FOREIGN KEY ("ephemeris_dataset_id") REFERENCES "ephemeris_dataset"("id") ON DELETE CASCADE ON UPDATE CASCADE;
