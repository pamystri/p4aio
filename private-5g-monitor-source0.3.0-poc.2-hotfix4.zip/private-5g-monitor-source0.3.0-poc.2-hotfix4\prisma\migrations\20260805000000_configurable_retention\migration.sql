CREATE TABLE "retention_policy" (
  "id" TEXT NOT NULL DEFAULT 'default',
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "retention_days" INTEGER NOT NULL DEFAULT 7,
  "last_started_at" TIMESTAMPTZ(6),
  "last_completed_at" TIMESTAMPTZ(6),
  "last_status" TEXT,
  "last_deleted_rows" INTEGER NOT NULL DEFAULT 0,
  "last_error" TEXT,
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "retention_policy_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "retention_policy_days_check" CHECK ("retention_days" BETWEEN 1 AND 3650)
);

INSERT INTO "retention_policy" ("id", "enabled", "retention_days", "updated_at")
VALUES ('default', true, 7, CURRENT_TIMESTAMP);

CREATE INDEX "collection_run_started_at_idx" ON "collection_run"("started_at");
CREATE INDEX "raw_observation_received_at_idx" ON "raw_observation"("received_at");
CREATE INDEX "location_estimate_estimated_at_idx" ON "location_estimate"("estimated_at");
CREATE INDEX "ue_registration_ended_at_idx" ON "ue_registration"("ended_at");
CREATE INDEX "ue_session_ended_at_idx" ON "ue_session"("ended_at");
CREATE INDEX "ue_radio_binding_ended_at_idx" ON "ue_radio_binding"("ended_at");
CREATE INDEX "predicted_pass_los_at_idx" ON "predicted_pass"("los_at");
