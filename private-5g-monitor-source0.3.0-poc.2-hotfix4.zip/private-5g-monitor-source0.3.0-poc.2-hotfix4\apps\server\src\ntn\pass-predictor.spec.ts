import type { EphemerisView, SitePassConfigurationView } from '@application/ntn/ntn.repository';
import { PassPredictor } from './pass-predictor';
import type { TrajectoryRegistryService } from './trajectory/trajectory-registry.service';

describe('PassPredictor', () => {
  it('finds AOS, peak elevation and LOS for geometric visibility', () => {
    const origin = new Date('2026-08-04T00:00:00.000Z');
    const periodMs = 90 * 60_000;
    const trajectories = { propagate: (_ephemeris: EphemerisView, at: Date) => {
      const angle = ((at.getTime() - origin.getTime()) / periodMs) * Math.PI * 2 - Math.PI;
      const radius = 6_878_137;
      return { timestamp: at, latitude: 0, longitude: 0, altitudeM: 500_000, speedMps: 7_600, ecefPositionM: { x: radius * Math.cos(angle), y: radius * Math.sin(angle), z: 0 }, sourceType: 'TLE' as const, sourceRevision: 'e1' };
    } } as unknown as TrajectoryRegistryService;
    const predictor = new PassPredictor(trajectories, 30);
    const passes = predictor.predict(configuration(), ephemeris(), origin, new Date(origin.getTime() + periodMs));
    expect(passes).toHaveLength(1);
    expect(passes[0]?.aosAt.getTime()).toBeLessThan(passes[0]?.losAt.getTime() ?? 0);
    expect(passes[0]?.maximumElevationDeg).toBeGreaterThan(80);
    expect(passes[0]?.details).toMatchObject({ geometricOnly: true });
  });
});

function configuration(): SitePassConfigurationView { return { id: 'c1', siteId: 's1', siteName: 'Site', siteLatitude: 0, siteLongitude: 0, siteAltitudeM: 0, spaceAssetId: 'a1', assetName: 'SAT', minimumElevationDeg: 10, predictionHorizonDays: 1, enabled: true }; }
function ephemeris(): EphemerisView { return { id: 'e1', spaceAssetId: 'a1', sourceType: 'TLE', formatVersion: null, epochUtc: new Date(), validFrom: null, validTo: null, referenceFrame: 'TEME', timeSystem: 'UTC', rawText: null, rawJson: null, payloadSha256: Buffer.alloc(32), validationStatus: 'VALID', validationDiagnostics: {}, active: true, createdAt: new Date() }; }
