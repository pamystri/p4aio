# Private 5G Monitor — Local Ubuntu Installation

This package installs entirely on one dedicated Ubuntu machine. It contains:

- NestJS REST, Socket.IO, scheduler, and Amarisoft Remote API collector on loopback port 3000;
- Next.js operator dashboard on loopback port 3001;
- PostgreSQL on the local/internal interface;
- Nginx as the only operator-facing service on HTTPS port 443.

The monitored Amarisoft system is not modified. No agent, script, or copy of `ws.js` is installed or executed remotely. The collector connects directly to the published WebSocket Remote APIs: normally MME/AMF on TCP 9000 and eNB/gNB on TCP 9001.

## 1. Prepare Ubuntu

Use Ubuntu Server 24.04 LTS with a static management address and working NTP. Install approved Node.js 22, PostgreSQL 16, Nginx, and build tools:

```bash
sudo apt update
sudo apt install -y postgresql postgresql-contrib nginx ca-certificates curl build-essential
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node --version
npm --version
```

Allow inbound TCP 443 only from the operator network. Allow outbound TCP 9000/9001 only to configured Amarisoft management addresses. NTN orbit calculations are local and require no satellite or public-internet connection. Do not expose ports 3000, 3001, or 5432.

## 2. Create the service account and release directory

```bash
sudo useradd --system --home /var/lib/private-5g-monitor --create-home \
  --shell /usr/sbin/nologin private5g
sudo install -d -o root -g private5g -m 0750 /etc/private-5g-monitor
sudo install -d -o private5g -g private5g -m 0750 /opt/private-5g-monitor/releases
```

Extract `private-5g-monitor-source0.3.0-poc.2.zip` into `/opt/private-5g-monitor/releases/0.3.0-poc.2`, then create the active link:

```bash
sudo ln -sfn /opt/private-5g-monitor/releases/0.3.0-poc.2 /opt/private-5g-monitor/current
sudo chown -R private5g:private5g /opt/private-5g-monitor/releases/0.3.0-poc.2
cd /opt/private-5g-monitor/current
```

## 3. Create PostgreSQL

```bash
sudo -u postgres psql <<'SQL'
CREATE ROLE private5g LOGIN PASSWORD 'REPLACE_WITH_GENERATED_PASSWORD';
CREATE DATABASE private5g OWNER private5g;
REVOKE ALL ON DATABASE private5g FROM PUBLIC;
SQL
```

Keep PostgreSQL bound to loopback and use SCRAM authentication.

## 4. Create secrets and configuration

```bash
sudo cp config/production.yaml /etc/private-5g-monitor/production.yaml
sudo sh -c 'umask 077; cat > /etc/private-5g-monitor/private-5g-monitor.env' <<'EOF'
DATABASE_URL=postgresql://private5g:REPLACE_WITH_URL_ENCODED_PASSWORD@127.0.0.1:5432/private5g?schema=public
API_AUTH_KEY=REPLACE_WITH_AT_LEAST_32_RANDOM_CHARACTERS
PSEUDONYM_KEY=REPLACE_WITH_A_DIFFERENT_RANDOM_VALUE_OF_AT_LEAST_32_CHARACTERS
AMARISOFT_GNB_1_PASSWORD=REPLACE_ONLY_IF_REMOTE_API_AUTHENTICATION_IS_ENABLED
LOG_LEVEL=info
EOF
sudo chown root:private5g /etc/private-5g-monitor/private-5g-monitor.env
sudo chmod 0640 /etc/private-5g-monitor/private-5g-monitor.env
```

Generate independent secrets with `openssl rand -base64 48`. In the radio-target configuration, refer to the Amarisoft password as `env:AMARISOFT_GNB_1_PASSWORD`; never store the password in YAML or PostgreSQL.

The supplied backend systemd unit reads `/etc/private-5g-monitor/production.yaml` and the protected environment file directly.

## 5. Install, validate, build, and migrate

Dependencies are intentionally not bundled in the ZIP. Run:

```bash
cd /opt/private-5g-monitor/current
npm install
npm run prisma:generate
npm run lint
npm test
npm run build
npm run web:lint
npm run web:build
```

Load the protected environment only for migration:

```bash
set -a
. /etc/private-5g-monitor/private-5g-monitor.env
set +a
npm run prisma:migrate:deploy
unset DATABASE_URL API_AUTH_KEY PSEUDONYM_KEY AMARISOFT_GNB_1_PASSWORD
```

After the first approved installation, retain `package-lock.json` and use `npm ci` for later releases.

### Fully offline map tiles

The default map uses OpenStreetMap tiles. For a disconnected installation, set the internal tile template before the web build:

```bash
export NEXT_PUBLIC_TILE_URL='https://tiles.monitor.internal/{z}/{x}/{y}.png'
npm run web:build
unset NEXT_PUBLIC_TILE_URL
```

The application itself has no public cloud or analytics dependency.

## 6. Install the local services

```bash
sudo cp deploy/systemd/private-5g-monitor.service /etc/systemd/system/
sudo cp deploy/systemd/private-5g-monitor-web.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now private-5g-monitor private-5g-monitor-web
sudo systemctl status private-5g-monitor
sudo systemctl status private-5g-monitor-web
```

Local smoke tests:

```bash
set -a
. /etc/private-5g-monitor/private-5g-monitor.env
set +a
curl --fail http://127.0.0.1:3000/api/v1/health/live
curl --fail http://127.0.0.1:3000/api/v1/health/ready
curl --fail -H "x-api-key: $API_AUTH_KEY" http://127.0.0.1:3000/api/v1/connectors
curl --fail http://127.0.0.1:3001/
unset DATABASE_URL API_AUTH_KEY PSEUDONYM_KEY AMARISOFT_GNB_1_PASSWORD
```

## 7. Configure private HTTPS

Edit the internal DNS name and certificate paths in `deploy/nginx/private-5g-monitor.conf`, then install it:

```bash
sudo cp deploy/nginx/private-5g-monitor.conf /etc/nginx/sites-available/private-5g-monitor
sudo ln -s /etc/nginx/sites-available/private-5g-monitor \
  /etc/nginx/sites-enabled/private-5g-monitor
sudo nginx -t
sudo systemctl reload nginx
```

Open `https://monitor.example.internal/`. In Settings, enter the API key if API-key authentication is enabled. Swagger is available locally at `https://monitor.example.internal/docs`.

## 8. Configure sites and radios

Use Swagger or the REST API to:

1. Create a site with its latitude, longitude, altitude, and time zone.
2. Create an Amarisoft MME/AMF target on port 9000 with `configuration.componentType` set to `mme`.
3. Create an Amarisoft gNB target on port 9001 with `configuration.componentType` set to `gnb`.
4. Keep both targets under the same site; this is the correlation boundary for the PoC.
5. Set `secretReference` to the relevant environment-secret name if authentication is enabled.
6. Enable `ue_get` and `stats` for both targets at a conservative interval, initially 2–5 seconds. Give MME `ue_get` equal or higher priority than gNB `ue_get`.
7. Confirm `/collectors/status`, then verify the UE page shows MME registration/IP data and gNB radio activity.

The map displays configured sites immediately. After each successful `ue_get`, the built-in single-cell estimator writes UE estimates when serving-cell radio evidence and cell or site coordinates are available. Every estimate includes method, confidence, accuracy, evidence, and algorithm version, so future algorithms require no UI changes. The first algorithm uses a stable display bearing for an omnidirectional cell; this bearing is not measured and its broad accuracy circle communicates that uncertainty.

For an existing installation upgrading to this release, copy the new `location:` section from `config/production.yaml` into `/etc/private-5g-monitor/production.yaml` before restarting. The default `timingAdvanceMetersPerUnit` of `39.0625` assumes NR 30 kHz subcarrier spacing and should be calibrated for the deployed radio configuration.

Also copy the `uePresence:` section. `radioActiveWithinMs` defines how long after the newest correlated gNB `ue_get` presence a registered UE remains classified as radio-active; set it to at least two or three gNB polling intervals.

`correlationWindowMs` controls how long recent gNB state may be carried when the MME reports a new `ran_ue_id` for the same UE. The 60-second default is intentionally longer than normal PoC polling intervals but short enough to avoid joining unrelated stale sessions.

### Automatic seven-day retention

Copy the `retention:` block from `config/production.yaml`. After migration and restart, open **Settings → Historical data retention**. Select how long to keep history, enable automatic cleanup, and save. The default is seven days with a cleanup tick every six hours. **Clean now** uses the saved period and is useful after upgrading a database that already contains old data.

Cleanup deletes in small dependency-ordered batches so polling can continue. PostgreSQL normally reuses the released pages; the operating-system file size may not immediately shrink. Continue normal autovacuum, and use `VACUUM (ANALYZE)` during a maintenance window after an unusually large first cleanup. Do not run `VACUUM FULL` routinely because it takes stronger locks and temporarily needs additional disk space.

### PoC 0.2 database reset

This proof-of-concept release intentionally does not migrate earlier UE history. The following command destroys all data in the configured `private5g` database and recreates the schema. Use it only for the PoC database explicitly accepted for reset:

```bash
sudo systemctl stop private-5g-monitor private-5g-monitor-web
cd /opt/private-5g-monitor/current
set -a
. /etc/private-5g-monitor/private-5g-monitor.env
set +a
npx prisma migrate reset --force
unset DATABASE_URL API_AUTH_KEY PSEUDONYM_KEY AMARISOFT_GNB_1_PASSWORD
sudo systemctl start private-5g-monitor private-5g-monitor-web
```

Recreate the site and both component targets after the reset. Once the final design is agreed, destructive resets stop and migrations/backups become mandatory.

## 9. Configure transparent NTN pass tracking

Copy the new `ntn:` block from `config/production.yaml` into `/etc/private-5g-monitor/production.yaml`, run the database migration, and restart the backend. Then open **NTN Assets** in the dashboard:

1. Create the satellite asset. A NORAD catalogue ID is recommended for TLE validation.
2. Upload a local `.tle` or text file. The backend validates line length, line numbers, matching catalogue IDs, checksums, epoch, and SGP4 initialization before storing it.
3. Link the asset to the Amarisoft gNB target that represents the transparent payload path.
4. Select the ground site and save its minimum elevation threshold and prediction horizon.
5. Open **Network Map** to see the current satellite subpoint, ground track, current pass, and next passes.

Site latitude and longitude are mandatory. All predictions are geometric line-of-sight opportunities. The release does not model beams, link budgets, gateways, terrain, weather, interference, or actual RF coverage. TLE files are never fetched automatically; upload a newer revision when the UI reports `STALE`.

## 10. Docker Compose alternative

Create `.env` from `.env.example`, populate all secrets, then run:

```bash
docker compose build
docker compose up -d
docker compose ps
```

The supplied Compose file binds backend and web ports to loopback. Use the supplied Nginx configuration on the host for private HTTPS.

## 11. Operations

- Backend logs: `sudo journalctl -u private-5g-monitor -f`
- Web logs: `sudo journalctl -u private-5g-monitor-web -f`
- Readiness: `/api/v1/health/ready`
- Collector state: `/api/v1/collectors/status`
- Backup: encrypted nightly `pg_dump --format=custom`, off-host copy, and regular restore tests.
- Upgrade: install into a new version directory, build/test/migrate, atomically update `current`, and restart both services.

Database migrations are forward-only. Back up PostgreSQL before every upgrade.
