import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createHash } from 'node:crypto';
import { PinoLogger } from 'nestjs-pino';
import {
  NTN_REPOSITORY,
  type EphemerisView,
  type NtnRepository,
} from '@application/ntn/ntn.repository';
import { RADIO_TARGET_REPOSITORY, type RadioTargetRepository } from '@application/targets/radio-target.repository';
import { SITE_REPOSITORY, type SiteRepository } from '@application/sites/site.repository';
import { LiveGateway } from '@app/live/live.gateway';
import type {
  CreateSpaceAssetDto,
  CreateTransparentAssignmentDto,
  NtnPassQueryDto,
  NtnTrackQueryDto,
  UpdateSitePassConfigurationDto,
  UploadEphemerisDto,
} from './dto/ntn.dto';
import { PassPredictionService } from './pass-prediction.service';
import { lookAngle } from './trajectory/trajectory-provider';
import { parseTle } from './trajectory/tle-sgp4.provider';
import { TrajectoryRegistryService } from './trajectory/trajectory-registry.service';

/** Application boundary for transparent-NTN assets, ephemeris and geometric site passes. */
@Injectable()
export class NtnService {
  constructor(
    @Inject(NTN_REPOSITORY) private readonly repository: NtnRepository,
    @Inject(RADIO_TARGET_REPOSITORY) private readonly targets: RadioTargetRepository,
    @Inject(SITE_REPOSITORY) private readonly sites: SiteRepository,
    private readonly trajectories: TrajectoryRegistryService,
    private readonly predictions: PassPredictionService,
    private readonly config: ConfigService,
    private readonly live: LiveGateway,
    private readonly logger: PinoLogger,
  ) { this.logger.setContext(NtnService.name); }

  createAsset(input: CreateSpaceAssetDto) { return this.repository.createAsset(input); }
  listAssets() { return this.repository.listAssets(); }
  listAssignments() { return this.repository.listAssignments(); }
  listPassConfigurations() { return this.repository.listPassConfigurations(); }

  async listEphemerides(assetId: string) {
    await this.requireAsset(assetId);
    return (await this.repository.listEphemerides(assetId)).map((item) => this.presentEphemeris(item));
  }

  async uploadEphemeris(assetId: string, input: UploadEphemerisDto) {
    const asset = await this.requireAsset(assetId);
    let record: Parameters<NtnRepository['createEphemeris']>[0];
    try {
      if (input.sourceType === 'TLE') {
        const rawText = input.tleText as string;
        const parsed = parseTle(rawText);
        if (asset.noradCatalogId !== null && asset.noradCatalogId !== parsed.catalogId) {
          throw new Error(`TLE catalogue ${parsed.catalogId} does not match asset catalogue ${asset.noradCatalogId}`);
        }
        const staleAfterMs = this.config.getOrThrow<number>('ntn.tleStaleAfterDays') * 86_400_000;
        record = {
          spaceAssetId: assetId, sourceType: input.sourceType, formatVersion: input.formatVersion ?? 'TLE',
          epochUtc: parsed.epochUtc, validFrom: date(input.validFrom), validTo: date(input.validTo),
          referenceFrame: 'TEME', timeSystem: 'UTC', rawText,
          payloadSha256: digest(rawText),
          validationStatus: Date.now() - parsed.epochUtc.getTime() > staleAfterMs ? 'STALE' : 'VALID',
          validationDiagnostics: { catalogId: parsed.catalogId, name: parsed.name }, active: input.activate,
        };
      } else {
        const epochUtc = new Date(input.epochUtc as string);
        const rawJson = input.data as Record<string, unknown>;
        record = {
          spaceAssetId: assetId, sourceType: input.sourceType, formatVersion: input.formatVersion,
          epochUtc, validFrom: date(input.validFrom), validTo: date(input.validTo),
          referenceFrame: input.sourceType === 'THREE_GPP_POSITION_VELOCITY' ? 'ECEF' : 'ECI',
          timeSystem: 'UTC', rawJson, payloadSha256: digest(canonicalJson(rawJson)),
          validationStatus: 'VALID', validationDiagnostics: { decoded: true, units: 'SI' }, active: input.activate,
        };
        this.trajectories.propagate(temporaryEphemeris(record), epochUtc);
      }
      if (record.validFrom && record.validTo && record.validFrom >= record.validTo) throw new Error('validFrom must precede validTo');
    } catch (error) {
      throw new BadRequestException(error instanceof Error ? error.message : 'Ephemeris is invalid');
    }
    const duplicate = (await this.repository.listEphemerides(assetId)).find((item) => item.payloadSha256.equals(record.payloadSha256));
    if (duplicate) {
      const selected = input.activate && !duplicate.active ? await this.repository.activateEphemeris(assetId, duplicate.id) : duplicate;
      if (selected.active) await this.predictions.refreshAsset(assetId);
      return this.presentEphemeris(selected);
    }
    const created = await this.repository.createEphemeris(record);
    if (created.active) await this.predictions.refreshAsset(assetId);
    this.live.publish('ntn.ephemeris.updated', { assetId, ephemerisId: created.id, status: created.validationStatus });
    this.logger.info({ assetId, ephemerisId: created.id, sourceType: created.sourceType }, 'NTN ephemeris accepted');
    return this.presentEphemeris(created);
  }

  async activateEphemeris(assetId: string, datasetId: string) {
    await this.requireAsset(assetId);
    const dataset = await this.repository.findEphemeris(datasetId);
    if (!dataset || dataset.spaceAssetId !== assetId) throw new NotFoundException('Ephemeris dataset was not found for this asset');
    if (dataset.validationStatus === 'INVALID') throw new BadRequestException('An invalid ephemeris dataset cannot be activated');
    const active = await this.repository.activateEphemeris(assetId, datasetId);
    await this.predictions.refreshAsset(assetId);
    this.live.publish('ntn.ephemeris.updated', { assetId, ephemerisId: datasetId, active: true });
    return this.presentEphemeris(active);
  }

  async createAssignment(input: CreateTransparentAssignmentDto) {
    await this.requireAsset(input.spaceAssetId);
    const target = (await this.targets.list()).find((item) => item.id === input.radioTargetId);
    if (!target) throw new NotFoundException('Radio target was not found');
    if (target.componentType !== 'gnb') throw new BadRequestException('Transparent NTN assignments require a gNB radio target');
    const validFrom = date(input.validFrom) ?? new Date();
    const validTo = date(input.validTo);
    if (validTo && validFrom >= validTo) throw new BadRequestException('validFrom must precede validTo');
    return this.repository.createAssignment({ ...input, validFrom, validTo });
  }

  async updatePassConfiguration(input: UpdateSitePassConfigurationDto) {
    await this.requireAsset(input.spaceAssetId);
    const site = await this.sites.findById(input.siteId);
    if (!site) throw new NotFoundException('Site was not found');
    if (site.latitude === null || site.longitude === null) throw new BadRequestException('Site latitude and longitude are required for pass prediction');
    const horizon = input.predictionHorizonDays ?? this.config.getOrThrow<number>('ntn.defaultPredictionHorizonDays');
    if (horizon > this.config.getOrThrow<number>('ntn.maximumPredictionHorizonDays')) throw new BadRequestException('Prediction horizon exceeds the configured maximum');
    const saved = await this.repository.upsertPassConfiguration({
      siteId: input.siteId, spaceAssetId: input.spaceAssetId,
      minimumElevationDeg: input.minimumElevationDeg ?? this.config.getOrThrow<number>('ntn.defaultMinimumElevationDeg'),
      predictionHorizonDays: horizon, enabled: input.enabled,
    });
    await this.predictions.refreshAsset(input.spaceAssetId);
    this.live.publish('ntn.pass.updated', { siteId: input.siteId, assetId: input.spaceAssetId });
    return saved;
  }

  async listPasses(query: NtnPassQueryDto) {
    const from = date(query.from) ?? new Date();
    const to = date(query.to) ?? new Date(from.getTime() + 7 * 86_400_000);
    if (from >= to) throw new BadRequestException('from must precede to');
    return this.repository.listPasses({ ...query, from, to, limit: query.limit });
  }

  async currentPositions(at = new Date()) {
    const configurations = (await this.repository.listPassConfigurations()).filter((item) => item.enabled);
    const assignments = await this.repository.listAssignments();
    const assets = await this.repository.listAssets();
    const results: Record<string, unknown>[] = [];
    for (const asset of assets) {
      const ephemeris = await this.repository.activeEphemeris(asset.id);
      if (!ephemeris) continue;
      if ((ephemeris.validFrom && at < ephemeris.validFrom) || (ephemeris.validTo && at > ephemeris.validTo)) continue;
      try {
        const position = this.trajectories.propagate(ephemeris, at);
        const siteLooks = configurations.filter((item) => item.spaceAssetId === asset.id && item.siteLatitude !== null && item.siteLongitude !== null).map((item) => {
          const look = lookAngle(position, { latitude: item.siteLatitude as number, longitude: item.siteLongitude as number, altitudeM: item.siteAltitudeM ?? 0 });
          return { siteId: item.siteId, siteName: item.siteName, minimumElevationDeg: item.minimumElevationDeg, ...look, inPass: look.elevationDeg >= item.minimumElevationDeg };
        });
        results.push({ asset, position, ephemeris: this.presentEphemeris(ephemeris), siteLooks, assignments: assignments.filter((item) => item.spaceAssetId === asset.id) });
      } catch (error) { this.logger.warn({ err: error, assetId: asset.id }, 'Could not propagate active NTN ephemeris'); }
    }
    return { generatedAt: at, geometricOnly: true, assets: results };
  }

  async tracks(query: NtnTrackQueryDto) {
    const now = new Date();
    const start = new Date(now.getTime() - query.minutes * 20_000);
    const end = new Date(start.getTime() + query.minutes * 60_000);
    const assets = await this.repository.listAssets();
    const tracks = [];
    for (const asset of assets) {
      const ephemeris = await this.repository.activeEphemeris(asset.id);
      if (!ephemeris) continue;
      const points = [];
      for (let timestamp = start.getTime(); timestamp <= end.getTime(); timestamp += query.stepSeconds * 1000) {
        if ((ephemeris.validFrom && timestamp < ephemeris.validFrom.getTime()) || (ephemeris.validTo && timestamp > ephemeris.validTo.getTime())) continue;
        try {
          const state = this.trajectories.propagate(ephemeris, new Date(timestamp));
          points.push({ timestamp: state.timestamp, latitude: state.latitude, longitude: state.longitude, altitudeM: state.altitudeM });
        } catch { break; }
      }
      tracks.push({ assetId: asset.id, assetName: asset.name, sourceRevision: ephemeris.id, points });
    }
    return { generatedAt: now, geometricOnly: true, tracks };
  }

  private async requireAsset(id: string) {
    const asset = await this.repository.findAsset(id);
    if (!asset) throw new NotFoundException('Space asset was not found');
    return asset;
  }
  private presentEphemeris(value: EphemerisView) {
    const safe = safeEphemeris(value);
    const staleAfterMs = this.config.getOrThrow<number>('ntn.tleStaleAfterDays') * 86_400_000;
    return value.sourceType === 'TLE' && Date.now() - value.epochUtc.getTime() > staleAfterMs
      ? { ...safe, validationStatus: 'STALE' as const }
      : safe;
  }
}

function date(value?: string): Date | undefined { return value ? new Date(value) : undefined; }
function digest(value: string): Buffer { return createHash('sha256').update(value).digest(); }
function canonicalJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${canonicalJson(item)}`).join(',')}}`;
  return JSON.stringify(value) ?? 'null';
}
function temporaryEphemeris(input: Parameters<NtnRepository['createEphemeris']>[0]): EphemerisView {
  return {
    id: 'validation', spaceAssetId: input.spaceAssetId, sourceType: input.sourceType,
    formatVersion: input.formatVersion ?? null, epochUtc: input.epochUtc,
    validFrom: input.validFrom ?? null, validTo: input.validTo ?? null,
    referenceFrame: input.referenceFrame, timeSystem: input.timeSystem,
    rawText: input.rawText ?? null, rawJson: input.rawJson ?? null,
    payloadSha256: input.payloadSha256, validationStatus: input.validationStatus,
    validationDiagnostics: input.validationDiagnostics, active: input.active, createdAt: new Date(),
  };
}
function safeEphemeris(value: EphemerisView) {
  const { rawText, rawJson, payloadSha256, ...safe } = value;
  return { ...safe, hasRawText: rawText !== null, hasRawJson: rawJson !== null, payloadSha256: payloadSha256.toString('hex') };
}
