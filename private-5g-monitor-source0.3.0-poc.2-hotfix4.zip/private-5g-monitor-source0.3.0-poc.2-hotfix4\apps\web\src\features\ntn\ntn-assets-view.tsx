'use client';

import { useState, type ChangeEvent, type FormEvent } from 'react';
import { Alert, Box, Button, Card, CardContent, Chip, Grid, MenuItem, Stack, TextField, Typography } from '@mui/material';
import SatelliteAltRounded from '@mui/icons-material/SatelliteAltRounded';
import UploadFileRounded from '@mui/icons-material/UploadFileRounded';
import { PageHeader } from '@/components/common/page-header';
import { useApi } from '@/core/api/use-api';
import { apiSend } from '@/core/api/client';
import { useLive } from '@/core/live/live-context';
import type { NtnAssignment, Page, RadioTarget, SafeEphemeris, Site, SitePassConfiguration, SpaceAsset } from '@/core/api/types';

/** Local administration screen for transparent-payload NTN assets and geometric passes. */
export function NtnAssetsView() {
  const { refresh } = useLive();
  const assets = useApi<SpaceAsset[]>('/ntn/assets');
  const sites = useApi<Page<Site>>('/sites?limit=100');
  const targets = useApi<RadioTarget[]>('/radio-targets');
  const assignments = useApi<NtnAssignment[]>('/ntn/assignments');
  const configurations = useApi<SitePassConfiguration[]>('/ntn/pass-configurations');
  const [selectedAsset, setSelectedAsset] = useState('');
  const [sourceType, setSourceType] = useState<'TLE' | 'THREE_GPP_POSITION_VELOCITY' | 'THREE_GPP_ORBITAL'>('TLE');
  const [tleText, setTleText] = useState('');
  const ephemerides = useApi<SafeEphemeris[]>(selectedAsset ? `/ntn/assets/${selectedAsset}/ephemerides` : null);
  const [message, setMessage] = useState<{ severity: 'success' | 'error'; text: string } | null>(null);
  const run = async (operation: () => Promise<unknown>, success: string) => { try { await operation(); setMessage({ severity: 'success', text: success }); refresh(); } catch (error) { setMessage({ severity: 'error', text: error instanceof Error ? error.message : 'Request failed' }); } };

  const createAsset = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); const values = new FormData(event.currentTarget);
    void run(async () => { const created = await apiSend<SpaceAsset>('/ntn/assets', 'POST', { name: values.get('name'), noradCatalogId: numberOrUndefined(values.get('noradCatalogId')), orbitClass: values.get('orbitClass') || undefined }); if (created) setSelectedAsset(created.id); }, 'Space asset created.');
  };
  const uploadEphemeris = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); if (!selectedAsset) return;
    const values = new FormData(event.currentTarget);
    void run(() => {
      const payload = sourceType === 'TLE'
        ? { sourceType, tleText: values.get('payload'), activate: true }
        : { sourceType, epochUtc: new Date(String(values.get('epochUtc'))).toISOString(), data: JSON.parse(String(values.get('payload'))) as unknown, activate: true };
      return apiSend(`/ntn/assets/${selectedAsset}/ephemerides`, 'POST', payload);
    }, 'Ephemeris validated, stored and activated.');
  };
  const loadFile = (event: ChangeEvent<HTMLInputElement>) => { const file = event.target.files?.[0]; if (file) void file.text().then(setTleText); };
  const assign = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); const values = new FormData(event.currentTarget); void run(() => apiSend('/ntn/assignments', 'POST', { spaceAssetId: values.get('spaceAssetId'), radioTargetId: values.get('radioTargetId') }), 'Transparent gNB assignment created.'); };
  const configure = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); const values = new FormData(event.currentTarget); void run(() => apiSend('/ntn/pass-configurations', 'PUT', { spaceAssetId: values.get('spaceAssetId'), siteId: values.get('siteId'), minimumElevationDeg: Number(values.get('minimumElevationDeg')), predictionHorizonDays: Number(values.get('predictionHorizonDays')), enabled: true }), 'Site-pass prediction configured.'); };

  return <><PageHeader eyebrow="Transparent payload" title="NTN assets" description="Manage satellite ephemeris and geometric site-pass visibility. This feature does not predict RF coverage." actions={<Chip icon={<SatelliteAltRounded />} color="primary" variant="outlined" label={`${assets.data?.length ?? 0} assets`} />} />
    {message && <Alert severity={message.severity} sx={{ mb: 2 }} onClose={() => setMessage(null)}>{message.text}</Alert>}
    <Grid container spacing={2}>
      <Grid size={{ xs: 12, lg: 4 }}><Card><CardContent><Typography variant="h2">1. Create asset</Typography><Stack component="form" spacing={2} sx={{ mt: 2 }} onSubmit={createAsset}><TextField required name="name" label="Asset name" /><TextField name="noradCatalogId" label="NORAD catalogue ID" type="number" /><TextField name="orbitClass" label="Orbit class" placeholder="LEO" /><Button type="submit" variant="contained">Create asset</Button></Stack></CardContent></Card></Grid>
      <Grid size={{ xs: 12, lg: 4 }}><Card><CardContent><Typography variant="h2">2. Add ephemeris</Typography><Stack component="form" spacing={2} sx={{ mt: 2 }} onSubmit={uploadEphemeris}><TextField select required label="Asset" value={selectedAsset} onChange={(event) => setSelectedAsset(event.target.value)}>{assets.data?.map((asset) => <MenuItem key={asset.id} value={asset.id}>{asset.name}</MenuItem>)}</TextField><TextField select label="Source format" value={sourceType} onChange={(event) => { setSourceType(event.target.value as typeof sourceType); setTleText(''); }}><MenuItem value="TLE">TLE / SGP4</MenuItem><MenuItem value="THREE_GPP_POSITION_VELOCITY">3GPP position + velocity</MenuItem><MenuItem value="THREE_GPP_ORBITAL">3GPP orbital parameters</MenuItem></TextField>{sourceType === 'TLE' ? <Button component="label" variant="outlined" startIcon={<UploadFileRounded />}>Choose local TLE file<input hidden type="file" accept=".tle,.txt,text/plain" onChange={loadFile} /></Button> : <TextField required name="epochUtc" label="Absolute UTC epoch" type="datetime-local" slotProps={{ inputLabel: { shrink: true } }} />}<TextField required multiline minRows={5} name="payload" label={sourceType === 'TLE' ? 'TLE text' : 'Decoded SI-unit JSON'} value={tleText} onChange={(event) => setTleText(event.target.value)} placeholder={sourceType === 'TLE' ? 'SATELLITE NAME\n1 ...\n2 ...' : '{ "orbital": { ... } }'} /><Button disabled={!selectedAsset} type="submit" variant="contained">Validate and activate</Button></Stack>{ephemerides.data?.map((item) => <Stack key={item.id} direction="row" spacing={1} sx={{ mt: 1.5, alignItems: 'center' }}><Chip size="small" color={item.validationStatus === 'VALID' ? 'success' : 'warning'} label={item.validationStatus} /><Typography variant="caption">{item.sourceType} · {new Date(item.epochUtc).toLocaleString()}</Typography></Stack>)}</CardContent></Card></Grid>
      <Grid size={{ xs: 12, lg: 4 }}><Stack spacing={2}><Card><CardContent><Typography variant="h2">3. Link transparent gNB</Typography><Stack component="form" spacing={2} sx={{ mt: 2 }} onSubmit={assign}><AssetSelect assets={assets.data ?? []} name="spaceAssetId" /><TextField select required name="radioTargetId" label="gNB target" defaultValue="">{(targets.data ?? []).filter((target) => target.componentType === 'gnb').map((target) => <MenuItem key={target.id} value={target.id}>{target.siteName} · {target.name}</MenuItem>)}</TextField><Button type="submit" variant="outlined">Create assignment</Button></Stack></CardContent></Card><Card><CardContent><Typography variant="h2">4. Predict site passes</Typography><Stack component="form" spacing={2} sx={{ mt: 2 }} onSubmit={configure}><AssetSelect assets={assets.data ?? []} name="spaceAssetId" /><TextField select required name="siteId" label="Site" defaultValue="">{sites.data?.items.map((site) => <MenuItem key={site.id} value={site.id}>{site.name}</MenuItem>)}</TextField><Stack direction="row" spacing={1}><TextField required name="minimumElevationDeg" label="Min elevation °" type="number" defaultValue="10" /><TextField required name="predictionHorizonDays" label="Horizon days" type="number" defaultValue="7" /></Stack><Button type="submit" variant="outlined">Save and calculate</Button></Stack></CardContent></Card></Stack></Grid>
    </Grid>
    <Card sx={{ mt: 2 }}><CardContent><Typography variant="h2">Configured transparent links</Typography><Stack spacing={1} sx={{ mt: 1.5 }}>{(assignments.data ?? []).map((item) => <Box key={item.id} sx={{ p: 1.2, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}><Typography sx={{ fontWeight: 700, fontSize: 13 }}>{item.assetName} → {item.targetName}</Typography><Typography variant="caption" color="text.secondary">Transparent payload association</Typography></Box>)}{(configurations.data ?? []).map((item) => <Box key={item.id} sx={{ p: 1.2, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}><Typography sx={{ fontWeight: 700, fontSize: 13 }}>{item.assetName} ↔ {item.siteName}</Typography><Typography variant="caption" color="text.secondary">Geometric pass threshold {item.minimumElevationDeg}° · {item.predictionHorizonDays} days</Typography></Box>)}</Stack></CardContent></Card>
  </>;
}

function AssetSelect({ assets, name }: { assets: SpaceAsset[]; name: string }) { return <TextField select required name={name} label="Asset" defaultValue="">{assets.map((asset) => <MenuItem key={asset.id} value={asset.id}>{asset.name}</MenuItem>)}</TextField>; }
function numberOrUndefined(value: FormDataEntryValue | null): number | undefined { return value === null || value === '' ? undefined : Number(value); }
