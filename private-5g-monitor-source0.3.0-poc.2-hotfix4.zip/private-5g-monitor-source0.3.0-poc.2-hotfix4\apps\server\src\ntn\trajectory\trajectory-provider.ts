import type { EphemerisSourceType, EphemerisView } from '@application/ntn/ntn.repository';

export interface TrajectoryState {
  timestamp: Date;
  latitude: number;
  longitude: number;
  altitudeM: number;
  speedMps: number;
  ecefPositionM: { x: number; y: number; z: number };
  sourceType: EphemerisSourceType;
  sourceRevision: string;
}

export interface SiteLookAngle {
  azimuthDeg: number;
  elevationDeg: number;
  slantRangeM: number;
  approximateOneWayDelayMs: number;
}

export interface TrajectoryProvider {
  supports(sourceType: EphemerisSourceType): boolean;
  propagate(ephemeris: EphemerisView, at: Date): TrajectoryState;
}

export const speedOfLightMps = 299_792_458;

export function lookAngle(
  state: TrajectoryState,
  site: { latitude: number; longitude: number; altitudeM: number },
): SiteLookAngle {
  const observer = geodeticToEcef(site.latitude, site.longitude, site.altitudeM);
  const delta = {
    x: state.ecefPositionM.x - observer.x,
    y: state.ecefPositionM.y - observer.y,
    z: state.ecefPositionM.z - observer.z,
  };
  const latitude = radians(site.latitude);
  const longitude = radians(site.longitude);
  const east = -Math.sin(longitude) * delta.x + Math.cos(longitude) * delta.y;
  const north =
    -Math.sin(latitude) * Math.cos(longitude) * delta.x -
    Math.sin(latitude) * Math.sin(longitude) * delta.y +
    Math.cos(latitude) * delta.z;
  const up =
    Math.cos(latitude) * Math.cos(longitude) * delta.x +
    Math.cos(latitude) * Math.sin(longitude) * delta.y +
    Math.sin(latitude) * delta.z;
  const range = Math.hypot(east, north, up);
  const azimuth = normalizeDegrees(degrees(Math.atan2(east, north)));
  const elevation = degrees(Math.asin(up / range));
  return {
    azimuthDeg: azimuth,
    elevationDeg: elevation,
    slantRangeM: range,
    approximateOneWayDelayMs: (range / speedOfLightMps) * 1000,
  };
}

export function geodeticToEcef(latitudeDeg: number, longitudeDeg: number, altitudeM: number) {
  const equatorialRadiusM = 6_378_137;
  const eccentricitySquared = 6.69437999014e-3;
  const latitude = radians(latitudeDeg);
  const longitude = radians(longitudeDeg);
  const normal = equatorialRadiusM / Math.sqrt(1 - eccentricitySquared * Math.sin(latitude) ** 2);
  return {
    x: (normal + altitudeM) * Math.cos(latitude) * Math.cos(longitude),
    y: (normal + altitudeM) * Math.cos(latitude) * Math.sin(longitude),
    z: (normal * (1 - eccentricitySquared) + altitudeM) * Math.sin(latitude),
  };
}

export function ecefToGeodetic(position: { x: number; y: number; z: number }) {
  const a = 6_378_137;
  const e2 = 6.69437999014e-3;
  const longitude = Math.atan2(position.y, position.x);
  const p = Math.hypot(position.x, position.y);
  let latitude = Math.atan2(position.z, p * (1 - e2));
  let altitude = 0;
  for (let iteration = 0; iteration < 8; iteration += 1) {
    const normal = a / Math.sqrt(1 - e2 * Math.sin(latitude) ** 2);
    altitude = p / Math.cos(latitude) - normal;
    latitude = Math.atan2(position.z, p * (1 - (e2 * normal) / (normal + altitude)));
  }
  return { latitude: degrees(latitude), longitude: normalizeLongitude(degrees(longitude)), altitudeM: altitude };
}

export function radians(value: number): number { return (value * Math.PI) / 180; }
export function degrees(value: number): number { return (value * 180) / Math.PI; }
export function normalizeDegrees(value: number): number { return ((value % 360) + 360) % 360; }
export function normalizeLongitude(value: number): number { return ((value + 540) % 360) - 180; }

