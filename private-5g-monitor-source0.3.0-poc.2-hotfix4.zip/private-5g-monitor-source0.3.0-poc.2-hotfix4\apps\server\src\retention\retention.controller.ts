import { Body, Controller, Get, Post, Put } from '@nestjs/common';
import { ApiOperation, ApiSecurity, ApiTags } from '@nestjs/swagger';
import { RetentionService } from './retention.service';
import { UpdateRetentionPolicyDto } from './dto/retention.dto';

@ApiTags('retention')
@ApiSecurity('api-key')
@Controller('retention')
export class RetentionController {
  constructor(private readonly retention: RetentionService) {}
  @Get() @ApiOperation({ summary: 'Retention policy, execution status, and database size' }) status() { return this.retention.status(); }
  @Put() @ApiOperation({ summary: 'Set automatic historical retention period' }) update(@Body() input: UpdateRetentionPolicyDto) { return this.retention.update(input); }
  @Post('run') @ApiOperation({ summary: 'Run retention immediately using the saved period' }) run() { return this.retention.runNow(); }
}
