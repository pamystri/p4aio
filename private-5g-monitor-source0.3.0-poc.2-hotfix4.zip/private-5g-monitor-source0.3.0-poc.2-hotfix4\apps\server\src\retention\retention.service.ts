import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PinoLogger } from 'nestjs-pino';
import { RETENTION_REPOSITORY, type RetentionBatchResult, type RetentionRepository } from '@application/retention/retention.repository';
import type { UpdateRetentionPolicyDto } from './dto/retention.dto';

export interface RetentionRunSummary {
  status: 'COMPLETED' | 'PARTIAL_LIMIT' | 'DISABLED';
  cutoff: Date;
  batches: number;
  deletedRows: number;
  deletedByTable: Omit<RetentionBatchResult, 'total'>;
}

/** Owns the persistent retention policy and serializes scheduled/manual cleanup runs. */
@Injectable()
export class RetentionService {
  private running?: Promise<RetentionRunSummary>;
  constructor(@Inject(RETENTION_REPOSITORY) private readonly repository: RetentionRepository, private readonly config: ConfigService, private readonly logger: PinoLogger) { this.logger.setContext(RetentionService.name); }

  async status() {
    const [policy, storage] = await Promise.all([this.policy(), this.repository.storage()]);
    return { policy, storage, running: this.running !== undefined };
  }

  update(input: UpdateRetentionPolicyDto) { return this.repository.updatePolicy(input.enabled, input.retentionDays); }
  runNow() { return this.start(false); }
  runScheduled() { return this.start(true); }

  private start(scheduled: boolean): Promise<RetentionRunSummary> {
    if (this.running) return this.running;
    this.running = this.execute(scheduled).finally(() => { this.running = undefined; });
    return this.running;
  }

  private async execute(scheduled: boolean): Promise<RetentionRunSummary> {
    const policy = await this.policy();
    const cutoff = new Date(Date.now() - policy.retentionDays * 86_400_000);
    if (scheduled && (!this.config.getOrThrow<boolean>('retention.enabled') || !policy.enabled)) {
      return { status: 'DISABLED', cutoff, batches: 0, deletedRows: 0, deletedByTable: emptyCounts() };
    }
    const startedAt = new Date();
    await this.repository.markStarted(startedAt);
    const totals = emptyCounts();
    const batchSize = this.config.getOrThrow<number>('retention.batchSize');
    const maximumBatches = this.config.getOrThrow<number>('retention.maxBatchesPerRun');
    let batches = 0;
    let exhausted = false;
    try {
      for (; batches < maximumBatches; batches += 1) {
        const batch = await this.repository.deleteBatch(cutoff, batchSize);
        addCounts(totals, batch);
        if (batch.total === 0) { exhausted = true; break; }
      }
      const deletedRows = Object.values(totals).reduce((sum, value) => sum + value, 0);
      const status = exhausted ? 'COMPLETED' : 'PARTIAL_LIMIT';
      await this.repository.markCompleted(new Date(), status, deletedRows);
      this.logger.info({ status, cutoff, batches, deletedRows, deletedByTable: totals }, 'Historical retention cleanup completed');
      return { status, cutoff, batches, deletedRows, deletedByTable: totals };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown retention failure';
      await this.repository.markFailed(new Date(), message);
      this.logger.error({ err: error, cutoff, batches }, 'Historical retention cleanup failed');
      throw error;
    }
  }

  private policy() {
    return this.repository.getPolicy(this.config.getOrThrow<number>('retention.defaultDays'), this.config.getOrThrow<boolean>('retention.enabled'));
  }
}

function emptyCounts(): Omit<RetentionBatchResult, 'total'> { return { locationEvidence: 0, locationEstimates: 0, radioObservations: 0, domainEvents: 0, rawObservations: 0, collectionRuns: 0, auditEvents: 0, endedSessions: 0, endedRegistrations: 0, endedRadioBindings: 0, predictedPasses: 0 }; }
function addCounts(total: Omit<RetentionBatchResult, 'total'>, batch: RetentionBatchResult): void { for (const key of Object.keys(total) as Array<keyof typeof total>) total[key] += batch[key]; }
