import { Body, Controller, Get, Param, ParseUUIDPipe, Post, Put, Query } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { NtnService } from './ntn.service';
import { CreateSpaceAssetDto, CreateTransparentAssignmentDto, NtnPassQueryDto, NtnTrackQueryDto, UpdateSitePassConfigurationDto, UploadEphemerisDto } from './dto/ntn.dto';

/** REST resources for transparent NTN topology, ephemeris, tracks and site passes. */
@ApiTags('ntn')
@Controller('ntn')
export class NtnController {
  constructor(private readonly service: NtnService) {}

  @Post('assets') @ApiOperation({ summary: 'Create a satellite/space asset' })
  createAsset(@Body() input: CreateSpaceAssetDto) { return this.service.createAsset(input); }
  @Get('assets') listAssets() { return this.service.listAssets(); }

  @Post('assets/:assetId/ephemerides') @ApiOperation({ summary: 'Upload TLE or decoded 3GPP ephemeris' })
  upload(@Param('assetId', ParseUUIDPipe) assetId: string, @Body() input: UploadEphemerisDto) { return this.service.uploadEphemeris(assetId, input); }
  @Get('assets/:assetId/ephemerides') listEphemerides(@Param('assetId', ParseUUIDPipe) assetId: string) { return this.service.listEphemerides(assetId); }
  @Put('assets/:assetId/ephemerides/:datasetId/active')
  activate(@Param('assetId', ParseUUIDPipe) assetId: string, @Param('datasetId', ParseUUIDPipe) datasetId: string) { return this.service.activateEphemeris(assetId, datasetId); }

  @Post('assignments') createAssignment(@Body() input: CreateTransparentAssignmentDto) { return this.service.createAssignment(input); }
  @Get('assignments') listAssignments() { return this.service.listAssignments(); }
  @Put('pass-configurations') configurePasses(@Body() input: UpdateSitePassConfigurationDto) { return this.service.updatePassConfiguration(input); }
  @Get('pass-configurations') passConfigurations() { return this.service.listPassConfigurations(); }
  @Get('passes') passes(@Query() query: NtnPassQueryDto) { return this.service.listPasses(query); }
  @Get('positions/current') positions() { return this.service.currentPositions(); }
  @Get('tracks/current') tracks(@Query() query: NtnTrackQueryDto) { return this.service.tracks(query); }
}
