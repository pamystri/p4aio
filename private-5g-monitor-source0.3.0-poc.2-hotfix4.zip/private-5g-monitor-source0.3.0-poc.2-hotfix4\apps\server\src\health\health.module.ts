import { Module } from '@nestjs/common';
import { PersistenceModule } from '@persistence/persistence.module';
import { SchedulerModule } from '@app/scheduler/scheduler.module';
import { HealthController } from './health.controller';
import { NtnModule } from '@app/ntn/ntn.module';
import { RetentionModule } from '@app/retention/retention.module';

@Module({
  imports: [PersistenceModule, SchedulerModule, NtnModule, RetentionModule],
  controllers: [HealthController],
})
export class HealthModule {}
