import type { EphemerisView } from '@application/ntn/ntn.repository';
import { parseTle, TleSgp4TrajectoryProvider } from './tle-sgp4.provider';

describe('TleSgp4TrajectoryProvider', () => {
  const line1 = checksum('1 25544U 98067A   24001.50000000  .00016717  00000+0  30183-3 0  999');
  const line2 = checksum('2 25544  51.6400 120.0000 0005000  20.0000 340.0000 15.5000000012345');
  const text = `ISS TEST\n${line1}\n${line2}`;

  it('validates catalogue, checksum and epoch', () => {
    const parsed = parseTle(text);
    expect(parsed.catalogId).toBe(25544);
    expect(parsed.epochUtc.toISOString()).toBe('2024-01-01T12:00:00.000Z');
  });

  it('produces a finite geodetic position through SGP4', () => {
    const parsed = parseTle(text);
    const ephemeris = fixture({ rawText: text, epochUtc: parsed.epochUtc });
    const result = new TleSgp4TrajectoryProvider().propagate(ephemeris, parsed.epochUtc);
    expect(Number.isFinite(result.latitude)).toBe(true);
    expect(result.longitude).toBeGreaterThanOrEqual(-180);
    expect(result.longitude).toBeLessThan(180);
    expect(result.altitudeM).toBeGreaterThan(100_000);
  });

  it('rejects a corrupted checksum', () => {
    const wrong = (Number(line1[68]) + 1) % 10;
    expect(() => parseTle(`${line1.slice(0, 68)}${wrong}\n${line2}`)).toThrow('checksum');
  });
});

function checksum(first68: string): string {
  const padded = first68.padEnd(68, ' ').slice(0, 68);
  const sum = [...padded].reduce((total, character) => total + (character >= '0' && character <= '9' ? Number(character) : character === '-' ? 1 : 0), 0);
  return `${padded}${sum % 10}`;
}
function fixture(input: Partial<EphemerisView>): EphemerisView {
  return { id: 'tle-1', spaceAssetId: 'asset-1', sourceType: 'TLE', formatVersion: 'TLE', epochUtc: new Date(), validFrom: null, validTo: null, referenceFrame: 'TEME', timeSystem: 'UTC', rawText: null, rawJson: null, payloadSha256: Buffer.alloc(32), validationStatus: 'VALID', validationDiagnostics: {}, active: true, createdAt: new Date(), ...input };
}
