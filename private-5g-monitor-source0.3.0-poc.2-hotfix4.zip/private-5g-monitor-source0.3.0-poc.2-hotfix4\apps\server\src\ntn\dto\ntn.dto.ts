import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsBoolean,
  IsIn,
  IsInt,
  IsISO8601,
  IsObject,
  IsOptional,
  IsString,
  IsUUID,
  Max,
  MaxLength,
  Min,
  ValidateIf,
} from 'class-validator';

export class CreateSpaceAssetDto {
  @ApiProperty({ example: 'SAT-1' }) @IsString() @MaxLength(120) name!: string;
  @ApiPropertyOptional({ example: 25544 }) @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(999999) noradCatalogId?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(32) internationalDesignator?: string;
  @ApiPropertyOptional({ example: 'LEO' }) @IsOptional() @IsString() @MaxLength(32) orbitClass?: string;
  @ApiPropertyOptional({ type: 'object', additionalProperties: true }) @IsOptional() @IsObject() attributes?: Record<string, unknown>;
}

export class UploadEphemerisDto {
  @ApiProperty({ enum: ['TLE', 'THREE_GPP_POSITION_VELOCITY', 'THREE_GPP_ORBITAL'] })
  @IsIn(['TLE', 'THREE_GPP_POSITION_VELOCITY', 'THREE_GPP_ORBITAL'])
  sourceType!: 'TLE' | 'THREE_GPP_POSITION_VELOCITY' | 'THREE_GPP_ORBITAL';

  @ApiPropertyOptional({ description: 'Exact two-line or optional three-line TLE text' })
  @ValidateIf((value: UploadEphemerisDto) => value.sourceType === 'TLE')
  @IsString()
  @MaxLength(16384)
  tleText?: string;

  @ApiPropertyOptional({ description: 'Required absolute UTC epoch for decoded 3GPP ephemeris' })
  @ValidateIf((value: UploadEphemerisDto) => value.sourceType !== 'TLE')
  @IsISO8601({ strict: true })
  epochUtc?: string;

  @ApiPropertyOptional({ type: 'object', additionalProperties: true, description: 'Decoded SI-unit 3GPP positionVelocity or orbital object' })
  @ValidateIf((value: UploadEphemerisDto) => value.sourceType !== 'TLE')
  @IsObject()
  data?: Record<string, unknown>;

  @ApiPropertyOptional({ example: '3GPP TS 38.331 Release 17' }) @IsOptional() @IsString() @MaxLength(120) formatVersion?: string;
  @ApiPropertyOptional() @IsOptional() @IsISO8601({ strict: true }) validFrom?: string;
  @ApiPropertyOptional() @IsOptional() @IsISO8601({ strict: true }) validTo?: string;
  @ApiPropertyOptional({ default: true }) @IsOptional() @IsBoolean() activate = true;
}

export class CreateTransparentAssignmentDto {
  @ApiProperty() @IsUUID() spaceAssetId!: string;
  @ApiProperty() @IsUUID() radioTargetId!: string;
  @ApiPropertyOptional() @IsOptional() @IsISO8601({ strict: true }) validFrom?: string;
  @ApiPropertyOptional() @IsOptional() @IsISO8601({ strict: true }) validTo?: string;
  @ApiPropertyOptional({ type: 'object', additionalProperties: true }) @IsOptional() @IsObject() attributes?: Record<string, unknown>;
}

export class UpdateSitePassConfigurationDto {
  @ApiProperty() @IsUUID() siteId!: string;
  @ApiProperty() @IsUUID() spaceAssetId!: string;
  @ApiPropertyOptional({ default: 10, minimum: -5, maximum: 90 }) @IsOptional() @Type(() => Number) @Min(-5) @Max(90) minimumElevationDeg?: number;
  @ApiPropertyOptional({ default: 7, minimum: 1, maximum: 90 }) @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(90) predictionHorizonDays?: number;
  @ApiPropertyOptional({ default: true }) @IsOptional() @IsBoolean() enabled = true;
}

export class NtnPassQueryDto {
  @ApiPropertyOptional() @IsOptional() @IsUUID() siteId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() spaceAssetId?: string;
  @ApiPropertyOptional() @IsOptional() @IsISO8601({ strict: true }) from?: string;
  @ApiPropertyOptional() @IsOptional() @IsISO8601({ strict: true }) to?: string;
  @ApiPropertyOptional({ default: 100, minimum: 1, maximum: 1000 }) @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(1000) limit = 100;
}

export class NtnTrackQueryDto {
  @ApiPropertyOptional({ default: 90, minimum: 10, maximum: 360 }) @IsOptional() @Type(() => Number) @IsInt() @Min(10) @Max(360) minutes = 90;
  @ApiPropertyOptional({ default: 60, minimum: 10, maximum: 300 }) @IsOptional() @Type(() => Number) @IsInt() @Min(10) @Max(300) stepSeconds = 60;
}
