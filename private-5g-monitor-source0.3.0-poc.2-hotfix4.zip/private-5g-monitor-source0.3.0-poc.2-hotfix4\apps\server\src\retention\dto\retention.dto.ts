import { Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsInt, Max, Min } from 'class-validator';

export class UpdateRetentionPolicyDto {
  @ApiProperty({ default: true }) @IsBoolean() enabled!: boolean;
  @ApiProperty({ default: 7, minimum: 1, maximum: 3650 }) @Type(() => Number) @IsInt() @Min(1) @Max(3650) retentionDays!: number;
}
