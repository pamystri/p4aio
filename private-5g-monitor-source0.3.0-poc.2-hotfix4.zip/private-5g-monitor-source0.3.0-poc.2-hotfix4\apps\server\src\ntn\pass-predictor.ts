import type { EphemerisView, PredictedPassInput, SitePassConfigurationView } from '@application/ntn/ntn.repository';
import { lookAngle } from './trajectory/trajectory-provider';
import { TrajectoryRegistryService } from './trajectory/trajectory-registry.service';

const predictionVersion = 'site-pass-v1';

/** Pure geometric AOS/LOS predictor; it deliberately makes no RF coverage claim. */
export class PassPredictor {
  constructor(
    private readonly trajectories: TrajectoryRegistryService,
    private readonly stepSeconds: number,
  ) {}

  predict(configuration: SitePassConfigurationView, ephemeris: EphemerisView, from: Date, to: Date): PredictedPassInput[] {
    if (configuration.siteLatitude === null || configuration.siteLongitude === null) return [];
    const site = {
      latitude: configuration.siteLatitude,
      longitude: configuration.siteLongitude,
      altitudeM: configuration.siteAltitudeM ?? 0,
    };
    const stepMs = this.stepSeconds * 1000;
    const passes: PredictedPassInput[] = [];
    let previousTime = from;
    let previousLook = lookAngle(this.trajectories.propagate(ephemeris, from), site);
    let current: { aosAt: Date; aosAzimuthDeg: number; maximumElevationAt: Date; maximumElevationDeg: number; minimumSlantRangeM: number } | null =
      previousLook.elevationDeg >= configuration.minimumElevationDeg
        ? { aosAt: from, aosAzimuthDeg: previousLook.azimuthDeg, maximumElevationAt: from, maximumElevationDeg: previousLook.elevationDeg, minimumSlantRangeM: previousLook.slantRangeM }
        : null;

    for (let timestamp = from.getTime() + stepMs; timestamp <= to.getTime(); timestamp += stepMs) {
      const time = new Date(timestamp);
      const currentLook = lookAngle(this.trajectories.propagate(ephemeris, time), site);
      const previouslyAbove = previousLook.elevationDeg >= configuration.minimumElevationDeg;
      const currentlyAbove = currentLook.elevationDeg >= configuration.minimumElevationDeg;
      if (!previouslyAbove && currentlyAbove) {
        const aosAt = this.refineCrossing(ephemeris, site, previousTime, time, configuration.minimumElevationDeg, true);
        const aosLook = lookAngle(this.trajectories.propagate(ephemeris, aosAt), site);
        current = { aosAt, aosAzimuthDeg: aosLook.azimuthDeg, maximumElevationAt: time, maximumElevationDeg: currentLook.elevationDeg, minimumSlantRangeM: currentLook.slantRangeM };
      }
      if (current && currentlyAbove) {
        if (currentLook.elevationDeg > current.maximumElevationDeg) {
          current.maximumElevationDeg = currentLook.elevationDeg;
          current.maximumElevationAt = time;
        }
        current.minimumSlantRangeM = Math.min(current.minimumSlantRangeM, currentLook.slantRangeM);
      }
      if (current && previouslyAbove && !currentlyAbove) {
        const losAt = this.refineCrossing(ephemeris, site, previousTime, time, configuration.minimumElevationDeg, false);
        const losLook = lookAngle(this.trajectories.propagate(ephemeris, losAt), site);
        passes.push({
          ...current,
          losAt,
          losAzimuthDeg: losLook.azimuthDeg,
          predictionVersion,
          details: { minimumElevationDeg: configuration.minimumElevationDeg, geometricOnly: true },
        });
        current = null;
      }
      previousTime = time;
      previousLook = currentLook;
    }
    return passes;
  }

  private refineCrossing(
    ephemeris: EphemerisView,
    site: { latitude: number; longitude: number; altitudeM: number },
    lower: Date,
    upper: Date,
    threshold: number,
    rising: boolean,
  ): Date {
    let low = lower.getTime();
    let high = upper.getTime();
    for (let iteration = 0; iteration < 14; iteration += 1) {
      const middle = Math.floor((low + high) / 2);
      const above = lookAngle(this.trajectories.propagate(ephemeris, new Date(middle)), site).elevationDeg >= threshold;
      if (above === rising) high = middle;
      else low = middle;
    }
    return new Date(Math.floor((low + high) / 2));
  }
}

