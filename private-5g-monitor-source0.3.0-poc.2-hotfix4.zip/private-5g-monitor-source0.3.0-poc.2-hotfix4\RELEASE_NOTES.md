# Private 5G Monitor 0.3.0-poc.2

## Added

- An observability-first dashboard with traffic, radio-quality, live UE/IP, location confidence, collector health, and alerts.
- A map-centric Network Map with KPI ribbon, large terrestrial/NTN map, active UE detail, pass state, traffic, and alerts.
- A persistent historical-retention policy. Operators can select 1, 3, 7, 14, 30, 90, or 365 days in Settings, enable automatic cleanup, or run cleanup immediately.
- Dependency-ordered, bounded PostgreSQL cleanup for raw responses, parsed metrics, poll history, alarms, location estimates/evidence, ended UE correlation records, audit events, and expired pass predictions.
- Retention status and storage-size APIs at `GET/PUT /api/v1/retention` and `POST /api/v1/retention/run`.

## Corrected

- Live WebSocket events no longer cancel and restart every in-flight REST request. Each resource now uses a single-flight request with at most one trailing refresh, preventing browser-driven Prisma pool exhaustion and a permanently updating Network Map.
- Collector status that has not loaded is displayed as unavailable instead of the misleading `0/0` healthy count.
- Prisma interactive transactions may wait up to 15 seconds for a connection and run for up to 60 seconds, preventing normal metric persistence from expiring at the five-second client default.
- The dashboard's six-hour rolling Network Traffic view no longer returns HTTP 500 when PostgreSQL supplies aggregate sample counts as `bigint`; historical metric responses now expose only JSON-safe numbers.
- Network Map background refreshes no longer unmount Leaflet, reload map tiles, or reset pan/zoom every few seconds. Existing data remains visible, rapid live events are coalesced, and bounds are fitted only when topology changes.
- Changing Amarisoft `ran_ue_id` values no longer create a current UE binding with missing gNB state. A new MME binding carries the same UE's recent gNB target, serving cell, and `last_gnb_seen_at` within the configured correlation window.
- Current UE and map state consistently select the newest non-null gNB observation across historical bindings.
- Current traffic and radio-quality displays accept integer-backed as well as floating-point observations.

## Upgrade notes

- Apply migration `20260805000000_configurable_retention`.
- Copy the `retention:` block and `uePresence.correlationWindowMs` from `config/production.yaml` into the protected production configuration.
- The default policy keeps seven days and runs every six hours. The first cleanup may need several scheduled cycles when a database already contains a large backlog.

## Scope unchanged

NTN support remains transparent-payload, geometric site-pass awareness only. RF coverage, beams, gateways, link budgets, regenerative payloads, and automatic public TLE retrieval remain out of scope.
