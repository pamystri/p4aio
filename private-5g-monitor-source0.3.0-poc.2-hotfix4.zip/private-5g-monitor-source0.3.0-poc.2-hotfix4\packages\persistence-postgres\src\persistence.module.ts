import { Global, Module } from '@nestjs/common';
import { SITE_REPOSITORY } from '@application/sites/site.repository';
import { PrismaService } from '@persistence/prisma/prisma.service';
import { PrismaSiteRepository } from '@persistence/repositories/prisma-site.repository';
import { PrismaPollScheduleRepository } from '@persistence/repositories/prisma-poll-schedule.repository';
import { POLL_SCHEDULE_REPOSITORY } from '@application/scheduler/poll-schedule.repository';
import { COLLECTION_REPOSITORY } from '@application/collection/collection.repository';
import { PrismaCollectionRepository } from '@persistence/repositories/prisma-collection.repository';
import { RADIO_TARGET_REPOSITORY } from '@application/targets/radio-target.repository';
import { PrismaRadioTargetRepository } from '@persistence/repositories/prisma-radio-target.repository';
import { MONITORING_QUERY_REPOSITORY } from '@application/monitoring/monitoring-query.repository';
import { PrismaMonitoringQueryRepository } from '@persistence/repositories/prisma-monitoring-query.repository';
import { LOCATION_ESTIMATION_REPOSITORY } from '@application/location/location-estimation.repository';
import { PrismaLocationEstimationRepository } from '@persistence/repositories/prisma-location-estimation.repository';
import { NTN_REPOSITORY } from '@application/ntn/ntn.repository';
import { PrismaNtnRepository } from '@persistence/repositories/prisma-ntn.repository';
import { RETENTION_REPOSITORY } from '@application/retention/retention.repository';
import { PrismaRetentionRepository } from '@persistence/repositories/prisma-retention.repository';

@Global()
@Module({
  providers: [
    PrismaService,
    { provide: SITE_REPOSITORY, useClass: PrismaSiteRepository },
    { provide: POLL_SCHEDULE_REPOSITORY, useClass: PrismaPollScheduleRepository },
    { provide: COLLECTION_REPOSITORY, useClass: PrismaCollectionRepository },
    { provide: RADIO_TARGET_REPOSITORY, useClass: PrismaRadioTargetRepository },
    { provide: MONITORING_QUERY_REPOSITORY, useClass: PrismaMonitoringQueryRepository },
    { provide: LOCATION_ESTIMATION_REPOSITORY, useClass: PrismaLocationEstimationRepository },
    { provide: NTN_REPOSITORY, useClass: PrismaNtnRepository },
    { provide: RETENTION_REPOSITORY, useClass: PrismaRetentionRepository },
  ],
  exports: [
    PrismaService,
    SITE_REPOSITORY,
    POLL_SCHEDULE_REPOSITORY,
    COLLECTION_REPOSITORY,
    RADIO_TARGET_REPOSITORY,
    MONITORING_QUERY_REPOSITORY,
    LOCATION_ESTIMATION_REPOSITORY,
    NTN_REPOSITORY,
    RETENTION_REPOSITORY,
  ],
})
export class PersistenceModule {}
