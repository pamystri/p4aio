import { Module } from '@nestjs/common';
import { LiveModule } from '@app/live/live.module';
import { NtnController } from './ntn.controller';
import { NtnService } from './ntn.service';
import { NtnRuntimeWorker } from './ntn-runtime.worker';
import { PassPredictionService } from './pass-prediction.service';
import { TleSgp4TrajectoryProvider } from './trajectory/tle-sgp4.provider';
import { ThreeGppTrajectoryProvider } from './trajectory/three-gpp.provider';
import { TrajectoryRegistryService } from './trajectory/trajectory-registry.service';

/** Transparent-payload NTN module. It performs orbit display and site-pass prediction only. */
@Module({
  imports: [LiveModule], controllers: [NtnController],
  providers: [NtnService, NtnRuntimeWorker, PassPredictionService, TleSgp4TrajectoryProvider, ThreeGppTrajectoryProvider, TrajectoryRegistryService],
  exports: [NtnService, PassPredictionService, NtnRuntimeWorker],
})
export class NtnModule {}
