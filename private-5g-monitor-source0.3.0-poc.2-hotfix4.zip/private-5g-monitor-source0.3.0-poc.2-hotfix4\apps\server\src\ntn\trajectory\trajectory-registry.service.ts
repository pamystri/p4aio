import { Injectable } from '@nestjs/common';
import type { EphemerisView } from '@application/ntn/ntn.repository';
import type { TrajectoryProvider, TrajectoryState } from './trajectory-provider';
import { TleSgp4TrajectoryProvider } from './tle-sgp4.provider';
import { ThreeGppTrajectoryProvider } from './three-gpp.provider';

/** Resolves ephemeris formats without coupling consumers to their propagator. */
@Injectable()
export class TrajectoryRegistryService {
  private readonly providers: TrajectoryProvider[];

  constructor(tle: TleSgp4TrajectoryProvider, threeGpp: ThreeGppTrajectoryProvider) {
    this.providers = [tle, threeGpp];
  }

  propagate(ephemeris: EphemerisView, at: Date): TrajectoryState {
    const provider = this.providers.find((candidate) => candidate.supports(ephemeris.sourceType));
    if (!provider) throw new Error(`No trajectory provider supports ${ephemeris.sourceType}`);
    return provider.propagate(ephemeris, at);
  }
}
