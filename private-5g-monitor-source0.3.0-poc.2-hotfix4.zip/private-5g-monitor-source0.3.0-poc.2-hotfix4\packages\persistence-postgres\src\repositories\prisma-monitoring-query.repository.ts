import { Injectable } from '@nestjs/common';
import { Prisma, type RadioObservation } from '@prisma/client';
import type {
  AggregateMetricFilters, AggregatedMetricView, AlarmFilters, AlarmView, CellView,
  CollectorStatusView, EntityFilters, LocationView, MetricFilters, MetricView,
  MonitoringQueryRepository, Page, UeView,
} from '@application/monitoring/monitoring-query.repository';
import { PrismaService } from '@persistence/prisma/prisma.service';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class PrismaMonitoringQueryRepository implements MonitoringQueryRepository {
  private readonly radioActiveWithinMs: number;

  constructor(private readonly prisma: PrismaService, config: ConfigService) {
    this.radioActiveWithinMs = config.getOrThrow<number>('uePresence.radioActiveWithinMs');
  }

  async listCells(filters: EntityFilters): Promise<Page<CellView>> {
    const rows = await this.prisma.cell.findMany({
      where: {
        ...(filters.targetId ? { radioTargetId: filters.targetId } : {}),
        ...(filters.siteId ? { radioTarget: { siteId: filters.siteId } } : {}),
        ...(filters.search ? { OR: [{ displayName: { contains: filters.search, mode: 'insensitive' } }, { vendorCellKey: { contains: filters.search, mode: 'insensitive' } }] } : {}),
      },
      include: { radioTarget: { select: { siteId: true } } },
      take: filters.limit + 1,
      orderBy: { id: filters.sort },
      ...(filters.cursor ? { cursor: { id: filters.cursor }, skip: 1 } : {}),
    });
    return this.page(rows, filters.limit, (row) => row.id, (row) => ({
      id: row.id, targetId: row.radioTargetId, siteId: row.radioTarget.siteId,
      vendorCellKey: row.vendorCellKey, displayName: row.displayName, technology: row.technology,
      pci: row.pci, arfcn: row.arfcn, lastSeenAt: row.lastSeenAt,
    }));
  }

  async getCell(id: string): Promise<CellView | null> {
    const row = await this.prisma.cell.findUnique({ where: { id }, include: { radioTarget: { select: { siteId: true } } } });
    return row ? { id: row.id, targetId: row.radioTargetId, siteId: row.radioTarget.siteId, vendorCellKey: row.vendorCellKey, displayName: row.displayName, technology: row.technology, pci: row.pci, arfcn: row.arfcn, lastSeenAt: row.lastSeenAt } : null;
  }

  async listUes(filters: EntityFilters): Promise<Page<UeView>> {
    const activeSince = new Date(Date.now() - this.radioActiveWithinMs);
    const rows = await this.prisma.ue.findMany({
      where: {
        ...(filters.search ? { pseudonym: { contains: filters.search, mode: 'insensitive' as const } } : {}),
        ...(filters.siteId ? { radioBindings: { some: { siteId: filters.siteId } } } : {}),
        ...(filters.targetId ? {
          OR: [
            { registrations: { some: { mmeTargetId: filters.targetId } } },
            { radioBindings: { some: { OR: [{ mmeTargetId: filters.targetId }, { gnbTargetId: filters.targetId }] } } },
          ],
        } : {}),
      },
      include: {
        registrations: { orderBy: { lastSeenAt: 'desc' }, select: { registered: true, lastSeenAt: true } },
        sessions: { where: { endedAt: null }, orderBy: { lastSeenAt: 'desc' }, select: { ipAddress: true } },
        radioBindings: { orderBy: { lastGnbSeenAt: 'desc' }, select: { siteId: true, lastMmeSeenAt: true, lastGnbSeenAt: true } },
      },
      take: filters.limit + 1, orderBy: { id: filters.sort },
      ...(filters.cursor ? { cursor: { id: filters.cursor }, skip: 1 } : {}),
    });
    return this.page(rows, filters.limit, (row) => row.id, (row) => {
      const lastRadioSeenAt = row.radioBindings.find((binding) => binding.lastGnbSeenAt)?.lastGnbSeenAt ?? null;
      return {
        id: row.id,
        pseudonym: row.pseudonym,
        firstSeenAt: row.firstSeenAt,
        lastSeenAt: row.lastSeenAt,
        registrationStatus: row.registrations.some((registration) => registration.registered) ? 'registered' : 'deregistered',
        radioStatus: lastRadioSeenAt && lastRadioSeenAt >= activeSince ? 'active' : 'idle',
        ipAddresses: [...new Set(row.sessions.map((session) => session.ipAddress))],
        lastMmeSeenAt: row.registrations[0]?.lastSeenAt ?? row.radioBindings[0]?.lastMmeSeenAt ?? null,
        lastRadioSeenAt,
        siteIds: [...new Set(row.radioBindings.map((binding) => binding.siteId))],
      };
    });
  }

  async getUe(id: string): Promise<UeView | null> {
    const row = await this.prisma.ue.findUnique({
      where: { id },
      include: {
        registrations: { orderBy: { lastSeenAt: 'desc' }, select: { registered: true, lastSeenAt: true } },
        sessions: { where: { endedAt: null }, orderBy: { lastSeenAt: 'desc' }, select: { ipAddress: true } },
        radioBindings: { orderBy: { lastGnbSeenAt: 'desc' }, select: { siteId: true, lastMmeSeenAt: true, lastGnbSeenAt: true } },
      },
    });
    if (!row) return null;
    const lastRadioSeenAt = row.radioBindings.find((binding) => binding.lastGnbSeenAt)?.lastGnbSeenAt ?? null;
    return {
      id: row.id,
      pseudonym: row.pseudonym,
      firstSeenAt: row.firstSeenAt,
      lastSeenAt: row.lastSeenAt,
      registrationStatus: row.registrations.some((registration) => registration.registered) ? 'registered' : 'deregistered',
      radioStatus: lastRadioSeenAt && lastRadioSeenAt >= new Date(Date.now() - this.radioActiveWithinMs) ? 'active' : 'idle',
      ipAddresses: [...new Set(row.sessions.map((session) => session.ipAddress))],
      lastMmeSeenAt: row.registrations[0]?.lastSeenAt ?? row.radioBindings[0]?.lastMmeSeenAt ?? null,
      lastRadioSeenAt,
      siteIds: [...new Set(row.radioBindings.map((binding) => binding.siteId))],
    };
  }

  async currentMetrics(filters: Omit<MetricFilters, 'from' | 'to'>): Promise<Page<MetricView>> {
    const rows = await this.prisma.radioObservation.findMany({
      where: this.metricWhere(filters), include: { metricDefinition: true },
      orderBy: [{ observedAt: 'desc' }, { id: 'desc' }], take: Math.min(5000, filters.limit * 20),
      ...(filters.cursor ? { cursor: { id: BigInt(filters.cursor) }, skip: 1 } : {}),
    });
    const seen = new Set<string>();
    const unique = rows.filter((row) => {
      const dimensionHash = Buffer.from(row.dimensionHash).toString('hex');
      const key = `${row.metricDefinitionId}:${row.cellId ?? ''}:${row.ueId ?? ''}:${row.radioTargetId}:${dimensionHash}`;
      if (seen.has(key)) return false; seen.add(key); return true;
    });
    return this.metricPage(unique, filters.limit);
  }

  async historicalMetrics(filters: MetricFilters): Promise<Page<MetricView>> {
    const rows = await this.prisma.radioObservation.findMany({
      where: { ...this.metricWhere(filters), observedAt: { gte: filters.from, lte: filters.to } },
      include: { metricDefinition: true }, take: filters.limit + 1,
      orderBy: [{ observedAt: filters.sort }, { id: filters.sort }],
      ...(filters.cursor ? { cursor: { id: BigInt(filters.cursor) }, skip: 1 } : {}),
    });
    return this.metricPage(rows, filters.limit);
  }

  async aggregateMetrics(filters: AggregateMetricFilters): Promise<AggregatedMetricView[]> {
    const bucket = { minute: Prisma.sql`date_trunc('minute', ro.observed_at)`, hour: Prisma.sql`date_trunc('hour', ro.observed_at)`, day: Prisma.sql`date_trunc('day', ro.observed_at)` }[filters.bucket];
    const numeric = Prisma.sql`COALESCE(ro.value_double, ro.value_integer::double precision)`;
    const aggregate = { avg: Prisma.sql`AVG(${numeric})`, sum: Prisma.sql`SUM(${numeric})`, min: Prisma.sql`MIN(${numeric})`, max: Prisma.sql`MAX(${numeric})` }[filters.aggregation];
    const conditions: Prisma.Sql[] = [Prisma.sql`ro.observed_at >= ${filters.from}`, Prisma.sql`ro.observed_at <= ${filters.to}`, Prisma.sql`(ro.value_double IS NOT NULL OR ro.value_integer IS NOT NULL)`];
    if (filters.siteId) conditions.push(Prisma.sql`rt.site_id = ${filters.siteId}::uuid`);
    if (filters.targetId) conditions.push(Prisma.sql`ro.radio_target_id = ${filters.targetId}::uuid`);
    if (filters.cellId) conditions.push(Prisma.sql`ro.cell_id = ${filters.cellId}::uuid`);
    if (filters.ueId) conditions.push(Prisma.sql`ro.ue_id = ${filters.ueId}::uuid`);
    if (filters.metric) conditions.push(Prisma.sql`(md.namespace || '.' || md.key) = ${filters.metric}`);
    const rows = await this.prisma.$queryRaw<Array<{ bucket: Date; metric: string; unit: string; value: number; sample_count: bigint }>>(Prisma.sql`
      SELECT ${bucket} AS bucket,
             md.namespace || '.' || md.key AS metric, md.unit, ${aggregate} AS value, COUNT(*) AS sample_count
      FROM radio_observation ro
      JOIN metric_definition md ON md.id = ro.metric_definition_id
      JOIN radio_target rt ON rt.id = ro.radio_target_id
      WHERE ${Prisma.join(conditions, ' AND ')}
      GROUP BY bucket, md.namespace, md.key, md.unit
      ORDER BY bucket ${filters.sort === 'asc' ? Prisma.sql`ASC` : Prisma.sql`DESC`}
      LIMIT ${filters.limit}`);
    // PostgreSQL returns COUNT(*) as bigint. Build the public view explicitly so
    // the raw sample_count bigint is not retained and later passed to JSON.stringify.
    return rows.map((row) => ({
      bucket: row.bucket,
      metric: row.metric,
      unit: row.unit,
      value: Number(row.value),
      sampleCount: Number(row.sample_count),
    }));
  }

  async alarms(filters: AlarmFilters): Promise<Page<AlarmView>> {
    const rows = await this.prisma.domainEvent.findMany({
      where: { occurredAt: { gte: filters.from, lte: filters.to }, severity: filters.severity ?? { in: ['warning', 'error', 'critical'] }, ...(filters.targetId ? { radioTargetId: filters.targetId } : {}), ...(filters.siteId ? { radioTarget: { siteId: filters.siteId } } : {}) },
      take: filters.currentOnly ? Math.min(5000, filters.limit * 20) : filters.limit + 1,
      orderBy: [{ occurredAt: filters.currentOnly ? 'desc' : filters.sort }, { id: filters.currentOnly ? 'desc' : filters.sort }],
      ...(filters.cursor ? { cursor: { id: BigInt(filters.cursor) }, skip: 1 } : {}),
    });
    const selected = filters.currentOnly ? this.latestAlarms(rows) : rows;
    return this.page(selected, filters.limit, (row) => row.id.toString(), (row) => ({ id: row.id.toString(), occurredAt: row.occurredAt, type: row.eventType, category: row.category, severity: row.severity, entityType: row.entityType, targetId: row.radioTargetId, cellId: row.cellId, ueId: row.ueId, message: row.message, details: row.details as object }));
  }

  async collectorStatus(siteId?: string, targetId?: string): Promise<CollectorStatusView[]> {
    const targets = await this.prisma.radioTarget.findMany({ where: { ...(siteId ? { siteId } : {}), ...(targetId ? { id: targetId } : {}) }, include: { pollSchedules: true, collectionRuns: { take: 1, orderBy: { startedAt: 'desc' } } }, orderBy: { name: 'asc' } });
    return targets.map((target) => ({ targetId: target.id, targetName: target.name, enabled: target.enabled, lastSuccessAt: target.lastSuccessAt, lastRunStatus: target.collectionRuns[0]?.status ?? null, lastRunAt: target.collectionRuns[0]?.startedAt ?? null, schedules: target.pollSchedules.map((schedule) => ({ operation: schedule.logicalOperation, enabled: schedule.enabled, intervalMs: schedule.intervalMs, nextDueAt: schedule.nextDueAt })) }));
  }

  async currentLocations(siteId?: string, targetId?: string, limit = 1000): Promise<LocationView[]> {
    const rows = await this.prisma.locationEstimate.findMany({
      where: (siteId || targetId) ? { servingCell: { is: { radioTarget: { ...(siteId ? { siteId } : {}), ...(targetId ? { id: targetId } : {}) } } } } : {},
      include: { ue: { select: { pseudonym: true, sessions: { where: { endedAt: null }, select: { ipAddress: true } }, radioBindings: { where: { lastGnbSeenAt: { not: null } }, orderBy: { lastGnbSeenAt: 'desc' }, take: 1, select: { lastGnbSeenAt: true } } } }, servingCell: { select: { displayName: true, radioTarget: { select: { siteId: true } } } } },
      orderBy: [{ estimatedAt: 'desc' }, { id: 'desc' }], take: Math.min(5000, limit * 10),
    });
    const seen = new Set<string>();
    const activeSince = new Date(Date.now() - this.radioActiveWithinMs);
    return rows.filter((row) => { if (seen.has(row.ueId)) return false; seen.add(row.ueId); return true; }).slice(0, limit).map((row) => ({
      id: row.id.toString(), ueId: row.ueId, pseudonym: row.ue.pseudonym, estimatedAt: row.estimatedAt,
      latitude: row.latitude, longitude: row.longitude, altitudeM: row.altitudeM,
      horizontalAccuracyM: row.horizontalAccuracyM, confidence: row.confidence,
      method: row.method, algorithmVersion: row.algorithmVersion, servingCellId: row.servingCellId,
      servingCellName: row.servingCell?.displayName ?? null, siteId: row.servingCell?.radioTarget.siteId ?? null,
      radioStatus: row.ue.radioBindings[0]?.lastGnbSeenAt && row.ue.radioBindings[0].lastGnbSeenAt >= activeSince ? 'active' : 'idle',
      ipAddresses: [...new Set(row.ue.sessions.map((session) => session.ipAddress))],
      details: row.details as object,
    }));
  }

  async statistics(siteId?: string, targetId?: string): Promise<Record<string, number>> {
    const targetWhere = { ...(siteId ? { siteId } : {}), ...(targetId ? { id: targetId } : {}) };
    const observationWhere = { ...(targetId ? { radioTargetId: targetId } : {}), ...(siteId ? { radioTarget: { siteId } } : {}) };
    const since = new Date(Date.now() - 5 * 60_000);
    const activeSince = new Date(Date.now() - this.radioActiveWithinMs);
    const [sites, targets, cells, activeUes, alarms, failedPolls] = await Promise.all([
      this.prisma.site.count({ where: siteId ? { id: siteId } : {} }), this.prisma.radioTarget.count({ where: targetWhere }),
      this.prisma.cell.count({ where: { radioTarget: targetWhere } }), this.prisma.ue.count({ where: { radioBindings: { some: { lastGnbSeenAt: { gte: activeSince }, ...(siteId ? { siteId } : {}), ...(targetId ? { OR: [{ gnbTargetId: targetId }, { mmeTargetId: targetId }] } : {}) } } } }),
      this.prisma.domainEvent.count({ where: { occurredAt: { gte: new Date(Date.now() - 86_400_000) }, severity: { in: ['warning', 'error', 'critical'] }, ...(targetId ? { radioTargetId: targetId } : {}), ...(siteId ? { radioTarget: { siteId } } : {}) } }),
      this.prisma.collectionRun.count({ where: { status: 'FAILED', startedAt: { gte: new Date(Date.now() - 86_400_000) }, ...observationWhere } }),
    ]);
    const throughputConditions: Prisma.Sql[] = [
      Prisma.sql`(md.namespace || '.' || md.key) IN ('radio.ue.dl_bitrate', 'radio.ue.ul_bitrate')`,
      Prisma.sql`ro.observed_at >= ${since}`,
    ];
    if (siteId) throughputConditions.push(Prisma.sql`rt.site_id = ${siteId}::uuid`);
    if (targetId) throughputConditions.push(Prisma.sql`ro.radio_target_id = ${targetId}::uuid`);
    const throughput = await this.prisma.$queryRaw<Array<{ metric: string; value: number }>>(Prisma.sql`
      WITH latest AS (
        SELECT DISTINCT ON (ro.ue_id, ro.metric_definition_id)
          md.namespace || '.' || md.key AS metric,
          COALESCE(ro.value_double, ro.value_integer::double precision) AS numeric_value
        FROM radio_observation ro
        JOIN metric_definition md ON md.id = ro.metric_definition_id
        JOIN radio_target rt ON rt.id = ro.radio_target_id
        WHERE ${Prisma.join(throughputConditions, ' AND ')}
          AND (ro.value_double IS NOT NULL OR ro.value_integer IS NOT NULL)
        ORDER BY ro.ue_id, ro.metric_definition_id, ro.observed_at DESC
      ) SELECT metric, SUM(numeric_value) AS value FROM latest GROUP BY metric`);
    const totals = Object.fromEntries(throughput.map((item) => [item.metric.endsWith('dl_bitrate') ? 'totalDlBitrate' : 'totalUlBitrate', Number(item.value)]));
    return { sites, targets, cells, activeUes, alarmsLast24Hours: alarms, failedPollsLast24Hours: failedPolls, totalDlBitrate: 0, totalUlBitrate: 0, ...totals };
  }

  private metricWhere(filters: Partial<MetricFilters>): Prisma.RadioObservationWhereInput {
    return { ...(filters.targetId ? { radioTargetId: filters.targetId } : {}), ...(filters.siteId ? { radioTarget: { siteId: filters.siteId } } : {}), ...(filters.cellId ? { cellId: filters.cellId } : {}), ...(filters.ueId ? { ueId: filters.ueId } : {}), ...(filters.metric ? { metricDefinition: { is: { namespace: filters.metric.split('.').slice(0, -1).join('.'), key: filters.metric.split('.').at(-1) } } } : {}) };
  }

  private metricPage(rows: Array<RadioObservation & { metricDefinition: { namespace: string; key: string; unit: string; entityType: string } }>, limit: number): Page<MetricView> {
    return this.page(rows, limit, (row) => row.id.toString(), (row) => ({ id: row.id.toString(), observedAt: row.observedAt, metric: `${row.metricDefinition.namespace}.${row.metricDefinition.key}`, entityType: row.metricDefinition.entityType, targetId: row.radioTargetId, cellId: row.cellId, ueId: row.ueId, unit: row.metricDefinition.unit, value: this.value(row), dimensions: row.dimensions as object }));
  }

  private value(row: RadioObservation): number | string | boolean | object {
    if (row.valueDouble !== null) return row.valueDouble; if (row.valueInteger !== null) return row.valueInteger.toString();
    if (row.valueBoolean !== null) return row.valueBoolean; if (row.valueText !== null) return row.valueText;
    return (row.valueJson ?? {}) as object;
  }

  private latestAlarms<T extends { eventType: string; radioTargetId: string; cellId: string | null; ueId: string | null }>(rows: T[]): T[] {
    const seen = new Set<string>(); return rows.filter((row) => { const key = `${row.eventType}:${row.radioTargetId}:${row.cellId ?? ''}:${row.ueId ?? ''}`; if (seen.has(key)) return false; seen.add(key); return true; });
  }

  private page<T, R>(rows: T[], limit: number, cursor: (row: T) => string, map: (row: T) => R): Page<R> {
    const hasNext = rows.length > limit; const selected = hasNext ? rows.slice(0, limit) : rows;
    return { items: selected.map(map), nextCursor: hasNext ? cursor(selected[selected.length - 1] as T) : null };
  }
}
