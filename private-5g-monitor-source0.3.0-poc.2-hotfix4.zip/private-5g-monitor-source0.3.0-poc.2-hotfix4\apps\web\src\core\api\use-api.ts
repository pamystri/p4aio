'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { apiFetch } from './client';
import { useLive } from '@/core/live/live-context';

interface ApiResult<T> {
  path: string | null;
  data: T | null;
  error: string | null;
}

interface RequestState {
  path: string | null;
  inFlight: boolean;
}

interface ActiveRequest {
  path: string;
  controller: AbortController;
  allowTrailingRefresh: boolean;
}

/**
 * Fetches an API resource without allowing live-update events to create a
 * request storm. One request per hook may run at a time. Events received while
 * the primary request is running are coalesced into at most one trailing
 * refresh; events received during that trailing refresh are satisfied by its
 * result. Requests are aborted only when the resource path changes or the
 * component unmounts.
 */
export function useApi<T>(path: string | null) {
  const { generation } = useLive();
  const [result, setResult] = useState<ApiResult<T>>({ path: null, data: null, error: null });
  const [requestState, setRequestState] = useState<RequestState>({ path: null, inFlight: false });
  const mounted = useRef(false);
  const currentPath = useRef<string | null>(path);
  const activeRequest = useRef<ActiveRequest | null>(null);
  const trailingRefreshQueued = useRef(false);

  const startRequest = useCallback(function executeRequest(
    requestedPath: string,
    allowTrailingRefresh: boolean,
  ): void {
    if (!mounted.current || currentPath.current !== requestedPath) return;

    const active = activeRequest.current;
    if (active) {
      if (active.path === requestedPath && active.allowTrailingRefresh) {
        trailingRefreshQueued.current = true;
      }
      return;
    }

    const controller = new AbortController();
    activeRequest.current = { path: requestedPath, controller, allowTrailingRefresh };
    setRequestState({ path: requestedPath, inFlight: true });

    void apiFetch<T>(requestedPath, controller.signal)
      .then((data) => {
        if (!controller.signal.aborted && mounted.current && currentPath.current === requestedPath) {
          setResult({ path: requestedPath, data, error: null });
        }
      })
      .catch((reason: unknown) => {
        if (!controller.signal.aborted && mounted.current && currentPath.current === requestedPath) {
          setResult((previous) => ({
            path: requestedPath,
            data: previous.path === requestedPath ? previous.data : null,
            error: reason instanceof Error ? reason.message : 'Unable to load data',
          }));
        }
      })
      .finally(() => {
        if (activeRequest.current?.controller !== controller) return;
        activeRequest.current = null;
        if (!mounted.current || currentPath.current !== requestedPath) return;

        if (allowTrailingRefresh && trailingRefreshQueued.current) {
          trailingRefreshQueued.current = false;
          executeRequest(requestedPath, false);
          return;
        }

        trailingRefreshQueued.current = false;
        setRequestState({ path: requestedPath, inFlight: false });
      });
  }, []);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      trailingRefreshQueued.current = false;
      const active = activeRequest.current;
      activeRequest.current = null;
      active?.controller.abort();
    };
  }, []);

  useEffect(() => {
    const active = activeRequest.current;
    if (currentPath.current !== path) {
      currentPath.current = path;
      trailingRefreshQueued.current = false;
      if (active) {
        activeRequest.current = null;
        active.controller.abort();
      }
    }

    if (path === null) return;
    startRequest(path, true);
  }, [generation, path, startRequest]);

  const data = result.path === path ? result.data : null;
  const error = result.path === path ? result.error : null;
  const inFlight = requestState.path === path && requestState.inFlight;
  const settled = result.path === path && (result.data !== null || result.error !== null);
  return {
    data,
    error,
    loading: path !== null && data === null && (!settled || inFlight),
    refreshing: path !== null && data !== null && inFlight,
  };
}
