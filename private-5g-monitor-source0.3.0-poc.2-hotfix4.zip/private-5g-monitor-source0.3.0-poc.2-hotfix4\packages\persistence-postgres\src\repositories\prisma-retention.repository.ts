import { Injectable } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import type { RetentionBatchResult, RetentionPolicyView, RetentionRepository, RetentionStorageView } from '@application/retention/retention.repository';
import { PrismaService } from '@persistence/prisma/prisma.service';

/** Performs bounded, dependency-ordered retention deletes so polling can continue safely. */
@Injectable()
export class PrismaRetentionRepository implements RetentionRepository {
  constructor(private readonly prisma: PrismaService) {}

  async getPolicy(defaultDays: number, defaultEnabled: boolean): Promise<RetentionPolicyView> {
    return this.prisma.retentionPolicy.upsert({
      where: { id: 'default' },
      create: { id: 'default', enabled: defaultEnabled, retentionDays: defaultDays },
      update: {},
    });
  }

  async updatePolicy(enabled: boolean, retentionDays: number): Promise<RetentionPolicyView> {
    return this.prisma.retentionPolicy.upsert({
      where: { id: 'default' },
      create: { id: 'default', enabled, retentionDays },
      update: { enabled, retentionDays },
    });
  }

  async markStarted(startedAt: Date): Promise<void> {
    await this.prisma.retentionPolicy.update({ where: { id: 'default' }, data: { lastStartedAt: startedAt, lastStatus: 'RUNNING', lastError: null } });
  }

  async markCompleted(completedAt: Date, status: string, deletedRows: number): Promise<void> {
    await this.prisma.retentionPolicy.update({ where: { id: 'default' }, data: { lastCompletedAt: completedAt, lastStatus: status, lastDeletedRows: deletedRows, lastError: null } });
  }

  async markFailed(completedAt: Date, error: string): Promise<void> {
    await this.prisma.retentionPolicy.update({ where: { id: 'default' }, data: { lastCompletedAt: completedAt, lastStatus: 'FAILED', lastError: error.slice(0, 512) } });
  }

  async deleteBatch(cutoff: Date, batchSize: number): Promise<RetentionBatchResult> {
    const values = await this.prisma.$transaction(async (transaction) => {
      const locationEvidence = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM location_evidence le USING (
          SELECT le2.location_estimate_id, le2.radio_observation_id
          FROM location_evidence le2 JOIN radio_observation ro ON ro.id = le2.radio_observation_id
          WHERE ro.observed_at < ${cutoff} LIMIT ${batchSize}
        ) doomed
        WHERE le.location_estimate_id = doomed.location_estimate_id AND le.radio_observation_id = doomed.radio_observation_id`);
      const locationEstimates = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM location_estimate WHERE id IN (
          SELECT id FROM location_estimate WHERE estimated_at < ${cutoff} ORDER BY estimated_at LIMIT ${batchSize}
        )`);
      const domainEvents = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM domain_event WHERE id IN (
          SELECT id FROM domain_event WHERE occurred_at < ${cutoff} ORDER BY occurred_at LIMIT ${batchSize}
        )`);
      const radioObservations = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM radio_observation ro WHERE ro.id IN (
          SELECT candidate.id FROM radio_observation candidate
          WHERE candidate.observed_at < ${cutoff}
            AND NOT EXISTS (SELECT 1 FROM location_evidence le WHERE le.radio_observation_id = candidate.id)
          ORDER BY candidate.observed_at LIMIT ${batchSize}
        )`);
      const rawObservations = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM raw_observation ro WHERE ro.id IN (
          SELECT candidate.id FROM raw_observation candidate
          WHERE candidate.received_at < ${cutoff}
            AND NOT EXISTS (SELECT 1 FROM radio_observation obs WHERE obs.raw_observation_id = candidate.id)
            AND NOT EXISTS (SELECT 1 FROM domain_event event WHERE event.raw_observation_id = candidate.id)
          ORDER BY candidate.received_at LIMIT ${batchSize}
        )`);
      const collectionRuns = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM collection_run run WHERE run.id IN (
          SELECT candidate.id FROM collection_run candidate
          WHERE candidate.started_at < ${cutoff}
            AND NOT EXISTS (SELECT 1 FROM raw_observation raw WHERE raw.collection_run_id = candidate.id)
            AND NOT EXISTS (SELECT 1 FROM radio_observation obs WHERE obs.collection_run_id = candidate.id)
            AND NOT EXISTS (SELECT 1 FROM domain_event event WHERE event.collection_run_id = candidate.id)
          ORDER BY candidate.started_at LIMIT ${batchSize}
        )`);
      const auditEvents = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM audit_event WHERE id IN (
          SELECT id FROM audit_event WHERE occurred_at < ${cutoff} ORDER BY occurred_at LIMIT ${batchSize}
        )`);
      const endedSessions = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM ue_session WHERE id IN (
          SELECT id FROM ue_session WHERE ended_at < ${cutoff} ORDER BY ended_at LIMIT ${batchSize}
        )`);
      const endedRegistrations = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM ue_registration WHERE id IN (
          SELECT id FROM ue_registration WHERE ended_at < ${cutoff} ORDER BY ended_at LIMIT ${batchSize}
        )`);
      const endedRadioBindings = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM ue_radio_binding WHERE id IN (
          SELECT id FROM ue_radio_binding WHERE ended_at < ${cutoff} ORDER BY ended_at LIMIT ${batchSize}
        )`);
      const predictedPasses = await transaction.$executeRaw(Prisma.sql`
        DELETE FROM predicted_pass WHERE id IN (
          SELECT id FROM predicted_pass WHERE los_at < ${cutoff} ORDER BY los_at LIMIT ${batchSize}
        )`);
      return { locationEvidence, locationEstimates, radioObservations, domainEvents, rawObservations, collectionRuns, auditEvents, endedSessions, endedRegistrations, endedRadioBindings, predictedPasses };
    });
    return { ...values, total: Object.values(values).reduce((sum, value) => sum + value, 0) };
  }

  async storage(): Promise<RetentionStorageView> {
    const [database] = await this.prisma.$queryRaw<Array<{ bytes: bigint }>>(Prisma.sql`SELECT pg_database_size(current_database()) AS bytes`);
    const tables = await this.prisma.$queryRaw<Array<{ table: string; bytes: bigint }>>(Prisma.sql`
      SELECT relname::text AS table, pg_total_relation_size(relid) AS bytes
      FROM pg_catalog.pg_statio_user_tables
      ORDER BY pg_total_relation_size(relid) DESC LIMIT 12`);
    return { databaseBytes: Number(database?.bytes ?? 0n), tables: tables.map((item) => ({ table: item.table, bytes: Number(item.bytes) })) };
  }
}
