export const RETENTION_REPOSITORY = Symbol('RETENTION_REPOSITORY');

export interface RetentionPolicyView {
  enabled: boolean;
  retentionDays: number;
  lastStartedAt: Date | null;
  lastCompletedAt: Date | null;
  lastStatus: string | null;
  lastDeletedRows: number;
  lastError: string | null;
  updatedAt: Date;
}

export interface RetentionBatchResult {
  locationEvidence: number;
  locationEstimates: number;
  radioObservations: number;
  domainEvents: number;
  rawObservations: number;
  collectionRuns: number;
  auditEvents: number;
  endedSessions: number;
  endedRegistrations: number;
  endedRadioBindings: number;
  predictedPasses: number;
  total: number;
}

export interface RetentionStorageView {
  databaseBytes: number;
  tables: Array<{ table: string; bytes: number }>;
}

export interface RetentionRepository {
  getPolicy(defaultDays: number, defaultEnabled: boolean): Promise<RetentionPolicyView>;
  updatePolicy(enabled: boolean, retentionDays: number): Promise<RetentionPolicyView>;
  markStarted(startedAt: Date): Promise<void>;
  markCompleted(completedAt: Date, status: string, deletedRows: number): Promise<void>;
  markFailed(completedAt: Date, error: string): Promise<void>;
  deleteBatch(cutoff: Date, batchSize: number): Promise<RetentionBatchResult>;
  storage(): Promise<RetentionStorageView>;
}
