import { ConfigService } from '@nestjs/config';
import type { PinoLogger } from 'nestjs-pino';
import type { RetentionRepository } from '@application/retention/retention.repository';
import { RetentionService } from './retention.service';

describe('RetentionService', () => {
  const policy = {
    enabled: true,
    retentionDays: 7,
    lastStartedAt: null,
    lastCompletedAt: null,
    lastStatus: null,
    lastDeletedRows: 0,
    lastError: null,
    updatedAt: new Date('2026-08-05T00:00:00Z'),
  };

  it('deletes in bounded batches until no eligible rows remain', async () => {
    const repository = {
      getPolicy: jest.fn().mockResolvedValue(policy),
      markStarted: jest.fn(),
      markCompleted: jest.fn(),
      markFailed: jest.fn(),
      deleteBatch: jest.fn()
        .mockResolvedValueOnce(batch(3))
        .mockResolvedValueOnce(batch(0)),
    } as unknown as RetentionRepository;
    const service = new RetentionService(repository, config(), logger());

    const result = await service.runNow();

    expect(result.status).toBe('COMPLETED');
    expect(result.deletedRows).toBe(3);
    expect(repository.deleteBatch).toHaveBeenCalledTimes(2);
    expect(repository.markCompleted).toHaveBeenCalledWith(expect.any(Date), 'COMPLETED', 3);
  });

  it('does not run scheduled cleanup when the saved policy is disabled', async () => {
    const repository = {
      getPolicy: jest.fn().mockResolvedValue({ ...policy, enabled: false }),
      deleteBatch: jest.fn(),
    } as unknown as RetentionRepository;
    const service = new RetentionService(repository, config(), logger());

    const result = await service.runScheduled();

    expect(result.status).toBe('DISABLED');
    expect(repository.deleteBatch).not.toHaveBeenCalled();
  });
});

function batch(rawObservations: number) {
  return {
    locationEvidence: 0, locationEstimates: 0, radioObservations: 0, domainEvents: 0,
    rawObservations, collectionRuns: 0, auditEvents: 0, endedSessions: 0,
    endedRegistrations: 0, endedRadioBindings: 0, predictedPasses: 0, total: rawObservations,
  };
}

function config() {
  const values: Record<string, unknown> = {
    'retention.enabled': true, 'retention.defaultDays': 7,
    'retention.batchSize': 5000, 'retention.maxBatchesPerRun': 10,
  };
  return { getOrThrow: jest.fn((key: string) => values[key]) } as unknown as ConfigService;
}

function logger() {
  return { setContext: jest.fn(), info: jest.fn(), error: jest.fn() } as unknown as PinoLogger;
}
