'use client';

import { useMemo, type ReactNode } from 'react';
import { Box, Card, CardContent, Grid, LinearProgress, Stack, Typography } from '@mui/material';
import CellTowerRounded from '@mui/icons-material/CellTowerRounded';
import DevicesRounded from '@mui/icons-material/DevicesRounded';
import RouterRounded from '@mui/icons-material/RouterRounded';
import NotificationsRounded from '@mui/icons-material/NotificationsRounded';
import { PageHeader } from '@/components/common/page-header';
import { StatCard } from '@/components/common/stat-card';
import { StatusBadge } from '@/components/common/status-badge';
import { EChart, timeSeriesOption } from '@/components/charts/echart';
import { StatePanel } from '@/components/common/state-panel';
import { useApi } from '@/core/api/use-api';
import { queryString } from '@/core/api/client';
import { useCurrentTime } from '@/core/time/use-current-time';
import type { AggregatedMetric, Alarm, CollectorStatus, LocationEstimate, Metric, Page, Statistics, Ue } from '@/core/api/types';

const bitrate = (value = 0) => value >= 1_000_000 ? `${(value / 1_000_000).toFixed(1)} Mb/s` : `${(value / 1000).toFixed(0)} kb/s`;
const qualityMetrics = [
  ['CQI', 'radio.ue.cqi', ''], ['DL MCS', 'radio.ue.dl_mcs', ''], ['UL SNR', 'radio.ue.pusch_snr', 'dB'],
  ['Path loss', 'radio.ue.ul_path_loss', 'dB'], ['Timing advance', 'radio.ue.initial_ta', 'units'], ['Retransmissions', 'radio.ue.ul_retx', ''],
] as const;

export function DashboardView() {
  const stats = useApi<Statistics>('/statistics');
  const collectors = useApi<CollectorStatus[]>('/collectors/status');
  const alarms = useApi<Page<Alarm>>('/alarms/current?limit=5');
  const ues = useApi<Page<Ue>>('/ues?limit=100');
  const locations = useApi<LocationEstimate[]>('/locations/current');
  const metrics = useApi<Page<Metric>>('/metrics/current?limit=1000');
  const currentTime = useCurrentTime();
  const to = new Date(Math.floor(currentTime / 60_000) * 60_000);
  const from = new Date(to.getTime() - 6 * 60 * 60_000);
  const historyPath = (metric: string) => `/metrics/historical${queryString({ metric, from: from.toISOString(), to: to.toISOString(), aggregation: 'avg', bucket: 'minute', limit: 360, sort: 'asc' })}`;
  const dl = useApi<Page<AggregatedMetric>>(historyPath('radio.ue.dl_bitrate'));
  const ul = useApi<Page<AggregatedMetric>>(historyPath('radio.ue.ul_bitrate'));
  const trafficOption = useMemo(() => timeSeriesOption([
    { name: 'Downlink', color: '#20bad8', data: (dl.data?.items ?? []).map((point) => [point.bucket, point.value]) },
    { name: 'Uplink', color: '#8b78f6', data: (ul.data?.items ?? []).map((point) => [point.bucket, point.value]) },
  ], 'bit/s'), [dl.data, ul.data]);
  const activeUe = ues.data?.items.find((item) => item.radioStatus === 'active') ?? ues.data?.items.find((item) => item.registrationStatus === 'registered');
  const location = locations.data?.find((item) => item.ueId === activeUe?.id) ?? locations.data?.[0];
  const ueMetrics = (metrics.data?.items ?? []).filter((item) => !activeUe || item.ueId === activeUe.id);
  const healthy = collectors.data?.filter((item) => isCollectorHealthy(item, currentTime)).length ?? 0;
  const enabledCollectors = collectors.data?.filter((item) => item.enabled).length ?? 0;
  const collectorStatusAvailable = collectors.data !== null;
  const collectorSummary = collectorStatusAvailable ? `${healthy}/${enabledCollectors}` : '—';
  const collectorHelper = !collectorStatusAvailable
    ? collectors.error ? 'Collector status unavailable' : 'Loading collector status'
    : enabledCollectors && healthy === enabledCollectors ? 'All polling normally' : 'Review collector status';
  const error = stats.error ?? collectors.error ?? alarms.error ?? ues.error ?? locations.error ?? metrics.error;

  return <>
    <PageHeader eyebrow="Network operations" title="Private 5G overview" description="Live service, radio quality, UE presence, location confidence, and collector health in one operational view." />
    <StatePanel loading={stats.loading} error={error}>
      <Grid container spacing={1.5}>{[
        ['Sites', stats.data?.sites ?? 0, `${stats.data?.cells ?? 0} configured cells`, CellTowerRounded, 'primary'],
        ['Active UEs', stats.data?.activeUes ?? 0, `${ues.data?.items.filter((item) => item.registrationStatus === 'registered').length ?? 0} MME registered`, DevicesRounded, 'secondary'],
        ['Collectors healthy', collectorSummary, collectorHelper, RouterRounded, collectorStatusAvailable && healthy === enabledCollectors && enabledCollectors > 0 ? 'success' : 'warning'],
        ['Current alerts', alarms.data?.items.length ?? 0, 'Open warning or higher', NotificationsRounded, alarms.data?.items.length ? 'warning' : 'success'],
      ].map(([label, value, helper, icon, tone]) => <Grid key={String(label)} size={{ xs: 12, sm: 6, xl: 3 }}><StatCard label={String(label)} value={value as string | number} helper={String(helper)} icon={icon as typeof DevicesRounded} tone={tone as 'primary' | 'secondary' | 'warning' | 'success'} /></Grid>)}</Grid>
    </StatePanel>

    <Grid container spacing={2} sx={{ mt: .25 }}>
      <Grid size={{ xs: 12, xl: 8 }}><Stack spacing={2}>
        <Card><CardContent><SectionTitle title="Network traffic" subtitle="Six-hour rolling view · one-minute averages" status={dl.error || ul.error ? 'degraded' : 'live'} /><StatePanel loading={dl.loading || ul.loading} error={dl.error ?? ul.error} empty={!dl.data?.items.length && !ul.data?.items.length}><EChart option={trafficOption} height={310} ariaLabel="Downlink and uplink network traffic" /></StatePanel><Stack direction="row" spacing={3} sx={{ mt: 1 }}><TrafficValue label="Current downlink" value={bitrate(stats.data?.totalDlBitrate)} color="#20bad8" /><TrafficValue label="Current uplink" value={bitrate(stats.data?.totalUlBitrate)} color="#8b78f6" /></Stack></CardContent></Card>
        <Card><CardContent><SectionTitle title="Radio quality" subtitle={activeUe ? `Latest measurements for ${activeUe.pseudonym}` : 'Latest measurements across active UEs'} status={activeUe?.radioStatus ?? 'waiting'} /><Grid container spacing={1.2} sx={{ mt: .5 }}>{qualityMetrics.map(([label, name, unit]) => { const value = latestMetric(ueMetrics, name); return <Grid key={name} size={{ xs: 6, md: 4 }}><Box sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 2, minHeight: 83 }}><Typography variant="caption" color="text.secondary">{label}</Typography><Typography sx={{ fontSize: '1.25rem', fontWeight: 760, mt: .5 }}>{formatMetric(value)} <Box component="span" sx={{ fontSize: 11, color: 'text.secondary', fontWeight: 600 }}>{unit}</Box></Typography><LinearProgress variant="determinate" value={qualityBar(name, value)} sx={{ height: 3, mt: 1.1, borderRadius: 2 }} /></Box></Grid>; })}</Grid></CardContent></Card>
      </Stack></Grid>

      <Grid size={{ xs: 12, xl: 4 }}><Stack spacing={2}>
        <Card><CardContent><SectionTitle title="Live UE" subtitle="MME identity correlated with gNB activity" status={activeUe?.radioStatus ?? 'waiting'} />{activeUe ? <Stack spacing={1.25} sx={{ mt: 1.5 }}><Box sx={{ p: 1.5, bgcolor: 'action.hover', borderRadius: 2 }}><Typography sx={{ fontFamily: 'monospace', fontWeight: 780 }}>{activeUe.pseudonym}</Typography><Typography variant="caption" color="text.secondary">IP {activeUe.ipAddresses.join(', ') || 'not assigned'}</Typography></Box><DetailRow label="MME registration" value={<StatusBadge status={activeUe.registrationStatus} />} /><DetailRow label="Radio presence" value={<StatusBadge status={activeUe.radioStatus} />} /><DetailRow label="Serving cell" value={location?.servingCellName ?? 'Not correlated'} /><DetailRow label="Last radio sample" value={activeUe.lastRadioSeenAt ? new Date(activeUe.lastRadioSeenAt).toLocaleTimeString() : 'Never'} />{location && <><Box sx={{ position: 'relative', height: 112, borderRadius: 2, overflow: 'hidden', border: '1px solid', borderColor: 'divider', background: 'radial-gradient(circle at 50% 50%, rgba(32,186,216,.22) 0 3%, transparent 4% 18%, rgba(32,186,216,.12) 19% 20%, transparent 21% 38%, rgba(139,120,246,.12) 39% 40%, transparent 41%)' }}><Box sx={{ position: 'absolute', left: `${42 + Number(location.details.displayBearingDeg ?? 0) % 16}%`, top: '45%', width: 10, height: 10, borderRadius: '50%', bgcolor: 'secondary.main', boxShadow: '0 0 18px #8b78f6' }} /></Box><DetailRow label="Estimated accuracy" value={`±${Math.round(location.horizontalAccuracyM)} m`} /><DetailRow label="Confidence" value={location.confidence === null ? 'Not scored' : `${Math.round(location.confidence * 100)}%`} /><Typography variant="caption" color="text.secondary">Single-cell omni estimate · bearing is illustrative, not measured.</Typography></>}</Stack> : <Typography color="text.secondary" sx={{ mt: 2 }}>No registered UE is available.</Typography>}</CardContent></Card>
        <Card><CardContent><SectionTitle title="Collector health" subtitle={collectorStatusAvailable ? `${healthy} of ${enabledCollectors} enabled collectors healthy` : 'Collector status unavailable'} status={!collectorStatusAvailable ? 'unavailable' : healthy === enabledCollectors && enabledCollectors > 0 ? 'healthy' : 'degraded'} /><Stack spacing={1} sx={{ mt: 1.5 }}>{collectors.data?.filter((item) => item.enabled).map((item) => <Box key={item.targetId} sx={{ p: 1.25, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}><Stack direction="row" sx={{ justifyContent: 'space-between', alignItems: 'center' }}><Box><Typography sx={{ fontSize: 13, fontWeight: 730 }}>{item.targetName}</Typography><Typography variant="caption" color="text.secondary">{item.schedules.map((schedule) => `${schedule.operation} · ${schedule.intervalMs / 1000}s`).join('  |  ') || 'No schedule'}</Typography></Box><StatusBadge status={isCollectorHealthy(item, currentTime) ? 'healthy' : item.lastRunStatus} /></Stack></Box>)}{!collectorStatusAvailable && <Typography variant="body2" color="text.secondary">{collectors.error ?? 'Loading collector status…'}</Typography>}</Stack></CardContent></Card>
        <Card><CardContent><SectionTitle title="Recent alerts" subtitle="Latest operational condition" status={alarms.data?.items.length ? 'warning' : 'healthy'} />{alarms.data?.items.length ? <Stack spacing={1} sx={{ mt: 1.5 }}>{alarms.data.items.slice(0, 3).map((alarm) => <Box key={alarm.id} sx={{ p: 1.2, borderLeft: '3px solid', borderColor: 'warning.main', bgcolor: 'action.hover' }}><Stack direction="row" sx={{ justifyContent: 'space-between', gap: 1 }}><Typography sx={{ fontSize: 12.5, fontWeight: 700 }}>{alarm.message}</Typography><StatusBadge status={alarm.severity} /></Stack><Typography variant="caption" color="text.secondary">{new Date(alarm.occurredAt).toLocaleString()}</Typography></Box>)}</Stack> : <Typography variant="body2" color="text.secondary" sx={{ mt: 1.5 }}>No current alerts.</Typography>}</CardContent></Card>
      </Stack></Grid>
    </Grid>
  </>;
}

function SectionTitle({ title, subtitle, status }: { title: string; subtitle: string; status: string }) { return <Stack direction="row" sx={{ justifyContent: 'space-between', alignItems: 'flex-start', gap: 1, mb: 1 }}><Box><Typography variant="h2">{title}</Typography><Typography variant="caption" color="text.secondary">{subtitle}</Typography></Box><StatusBadge status={status} /></Stack>; }
function TrafficValue({ label, value, color }: { label: string; value: string; color: string }) { return <Box><Typography variant="caption" color="text.secondary">{label}</Typography><Typography sx={{ fontWeight: 750, color }}>{value}</Typography></Box>; }
function DetailRow({ label, value }: { label: string; value: ReactNode }) { return <Stack direction="row" sx={{ justifyContent: 'space-between', alignItems: 'center', gap: 2 }}><Typography variant="caption" color="text.secondary">{label}</Typography><Box sx={{ fontSize: 12.5, fontWeight: 650, textAlign: 'right' }}>{value}</Box></Stack>; }
function latestMetric(metrics: Metric[], name: string): number | undefined { const item = metrics.filter((metric) => metric.metric === name && (typeof metric.value === 'number' || typeof metric.value === 'string')).sort((a, b) => b.observedAt.localeCompare(a.observedAt))[0]; const value = typeof item?.value === 'number' ? item.value : Number(item?.value); return Number.isFinite(value) ? value : undefined; }
function formatMetric(value: number | undefined): string { return value === undefined ? '—' : Number.isInteger(value) ? String(value) : value.toFixed(1); }
function qualityBar(name: string, value: number | undefined): number { if (value === undefined) return 0; if (name.endsWith('pusch_snr')) return Math.max(0, Math.min(100, (value + 10) * 2.5)); if (name.endsWith('ul_path_loss')) return Math.max(0, Math.min(100, 140 - value)); if (name.endsWith('cqi')) return Math.min(100, value / 15 * 100); if (name.includes('mcs')) return Math.min(100, value / 28 * 100); return Math.max(5, Math.min(100, value)); }
function isCollectorHealthy(item: CollectorStatus, now: number): boolean { if (!item.enabled || item.lastSuccessAt === null || item.lastRunStatus !== 'SUCCEEDED') return false; const tolerance = Math.max(30_000, ...item.schedules.filter((schedule) => schedule.enabled).map((schedule) => schedule.intervalMs * 3), 30_000); return now - new Date(item.lastSuccessAt).getTime() <= tolerance; }
