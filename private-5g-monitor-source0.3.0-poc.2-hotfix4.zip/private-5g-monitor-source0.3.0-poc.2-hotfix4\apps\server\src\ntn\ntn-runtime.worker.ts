import { Injectable, OnApplicationBootstrap, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PinoLogger } from 'nestjs-pino';
import { LiveGateway } from '@app/live/live.gateway';
import { NtnService } from './ntn.service';
import { PassPredictionService } from './pass-prediction.service';

/** Publishes live satellite positions and periodically refreshes geometric site passes. */
@Injectable()
export class NtnRuntimeWorker implements OnApplicationBootstrap, OnModuleDestroy {
  private positionTimer?: NodeJS.Timeout;
  private passTimer?: NodeJS.Timeout;
  private positionRunning = false;
  private passRunning = false;
  private lastPositionAt: Date | null = null;
  private lastPassRefreshAt: Date | null = null;
  constructor(private readonly service: NtnService, private readonly passes: PassPredictionService, private readonly config: ConfigService, private readonly live: LiveGateway, private readonly logger: PinoLogger) { this.logger.setContext(NtnRuntimeWorker.name); }

  onApplicationBootstrap(): void {
    if (!this.config.getOrThrow<boolean>('ntn.enabled')) return;
    this.positionTimer = setInterval(() => void this.publishPositions(), this.config.getOrThrow<number>('ntn.positionUpdateMs'));
    this.passTimer = setInterval(() => void this.refreshPasses(), this.config.getOrThrow<number>('ntn.passRefreshMs'));
    this.positionTimer.unref(); this.passTimer.unref();
    void this.publishPositions(); void this.refreshPasses();
  }
  async onModuleDestroy(): Promise<void> {
    if (this.positionTimer) clearInterval(this.positionTimer);
    if (this.passTimer) clearInterval(this.passTimer);
    const deadline = Date.now() + this.config.getOrThrow<number>('server.shutdownGraceMs');
    while ((this.positionRunning || this.passRunning) && Date.now() < deadline) await new Promise((resolve) => setTimeout(resolve, 25));
  }
  health(): Readonly<Record<string, unknown>> & { ready: boolean } {
    const enabled = this.config.getOrThrow<boolean>('ntn.enabled');
    const maximumPositionAge = this.config.getOrThrow<number>('ntn.positionUpdateMs') * 3;
    return {
      ready: !enabled || (this.positionTimer !== undefined && this.lastPositionAt !== null && Date.now() - this.lastPositionAt.getTime() <= maximumPositionAge),
      enabled,
      positionRunning: this.positionRunning,
      passRefreshRunning: this.passRunning,
      lastPositionAt: this.lastPositionAt?.toISOString() ?? null,
      lastPassRefreshAt: this.lastPassRefreshAt?.toISOString() ?? null,
    };
  }
  private async publishPositions(): Promise<void> {
    if (this.positionRunning) return; this.positionRunning = true;
    try { const snapshot = await this.service.currentPositions(); this.lastPositionAt = new Date(); this.live.publish('ntn.position.updated', snapshot); }
    catch (error) { this.logger.error({ err: error }, 'NTN live position update failed'); }
    finally { this.positionRunning = false; }
  }
  private async refreshPasses(): Promise<void> {
    if (this.passRunning) return; this.passRunning = true;
    try { const generated = await this.passes.refreshAll(); this.lastPassRefreshAt = new Date(); this.live.publish('ntn.pass.updated', { generated }); }
    catch (error) { this.logger.error({ err: error }, 'NTN site-pass refresh failed'); }
    finally { this.passRunning = false; }
  }
}
