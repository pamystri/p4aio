# Local Web Dashboard

The dashboard is a Next.js, React, Material UI, Apache ECharts, and Leaflet application under `apps/web`. It is designed for the dedicated private-network host and has no database driver or direct PostgreSQL path. All operational data comes from the documented REST API; Socket.IO messages are post-commit refresh signals.

![Representative dashboard design](web-dashboard-representative-snapshot.png)

The image above is a representative design preview matching the implemented visual system. It is not presented as a runtime browser capture because dependencies were intentionally deferred to the Ubuntu installation.

## Routes

- `/` — operational dashboard with KPIs, traffic trends, collector health, and recent alerts.
- `/live-monitoring` — current UE/cell metrics and current-value distribution.
- `/analytics` — selectable historical KPI trends with time range and aggregation.
- `/sites`, `/cells`, `/ues` — searchable and exportable inventory; UEs include MME registration, assigned IPs, and gNB active/idle state.
- `/map` — site and UE estimate map with UE IP, radio state, confidence, accuracy, serving cell, algorithm, and timestamp.
- `/alerts` — current and historical alarm workflow.
- `/settings` — browser-local API connection and refresh settings.
- `/administration` — readiness, connector, scheduler, and radio-target status.

Release `0.3.0-poc.2` uses the observability-first layout on `/`: traffic and radio quality remain central, while the right rail combines MME/gNB-correlated UE identity, IP address, location quality, collectors, and alerts. `/map` uses the map-centric layout: the map is the primary workspace, with KPI context, active UE detail, traffic, terrestrial health, satellite subpoints, dateline-safe tracks, current/next passes, and active geometric site links. The interface explicitly labels NTN data as geometric visibility; it does not show or imply an RF coverage footprint.

Settings includes the persistent historical-retention control. It shows database size and the last cleanup result, lets the operator select the number of days to retain, and can trigger the same bounded cleanup used by the background worker.

Operational refreshes use stale-while-revalidate behaviour: rendered data remains visible while replacement requests run. The Network Map keeps its Leaflet instance and base tiles mounted, updates overlay data in place, coalesces bursts of live notifications, and preserves operator pan/zoom unless the configured topology changes.

Design references shipped with this release:

- `docs/dashboard-observability-concept.png`
- `docs/network-map-map-centric-concept.png`

Tables export their current filtered view to CSV, Excel, or PDF. Charts support tooltips and pointer/touch zoom. The layout collapses to a navigation drawer on small screens and preserves full table scrolling.

## Local data boundary

In production, Nginx provides a single local HTTPS origin:

```text
Operator browser -> Nginx :443
                    |-- /              -> Next.js :3001
                    |-- /api/v1/*      -> NestJS :3000
                    |-- /socket.io/*   -> NestJS Socket.IO :3000
```

Ports 3000 and 3001 bind to loopback. PostgreSQL remains on the internal backend network. The API key, when used, is browser-local and never included in an export.

OpenStreetMap is used only as a tile source. Set `NEXT_PUBLIC_TILE_URL` during the web build to point to an approved internal tile service for a fully disconnected installation. No analytics SDK, public CDN, remote font, or cloud application service is used.

## Location compatibility

The UI consumes a stable location envelope: coordinates, accuracy, optional confidence, serving cell, timestamp, method, algorithm version, and opaque details. A future location algorithm can therefore publish estimates without map-component changes.

The first estimator is intentionally conservative. For one omnidirectional cell, the marker bearing is a stable visualization convention rather than a measured direction. The accuracy value represents the directional ambiguity, and the method is exposed as `single_cell_omnidirectional_range`. Operators should calibrate the timing-advance scale and path-loss model in `config/production.yaml` for their radio numerology and indoor environment.

## Build and run

Dependencies are installed later on the Ubuntu host from the monorepo root:

```bash
npm install
npm run web:lint
npm run web:build
PORT=3001 npm run start --workspace @private-5g-monitor/web
```

For native deployment, enable both systemd services and install the supplied Nginx configuration. Docker Compose builds separate backend and web runtime images.
