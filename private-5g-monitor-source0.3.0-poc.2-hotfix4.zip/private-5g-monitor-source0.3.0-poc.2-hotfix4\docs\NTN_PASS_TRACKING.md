# Transparent NTN site-pass tracking

## Release scope

Release `0.3.0-poc.1` adds local satellite movement and site-pass awareness for an Amarisoft gNB carried through a transparent satellite payload. It answers one operational question: **when is the satellite geometrically visible above the configured elevation mask at this site?**

It does not claim that 5G service is available. There is no beam footprint, RF link budget, antenna pattern, gateway, feeder-link, terrain, weather, interference, handover, or regenerative-payload model.

## Architecture

```mermaid
flowchart LR
  UI["NTN Assets / Network Map"] --> API["NestJS NTN REST API"]
  API --> Service["NtnService"]
  Service --> Registry["Trajectory Registry"]
  Registry --> SGP4["TLE + SGP4 provider"]
  Registry --> GPP["Decoded 3GPP ephemeris provider"]
  Service --> Repo["NTN repository port"]
  Repo --> DB[("PostgreSQL")]
  Worker["NTN runtime worker"] --> Service
  Worker --> Live["Socket.IO refresh topics"]
  Predictor["Geometric pass predictor"] --> Registry
  Predictor --> Repo
```

The existing Amarisoft Remote API collector remains unchanged. `ntn_transparent_assignment` links a satellite asset to an existing gNB target as topology metadata; orbit propagation never opens a connection to the satellite or gNB.

## Ephemeris inputs

Each upload creates an immutable `ephemeris_dataset` with its exact source payload and SHA-256 digest. Only one revision per asset is active.

- `TLE`: exact two-line or named three-line text. Validation covers payload size, 69-character lines, line numbers, matching catalogue numbers, checksum, epoch, and SGP4 initialization. Propagation uses SGP4 and converts the orbit state to Earth-fixed geodetic coordinates.
- `THREE_GPP_POSITION_VELOCITY`: already-decoded ECEF position in metres and velocity in metres per second at an absolute UTC epoch. The backend derives a bound Kepler orbit for display and passes.
- `THREE_GPP_ORBITAL`: already-decoded SI-unit orbital elements at an absolute UTC epoch. The backend performs two-body Kepler propagation.

The API intentionally accepts decoded 3GPP values rather than vendor-encoded bit fields. A future connector may decode a published vendor response into this stable input without altering storage or the UI.

Decoded state-vector payload example:

```json
{
  "positionVelocity": {
    "positionM": { "x": 6878137, "y": 0, "z": 0 },
    "velocityMps": { "x": 0, "y": 500, "z": 7590 }
  }
}
```

Decoded orbital payload example:

```json
{
  "orbital": {
    "semiMajorAxisM": 6878137,
    "eccentricity": 0.001,
    "inclinationDeg": 53,
    "longitudeOfAscendingNodeDeg": 10,
    "argumentOfPeriapsisDeg": 20,
    "meanAnomalyDeg": 30
  }
}
```

Both require a separate absolute UTC `epochUtc` field in the upload request. Values are SI units and degrees as named; the API rejects unbound or physically unsupported Earth orbits.

## Site-pass calculation

For each enabled site/asset configuration, the predictor:

1. samples the active ephemeris from the current time to the configured horizon;
2. converts the satellite state to an Earth-fixed position;
3. converts the site latitude, longitude, and altitude to Earth-fixed coordinates;
4. transforms the relative vector into the site East/North/Up frame;
5. computes azimuth, elevation, slant range, and approximate free-space one-way delay;
6. detects elevation crossings of the configured minimum elevation mask;
7. refines AOS and LOS with binary search and records peak elevation and minimum slant range.

The calculation is deterministic and versioned as `site-pass-v1`. Stored pass details contain `geometricOnly: true`. The periodic refresh replaces only future predictions for the affected site/asset/ephemeris combination.

## Network Map semantics

- Cyan `SAT` marker: current propagated sub-satellite point.
- Cyan dashed polyline: recent/future display track, split at the international date line.
- Green dashed site-to-satellite line: current elevation is above the configured site mask.
- Pass cards: current LOS or next AOS and predicted peak elevation.
- Ephemeris badge: source and validation/freshness state.

The map never draws a coverage circle. Every satellite popup and pass panel states that the result is geometric visibility rather than RF coverage.

## Operations and limitations

The runtime defaults to 5-second map updates and 15-minute pass recalculation. Pass prediction uses 30-second samples and a seven-day horizon, capped by configuration. TLEs older than the configured freshness period remain usable but are marked `STALE`; operators should upload a newer approved file. The application performs no external TLE download.

For this small-network PoC, propagation and scheduling run in the NestJS process. Ten radios and a small number of satellite assets are within this design. A later scale-out can move the worker behind the same repository and live-event ports without changing REST resources or frontend types.
