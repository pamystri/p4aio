import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PinoLogger } from 'nestjs-pino';
import { NTN_REPOSITORY, type NtnRepository, type SitePassConfigurationView } from '@application/ntn/ntn.repository';
import { TrajectoryRegistryService } from './trajectory/trajectory-registry.service';
import { PassPredictor } from './pass-predictor';

/** Rebuilds deterministic site-pass windows from active ephemeris revisions. */
@Injectable()
export class PassPredictionService {
  private readonly predictor: PassPredictor;

  constructor(
    @Inject(NTN_REPOSITORY) private readonly repository: NtnRepository,
    trajectories: TrajectoryRegistryService,
    config: ConfigService,
    private readonly logger: PinoLogger,
  ) {
    this.logger.setContext(PassPredictionService.name);
    this.predictor = new PassPredictor(trajectories, config.getOrThrow<number>('ntn.predictionStepSeconds'));
  }

  async refreshAll(from = new Date()): Promise<number> {
    const configurations = await this.repository.listPassConfigurations();
    let generated = 0;
    for (const configuration of configurations.filter((item) => item.enabled)) {
      generated += await this.refreshConfiguration(configuration, from);
    }
    this.logger.info({ configurations: configurations.length, generated }, 'Transparent NTN site-pass predictions refreshed');
    return generated;
  }

  async refreshAsset(assetId: string, from = new Date()): Promise<number> {
    const configurations = (await this.repository.listPassConfigurations()).filter(
      (item) => item.enabled && item.spaceAssetId === assetId,
    );
    let generated = 0;
    for (const configuration of configurations) generated += await this.refreshConfiguration(configuration, from);
    return generated;
  }

  private async refreshConfiguration(configuration: SitePassConfigurationView, from: Date): Promise<number> {
    const ephemeris = await this.repository.activeEphemeris(configuration.spaceAssetId);
    if (!ephemeris) return 0;
    const effectiveFrom = ephemeris.validFrom && ephemeris.validFrom > from ? ephemeris.validFrom : from;
    const horizon = new Date(from.getTime() + configuration.predictionHorizonDays * 86_400_000);
    const to = ephemeris.validTo && ephemeris.validTo < horizon ? ephemeris.validTo : horizon;
    const passes = effectiveFrom < to ? this.predictor.predict(configuration, ephemeris, effectiveFrom, to) : [];
    await this.repository.replaceFuturePasses(configuration, ephemeris.id, from, passes);
    return passes.length;
  }
}
