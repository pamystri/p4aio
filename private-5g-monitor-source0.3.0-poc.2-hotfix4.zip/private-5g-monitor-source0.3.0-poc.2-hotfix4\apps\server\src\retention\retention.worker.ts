import { Injectable, OnApplicationBootstrap, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PinoLogger } from 'nestjs-pino';
import { RetentionService } from './retention.service';

/** Runs the database retention policy periodically without an external cron dependency. */
@Injectable()
export class RetentionWorker implements OnApplicationBootstrap, OnModuleDestroy {
  private timer?: NodeJS.Timeout;
  private lastTickAt: Date | null = null;
  constructor(private readonly service: RetentionService, private readonly config: ConfigService, private readonly logger: PinoLogger) { this.logger.setContext(RetentionWorker.name); }
  onApplicationBootstrap(): void {
    if (!this.config.getOrThrow<boolean>('retention.enabled')) return;
    const interval = this.config.getOrThrow<number>('retention.cleanupIntervalMs');
    this.timer = setInterval(() => void this.tick(), interval);
    this.timer.unref();
    void this.tick();
  }
  onModuleDestroy(): void { if (this.timer) clearInterval(this.timer); }
  health(): Readonly<Record<string, unknown>> & { ready: boolean } { const enabled = this.config.getOrThrow<boolean>('retention.enabled'); return { ready: !enabled || this.timer !== undefined, enabled, lastTickAt: this.lastTickAt?.toISOString() ?? null }; }
  private async tick(): Promise<void> { try { await this.service.runScheduled(); this.lastTickAt = new Date(); } catch (error) { this.logger.error({ err: error }, 'Scheduled retention tick failed'); } }
}
