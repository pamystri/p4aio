import type { EphemerisView } from '@application/ntn/ntn.repository';
import { ThreeGppTrajectoryProvider } from './three-gpp.provider';

describe('ThreeGppTrajectoryProvider', () => {
  it('propagates decoded SI-unit orbital elements', () => {
    const epoch = new Date('2026-08-04T12:00:00.000Z');
    const ephemeris: EphemerisView = {
      id: 'orbit-1', spaceAssetId: 'asset-1', sourceType: 'THREE_GPP_ORBITAL', formatVersion: '3GPP-R17', epochUtc: epoch,
      validFrom: null, validTo: null, referenceFrame: 'ECI', timeSystem: 'UTC', rawText: null,
      rawJson: { orbital: { semiMajorAxisM: 6_878_137, eccentricity: 0.001, inclinationDeg: 53, longitudeOfAscendingNodeDeg: 10, argumentOfPeriapsisDeg: 20, meanAnomalyDeg: 30 } },
      payloadSha256: Buffer.alloc(32), validationStatus: 'VALID', validationDiagnostics: {}, active: true, createdAt: epoch,
    };
    const state = new ThreeGppTrajectoryProvider().propagate(ephemeris, epoch);
    expect(Number.isFinite(state.latitude)).toBe(true);
    expect(state.altitudeM).toBeGreaterThan(100_000);
    expect(state.speedMps).toBeGreaterThan(5_000);
  });
});
