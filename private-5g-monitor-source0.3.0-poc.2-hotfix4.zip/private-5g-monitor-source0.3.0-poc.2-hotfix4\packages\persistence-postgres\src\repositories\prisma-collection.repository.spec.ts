import { ConfigService } from '@nestjs/config';
import type { CanonicalUeInventoryObservation } from '@connector-sdk/index';
import { PrismaCollectionRepository } from './prisma-collection.repository';

describe('PrismaCollectionRepository UE binding correlation', () => {
  const observedAt = new Date('2026-08-05T10:00:00.000Z');

  it('carries recent gNB state when the MME changes ran_ue_id', async () => {
    const transaction = {
      ueRegistration: { updateMany: jest.fn(), upsert: jest.fn() },
      ueSession: { updateMany: jest.fn(), upsert: jest.fn() },
      ueRadioBinding: {
        updateMany: jest.fn(),
        findFirst: jest.fn().mockResolvedValue({
          gnbTargetId: 'gnb-1',
          servingCellId: 'cell-1',
          lastGnbSeenAt: new Date(observedAt.getTime() - 5_000),
        }),
        upsert: jest.fn(),
      },
      ue: { upsert: jest.fn().mockResolvedValue({ id: 'ue-1' }) },
    };
    const config = {
      getOrThrow: jest.fn((key: string) => key === 'privacy.pseudonymKey' ? 'test-key' : 60_000),
    } as unknown as ConfigService;
    const repository = new PrismaCollectionRepository({} as never, config);
    const internals = repository as unknown as {
      persistUeInventory(
        tx: unknown,
        mmeTargetId: string,
        siteId: string,
        inventory: readonly CanonicalUeInventoryObservation[],
        mode: 'none' | 'snapshot' | 'delta',
        at: Date,
      ): Promise<void>;
    };

    await internals.persistUeInventory(transaction, 'mme-1', 'site-1', [{
      identityType: 'imsi',
      externalIdentity: '001010000000001',
      ranUeKey: '13417',
      registered: true,
      observedAt,
      sessions: [],
    }], 'snapshot', observedAt);

    expect(transaction.ueRadioBinding.findFirst).toHaveBeenCalledWith(expect.objectContaining({
      where: expect.objectContaining({ ueId: 'ue-1', siteId: 'site-1' }),
    }));
    expect(transaction.ueRadioBinding.upsert).toHaveBeenCalledWith(expect.objectContaining({
      create: expect.objectContaining({
        ranUeKey: '13417',
        gnbTargetId: 'gnb-1',
        servingCellId: 'cell-1',
      }),
      update: expect.objectContaining({
        gnbTargetId: 'gnb-1',
        servingCellId: 'cell-1',
      }),
    }));
  });

  it('does not carry stale gNB state outside the correlation window', async () => {
    const transaction = {
      ueRegistration: { updateMany: jest.fn(), upsert: jest.fn() },
      ueSession: { updateMany: jest.fn(), upsert: jest.fn() },
      ueRadioBinding: { updateMany: jest.fn(), findFirst: jest.fn().mockResolvedValue(null), upsert: jest.fn() },
      ue: { upsert: jest.fn().mockResolvedValue({ id: 'ue-1' }) },
    };
    const config = { getOrThrow: jest.fn((key: string) => key === 'privacy.pseudonymKey' ? 'test-key' : 60_000) } as unknown as ConfigService;
    const repository = new PrismaCollectionRepository({} as never, config);
    const internals = repository as unknown as {
      persistUeInventory(tx: unknown, mmeTargetId: string, siteId: string, inventory: readonly CanonicalUeInventoryObservation[], mode: 'none' | 'snapshot' | 'delta', at: Date): Promise<void>;
    };

    await internals.persistUeInventory(transaction, 'mme-1', 'site-1', [{
      identityType: 'imsi', externalIdentity: '001010000000001', ranUeKey: '13418', registered: true, observedAt, sessions: [],
    }], 'snapshot', observedAt);

    expect(transaction.ueRadioBinding.upsert).toHaveBeenCalledWith(expect.objectContaining({
      create: expect.objectContaining({ gnbTargetId: undefined, servingCellId: undefined }),
    }));
  });
});
