#!/bin/bash

# Function to display usage
usage() {
    echo "Usage: sudo $0 [--allow-unsupported-sfp-module]"
    echo "  --allow-unsupported-sfp-module: Persist ixgbe allow_unsupported_sfp=1 for 82599/X520 unsupported SFP+ modules"
    exit 1
}

installer_euid() {
    if [ -n "${PYTEST_CURRENT_TEST:-}" ] && [ -n "${CELEOS_INSTALL_TEST_EUID:-}" ]; then
        printf '%s' "$CELEOS_INSTALL_TEST_EUID"
    else
        printf '%s' "$EUID"
    fi
}

require_root() {
    if [ "$(installer_euid)" -ne 0 ]; then
        echo "ERROR: This script must be run as root. Please use sudo." >&2
        exit 1
    fi
}

require_root

allow_unsupported_sfp_module="false"
while [[ $# -gt 0 ]]; do
    case "$1" in
        --allow-unsupported-sfp-module)
            allow_unsupported_sfp_module="true"
            shift
            ;;
        -h|--help)
            usage
            ;;
        --*)
            echo "Error: Unknown flag '$1'"
            echo "Run '$0 --help' for usage information."
            exit 1
            ;;
        *)
            echo "Error: Unknown argument '$1'"
            echo "Run '$0 --help' for usage information."
            exit 1
            ;;
    esac
done

if [ -f /proc/device-tree/model ] && grep -qi jetson /proc/device-tree/model 2>/dev/null; then
    echo "This script shall not be run on Jetson version. Drivers should already be included in OS."
    exit
fi

IXGBE_UNSUPPORTED_SFP_CONF="/etc/modprobe.d/ixgbe-unsupported-sfp.conf"

configure_ixgbe_unsupported_sfp() {
    echo "Configuring persistent ixgbe unsupported SFP+ module option..."
    sudo mkdir -p /etc/modprobe.d
    sudo tee "$IXGBE_UNSUPPORTED_SFP_CONF" >/dev/null <<'EOF'
# Allow ixgbe to probe non-Intel/unsupported SFP+ modules on 82599/X520 adapters.
options ixgbe allow_unsupported_sfp=1
EOF

    if ! command -v update-initramfs >/dev/null 2>&1; then
        echo "ERROR: update-initramfs is required to persist the ixgbe module option on this Ubuntu host."
        exit 1
    fi

    if ! sudo update-initramfs -u -k all; then
        echo "ERROR: update-initramfs failed after writing $IXGBE_UNSUPPORTED_SFP_CONF"
        exit 1
    fi

    cat <<'EOF'

Configured persistent ixgbe unsupported SFP+ support.
This intentionally does not hot-reload ixgbe; this NIC can retain stale MDIO state after live reload.
The system reboot at the end of this script applies the ixgbe option.

After reboot, verify:
  modprobe -c | grep '^options ixgbe'
  ip -br link show
  lspci -k -D -s 0000:05:00.1
  journalctl -k -b --no-pager -g 'ixgbe|SFP|unsupported|05:00'

Expected result: enp5s0f1 exists and 0000:05:00.1 reports:
  Kernel driver in use: ixgbe

The kernel log may show Intel's warning about untested optics. It should not show:
  failed to load because an unsupported SFP+...

Separate throughput note: this host currently has the X520 behind a PCIe x1 link, so both ports
will not deliver full 2x10Gbps performance even after both ports bind.
EOF
}

if [ "$allow_unsupported_sfp_module" = "true" ]; then
    configure_ixgbe_unsupported_sfp
else
    echo "Skipping ixgbe unsupported SFP+ module option. Pass --allow-unsupported-sfp-module to enable it."
fi

# Remove existing NVIDIA drivers
echo "Removing existing NVIDIA drivers..."
sudo apt-get remove --purge '^nvidia-.*' -y
sudo apt-get remove --purge 'libnvidia-.*' -y
sudo apt-get remove --purge 'cuda-.*' -y
sudo apt-get remove --purge 'libcuda.*' -y

# Clean up
echo "Cleaning up..."
sudo apt-get autoremove -y
sudo apt-get autoclean -y

# Add the NVIDIA PPA repository
echo "Adding the NVIDIA PPA repository..."
sudo add-apt-repository ppa:graphics-drivers/ppa -y
sudo apt-get update

# Install the NVIDIA 570 driver
echo "Installing the NVIDIA 570 driver..."
sudo apt-get install nvidia-driver-570 -y

# Reboot the system
echo "Installation complete. The system will now reboot."

# Disable Ubuntu graphical UI
systemctl isolate multi-user.target
systemctl set-default multi-user.target

sudo reboot
