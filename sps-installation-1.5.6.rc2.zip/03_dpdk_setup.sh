#!/usr/bin/env bash
set -euo pipefail

SCRIPT_NAME="${0##*/}"
CONFIG_PATH="${CELEOS_DPDK_SETUP_CONFIG_PATH:-/etc/celeos-dpdk-usrp.conf}"
LEGACY_CONFIG_PATH="${CELEOS_DPDK_SETUP_LEGACY_CONFIG_PATH:-/etc/celeos-dpdk-x300.conf}"
UHD_CONFIG_PATH="${CELEOS_DPDK_SETUP_UHD_CONFIG_PATH:-/etc/uhd/uhd.conf}"
HELPER_PATH="/usr/local/sbin/celeos-dpdk-setup"
SERVICE_PATH="/etc/systemd/system/celeos-dpdk-setup.service"
SERVICE_NAME="celeos-dpdk-setup.service"
LEGACY_SERVICE_NAMES=("celeos-dpdk-usrp-setup.service" "celeos-dpdk-x300-setup.service")
IOMMU_GRUB_DROPIN_PATH="/etc/default/grub.d/90-celeos-vfio-iommu.cfg"
INSTALL_TEMP_DIR=""
ROOT_CMD=()

APPLY=0
DRY_RUN=0
EXPLICIT_DRY_RUN=0
PROMPT_APPLY_AFTER_PROBE=0
VIEW=0
CHECK=0
DISABLE_DPDK=0
BIND_VFIO_GROUP=0
NON_INTERACTIVE="${CELEOS_DPDK_SETUP_NON_INTERACTIVE:-0}"
HOST_UHD_PACKAGE="${CELEOS_DPDK_SETUP_UHD_HOST_PACKAGE:-uhd-host}"
HOST_UHD_TOOLS_INSTALLED=0
DPDK_PMD_PACKAGE_OVERRIDE="${CELEOS_DPDK_SETUP_DPDK_PMD_PACKAGE:-}"
DPDK_RING_MEMPOOL_PACKAGE_OVERRIDE="${CELEOS_DPDK_SETUP_DPDK_RING_MEMPOOL_PACKAGE:-}"
UHD_DPDK_MTU="${CELEOS_DPDK_SETUP_UHD_DPDK_MTU:-9000}"
UHD_DPDK_CORELIST="${CELEOS_DPDK_SETUP_UHD_DPDK_CORELIST:-4,5}"
UHD_DPDK_NUM_MBUFS="${CELEOS_DPDK_SETUP_UHD_DPDK_NUM_MBUFS:-8192}"
UHD_DPDK_MBUF_CACHE_SIZE="${CELEOS_DPDK_SETUP_UHD_DPDK_MBUF_CACHE_SIZE:-64}"
UHD_DPDK_DRIVER="${CELEOS_DPDK_SETUP_UHD_DPDK_DRIVER:-}"
UHD_DPDK_LOG_LEVEL="${CELEOS_DPDK_SETUP_UHD_DPDK_LOG_LEVEL:-lib.eal:info}"
UHD_DPDK_LCORE="${CELEOS_DPDK_SETUP_UHD_DPDK_LCORE:-5}"
UHD_DPDK_NUM_DESC="${CELEOS_DPDK_SETUP_UHD_DPDK_NUM_DESC:-4096}"

PCI=""
IFACE=""
IFACE_SOURCE=""
TARGET_DRIVER=""
TARGET_DRIVER_SOURCE=""
KERNEL_DRIVER=""
VFIO_GROUP_PCI=""
VFIO_GROUP_RESTORE_DRIVERS=""
HUGEPAGES=""
DPDK_MAC=""
DPDK_MAC_SOURCE=""
DPDK_IPV4=""
DPDK_IPV4_SOURCE=""
USRP_IP=""
USRP_MGMT_IP=""
USRP_TYPE=""
DUMMY_IFACE=""
NETWORK_USRP_CANDIDATES_LOADED=0
NETWORK_USRP_CANDIDATES=()
PCI_FUNCTIONS_PROBE_PRINTED=0
VFIO_GROUP_MEMBERS_PRINTED=0
EXPLICIT_HOST_VALUES=0
LOADED_CONFIG_PATH=""
DEMOTED_CONFIG_PATH=""
STOPPED_CELEOS_CONTAINERS=()

usage() {
    cat <<EOF
Usage: $SCRIPT_NAME [options]

Interactively prepare a generic Ubuntu host for CELEOS network USRP UHD DPDK.

Safe modes:
  --dry-run              Inspect and print the plan only. Makes no host changes.
  --view                 Show selected values and configured/applied status. Never prompts or changes host state.
  --check                Check installed post-reboot DPDK state. Makes no host changes.

Apply mode:
  --apply                Install the config, helper, and service.
  --bind-vfio-group      Allow --apply to bind all safe endpoint functions in the selected PCI IOMMU group.

Disable mode:
  --disable-dpdk         Disable the DPDK service and rebind the USRP NIC to the Ubuntu kernel driver.

Host values:
  --pci <addr>           PCI function connected to the network USRP, e.g. 0000:10:00.1.
  --iface <name>         Optional Linux interface name before DPDK binding.
  --target-driver <drv>  DPDK binding driver. Default: current DPDK binding, safe vfio-pci,
                         uio_pci_generic, or igb_uio.
  --kernel-driver <drv>  Ubuntu kernel driver to restore with --disable-dpdk, e.g. ixgbe or i40e.
  --dpdk-pmd-package <pkg>
                         Override the Ubuntu DPDK net PMD package for this NIC.
  --hugepages <count>    Persistent hugepage count. Default: 512.
  --dpdk-mac <mac>       MAC address of the selected 10 GbE function.
  --dpdk-ipv4 <addr>     Local DPDK IPv4/prefix, e.g. 192.168.40.1/24.
  --usrp-ip <addr>       USRP IPv4 address on the network link.
  --usrp-mgmt-ip <addr>  Optional USRP management/control IPv4 address.
  --usrp-type <type>     Optional UHD device type, e.g. x4xx.
  --dummy-iface <name>   Dummy Linux route interface. Default: usrpdpdk0.

Examples:
  $SCRIPT_NAME --dry-run
  $SCRIPT_NAME --view --pci 0000:10:00.1 --iface enp16s0f1 \\
     --dpdk-mac 00:10:86:83:5d:e3 --dpdk-ipv4 192.168.40.1/24 --usrp-ip 192.168.40.2
  sudo $SCRIPT_NAME --apply --pci 0000:10:00.1 --iface enp16s0f1 \\
     --dpdk-mac 00:10:86:83:5d:e3 --dpdk-ipv4 192.168.40.1/24 --usrp-ip 192.168.40.2
EOF
}

die() {
    echo "ERROR: $*" >&2
    exit 1
}

warn() {
    echo "WARNING: $*" >&2
}

installer_euid() {
    if [ -n "${PYTEST_CURRENT_TEST:-}" ] && [ -n "${CELEOS_INSTALL_TEST_EUID:-}" ]; then
        printf '%s' "$CELEOS_INSTALL_TEST_EUID"
    else
        printf '%s' "$EUID"
    fi
}

require_root() {
    if [ "$(installer_euid)" -ne 0 ]; then
        echo "ERROR: This script must be run as root. Please use sudo." >&2
        exit 1
    fi
}

require_root

have_cmd() {
    command -v "$1" >/dev/null 2>&1
}

parse_args() {
    local initial_arg_count="$#"

    while [ "$#" -gt 0 ]; do
        case "$1" in
            --dry-run)
                DRY_RUN=1
                EXPLICIT_DRY_RUN=1
                shift
                ;;
            --view)
                VIEW=1
                shift
                ;;
            --check)
                CHECK=1
                shift
                ;;
            --apply)
                APPLY=1
                shift
                ;;
            --bind-vfio-group)
                BIND_VFIO_GROUP=1
                shift
                ;;
            --disable-dpdk)
                DISABLE_DPDK=1
                shift
                ;;
            --pci)
                EXPLICIT_HOST_VALUES=1
                PCI="${2:-}"
                [ -n "$PCI" ] || die "--pci requires a value"
                shift 2
                ;;
            --iface)
                EXPLICIT_HOST_VALUES=1
                IFACE="${2:-}"
                [ -n "$IFACE" ] || die "--iface requires a value"
                IFACE_SOURCE="from command line"
                shift 2
                ;;
            --target-driver)
                EXPLICIT_HOST_VALUES=1
                TARGET_DRIVER="${2:-}"
                [ -n "$TARGET_DRIVER" ] || die "--target-driver requires a value"
                TARGET_DRIVER_SOURCE="from command line"
                shift 2
                ;;
            --kernel-driver)
                EXPLICIT_HOST_VALUES=1
                KERNEL_DRIVER="${2:-}"
                [ -n "$KERNEL_DRIVER" ] || die "--kernel-driver requires a value"
                shift 2
                ;;
            --dpdk-pmd-package)
                DPDK_PMD_PACKAGE_OVERRIDE="${2:-}"
                [ -n "$DPDK_PMD_PACKAGE_OVERRIDE" ] || die "--dpdk-pmd-package requires a value"
                shift 2
                ;;
            --hugepages)
                EXPLICIT_HOST_VALUES=1
                HUGEPAGES="${2:-}"
                [ -n "$HUGEPAGES" ] || die "--hugepages requires a value"
                shift 2
                ;;
            --dpdk-mac)
                EXPLICIT_HOST_VALUES=1
                DPDK_MAC="${2:-}"
                [ -n "$DPDK_MAC" ] || die "--dpdk-mac requires a value"
                DPDK_MAC_SOURCE="from command line"
                shift 2
                ;;
            --dpdk-ipv4)
                EXPLICIT_HOST_VALUES=1
                DPDK_IPV4="${2:-}"
                [ -n "$DPDK_IPV4" ] || die "--dpdk-ipv4 requires a value"
                DPDK_IPV4_SOURCE="from command line"
                shift 2
                ;;
            --usrp-ip)
                EXPLICIT_HOST_VALUES=1
                USRP_IP="${2:-}"
                [ -n "$USRP_IP" ] || die "--usrp-ip requires a value"
                shift 2
                ;;
            --usrp-mgmt-ip)
                EXPLICIT_HOST_VALUES=1
                USRP_MGMT_IP="${2:-}"
                [ -n "$USRP_MGMT_IP" ] || die "--usrp-mgmt-ip requires a value"
                shift 2
                ;;
            --usrp-type)
                EXPLICIT_HOST_VALUES=1
                USRP_TYPE="${2:-}"
                [ -n "$USRP_TYPE" ] || die "--usrp-type requires a value"
                shift 2
                ;;
            --dummy-iface)
                EXPLICIT_HOST_VALUES=1
                DUMMY_IFACE="${2:-}"
                [ -n "$DUMMY_IFACE" ] || die "--dummy-iface requires a value"
                shift 2
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                die "Unknown argument '$1'. Run with --help for usage."
                ;;
        esac
    done

    case "$NON_INTERACTIVE" in
        0|1) ;;
        *) die "CELEOS_DPDK_SETUP_NON_INTERACTIVE must be 0 or 1" ;;
    esac
    if [ -n "$DPDK_PMD_PACKAGE_OVERRIDE" ] && [[ ! "$DPDK_PMD_PACKAGE_OVERRIDE" =~ ^[a-z0-9][a-z0-9+.-]*$ ]]; then
        die "--dpdk-pmd-package must be a Debian package name"
    fi
    if [ -n "$DPDK_RING_MEMPOOL_PACKAGE_OVERRIDE" ] && [[ ! "$DPDK_RING_MEMPOOL_PACKAGE_OVERRIDE" =~ ^[a-z0-9][a-z0-9+.-]*$ ]]; then
        die "CELEOS_DPDK_SETUP_DPDK_RING_MEMPOOL_PACKAGE must be a Debian package name"
    fi

    if [ "$DRY_RUN" -eq 1 ] && [ "$APPLY" -eq 1 ]; then
        die "--dry-run and --apply cannot be used together"
    fi
    if [ "$VIEW" -eq 1 ] && { [ "$APPLY" -eq 1 ] || [ "$DRY_RUN" -eq 1 ] || [ "$CHECK" -eq 1 ] || [ "$DISABLE_DPDK" -eq 1 ]; }; then
        die "--view cannot be used with --apply, --dry-run, --check, or --disable-dpdk"
    fi
    if [ "$CHECK" -eq 1 ] && { [ "$APPLY" -eq 1 ] || [ "$VIEW" -eq 1 ] || [ "$DRY_RUN" -eq 1 ] || [ "$DISABLE_DPDK" -eq 1 ]; }; then
        die "--check cannot be used with --apply, --view, --dry-run, or --disable-dpdk"
    fi
    if [ "$DISABLE_DPDK" -eq 1 ] && [ "$APPLY" -eq 1 ]; then
        die "--disable-dpdk cannot be used with --apply"
    fi
    if [ "$APPLY" -eq 0 ] && [ "$VIEW" -eq 0 ] && [ "$CHECK" -eq 0 ] && [ "$DISABLE_DPDK" -eq 0 ]; then
        DRY_RUN=1
        if [ "$initial_arg_count" -eq 0 ]; then
            PROMPT_APPLY_AFTER_PROBE=1
        fi
    fi
    if [ "$VIEW" -eq 1 ]; then
        NON_INTERACTIVE=1
    fi
}

read_config_value() {
    local key="$1"
    local file="$2"

    [ -r "$file" ] || return 0
    awk -F= -v wanted="$key" '
        $1 == wanted {
            value = $0
            sub(/^[^=]*=/, "", value)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
            gsub(/^"|"$/, "", value)
            print value
            exit
        }
    ' "$file"
}

load_existing_config_defaults() {
    local existing="$CONFIG_PATH"
    local config_iface
    local config_target_driver
    local config_mac
    local config_ipv4

    if [ "${CELEOS_DPDK_SETUP_IGNORE_EXISTING_CONFIG:-0}" = "1" ]; then
        return 0
    fi

    if [ ! -r "$existing" ] && [ -r "$LEGACY_CONFIG_PATH" ]; then
        existing="$LEGACY_CONFIG_PATH"
    fi
    [ -r "$existing" ] || return 0
    LOADED_CONFIG_PATH="$existing"
    echo "Found existing $existing; using it as defaults for empty values."

    PCI="${PCI:-$(read_config_value PCI "$existing")}"
    if [ -z "$IFACE" ]; then
        config_iface="$(read_config_value IFACE "$existing")"
        if [ -n "$config_iface" ]; then
            IFACE="$config_iface"
            IFACE_SOURCE="from existing config"
        fi
    fi
    if [ -z "$TARGET_DRIVER" ]; then
        config_target_driver="$(read_config_value TARGET_DRIVER "$existing")"
        if [ -n "$config_target_driver" ]; then
            TARGET_DRIVER="$config_target_driver"
            TARGET_DRIVER_SOURCE="from existing config"
        fi
    fi
    VFIO_GROUP_PCI="${VFIO_GROUP_PCI:-$(read_config_value VFIO_GROUP_PCI "$existing")}"
    VFIO_GROUP_RESTORE_DRIVERS="${VFIO_GROUP_RESTORE_DRIVERS:-$(read_config_value VFIO_GROUP_RESTORE_DRIVERS "$existing")}"
    HUGEPAGES="${HUGEPAGES:-$(read_config_value HUGEPAGES "$existing")}"
    if [ -z "$DPDK_MAC" ]; then
        config_mac="$(read_config_value DPDK_MAC "$existing")"
        if [ -n "$config_mac" ]; then
            DPDK_MAC="$config_mac"
            DPDK_MAC_SOURCE="from existing config"
        fi
    fi
    if [ -z "$DPDK_IPV4" ]; then
        config_ipv4="$(read_config_value DPDK_IPV4 "$existing")"
        if [ -n "$config_ipv4" ]; then
            DPDK_IPV4="$config_ipv4"
            DPDK_IPV4_SOURCE="from existing config"
        fi
    fi
    USRP_IP="${USRP_IP:-$(read_config_value USRP_IP "$existing")}"
    USRP_MGMT_IP="${USRP_MGMT_IP:-$(read_config_value USRP_MGMT_IP "$existing")}"
    USRP_TYPE="${USRP_TYPE:-$(read_config_value USRP_TYPE "$existing")}"
    DUMMY_IFACE="${DUMMY_IFACE:-$(read_config_value DUMMY_IFACE "$existing")}"
}

apply_builtin_defaults() {
    HUGEPAGES="${HUGEPAGES:-512}"
    DUMMY_IFACE="${DUMMY_IFACE:-usrpdpdk0}"
}

print_mode() {
    if [ "$APPLY" -eq 1 ]; then
        echo "Mode: apply"
    elif [ "$DISABLE_DPDK" -eq 1 ]; then
        if [ "$DRY_RUN" -eq 1 ]; then
            echo "Mode: disable-dpdk dry-run"
        else
            echo "Mode: disable-dpdk"
        fi
    elif [ "$CHECK" -eq 1 ]; then
        echo "Mode: check"
    elif [ "$VIEW" -eq 1 ]; then
        return
    else
        if [ "$EXPLICIT_DRY_RUN" -eq 1 ]; then
            cat <<EOF
=========================
Read-only probe, no changes will be made to the system
=========================
EOF
        else
            if [ "$PROMPT_APPLY_AFTER_PROBE" -eq 1 ]; then
                cat <<EOF
=========================
Initial probe; UHD host tools may be offered if uhd_find_devices is missing
No DPDK host changes will be made unless you confirm apply at the end
=========================
EOF
            else
                cat <<EOF
=========================
Initial probe; UHD host tools may be offered if uhd_find_devices is missing
No DPDK host changes will be made unless --apply is used
=========================
EOF
            fi
        fi
    fi
}

install_uhd_host_tools() {
    local sudo_cmd=()

    have_cmd apt-get || die "apt-get is required to install $HOST_UHD_PACKAGE on this Ubuntu host."
    if [ "$(id -u)" -ne 0 ]; then
        have_cmd sudo || die "sudo is required to install $HOST_UHD_PACKAGE."
        sudo_cmd=(sudo)
    fi

    echo "Installing UHD host tools package '$HOST_UHD_PACKAGE' for network USRP discovery."
    "${sudo_cmd[@]}" apt-get update
    "${sudo_cmd[@]}" apt-get install -y "$HOST_UHD_PACKAGE"
    HOST_UHD_TOOLS_INSTALLED=1
}

format_kib_size() {
    local kib="$1"
    local whole
    local tenths

    if [[ ! "$kib" =~ ^[0-9]+$ ]]; then
        printf 'unknown'
        return
    fi

    if [ "$kib" -ge 1048576 ]; then
        whole=$((kib / 1048576))
        tenths=$(((kib % 1048576) * 10 / 1048576))
        printf '%d.%d GiB' "$whole" "$tenths"
    elif [ "$kib" -ge 1024 ]; then
        whole=$((kib / 1024))
        tenths=$(((kib % 1024) * 10 / 1024))
        printf '%d.%d MiB' "$whole" "$tenths"
    else
        printf '%d KiB' "$kib"
    fi
}

estimate_package_disk_space() {
    local package="$1"
    local line
    local estimate

    if ! have_cmd apt-get; then
        printf 'unknown'
        return
    fi

    while IFS= read -r line; do
        case "$line" in
            "After this operation, "*" of additional disk space will be used.")
                estimate="${line#After this operation, }"
                estimate="${estimate% of additional disk space will be used.}"
                printf '%s' "${estimate:-unknown}"
                return
                ;;
        esac
    done < <(apt-get -s install "$package" 2>/dev/null || true)

    if have_cmd apt-cache; then
        while IFS= read -r line; do
            case "$line" in
                "Installed-Size: "*)
                    estimate="${line#Installed-Size: }"
                    format_kib_size "$estimate"
                    return
                    ;;
            esac
        done < <(apt-cache show "$package" 2>/dev/null || true)
    fi

    printf 'unknown'
}

estimate_uhd_host_tools_disk_space() {
    estimate_package_disk_space "$HOST_UHD_PACKAGE"
}

ensure_uhd_find_devices() {
    local answer
    local estimate

    if [ -n "${CELEOS_DPDK_SETUP_UHD_FIND_DEVICES_FILE:-}" ]; then
        return 0
    fi
    if have_cmd uhd_find_devices; then
        return 0
    fi

    echo "uhd_find_devices not found in PATH."
    if [ "$EXPLICIT_DRY_RUN" -eq 1 ]; then
        echo "Explicit --dry-run mode will not install $HOST_UHD_PACKAGE."
        return 0
    fi

    estimate="$(estimate_uhd_host_tools_disk_space)"
    printf "Would you like to install minimal UHD tools for USRP discovery so this script can validate the configuration it creates? Estimated additional disk space: %s. [y/N]: " "$estimate" >&2
    if ! read -r answer; then
        die "Input ended while reading UHD tools installation confirmation."
    fi
    echo >&2
    case "$answer" in
        y|Y|yes|YES|Yes)
            ;;
        *)
            echo "Skipping UHD host tools installation."
            return 0
            ;;
    esac

    install_uhd_host_tools
    have_cmd uhd_find_devices || die "$HOST_UHD_PACKAGE installation completed, but uhd_find_devices is still not in PATH."
    echo "Installed UHD host tools; uhd_find_devices is now available."
}

probe_host() {
    ensure_uhd_find_devices
    print_pci_functions_probe
    print_network_usrp_probe
}

network_pci_candidates() {
    if [ -n "${CELEOS_DPDK_SETUP_LSPCI_FILE:-}" ]; then
        awk '$1 ~ /^[0-9A-Fa-f]{4}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}\.[0-7]$/ { print }' "$CELEOS_DPDK_SETUP_LSPCI_FILE"
        return
    fi

    have_cmd lspci || return
    lspci -Dnn 2>/dev/null | grep -Ei 'ethernet|network|82599|x520|10-gigabit|10 gigabit' || true
}

pci_driver_name() {
    local pci_addr="$1"
    local fixture_driver

    if [ -n "${CELEOS_DPDK_SETUP_PCI_DRIVER_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_PCI_DRIVER_FILE" ]; then
        fixture_driver="$(awk -v pci="$pci_addr" '$1 == pci { print $2; exit }' "$CELEOS_DPDK_SETUP_PCI_DRIVER_FILE")"
        if [ -n "$fixture_driver" ]; then
            printf '%s' "$fixture_driver"
            return
        fi
    fi
    if [ -e "/sys/bus/pci/devices/$pci_addr/driver" ]; then
        basename "$(readlink -f "/sys/bus/pci/devices/$pci_addr/driver")"
    else
        printf 'none'
    fi
}

lspci_details_for_pci() {
    local pci_addr="$1"

    if [ -n "${CELEOS_DPDK_SETUP_LSPCI_FILE:-}" ]; then
        awk -v pci="$pci_addr" '
            $1 == pci {
                print
                in_device = 1
                next
            }
            in_device && /^[[:space:]]/ {
                print
                next
            }
            in_device {
                exit
            }
        ' "$CELEOS_DPDK_SETUP_LSPCI_FILE"
        return
    fi

    have_cmd lspci || return
    lspci -Dnnk -s "$pci_addr" 2>/dev/null || true
}

kernel_modules_for_pci() {
    local pci_addr="$1"

    lspci_details_for_pci "$pci_addr" | awk -F: '
        /^[[:space:]]*Kernel modules:/ {
            value = $2
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
            gsub(/,[[:space:]]*/, " ", value)
            print value
            exit
        }
    '
}

pci_modalias() {
    local pci_addr="$1"
    local fixture_modalias

    if [ -n "${CELEOS_DPDK_SETUP_PCI_MODALIAS_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_PCI_MODALIAS_FILE" ]; then
        fixture_modalias="$(awk -v pci="$pci_addr" '$1 == pci { print $2; exit }' "$CELEOS_DPDK_SETUP_PCI_MODALIAS_FILE")"
        printf '%s' "$fixture_modalias"
        return
    fi
    if [ -n "${CELEOS_DPDK_SETUP_LSPCI_FILE:-}" ]; then
        return 0
    fi
    if [ -r "/sys/bus/pci/devices/$pci_addr/modalias" ]; then
        cat "/sys/bus/pci/devices/$pci_addr/modalias"
    fi
}

modalias_kernel_modules_for_pci() {
    local pci_addr="$1"
    local modalias
    local module

    modalias="$(pci_modalias "$pci_addr")"
    [ -n "$modalias" ] || return 0
    have_cmd modprobe || return 0

    while IFS= read -r module; do
        module="${module##*/}"
        module="${module%.ko}"
        module="${module%.ko.xz}"
        [ -n "$module" ] || continue
        is_dpdk_binding_driver "$module" && continue
        printf '%s\n' "$module"
    done < <(modprobe --resolve-alias "$modalias" 2>/dev/null || true)
}

kernel_driver_candidates_for_pci() {
    local pci_addr="$1"
    local current_driver
    local module
    local seen=" "

    while IFS= read -r module; do
        [ -n "$module" ] || continue
        case "$seen" in
            *" $module "*) continue ;;
        esac
        seen="$seen$module "
        printf '%s\n' "$module"
    done < <(modalias_kernel_modules_for_pci "$pci_addr")

    current_driver="$(pci_driver_name "$pci_addr")"
    if [ -n "$current_driver" ] && [ "$current_driver" != "none" ] && ! is_dpdk_binding_driver "$current_driver"; then
        case "$seen" in
            *" $current_driver "*) ;;
            *)
                seen="$seen$current_driver "
                printf '%s\n' "$current_driver"
                ;;
        esac
    fi

    for module in $(kernel_modules_for_pci "$pci_addr"); do
        if ! is_dpdk_binding_driver "$module"; then
            case "$seen" in
                *" $module "*) ;;
                *)
                    seen="$seen$module "
                    printf '%s\n' "$module"
                    ;;
            esac
        fi
    done
}

kernel_driver_default_for_pci() {
    local pci_addr="$1"
    local module

    while IFS= read -r module; do
        [ -n "$module" ] || continue
        printf '%s' "$module"
        return
    done < <(kernel_driver_candidates_for_pci "$pci_addr")
}

pci_driver_bind_name() {
    local driver="$1"
    local fixture_driver
    local driver_link

    [ -n "$driver" ] || return 0
    if [ -n "${CELEOS_DPDK_SETUP_MODULE_PCI_DRIVER_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_MODULE_PCI_DRIVER_FILE" ]; then
        fixture_driver="$(awk -v module="$driver" '$1 == module { print $2; exit }' "$CELEOS_DPDK_SETUP_MODULE_PCI_DRIVER_FILE")"
        if [ -n "$fixture_driver" ]; then
            printf '%s' "$fixture_driver"
            return 0
        fi
    fi
    if [ -d "/sys/bus/pci/drivers/$driver" ]; then
        printf '%s' "$driver"
        return 0
    fi
    for driver_link in /sys/module/"$driver"/drivers/pci:*; do
        [ -e "$driver_link" ] || continue
        basename "$driver_link" | sed 's/^pci://'
        return 0
    done
    printf '%s' "$driver"
}

join_lines_with_spaces() {
    awk 'NF { printf "%s%s", sep, $0; sep = " " }'
}

kernel_driver_candidates_text() {
    local pci_addr="$1"

    kernel_driver_candidates_for_pci "$pci_addr" | join_lines_with_spaces
}

dpdk_pmd_for_kernel_driver() {
    case "$1" in
        ixgbe) printf 'ixgbe' ;;
        i40e) printf 'i40e' ;;
        ice) printf 'ice' ;;
        iavf) printf 'iavf' ;;
        igc) printf 'igc' ;;
        igb|e1000e) printf 'e1000' ;;
        mlx5_core) printf 'mlx5' ;;
        mlx4_core) printf 'mlx4' ;;
        bnxt_en) printf 'bnxt' ;;
        ena) printf 'ena' ;;
        vmxnet3) printf 'vmxnet3' ;;
        virtio_net) printf 'virtio' ;;
    esac
}

dpdk_pmd_candidates_for_pci() {
    local pci_addr="$1"
    local driver
    local pmd
    local seen=" "

    while IFS= read -r driver; do
        [ -n "$driver" ] || continue
        pmd="$(dpdk_pmd_for_kernel_driver "$driver")"
        [ -n "$pmd" ] || continue
        case "$seen" in
            *" $pmd "*) continue ;;
        esac
        seen="$seen$pmd "
        printf '%s\n' "$pmd"
    done < <(kernel_driver_candidates_for_pci "$pci_addr")
}

dpdk_pmd_candidates_text() {
    local pci_addr="$1"

    dpdk_pmd_candidates_for_pci "$pci_addr" | join_lines_with_spaces
}

dpdk_pmd_package_matches() {
    local pmd="$1"
    local package="$2"
    local suffix

    case "$package" in
        "librte-net-$pmd")
            return 0
            ;;
        "librte-net-$pmd"[0-9]*)
            suffix="${package#librte-net-$pmd}"
            [[ "$suffix" =~ ^[0-9]+$ ]]
            return
            ;;
        "librte-net-$pmd"-[0-9]*)
            suffix="${package#librte-net-$pmd-}"
            [[ "$suffix" =~ ^[0-9]+$ ]]
            return
            ;;
    esac
    return 1
}

dpdk_pmd_packages_from_apt() {
    local pmd="$1"
    local package
    local seen=" "

    have_cmd apt-cache || return 0

    while IFS= read -r package; do
        package="${package%% *}"
        [ -n "$package" ] || continue
        dpdk_pmd_package_matches "$pmd" "$package" || continue
        case "$seen" in
            *" $package "*) continue ;;
        esac
        seen="$seen$package "
        printf '%s\n' "$package"
    done < <(
        apt-cache pkgnames "librte-net-$pmd" 2>/dev/null || true
        apt-cache search --names-only "^librte-net-$pmd" 2>/dev/null | awk '{ print $1 }' || true
    )
}

dpdk_ring_mempool_package_matches() {
    local package="$1"
    local suffix

    case "$package" in
        "librte-mempool-ring")
            return 0
            ;;
        "librte-mempool-ring"[0-9]*)
            suffix="${package#librte-mempool-ring}"
            [[ "$suffix" =~ ^[0-9]+$ ]]
            return
            ;;
        "librte-mempool-ring"-[0-9]*)
            suffix="${package#librte-mempool-ring-}"
            [[ "$suffix" =~ ^[0-9]+$ ]]
            return
            ;;
    esac
    return 1
}

dpdk_ring_mempool_packages_from_apt() {
    local package
    local seen=" "

    have_cmd apt-cache || return 0

    while IFS= read -r package; do
        package="${package%% *}"
        [ -n "$package" ] || continue
        dpdk_ring_mempool_package_matches "$package" || continue
        case "$seen" in
            *" $package "*) continue ;;
        esac
        seen="$seen$package "
        printf '%s\n' "$package"
    done < <(
        apt-cache pkgnames "librte-mempool-ring" 2>/dev/null || true
        apt-cache search --names-only "^librte-mempool-ring" 2>/dev/null | awk '{ print $1 }' || true
    )
}

dpdk_pmd_package_installed() {
    local package="$1"
    local status

    have_cmd dpkg-query || return 1
    status="$(dpkg-query -W -f='${Status}' "$package" 2>/dev/null || true)"
    [ "$status" = "install ok installed" ]
}

resolve_dpdk_pmd_package() {
    local pmd
    local package

    if [ -n "$DPDK_PMD_PACKAGE_OVERRIDE" ]; then
        printf '%s' "$DPDK_PMD_PACKAGE_OVERRIDE"
        return 0
    fi

    while IFS= read -r pmd; do
        [ -n "$pmd" ] || continue
        while IFS= read -r package; do
            [ -n "$package" ] || continue
            printf '%s' "$package"
            return 0
        done < <(dpdk_pmd_packages_from_apt "$pmd")
    done < <(dpdk_pmd_candidates_for_pci "$PCI")
}

resolve_dpdk_ring_mempool_package() {
    local package

    if [ -n "$DPDK_RING_MEMPOOL_PACKAGE_OVERRIDE" ]; then
        printf '%s' "$DPDK_RING_MEMPOOL_PACKAGE_OVERRIDE"
        return 0
    fi

    while IFS= read -r package; do
        [ -n "$package" ] || continue
        printf '%s' "$package"
        return 0
    done < <(dpdk_ring_mempool_packages_from_apt)
}

first_dpdk_pmd_candidate() {
    local pci_addr="$1"
    local pmd

    while IFS= read -r pmd; do
        [ -n "$pmd" ] || continue
        printf '%s' "$pmd"
        return
    done < <(dpdk_pmd_candidates_for_pci "$pci_addr")
}

print_dpdk_pmd_resolution_failure() {
    local kernel_candidates="$1"
    local pmd_candidates="$2"
    local details

    echo "Could not resolve a DPDK PMD package for PCI $PCI."
    echo "PCI details:"
    details="$(lspci_details_for_pci "$PCI")"
    if [ -n "$details" ]; then
        printf '%s\n' "$details" | sed 's/^/  /'
    else
        echo "  unavailable"
    fi
    echo "Kernel driver candidates: ${kernel_candidates:-none}"
    echo "DPDK PMD candidates: ${pmd_candidates:-none}"
    echo "Rerun with --dpdk-pmd-package <package> if this NIC needs a package name this script cannot infer."
}

print_dpdk_pmd_package_plan() {
    local kernel_candidates
    local pmd_candidates
    local package
    local ring_package
    local ring_status="missing"
    local status="missing"

    [ -n "$PCI" ] || return 0
    is_dpdk_binding_driver "$TARGET_DRIVER" || return 0

    kernel_candidates="$(kernel_driver_candidates_text "$PCI")"
    pmd_candidates="$(dpdk_pmd_candidates_text "$PCI")"
    package="$(resolve_dpdk_pmd_package)"

    cat <<EOF

DPDK NIC PMD package
====================
Kernel driver candidates: ${kernel_candidates:-none}
DPDK PMD candidates: ${pmd_candidates:-none}
EOF
    if [ -n "$DPDK_PMD_PACKAGE_OVERRIDE" ]; then
        echo "DPDK PMD package override: $DPDK_PMD_PACKAGE_OVERRIDE"
    fi

    if [ -n "$package" ]; then
        dpdk_pmd_package_installed "$package" && status="installed"
        echo "Required Ubuntu package: $package"
        echo "Status: $status"
        if [ "$EXPLICIT_DRY_RUN" -eq 1 ] && [ "$status" = "missing" ]; then
            echo "Explicit --dry-run mode will not install $package."
        fi
    else
        echo "Required Ubuntu package: unresolved"
        print_dpdk_pmd_resolution_failure "$kernel_candidates" "$pmd_candidates"
    fi

    ring_package="$(resolve_dpdk_ring_mempool_package)"
    cat <<EOF

DPDK packet mempool package
===========================
EOF
    if [ -n "$DPDK_RING_MEMPOOL_PACKAGE_OVERRIDE" ]; then
        echo "DPDK ring mempool package override: $DPDK_RING_MEMPOOL_PACKAGE_OVERRIDE"
    fi
    if [ -n "$ring_package" ]; then
        dpdk_pmd_package_installed "$ring_package" && ring_status="installed"
        echo "Required Ubuntu package: $ring_package"
        echo "Status: $ring_status"
        if [ "$EXPLICIT_DRY_RUN" -eq 1 ] && [ "$ring_status" = "missing" ]; then
            echo "Explicit --dry-run mode will not install $ring_package."
        fi
    else
        echo "Required Ubuntu package: unresolved"
        echo "Install librte-mempool-ring for this Ubuntu DPDK release before applying DPDK mode."
    fi
}

install_dpdk_package() {
    local package="$1"
    local label="${2:-DPDK package}"
    local sudo_cmd=()

    have_cmd apt-get || die "apt-get is required to install $package on this Ubuntu host."
    if [ "$(id -u)" -ne 0 ]; then
        have_cmd sudo || die "sudo is required to install $package."
        sudo_cmd=(sudo)
    fi

    echo "Installing $label '$package'."
    "${sudo_cmd[@]}" apt-get update
    "${sudo_cmd[@]}" apt-get install -y "$package"
    echo "Installed $label '$package'."
}

install_dpdk_pmd_package() {
    install_dpdk_package "$1" "DPDK PMD package"
}

ensure_dpdk_pmd_package_for_apply() {
    local kernel_candidates
    local pmd_candidates
    local pmd
    local package
    local estimate
    local answer

    [ -n "$PCI" ] || return 0
    is_dpdk_binding_driver "$TARGET_DRIVER" || return 0

    kernel_candidates="$(kernel_driver_candidates_text "$PCI")"
    pmd_candidates="$(dpdk_pmd_candidates_text "$PCI")"
    pmd="$(first_dpdk_pmd_candidate "$PCI")"
    package="$(resolve_dpdk_pmd_package)"

    if [ -z "$package" ]; then
        print_dpdk_pmd_resolution_failure "$kernel_candidates" "$pmd_candidates" >&2
        die "Required DPDK PMD package is unknown for $PCI."
    fi

    if dpdk_pmd_package_installed "$package"; then
        return 0
    fi

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        cat >&2 <<EOF
ERROR: Required DPDK PMD package $package is not installed.
Non-interactive --apply cannot install it because installation requires confirmation.
Install $package first, or rerun interactively.
EOF
        exit 1
    fi

    estimate="$(estimate_package_disk_space "$package")"
    echo
    echo "DPDK NIC PMD package '$package' is required for ${pmd:-the selected NIC} on $PCI."
    printf "Would you like to install %s now? Estimated additional disk space: %s. [y/N]: " "$package" "$estimate" >&2
    if ! read -r answer; then
        die "Input ended while reading DPDK PMD package installation confirmation."
    fi
    echo >&2

    case "$answer" in
        y|Y|yes|YES|Yes)
            install_dpdk_pmd_package "$package"
            ;;
        *)
            die "Required DPDK PMD package $package was not installed."
            ;;
    esac
}

ensure_dpdk_ring_mempool_package_for_apply() {
    local package
    local estimate
    local answer

    [ -n "$PCI" ] || return 0
    is_dpdk_binding_driver "$TARGET_DRIVER" || return 0

    package="$(resolve_dpdk_ring_mempool_package)"
    if [ -z "$package" ]; then
        die "Required DPDK packet mempool package is unknown. Install librte-mempool-ring for this Ubuntu DPDK release before applying DPDK mode."
    fi

    if dpdk_pmd_package_installed "$package"; then
        return 0
    fi

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        cat >&2 <<EOF
ERROR: Required DPDK packet mempool package $package is not installed.
Non-interactive --apply cannot install it because installation requires confirmation.
Install $package first, or rerun interactively.
EOF
        exit 1
    fi

    estimate="$(estimate_package_disk_space "$package")"
    echo
    echo "DPDK packet mempool package '$package' is required for UHD DPDK packet buffers."
    printf "Would you like to install %s now? Estimated additional disk space: %s. [y/N]: " "$package" "$estimate" >&2
    if ! read -r answer; then
        die "Input ended while reading DPDK packet mempool package installation confirmation."
    fi
    echo >&2

    case "$answer" in
        y|Y|yes|YES|Yes)
            install_dpdk_package "$package"
            ;;
        *)
            die "Required DPDK packet mempool package $package was not installed."
            ;;
    esac
}

require_dpdk_pmd_package_resolved_for_apply() {
    local kernel_candidates
    local pmd_candidates
    local package

    [ -n "$PCI" ] || return 0
    is_dpdk_binding_driver "$TARGET_DRIVER" || return 0

    package="$(resolve_dpdk_pmd_package)"
    [ -n "$package" ] && return 0

    kernel_candidates="$(kernel_driver_candidates_text "$PCI")"
    pmd_candidates="$(dpdk_pmd_candidates_text "$PCI")"
    print_dpdk_pmd_resolution_failure "$kernel_candidates" "$pmd_candidates" >&2
    die "Required DPDK PMD package is unknown for $PCI."
}

require_dpdk_ring_mempool_package_resolved_for_apply() {
    local package

    [ -n "$PCI" ] || return 0
    is_dpdk_binding_driver "$TARGET_DRIVER" || return 0

    package="$(resolve_dpdk_ring_mempool_package)"
    [ -n "$package" ] && return 0

    die "Required DPDK packet mempool package is unknown. Install librte-mempool-ring for this Ubuntu DPDK release before applying DPDK mode."
}

iface_for_pci() {
    local pci_addr="$1"
    local fixture_iface
    local iface_path
    local pci

    if [ -n "${CELEOS_DPDK_SETUP_PCI_IFACE_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_PCI_IFACE_FILE" ]; then
        fixture_iface="$(awk -v pci="$pci_addr" '$1 == pci { print $2; exit }' "$CELEOS_DPDK_SETUP_PCI_IFACE_FILE")"
        printf '%s' "$fixture_iface"
        return 0
    fi

    for iface_path in /sys/class/net/*; do
        [ -e "$iface_path/device" ] || continue
        pci="$(basename "$(readlink -f "$iface_path/device" 2>/dev/null || true)")"
        if [ "$pci" = "$pci_addr" ]; then
            basename "$iface_path"
            return 0
        fi
    done
    return 0
}

pci_for_iface() {
    local iface="$1"
    local fixture_pci

    if [ -n "${CELEOS_DPDK_SETUP_PCI_IFACE_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_PCI_IFACE_FILE" ]; then
        fixture_pci="$(awk -v iface="$iface" '$2 == iface { print $1; exit }' "$CELEOS_DPDK_SETUP_PCI_IFACE_FILE")"
        printf '%s' "$fixture_pci"
        return 0
    fi

    if [ -e "/sys/class/net/$iface/device" ]; then
        basename "$(readlink -f "/sys/class/net/$iface/device" 2>/dev/null || true)"
    fi
    return 0
}

route_iface_for_ip() {
    local ip_addr="$1"
    local fixture_iface

    if [ -n "${CELEOS_DPDK_SETUP_ROUTE_IFACE_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_ROUTE_IFACE_FILE" ]; then
        fixture_iface="$(awk -v ip_addr="$ip_addr" '$1 == ip_addr { print $2; exit }' "$CELEOS_DPDK_SETUP_ROUTE_IFACE_FILE")"
        printf '%s' "$fixture_iface"
        return 0
    fi

    if have_cmd ip; then
        ip route get "$ip_addr" 2>/dev/null | awk '
            {
                for (i = 1; i < NF; i++) {
                    if ($i == "dev") {
                        print $(i + 1)
                        exit
                    }
                }
            }
        '
    fi
    return 0
}

iface_has_default_route() {
    local iface="$1"
    local fixture_iface

    if [ -n "${CELEOS_DPDK_SETUP_DEFAULT_ROUTE_IFACES:-}" ]; then
        for fixture_iface in $CELEOS_DPDK_SETUP_DEFAULT_ROUTE_IFACES; do
            [ "$fixture_iface" = "$iface" ] && return 0
        done
        return 1
    fi

    if have_cmd ip; then
        ip route show default 2>/dev/null | awk '
            {
                for (i = 1; i < NF; i++) {
                    if ($i == "dev") {
                        print $(i + 1)
                    }
                }
            }
        ' | grep -Fxq "$iface"
        return
    fi
    return 1
}

ssh_client_ip() {
    local first

    first="${SSH_CLIENT:-}"
    first="${first%% *}"
    printf '%s' "$first"
}

vfio_group_binding_risks() {
    [ "$TARGET_DRIVER" = "vfio-pci" ] || return 0
    vfio_group_safety_risks 0
}

is_dpdk_binding_driver() {
    case "$1" in
        vfio-pci|vfio_pci|uio_pci_generic|igb_uio)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

dpdk_binding_driver_available() {
    local driver="$1"
    local available_driver
    local module_name

    [ -n "$driver" ] || return 1
    if [ -n "${CELEOS_DPDK_SETUP_AVAILABLE_DPDK_DRIVERS+x}" ]; then
        for available_driver in $CELEOS_DPDK_SETUP_AVAILABLE_DPDK_DRIVERS; do
            [ "$available_driver" = "$driver" ] && return 0
        done
        return 1
    fi

    if [ -d "/sys/bus/pci/drivers/$driver" ]; then
        return 0
    fi
    module_name="${driver//-/_}"
    if [ -d "/sys/module/$module_name" ] || [ -d "/sys/module/$driver" ]; then
        return 0
    fi
    have_cmd modprobe && modprobe -n "$driver" >/dev/null 2>&1
}

iface_mac_address() {
    local iface="$1"
    local fixture_mac

    if [ -n "${CELEOS_DPDK_SETUP_IFACE_MAC_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_IFACE_MAC_FILE" ]; then
        fixture_mac="$(awk -v iface="$iface" '$1 == iface { print $2; exit }' "$CELEOS_DPDK_SETUP_IFACE_MAC_FILE")"
        printf '%s' "$fixture_mac"
        return 0
    fi
    if [ -r "/sys/class/net/$iface/address" ]; then
        cat "/sys/class/net/$iface/address"
    fi
    return 0
}

iface_ipv4_address() {
    local iface="$1"
    local ipv4_addresses

    ipv4_addresses="$(iface_ipv4_addresses "$iface")"
    printf '%s' "${ipv4_addresses%%,*}"
}

iface_ipv4_addresses() {
    local iface="$1"
    local fixture_ipv4

    if [ -n "${CELEOS_DPDK_SETUP_IFACE_IPV4_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_IFACE_IPV4_FILE" ]; then
        fixture_ipv4="$(awk -v iface="$iface" '
            $1 == iface {
                for (i = 2; i <= NF; i++) {
                    printf "%s%s", sep, $i
                    sep = ","
                }
                exit
            }
        ' "$CELEOS_DPDK_SETUP_IFACE_IPV4_FILE")"
        printf '%s' "$fixture_ipv4"
        return 0
    fi
    if have_cmd ip; then
        ip -o -4 addr show dev "$iface" scope global 2>/dev/null | awk '
            $3 == "inet" {
                printf "%s%s", sep, $4
                sep = ","
            }
        '
    fi
    return 0
}

print_pci_candidate_rows() {
    local index=1
    local pci_addr
    local pci_driver
    local pci_iface
    local pci_ipv4
    local pci_line

    for pci_line in "$@"; do
        pci_addr="${pci_line%% *}"
        pci_driver="$(pci_driver_name "$pci_addr")"
        pci_iface="$(iface_for_pci "$pci_addr")"
        pci_ipv4=""
        if [ -n "$pci_iface" ]; then
            pci_ipv4="$(iface_ipv4_addresses "$pci_iface")"
        fi
        printf '  %d) %s driver=%s iface=%s ipv4=%s\n' \
            "$index" \
            "$pci_line" \
            "$pci_driver" \
            "${pci_iface:-none}" \
            "${pci_ipv4:-none}"
        index=$((index + 1))
    done
}

print_pci_functions_probe() {
    local candidates=()

    mapfile -t candidates < <(network_pci_candidates)

    echo
    echo "PCI functions:"
    PCI_FUNCTIONS_PROBE_PRINTED=1
    if [ "${#candidates[@]}" -eq 0 ]; then
        echo "  none"
        return
    fi

    print_pci_candidate_rows "${candidates[@]}"
}

target_driver_default() {
    local current_driver
    local vfio_risks

    if [ -n "$PCI" ]; then
        current_driver="$(pci_driver_name "$PCI")"
        if is_dpdk_binding_driver "$current_driver"; then
            printf '%s' "$current_driver"
            return
        fi
    fi

    if dpdk_binding_driver_available "vfio-pci"; then
        vfio_risks="$(vfio_group_safety_risks 1)"
        if [ -z "$vfio_risks" ]; then
            printf 'vfio-pci'
            return
        fi
    else
        vfio_risks="vfio-pci is not available"
    fi

    if dpdk_binding_driver_available "uio_pci_generic"; then
        printf 'uio_pci_generic'
        return
    fi
    if dpdk_binding_driver_available "igb_uio"; then
        printf 'igb_uio'
        return
    fi

    {
        echo "No safe DPDK binding driver is available for ${PCI:-the selected PCI function}."
        if dpdk_binding_driver_available "vfio-pci"; then
            echo "vfio-pci cannot be selected by default because the selected IOMMU group is unsafe:"
            printf '%s\n' "$vfio_risks" | sed 's/^/  /'
        else
            echo "vfio-pci is not available"
        fi
        echo "uio_pci_generic is not available"
        echo "igb_uio is not available"
        echo "Install/enable uio_pci_generic or igb_uio, choose a PCI function with a safe IOMMU group, or pass --target-driver after reviewing the topology."
    } >&2
    return 1
}

target_driver_prompt_default() {
    local current="$1"
    local recommended

    if [ "$TARGET_DRIVER_SOURCE" = "from command line" ]; then
        printf '%s' "$current"
        return 0
    fi

    if recommended="$(target_driver_default)"; then
        printf '%s' "$recommended"
        return 0
    fi

    if [ -n "$current" ]; then
        printf '%s' "$current"
        return 0
    fi

    return 1
}

vfio_driver_prompt_note() {
    local selected_pci="$1"
    local prompt_default="$2"
    local vfio_risks

    if ! vfio_iommu_active_for_pci "$selected_pci"; then
        if [ "$prompt_default" = "vfio-pci" ]; then
            printf ' (recommended, requires IOMMU reboot)'
        else
            printf ' (requires IOMMU reboot)'
        fi
        return
    fi

    vfio_risks="$(vfio_group_safety_risks 1)"
    if [ -n "$vfio_risks" ] && [ "$prompt_default" != "vfio-pci" ]; then
        printf ' (IOMMU active, unsafe group)'
        return
    fi

    if [ "$prompt_default" = "vfio-pci" ]; then
        printf ' (recommended, IOMMU active)'
    else
        printf ' (IOMMU active)'
    fi
}

kernel_cmdline() {
    if [ -n "${CELEOS_DPDK_SETUP_CMDLINE+x}" ]; then
        printf '%s' "$CELEOS_DPDK_SETUP_CMDLINE"
        return
    fi
    [ -r /proc/cmdline ] && cat /proc/cmdline
}

cpu_vendor() {
    if [ -n "${CELEOS_DPDK_SETUP_CPU_VENDOR+x}" ]; then
        printf '%s' "$CELEOS_DPDK_SETUP_CPU_VENDOR"
        return
    fi
    if have_cmd lscpu; then
        lscpu 2>/dev/null | awk -F: '/Vendor ID/ { gsub(/^[[:space:]]+/, "", $2); print $2; exit }'
        return
    fi
    awk -F: '/vendor_id/ { gsub(/^[[:space:]]+/, "", $2); print $2; exit }' /proc/cpuinfo 2>/dev/null || true
}

iommu_kernel_args() {
    case "$(cpu_vendor)" in
        GenuineIntel)
            printf 'intel_iommu=on iommu=pt'
            ;;
        AuthenticAMD)
            printf 'amd_iommu=on iommu=pt'
            ;;
        *)
            return 1
            ;;
    esac
}

iommu_kernel_args_present() {
    local cmdline
    local expected
    local arg

    cmdline="$(kernel_cmdline)"
    expected="$(iommu_kernel_args 2>/dev/null || true)"
    [ -n "$expected" ] || return 1

    for arg in $expected; do
        case " $cmdline " in
            *" $arg "*) ;;
            *) return 1 ;;
        esac
    done
}

iommu_group_count() {
    if [ -n "${CELEOS_DPDK_SETUP_IOMMU_GROUP_COUNT+x}" ]; then
        printf '%s' "$CELEOS_DPDK_SETUP_IOMMU_GROUP_COUNT"
        return
    fi
    if [ -d /sys/kernel/iommu_groups ]; then
        find /sys/kernel/iommu_groups -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l
    else
        printf '0'
    fi
}

pci_iommu_group() {
    local pci_addr="$1"
    local fixture_group
    local group_path

    if [ -n "${CELEOS_DPDK_SETUP_PCI_IOMMU_GROUP_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_PCI_IOMMU_GROUP_FILE" ]; then
        fixture_group="$(awk -v pci="$pci_addr" '$1 == pci { print $2; exit }' "$CELEOS_DPDK_SETUP_PCI_IOMMU_GROUP_FILE")"
        printf '%s' "$fixture_group"
        return
    fi

    group_path="$(readlink -f "/sys/bus/pci/devices/$pci_addr/iommu_group" 2>/dev/null || true)"
    if [ -n "$group_path" ]; then
        basename "$group_path"
    fi
    return 0
}

pci_iommu_group_members() {
    local pci_addr="$1"
    local iommu_group
    local member_path

    iommu_group="$(pci_iommu_group "$pci_addr")"
    [ -n "$iommu_group" ] || {
        printf '%s\n' "$pci_addr"
        return 0
    }

    if [ -n "${CELEOS_DPDK_SETUP_PCI_IOMMU_GROUP_FILE:-}" ] && [ -r "$CELEOS_DPDK_SETUP_PCI_IOMMU_GROUP_FILE" ]; then
        awk -v group="$iommu_group" '$2 == group { print $1 }' "$CELEOS_DPDK_SETUP_PCI_IOMMU_GROUP_FILE"
        return 0
    fi

    if [ -d "/sys/kernel/iommu_groups/$iommu_group/devices" ]; then
        for member_path in /sys/kernel/iommu_groups/"$iommu_group"/devices/*; do
            [ -e "$member_path" ] || continue
            basename "$member_path"
        done
        return 0
    fi

    printf '%s\n' "$pci_addr"
}

pci_summary_line() {
    local pci_addr="$1"

    lspci_details_for_pci "$pci_addr" | awk 'NF { print; exit }'
}

pci_is_bridge() {
    local pci_addr="$1"
    local summary

    summary="$(pci_summary_line "$pci_addr")"
    printf '%s\n' "$summary" | grep -Eiq '(^|[[:space:]])(PCI|Host|ISA|PCIe)?[[:space:]-]*bridge[[:space:]]|\[06[0-9A-Fa-f]{2}\]'
}

pci_is_network_endpoint() {
    local pci_addr="$1"
    local summary

    summary="$(pci_summary_line "$pci_addr")"
    printf '%s\n' "$summary" | grep -Eiq '(Ethernet controller|Network controller|\[02[0-9A-Fa-f]{2}\])'
}

vfio_candidate_endpoint_pci_list() {
    local member
    local printed=0

    while IFS= read -r member; do
        [ -n "$member" ] || continue
        if pci_is_bridge "$member"; then
            continue
        fi
        printf '%s\n' "$member"
        printed=1
    done < <(pci_iommu_group_members "$PCI")

    [ "$printed" -eq 1 ] || printf '%s\n' "$PCI"
}

vfio_group_endpoint_pci_list() {
    if [ "$TARGET_DRIVER" != "vfio-pci" ]; then
        printf '%s\n' "$PCI"
        return 0
    fi

    vfio_candidate_endpoint_pci_list
}

restore_driver_for_pci() {
    local pci_addr="$1"
    local pair

    for pair in $VFIO_GROUP_RESTORE_DRIVERS; do
        if [ "${pair%%=*}" = "$pci_addr" ]; then
            printf '%s' "${pair#*=}"
            return 0
        fi
    done

    if [ "$pci_addr" = "$PCI" ] && [ -n "$KERNEL_DRIVER" ]; then
        printf '%s' "$KERNEL_DRIVER"
        return 0
    fi

    kernel_driver_default_for_pci "$pci_addr"
}

vfio_group_safety_risks() {
    local require_group="${1:-1}"
    local iommu_group
    local endpoint
    local iface
    local ipv4s
    local restore_driver
    local summary
    local ssh_ip
    local ssh_iface

    [ -n "$PCI" ] || return 0

    iommu_group="$(pci_iommu_group "$PCI")"
    if [ -z "$iommu_group" ] && [ "$require_group" -eq 1 ]; then
        echo "$PCI has no detectable IOMMU group, so vfio-pci topology safety cannot be confirmed"
    fi

    ssh_ip="$(ssh_client_ip)"
    if [ -n "$ssh_ip" ]; then
        ssh_iface="$(route_iface_for_ip "$ssh_ip")"
    fi

    while IFS= read -r endpoint; do
        [ -n "$endpoint" ] || continue

        if [ "$endpoint" != "$PCI" ] && ! pci_is_network_endpoint "$endpoint"; then
            summary="$(pci_summary_line "$endpoint")"
            echo "$endpoint is a non-network endpoint${summary:+: $summary}"
        fi

        if [ "$endpoint" != "$PCI" ] || [ "$require_group" -eq 1 ]; then
            restore_driver="$(restore_driver_for_pci "$endpoint")"
            if [ -z "$restore_driver" ]; then
                echo "$endpoint restore driver cannot be determined"
            fi
        fi

        [ "$endpoint" != "$PCI" ] || continue
        pci_is_network_endpoint "$endpoint" || continue

        iface="$(iface_for_pci "$endpoint")"
        [ -n "$iface" ] || continue

        ipv4s="$(iface_ipv4_addresses "$iface")"
        if [ -n "$ipv4s" ]; then
            echo "$endpoint iface=$iface has IPv4 address(es): $ipv4s"
        fi
        if iface_has_default_route "$iface"; then
            echo "$endpoint iface=$iface carries a default route"
        fi
        if [ -n "${ssh_iface:-}" ] && [ "$ssh_iface" = "$iface" ]; then
            echo "$endpoint iface=$iface routes the current SSH client $ssh_ip"
        fi
    done < <(vfio_candidate_endpoint_pci_list)
}

refresh_vfio_group_values() {
    local endpoints=()
    local endpoint
    local restore_driver
    local restore_pairs=()

    [ -n "$PCI" ] || return 0

    if [ "$TARGET_DRIVER" != "vfio-pci" ]; then
        restore_driver="$(restore_driver_for_pci "$PCI")"
        VFIO_GROUP_PCI="$PCI"
        if [ -n "$restore_driver" ]; then
            VFIO_GROUP_RESTORE_DRIVERS="$PCI=$restore_driver"
        else
            VFIO_GROUP_RESTORE_DRIVERS=""
        fi
        return 0
    fi

    if [ -z "$VFIO_GROUP_PCI" ]; then
        mapfile -t endpoints < <(vfio_group_endpoint_pci_list)
        VFIO_GROUP_PCI="${endpoints[*]}"
    else
        read -r -a endpoints <<<"$VFIO_GROUP_PCI"
    fi

    if [ -z "$VFIO_GROUP_RESTORE_DRIVERS" ]; then
        for endpoint in "${endpoints[@]}"; do
            [ -n "$endpoint" ] || continue
            restore_driver="$(restore_driver_for_pci "$endpoint")"
            [ -n "$restore_driver" ] || continue
            restore_pairs+=("$endpoint=$restore_driver")
        done
        VFIO_GROUP_RESTORE_DRIVERS="${restore_pairs[*]}"
    fi
}

vfio_group_device_exists() {
    local iommu_group="$1"
    local group

    [ -n "$iommu_group" ] || return 1
    if [ -n "${CELEOS_DPDK_SETUP_VFIO_GROUPS:-}" ]; then
        for group in $CELEOS_DPDK_SETUP_VFIO_GROUPS; do
            [ "$group" = "$iommu_group" ] && return 0
        done
        return 1
    fi
    [ -e "/dev/vfio/$iommu_group" ]
}

vfio_iommu_active_for_pci() {
    local pci_addr="$1"
    local group_count
    local iommu_group

    group_count="$(iommu_group_count)"
    [[ "$group_count" =~ ^[0-9]+$ ]] || return 1
    [ "$group_count" -gt 0 ] || return 1

    iommu_group="$(pci_iommu_group "$pci_addr")"
    [ -n "$iommu_group" ] || return 1
    iommu_kernel_args_present
}

vfio_iommu_setup_needed() {
    [ "$TARGET_DRIVER" = "vfio-pci" ] || return 1
    ! vfio_iommu_active_for_pci "$PCI"
}

suggest_pci_from_discovered_usrps() {
    local candidates=()
    local candidate
    local candidate_ip
    local candidate_detail
    local route_iface
    local route_pci

    [ -z "$PCI" ] || return 0

    mapfile -t candidates < <(network_usrp_candidates)
    for candidate in "${candidates[@]}"; do
        IFS=$'\t' read -r candidate_ip candidate_detail <<< "$candidate"
        [ -n "$candidate_ip" ] || continue

        route_iface="$(route_iface_for_ip "$candidate_ip")"
        [ -n "$route_iface" ] || continue

        route_pci="$(pci_for_iface "$route_iface")"
        [ -n "$route_pci" ] || continue

        PCI="$route_pci"
        if [ -z "$IFACE" ]; then
            IFACE="$route_iface"
            IFACE_SOURCE="auto-detected from route to $candidate_ip"
        fi
        USRP_IP="${USRP_IP:-$candidate_ip}"
        apply_discovered_usrp_metadata_defaults "$candidate_ip"
        if [ "$VIEW" -eq 0 ]; then
            echo "Suggested PCI from discovered USRP route: $PCI (USRP $candidate_ip via $route_iface)." >&2
        fi
        return 0
    done
}

loaded_config_dpdk_runtime_active() {
    local current_driver

    [ -n "$LOADED_CONFIG_PATH" ] || return 1
    [ -n "$PCI" ] || return 1

    current_driver="$(pci_driver_name "$PCI")"
    is_dpdk_binding_driver "$current_driver"
}

demote_loaded_config_hardware_defaults_if_live_discovery_available() {
    local live_defaults
    local live_usrp_ip
    local live_iface
    local live_pci
    local live_usrp_mgmt_ip
    local live_usrp_type
    local configured_pci

    [ -n "$LOADED_CONFIG_PATH" ] || return 0
    [ "$EXPLICIT_HOST_VALUES" -eq 0 ] || return 0
    loaded_config_dpdk_runtime_active && return 0

    live_defaults="$(routed_discovered_usrp_defaults)"
    [ -n "$live_defaults" ] || return 0

    IFS='|' read -r live_usrp_ip live_iface live_pci live_usrp_mgmt_ip live_usrp_type <<< "$live_defaults"
    [ -n "$live_usrp_ip" ] || return 0
    [ -n "$live_iface" ] || return 0
    [ -n "$live_pci" ] || return 0

    configured_pci="$PCI"
    DEMOTED_CONFIG_PATH="$LOADED_CONFIG_PATH"
    LOADED_CONFIG_PATH=""

    PCI="$live_pci"
    IFACE="$live_iface"
    IFACE_SOURCE="auto-detected from route to $live_usrp_ip"
    DPDK_MAC=""
    DPDK_MAC_SOURCE=""
    DPDK_IPV4=""
    DPDK_IPV4_SOURCE=""
    VFIO_GROUP_PCI=""
    VFIO_GROUP_RESTORE_DRIVERS=""
    USRP_IP="$live_usrp_ip"
    USRP_MGMT_IP="$live_usrp_mgmt_ip"
    USRP_TYPE="$live_usrp_type"

    if [ "$VIEW" -eq 0 ]; then
        cat >&2 <<EOF
Host DPDK does not appear active for configured PCI ${configured_pci:-unknown}; using live uhd_find_devices route to $live_usrp_ip via $live_iface instead.
Hardware-derived defaults from $DEMOTED_CONFIG_PATH were demoted: PCI, IFACE, DPDK_MAC, DPDK_IPV4, VFIO group, USRP_IP, USRP_MGMT_IP, and USRP_TYPE.
EOF
    fi
}

derive_values_from_host() {
    local iface_mac
    local iface_ipv4

    if [ -n "$PCI" ] && [ -z "$IFACE" ]; then
        IFACE="$(iface_for_pci "$PCI")"
        if [ -n "$IFACE" ]; then
            IFACE_SOURCE="auto-detected from $PCI"
        fi
    fi

    if [ -n "$IFACE" ] && [ -z "$PCI" ] && [ -e "/sys/class/net/$IFACE/device" ]; then
        PCI="$(basename "$(readlink -f "/sys/class/net/$IFACE/device" 2>/dev/null || true)")"
    fi

    if [ -n "$IFACE" ] && [ -z "$DPDK_MAC" ]; then
        iface_mac="$(iface_mac_address "$IFACE")"
        if [ -n "$iface_mac" ]; then
            DPDK_MAC="$iface_mac"
            DPDK_MAC_SOURCE="auto-detected from $IFACE"
        fi
    fi

    if [ -n "$IFACE" ] && [ -z "$DPDK_IPV4" ]; then
        iface_ipv4="$(iface_ipv4_address "$IFACE")"
        if [ -n "$iface_ipv4" ]; then
            DPDK_IPV4="$iface_ipv4"
            DPDK_IPV4_SOURCE="auto-detected from $IFACE"
        fi
    fi
}

prompt_value() {
    local label="$1"
    local current="$2"
    local value

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        printf '%s' "$current"
        return
    fi

    if [ -n "$current" ]; then
        printf '%s [%s]: ' "$label" "$current" >&2
        read -r value
        echo >&2
        printf '%s' "${value:-$current}"
    else
        printf '%s: ' "$label" >&2
        read -r value
        echo >&2
        printf '%s' "$value"
    fi
}

warn_dpdk_mac_auto_detect_unavailable() {
    local current_driver

    [ -z "$DPDK_MAC" ] || return 0
    [ -n "$PCI" ] || return 0
    [ -z "$IFACE" ] || return 0

    current_driver="$(pci_driver_name "$PCI")"
    is_dpdk_binding_driver "$current_driver" || return 0

    cat >&2 <<EOF
MAC cannot be auto-detected because $PCI is bound to $current_driver and has no Linux network interface.
Enter the NIC port MAC manually, or temporarily bind it to the kernel driver before running setup.
EOF
}

prompt_dpdk_mac_value() {
    local value

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        printf '%s' "$DPDK_MAC"
        return
    fi

    warn_dpdk_mac_auto_detect_unavailable
    if [ -n "$DPDK_MAC" ] && [[ "$DPDK_MAC_SOURCE" == auto-detected* ]]; then
        printf '%s' "$DPDK_MAC"
        return
    fi
    if [ -n "$DPDK_MAC" ]; then
        if [ -n "$DPDK_MAC_SOURCE" ]; then
            printf 'DPDK port MAC address [%s] (%s): ' "$DPDK_MAC" "$DPDK_MAC_SOURCE" >&2
            read -r value
            echo >&2
        else
            printf 'DPDK port MAC address [%s]: ' "$DPDK_MAC" >&2
            read -r value
            echo >&2
        fi
        printf '%s' "${value:-$DPDK_MAC}"
    else
        printf 'DPDK port MAC address: ' >&2
        read -r value
        echo >&2
        printf '%s' "$value"
    fi
}

prompt_dpdk_ipv4_value() {
    local value

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        printf '%s' "$DPDK_IPV4"
        return
    fi

    if [ -n "$DPDK_IPV4" ]; then
        if [ -n "$DPDK_IPV4_SOURCE" ]; then
            printf 'Local DPDK IPv4/prefix [%s] (%s): ' "$DPDK_IPV4" "$DPDK_IPV4_SOURCE" >&2
            read -r value
            echo >&2
        else
            printf 'Local DPDK IPv4/prefix [%s]: ' "$DPDK_IPV4" >&2
            read -r value
            echo >&2
        fi
        printf '%s' "${value:-$DPDK_IPV4}"
    else
        printf 'Local DPDK IPv4/prefix: ' >&2
        read -r value
        echo >&2
        printf '%s' "$value"
    fi
}

uhd_find_devices_output() {
    if [ -n "${CELEOS_DPDK_SETUP_UHD_FIND_DEVICES_FILE:-}" ]; then
        cat "$CELEOS_DPDK_SETUP_UHD_FIND_DEVICES_FILE"
        return
    fi

    have_cmd uhd_find_devices || return 0
    if have_cmd timeout; then
        timeout 8s uhd_find_devices 2>/dev/null || true
    else
        uhd_find_devices 2>/dev/null || true
    fi
}

load_network_usrp_candidates() {
    [ "$NETWORK_USRP_CANDIDATES_LOADED" -eq 0 ] || return
    mapfile -t NETWORK_USRP_CANDIDATES < <(uhd_find_devices_output | awk '
        function reset_device() {
            delete ips
            delete ip_keys
            ip_count = 0
            serial = ""
            product = ""
            type = ""
        }
        function add_ip(value, key, i) {
            if (value !~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) {
                return
            }
            for (i = 1; i <= ip_count; i++) {
                if (ips[i] == value) {
                    return
                }
            }
            ip_count++
            ips[ip_count] = value
            ip_keys[ip_count] = key
        }
        function flush_device(i, detail) {
            for (i = 1; i <= ip_count; i++) {
                detail = ""
                if (type != "") {
                    detail = detail "type=" type
                }
                if (product != "") {
                    detail = detail (detail == "" ? "" : " ") "product=" product
                }
                if (serial != "") {
                    detail = detail (detail == "" ? "" : " ") "serial=" serial
                }
                detail = detail (detail == "" ? "" : " ") "via=" ip_keys[i]
                print ips[i] "\t" detail
            }
            reset_device()
        }
        BEGIN {
            reset_device()
        }
        /^-- UHD Device/ {
            flush_device()
            next
        }
        {
            line = $0
            sub(/^[[:space:]]+/, "", line)
            if (line !~ /^[A-Za-z_]+:/) {
                next
            }
            key = line
            sub(/:.*/, "", key)
            value = line
            sub(/^[^:]+:[[:space:]]*/, "", value)

            if (key == "serial") {
                serial = value
            } else if (key == "product") {
                product = value
            } else if (key == "type") {
                type = value
            } else if (key == "addr" || key == "mgmt_addr") {
                add_ip(value, key)
            }
        }
        END {
            flush_device()
        }
    ')
    NETWORK_USRP_CANDIDATES_LOADED=1
}

network_usrp_candidates() {
    load_network_usrp_candidates
    if [ "${#NETWORK_USRP_CANDIDATES[@]}" -gt 0 ]; then
        printf '%s\n' "${NETWORK_USRP_CANDIDATES[@]}"
    fi
}

network_usrp_detail_value() {
    local detail="$1"
    local wanted="$2"
    local field

    for field in $detail; do
        case "$field" in
            "$wanted="*)
                printf '%s' "${field#*=}"
                return 0
                ;;
        esac
    done
}

network_usrp_detail_for_ip() {
    local wanted_ip="$1"
    local candidate
    local candidate_ip
    local candidate_detail
    local candidates=()

    mapfile -t candidates < <(network_usrp_candidates)
    for candidate in "${candidates[@]}"; do
        IFS=$'\t' read -r candidate_ip candidate_detail <<< "$candidate"
        if [ "$candidate_ip" = "$wanted_ip" ]; then
            printf '%s' "$candidate_detail"
            return 0
        fi
    done
}

network_usrp_mgmt_ip_for_serial() {
    local wanted_serial="$1"
    local candidate
    local candidate_ip
    local candidate_detail
    local candidates=()

    [ -n "$wanted_serial" ] || return 0

    mapfile -t candidates < <(network_usrp_candidates)
    for candidate in "${candidates[@]}"; do
        IFS=$'\t' read -r candidate_ip candidate_detail <<< "$candidate"
        [ "$(network_usrp_detail_value "$candidate_detail" "serial")" = "$wanted_serial" ] || continue
        [ "$(network_usrp_detail_value "$candidate_detail" "via")" = "mgmt_addr" ] || continue
        printf '%s' "$candidate_ip"
        return 0
    done
}

apply_discovered_usrp_metadata_defaults() {
    local usrp_ip="$1"
    local detail
    local serial
    local type
    local mgmt_ip

    [ -n "$usrp_ip" ] || return 0

    detail="$(network_usrp_detail_for_ip "$usrp_ip")"
    [ -n "$detail" ] || return 0

    if [ -z "$USRP_TYPE" ]; then
        type="$(network_usrp_detail_value "$detail" "type")"
        USRP_TYPE="$type"
    fi

    if [ -z "$USRP_MGMT_IP" ]; then
        serial="$(network_usrp_detail_value "$detail" "serial")"
        mgmt_ip="$(network_usrp_mgmt_ip_for_serial "$serial")"
        if [ -n "$mgmt_ip" ]; then
            USRP_MGMT_IP="$mgmt_ip"
        elif [ "$(network_usrp_detail_value "$detail" "via")" = "mgmt_addr" ]; then
            USRP_MGMT_IP="$usrp_ip"
        fi
    fi
}

routed_discovered_usrp_defaults() {
    local candidates=()
    local candidate
    local candidate_ip
    local candidate_detail
    local candidate_serial
    local candidate_type
    local candidate_via
    local other
    local other_detail
    local other_ip
    local route_iface
    local route_pci
    local usrp_mgmt_ip=""

    mapfile -t candidates < <(network_usrp_candidates)
    for candidate in "${candidates[@]}"; do
        IFS=$'\t' read -r candidate_ip candidate_detail <<< "$candidate"
        [ -n "$candidate_ip" ] || continue

        candidate_via="$(network_usrp_detail_value "$candidate_detail" "via")"
        [ "$candidate_via" = "addr" ] || continue

        route_iface="$(route_iface_for_ip "$candidate_ip")"
        [ -n "$route_iface" ] || continue

        route_pci="$(pci_for_iface "$route_iface")"
        [ -n "$route_pci" ] || continue

        candidate_serial="$(network_usrp_detail_value "$candidate_detail" "serial")"
        candidate_type="$(network_usrp_detail_value "$candidate_detail" "type")"
        if [ -n "$candidate_serial" ]; then
            for other in "${candidates[@]}"; do
                IFS=$'\t' read -r other_ip other_detail <<< "$other"
                [ "$(network_usrp_detail_value "$other_detail" "serial")" = "$candidate_serial" ] || continue
                [ "$(network_usrp_detail_value "$other_detail" "via")" = "mgmt_addr" ] || continue
                usrp_mgmt_ip="$other_ip"
                break
            done
        fi

        # Use a non-whitespace delimiter so Bash read preserves an empty management IP field.
        printf '%s|%s|%s|%s|%s\n' "$candidate_ip" "$route_iface" "$route_pci" "$usrp_mgmt_ip" "$candidate_type"
        return 0
    done
}

print_network_usrp_probe() {
    local candidates=()
    local candidate
    local candidate_ip
    local candidate_detail
    local index

    echo
    echo "Network USRPs discovered by uhd_find_devices:"
    if [ -z "${CELEOS_DPDK_SETUP_UHD_FIND_DEVICES_FILE:-}" ] && ! have_cmd uhd_find_devices; then
        echo "  none (uhd_find_devices not found in PATH)"
        return
    fi

    mapfile -t candidates < <(network_usrp_candidates)
    if [ "${#candidates[@]}" -eq 0 ]; then
        echo "  none"
        return
    fi

    index=1
    for candidate in "${candidates[@]}"; do
        IFS=$'\t' read -r candidate_ip candidate_detail <<< "$candidate"
        printf '  %d) %s %s\n' "$index" "$candidate_ip" "$candidate_detail"
        index=$((index + 1))
    done
}

prompt_usrp_ip_value() {
    local current="$1"
    local value
    local selection
    local count
    local index
    local candidate
    local candidate_ip
    local candidate_detail
    local candidates=()

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        printf '%s' "$current"
        return
    fi

    mapfile -t candidates < <(network_usrp_candidates)
    count="${#candidates[@]}"

    if [ "$count" -eq 0 ]; then
        prompt_value "USRP IPv4 address" "$current"
        return
    fi

    echo >&2
    echo "Network USRPs discovered by uhd_find_devices:" >&2
    index=1
    for candidate in "${candidates[@]}"; do
        IFS=$'\t' read -r candidate_ip candidate_detail <<< "$candidate"
        printf '  %d) %s %s\n' "$index" "$candidate_ip" "$candidate_detail" >&2
        index=$((index + 1))
    done

    while true; do
        if [ -n "$current" ]; then
            printf 'Select USRP IPv4 [1-%s] or enter IP address [%s]: ' "$count" "$current" >&2
            if ! read -r value; then
                die "Input ended while reading USRP IPv4 selection."
            fi
            echo >&2
            selection="${value:-$current}"
        else
            printf 'Select USRP IPv4 [1-%s] or enter IP address: ' "$count" >&2
            if ! read -r selection; then
                die "Input ended while reading USRP IPv4 selection."
            fi
            echo >&2
        fi

        if [[ "$selection" =~ ^[0-9]+$ ]]; then
            if [ "$selection" -ge 1 ] && [ "$selection" -le "$count" ]; then
                candidate="${candidates[$((selection - 1))]}"
                IFS=$'\t' read -r candidate_ip candidate_detail <<< "$candidate"
                printf '%s' "$candidate_ip"
                return
            fi
            echo "Enter a number from 1 to $count, or enter an IP address." >&2
            continue
        fi

        if [ -n "$selection" ]; then
            printf '%s' "$selection"
            return
        fi

        echo "Enter a number from 1 to $count, or enter an IP address." >&2
    done
}

prompt_pci_value() {
    local current="$1"
    local value
    local selection
    local count
    local pci_addr
    local pci_line
    local candidates=()

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        printf '%s' "$current"
        return
    fi

    mapfile -t candidates < <(network_pci_candidates)
    count="${#candidates[@]}"

    if [ "$count" -eq 0 ]; then
        if ! have_cmd lspci && [ -z "${CELEOS_DPDK_SETUP_LSPCI_FILE:-}" ]; then
            warn "lspci is not installed; install pciutils for PCI discovery."
        fi
        prompt_value "PCI function connected to the network USRP" "$current"
        return
    fi

    if [ "$PCI_FUNCTIONS_PROBE_PRINTED" -eq 0 ]; then
        echo >&2
        echo "PCI function connected to the network USRP:" >&2
        print_pci_candidate_rows "${candidates[@]}" >&2
    fi

    while true; do
        if [ -n "$current" ]; then
            printf 'Select PCI function [1-%s] or enter PCI address [%s]: ' "$count" "$current" >&2
            read -r value
            echo >&2
            selection="${value:-$current}"
        else
            printf 'Select PCI function [1-%s] or enter PCI address: ' "$count" >&2
            read -r selection
            echo >&2
        fi

        if [[ "$selection" =~ ^[0-9]+$ ]] && [ "$selection" -ge 1 ] && [ "$selection" -le "$count" ]; then
            pci_line="${candidates[$((selection - 1))]}"
            printf '%s' "${pci_line%% *}"
            return
        fi

        if [ -n "$selection" ]; then
            printf '%s' "$selection"
            return
        fi

        echo "Enter a number from 1 to $count, or enter a PCI address." >&2
    done
}

prompt_driver_value() {
    local current="$1"
    local selected_pci="$2"
    local prompt_default="${3:-$current}"
    local value
    local selection
    local count
    local index
    local candidate
    local existing
    local found
    local current_driver
    local note
    local driver_options=()

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        printf '%s' "$prompt_default"
        return
    fi

    for candidate in "$current" "$prompt_default" "vfio-pci" "uio_pci_generic" "igb_uio"; do
        [ -n "$candidate" ] || continue
        found=0
        for existing in "${driver_options[@]}"; do
            if [ "$existing" = "$candidate" ]; then
                found=1
                break
            fi
        done
        [ "$found" -eq 0 ] && driver_options+=("$candidate")
    done
    count="${#driver_options[@]}"

    current_driver=""
    if [ -n "$selected_pci" ]; then
        current_driver="$(pci_driver_name "$selected_pci")"
    fi

    echo "Target DPDK driver:" >&2
    index=1
    for candidate in "${driver_options[@]}"; do
        note=""
        if [ "$candidate" = "vfio-pci" ]; then
            note="$(vfio_driver_prompt_note "$selected_pci" "$prompt_default")"
        elif [ "$candidate" = "$current_driver" ] && is_dpdk_binding_driver "$candidate"; then
            note=" (current binding)"
        fi
        printf '  %d) %s%s\n' "$index" "$candidate" "$note" >&2
        index=$((index + 1))
    done

    while true; do
        if [ -n "$prompt_default" ]; then
            printf 'Select target DPDK driver [1-%s] or enter driver [%s]: ' "$count" "$prompt_default" >&2
            read -r value
            echo >&2
            selection="${value:-$prompt_default}"
        else
            printf 'Select target DPDK driver [1-%s] or enter driver: ' "$count" >&2
            read -r selection
            echo >&2
        fi

        if [[ "$selection" =~ ^[0-9]+$ ]]; then
            if [ "$selection" -ge 1 ] && [ "$selection" -le "$count" ]; then
                printf '%s' "${driver_options[$((selection - 1))]}"
                return
            fi
            echo "Enter a number from 1 to $count, or enter a driver name." >&2
            continue
        fi

        if [ -n "$selection" ]; then
            printf '%s' "$selection"
            return
        fi

        echo "Enter a number from 1 to $count, or enter a driver name." >&2
    done
}

explicit_values_are_complete() {
    [ "$EXPLICIT_HOST_VALUES" -eq 1 ] || return 1
    [ -z "$(missing_values)" ] || return 1

    case "$IFACE_SOURCE" in
        auto-detected*) return 1 ;;
    esac
    case "$DPDK_MAC_SOURCE" in
        auto-detected*) return 1 ;;
    esac
    case "$DPDK_IPV4_SOURCE" in
        auto-detected*) return 1 ;;
    esac

    return 0
}

collect_values() {
    local previous_pci
    local target_driver_prompt_default_value

    load_existing_config_defaults
    apply_builtin_defaults
    demote_loaded_config_hardware_defaults_if_live_discovery_available
    if prompt_apply_loaded_config_values; then
        return
    fi

    suggest_pci_from_discovered_usrps
    derive_values_from_host
    apply_builtin_defaults
    if explicit_values_are_complete; then
        return
    fi
    if [ "$APPLY" -eq 1 ] && [ "$EXPLICIT_HOST_VALUES" -eq 0 ]; then
        TARGET_DRIVER="${TARGET_DRIVER:-$(target_driver_default)}"
        if prompt_apply_detected_values; then
            return
        fi
    fi

    previous_pci="$PCI"
    PCI="$(prompt_pci_value "$PCI")"
    if [ "$PCI" != "$previous_pci" ]; then
        case "$IFACE_SOURCE" in
            auto-detected*|"from existing config")
                IFACE=""
                IFACE_SOURCE=""
                ;;
        esac
        case "$DPDK_MAC_SOURCE" in
            auto-detected*|"from existing config")
                DPDK_MAC=""
                DPDK_MAC_SOURCE=""
                ;;
        esac
        case "$DPDK_IPV4_SOURCE" in
            auto-detected*|"from existing config")
                DPDK_IPV4=""
                DPDK_IPV4_SOURCE=""
                ;;
        esac
        VFIO_GROUP_PCI=""
        VFIO_GROUP_RESTORE_DRIVERS=""
    fi
    derive_values_from_host
    if [ -n "$IFACE" ] && [[ "$IFACE_SOURCE" != auto-detected* ]]; then
        IFACE="$(prompt_value "Linux interface name before binding" "$IFACE")"
        IFACE_SOURCE="from prompt"
    fi
    target_driver_prompt_default_value="$(target_driver_prompt_default "$TARGET_DRIVER")"
    TARGET_DRIVER="$(prompt_driver_value "$TARGET_DRIVER" "$PCI" "$target_driver_prompt_default_value")"
    TARGET_DRIVER_SOURCE="from prompt"
    HUGEPAGES="$(prompt_value "Hugepages" "$HUGEPAGES")"
    DPDK_MAC="$(prompt_dpdk_mac_value)"
    DPDK_IPV4="$(prompt_dpdk_ipv4_value)"
    USRP_IP="$(prompt_usrp_ip_value "$USRP_IP")"
    apply_discovered_usrp_metadata_defaults "$USRP_IP"
    DUMMY_IFACE="$(prompt_value "Dummy route interface" "$DUMMY_IFACE")"
}

missing_values() {
    local missing=()

    [ -n "$PCI" ] || missing+=("PCI")
    [ -n "$TARGET_DRIVER" ] || missing+=("TARGET_DRIVER")
    [ -n "$HUGEPAGES" ] || missing+=("HUGEPAGES")
    [ -n "$DPDK_MAC" ] || missing+=("DPDK_MAC")
    [ -n "$DPDK_IPV4" ] || missing+=("DPDK_IPV4")
    [ -n "$USRP_IP" ] || missing+=("USRP_IP")
    [ -n "$DUMMY_IFACE" ] || missing+=("DUMMY_IFACE")

    if [ "${#missing[@]}" -gt 0 ]; then
        printf '%s\n' "${missing[*]}"
    fi
}

validate_required_values() {
    local missing

    missing="$(missing_values)"
    if [ -n "$missing" ]; then
        die "Missing required values: $missing"
    fi

    [[ "$PCI" =~ ^[0-9A-Fa-f]{4}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}\.[0-7]$ ]] || \
        die "PCI must look like 0000:10:00.1"
    [[ "$HUGEPAGES" =~ ^[0-9]+$ ]] || die "HUGEPAGES must be numeric"
    [[ "$DPDK_MAC" =~ ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$ ]] || \
        die "DPDK_MAC must look like 00:10:86:83:5d:e3"
    [[ "$DPDK_IPV4" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$ ]] || \
        die "DPDK_IPV4 must look like 192.168.40.1/24"
    [[ "$USRP_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || \
        die "USRP_IP must look like 192.168.40.2"
    if [ -n "$USRP_MGMT_IP" ]; then
        [[ "$USRP_MGMT_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || \
            die "USRP_MGMT_IP must look like 192.168.40.10"
    fi
    if [ -n "$USRP_TYPE" ]; then
        [[ "$USRP_TYPE" =~ ^[A-Za-z0-9_:-]+$ ]] || \
            die "USRP_TYPE contains unsupported characters"
    fi
}

collect_disable_values() {
    load_existing_config_defaults
    apply_builtin_defaults
    derive_values_from_host

    if [ -z "$PCI" ]; then
        PCI="$(prompt_pci_value "$PCI")"
        derive_values_from_host
    fi

    if [ -z "$KERNEL_DRIVER" ] && [ -n "$PCI" ]; then
        KERNEL_DRIVER="$(kernel_driver_default_for_pci "$PCI")"
    fi
}

validate_disable_values() {
    [ -n "$PCI" ] || die "Missing required values for --disable-dpdk: PCI"

    [[ "$PCI" =~ ^[0-9A-Fa-f]{4}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}\.[0-7]$ ]] || \
        die "PCI must look like 0000:10:00.1"

    if [ -z "$KERNEL_DRIVER" ]; then
        die "Could not determine regular Ubuntu kernel driver for $PCI. Re-run with --kernel-driver <driver>."
    fi
    [[ "$KERNEL_DRIVER" =~ ^[A-Za-z0-9_-]+$ ]] || \
        die "KERNEL_DRIVER must be a Linux module name such as ixgbe or i40e"

    if [ -n "$IFACE" ]; then
        [[ "$IFACE" =~ ^[A-Za-z0-9_.:-]+$ ]] || die "IFACE contains unsupported characters"
    fi
    if [ -n "$DUMMY_IFACE" ]; then
        [[ "$DUMMY_IFACE" =~ ^[A-Za-z0-9_.:-]+$ ]] || die "DUMMY_IFACE contains unsupported characters"
    fi
    if [ -n "$DPDK_IPV4" ]; then
        [[ "$DPDK_IPV4" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$ ]] || \
            die "DPDK_IPV4 must look like 192.168.40.1/24"
    fi
}

print_disable_plan() {
    local current_driver

    refresh_vfio_group_values
    current_driver="$(pci_driver_name "$PCI")"
    cat <<EOF

Disable CELEOS network USRP DPDK
================================
PCI="$PCI"
IFACE="$IFACE"
Current driver="$current_driver"
Kernel driver to restore="$KERNEL_DRIVER"
VFIO group endpoints to restore="${VFIO_GROUP_PCI:-$PCI}"
DPDK IPv4 to move="${DPDK_IPV4:-none}"
Dummy interface to remove="${DUMMY_IFACE:-none}"
EOF
}

prompt_apply_current_values() {
    local prompt="$1"
    local answer

    [ "$APPLY" -eq 1 ] || return 1
    [ "$NON_INTERACTIVE" -eq 0 ] || return 1
    [ "$EXPLICIT_HOST_VALUES" -eq 0 ] || return 1
    [ -z "$(missing_values)" ] || return 1

    echo
    echo "$prompt"
    print_selected_values

    while true; do
        printf "Apply these values? [Y/n]: " >&2
        if ! read -r answer; then
            die "Input ended while reading installed config selection."
        fi
        echo >&2

        case "$answer" in
            ""|y|Y|yes|YES|Yes)
                return 0
                ;;
            n|N|no|NO|No)
                return 1
                ;;
            *)
                echo "Enter yes to apply these values, or no to edit them." >&2
                ;;
        esac
    done
}

prompt_apply_loaded_config_values() {
    [ -n "$LOADED_CONFIG_PATH" ] || return 1
    prompt_apply_current_values "Do you want to apply the previously configured network USRP DPDK values:"
}

prompt_apply_detected_values() {
    [ -z "$LOADED_CONFIG_PATH" ] || return 1
    prompt_apply_current_values "Do you want to apply the auto-detected network USRP DPDK values:"
}

missing_check_values() {
    local missing=()

    [ -n "$PCI" ] || missing+=("PCI")
    [ -n "$TARGET_DRIVER" ] || missing+=("TARGET_DRIVER")
    [ -n "$DPDK_IPV4" ] || missing+=("DPDK_IPV4")
    [ -n "$DUMMY_IFACE" ] || missing+=("DUMMY_IFACE")

    if [ "${#missing[@]}" -gt 0 ]; then
        printf '%s\n' "${missing[*]}"
    fi
}

die_missing_check_values() {
    local missing="$1"

    cat >&2 <<EOF
ERROR: --check could not determine what to validate.
Missing values: $missing

It normally reads these from the installed host config:
  $CONFIG_PATH

Did you complete step 3 with $SCRIPT_NAME --apply?

Or provide the values explicitly:
  bash $SCRIPT_NAME --check --pci <pci> --target-driver <driver> --dpdk-ipv4 <host-ip/prefix> --dummy-iface <iface>
EOF
    exit 1
}

validate_check_values() {
    local missing

    missing="$(missing_check_values)"
    if [ -n "$missing" ]; then
        die_missing_check_values "$missing"
    fi

    [[ "$PCI" =~ ^[0-9A-Fa-f]{4}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}\.[0-7]$ ]] || \
        die "PCI must look like 0000:10:00.1"
    [[ "$DPDK_IPV4" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$ ]] || \
        die "DPDK_IPV4 must look like 192.168.40.1/24"
}

load_check_values() {
    load_existing_config_defaults
    derive_values_from_host
    apply_builtin_defaults
    validate_check_values
}

check_service_active() {
    local output
    local status=0

    echo "+ systemctl is-active $SERVICE_NAME"
    if ! have_cmd systemctl; then
        echo "FAIL: systemctl command not found"
        return 1
    fi

    output="$(systemctl is-active "$SERVICE_NAME" 2>&1)" || status=$?
    [ -n "$output" ] && echo "$output"
    if [ "$status" -eq 0 ] && [ "$output" = "active" ]; then
        echo "PASS: $SERVICE_NAME is active"
        return 0
    fi

    echo "FAIL: $SERVICE_NAME is ${output:-unknown}, expected active"
    return 1
}

check_pci_driver_bound() {
    local output
    local status=0
    local selected_driver

    echo "+ lspci -nnk -s \"$PCI\""
    if ! have_cmd lspci; then
        echo "FAIL: lspci command not found"
        return 1
    fi

    output="$(lspci -nnk -s "$PCI" 2>&1)" || status=$?
    [ -n "$output" ] && echo "$output"
    if [ "$status" -ne 0 ] || [ -z "$output" ]; then
        echo "FAIL: lspci did not report $PCI"
        return 1
    fi

    selected_driver="$(pci_driver_name "$PCI")"
    if [ "$selected_driver" = "$TARGET_DRIVER" ]; then
        echo "PASS: $PCI is bound to $TARGET_DRIVER"
        return 0
    fi

    echo "FAIL: $PCI is bound to $selected_driver, expected $TARGET_DRIVER"
    return 1
}

check_vfio_group_bound() {
    local failed=0
    local endpoint
    local driver

    [ "$TARGET_DRIVER" = "vfio-pci" ] || return 0
    refresh_vfio_group_values

    echo "VFIO group endpoint binding:"
    for endpoint in $VFIO_GROUP_PCI; do
        [ -n "$endpoint" ] || continue
        driver="$(pci_driver_name "$endpoint")"
        case "$driver" in
            vfio-pci|vfio_pci|none|"")
                echo "PASS: VFIO group member $endpoint is bound to ${driver:-none}"
                ;;
            *)
                echo "FAIL: VFIO group member $endpoint is bound to $driver, expected vfio-pci or unbound"
                failed=1
                ;;
        esac
    done

    [ "$failed" -eq 0 ]
}

check_dummy_iface_addr() {
    local output
    local status=0

    echo "+ ip -o -brief addr show $DUMMY_IFACE"
    if ! have_cmd ip; then
        echo "FAIL: ip command not found"
        return 1
    fi

    output="$(ip -o -brief addr show "$DUMMY_IFACE" 2>&1)" || status=$?
    [ -n "$output" ] && echo "$output"
    if [ "$status" -ne 0 ] || [ -z "$output" ]; then
        echo "FAIL: $DUMMY_IFACE was not found"
        return 1
    fi

    if printf '%s\n' "$output" | grep -Fq "$DPDK_IPV4"; then
        echo "PASS: $DUMMY_IFACE has $DPDK_IPV4"
        return 0
    fi

    echo "FAIL: $DUMMY_IFACE does not have $DPDK_IPV4"
    return 1
}

interactive_prompt_available() {
    [ "$NON_INTERACTIVE" -eq 0 ] || return 1
    [ -t 0 ] || [ "${CELEOS_DPDK_SETUP_FORCE_INTERACTIVE:-0}" = "1" ]
}

celeos_named_containers() {
    have_cmd docker || return 0
    docker ps --format '{{.Names}}' 2>/dev/null | grep -Ei 'celeos' || true
}

all_celeos_containers() {
    have_cmd docker || return 0
    docker ps -a --format '{{.Names}}' 2>/dev/null | grep -Ei '^celeos($|[-_])' || true
}

preferred_celeos_container() {
    local container

    for container in "$@"; do
        if [ "$container" = "celeos" ]; then
            printf '%s' "$container"
            return 0
        fi
    done

    [ "$#" -gt 0 ] && printf '%s' "$1"
}

celeos_container_env() {
    local container="$1"

    docker inspect --format '{{range .Config.Env}}{{println .}}{{end}}' "$container" 2>/dev/null
}

celeos_container_mode() {
    local container="$1"
    local env_output

    if ! env_output="$(celeos_container_env "$container")"; then
        printf 'unknown'
        return
    fi

    if printf '%s\n' "$env_output" | grep -Eq '^(CELEOS_REQUIRE_USRP_DPDK|CELEOS_REQUIRE_X300_DPDK|CELEOS_FORCE_UHD_DPDK)=1$'; then
        printf 'dpdk'
    else
        printf 'no-dpdk'
    fi
}

validate_celeos_container_mode_for_visibility_check() {
    local container="$1"
    local expected_mode="$2"
    local actual_mode

    actual_mode="$(celeos_container_mode "$container")"
    case "$actual_mode:$expected_mode" in
        dpdk:dpdk|no-dpdk:no-dpdk)
            return 0
            ;;
        unknown:*)
            warn "Could not determine CELEOS container '$container' DPDK mode; continuing with UHD visibility check."
            return 0
            ;;
        no-dpdk:dpdk)
            cat >&2 <<EOF
ERROR: CELEOS container '$container' is not running in DPDK mode.
Host DPDK is enabled, but this container was started without --usrp-dpdk.

Recreate the CELEOS container in DPDK mode:
  Rerun the same Docker/installation/04_install_celeos.sh command with --usrp-dpdk.

Then check host/container state again:
  bash $SCRIPT_NAME --check
EOF
            exit 1
            ;;
        dpdk:no-dpdk)
            cat >&2 <<EOF
ERROR: CELEOS container '$container' is still running in DPDK mode.
Host DPDK is disabled, but this container was started with --usrp-dpdk.

Recreate the CELEOS container without DPDK mode:
  Rerun the same Docker/installation/04_install_celeos.sh command and omit --usrp-dpdk.

Then retry the non-DPDK visibility check:
  bash $SCRIPT_NAME --check
EOF
            exit 1
            ;;
        *)
            warn "Unexpected CELEOS container '$container' mode '$actual_mode'; continuing with UHD visibility check."
            return 0
            ;;
    esac
}

append_csv_arg() {
    local existing="$1"
    local next="$2"

    if [ -n "$existing" ]; then
        printf '%s,%s' "$existing" "$next"
    else
        printf '%s' "$next"
    fi
}

usrp_uhd_args() {
    local use_dpdk="${1:-0}"
    local args=""

    if [ -n "$USRP_TYPE" ]; then
        args="$(append_csv_arg "$args" "type=$USRP_TYPE")"
    fi
    if [ "$use_dpdk" = "1" ]; then
        args="$(append_csv_arg "$args" "use_dpdk=1")"
    fi
    if [ -n "$USRP_MGMT_IP" ]; then
        args="$(append_csv_arg "$args" "mgmt_addr=$USRP_MGMT_IP")"
    fi
    args="$(append_csv_arg "$args" "addr=$USRP_IP")"

    printf '%s' "$args"
}

usrp_visibility_output_matches() {
    local output="$1"

    printf '%s\n' "$output" | grep -Fq "$USRP_IP" && return 0
    [ -n "$USRP_MGMT_IP" ] && printf '%s\n' "$output" | grep -Fq "$USRP_MGMT_IP"
}

check_usrp_visibility_in_celeos_container() {
    local selected="$1"
    local transport_mode="${2:-dpdk}"
    local output
    local status=0
    local args
    local check_label
    local pass_label
    local fail_label
    local docker_exec_cmd=()

    case "$transport_mode" in
        dpdk)
            args="$(usrp_uhd_args 1)"
            check_label="Checking USRP visibility inside CELEOS container '$selected'..."
            pass_label="PASS: USRP $USRP_IP is visible over DPDK inside CELEOS container '$selected'."
            fail_label="USRP visibility check"
            ;;
        no-dpdk)
            args="$(usrp_uhd_args 0)"
            check_label="Checking USRP visibility without DPDK inside CELEOS container '$selected'..."
            pass_label="PASS: USRP $USRP_IP is visible without DPDK inside CELEOS container '$selected'."
            fail_label="USRP visibility check without DPDK"
            ;;
        *)
            die "Unknown CELEOS USRP visibility check mode: $transport_mode"
            ;;
    esac

    validate_celeos_container_mode_for_visibility_check "$selected" "$transport_mode"

    docker_exec_cmd=(docker exec "$selected" uhd_find_devices --args "$args")
    echo "$check_label"
    if have_cmd timeout; then
        echo "+ timeout 20s docker exec $selected uhd_find_devices --args $args"
        output="$(timeout 20s "${docker_exec_cmd[@]}" 2>&1)" || status=$?
    else
        echo "+ docker exec $selected uhd_find_devices --args $args"
        output="$("${docker_exec_cmd[@]}" 2>&1)" || status=$?
    fi
    [ -n "$output" ] && echo "$output"
    if usrp_visibility_output_matches "$output"; then
        echo "$pass_label"
    elif [ "$status" -ne 0 ]; then
        die "$fail_label failed inside CELEOS container '$selected'."
    else
        die "$fail_label did not report $USRP_IP inside CELEOS container '$selected'."
    fi
}

check_usrp_visibility_from_host_dpdk() {
    local args
    local output
    local status=0
    local sudo_cmd=()
    local sudo_label=""
    local host_uhd_cmd=()

    args="$(usrp_uhd_args 1)"
    echo "Checking USRP visibility with host UHD DPDK config..."
    if [ -n "${CELEOS_DPDK_SETUP_UHD_FIND_DEVICES_FILE:-}" ]; then
        warn "Host UHD DPDK verification skipped because fixture-based UHD discovery output is configured."
        return 0
    fi
    if ! have_cmd uhd_find_devices; then
        warn "uhd_find_devices is not in PATH; install $HOST_UHD_PACKAGE to validate host DPDK discovery."
        return 0
    fi

    if [ "$(id -u)" -ne 0 ]; then
        sudo_cmd=(sudo)
        sudo_label="sudo "
    fi

    cleanup_dpdk_runtime_artifacts
    host_uhd_cmd=("${sudo_cmd[@]}" env "UHD_CONFIG_FILE=$UHD_CONFIG_PATH" uhd_find_devices --args "$args")
    if have_cmd timeout; then
        echo "+ timeout 20s ${sudo_label}env UHD_CONFIG_FILE=$UHD_CONFIG_PATH uhd_find_devices --args $args"
        output="$(timeout 20s "${host_uhd_cmd[@]}" 2>&1)" || status=$?
    else
        echo "+ ${sudo_label}env UHD_CONFIG_FILE=$UHD_CONFIG_PATH uhd_find_devices --args $args"
        output="$("${host_uhd_cmd[@]}" 2>&1)" || status=$?
    fi
    [ -n "$output" ] && echo "$output"
    if usrp_visibility_output_matches "$output"; then
        echo "PASS: USRP $USRP_IP is visible over DPDK from the host."
        return 0
    fi

    if [ "$status" -ne 0 ]; then
        die "Host UHD DPDK discovery failed for USRP $USRP_IP. Check whether the USRP is powered on, physically connected to the selected NIC, and the host IP, UHD config, and USRP subnet match."
    fi
    die "Host UHD DPDK discovery did not report USRP $USRP_IP. Check whether the USRP is powered on, physically connected to the selected NIC, and the host IP, UHD config, and USRP subnet match."
}

cleanup_dpdk_runtime_artifacts() {
    local sudo_cmd=()

    if [ "$(id -u)" -ne 0 ]; then
        have_cmd sudo || return 0
        sudo_cmd=(sudo)
    fi

    "${sudo_cmd[@]}" rm -rf /var/run/dpdk/rte "/run/user/$(id -u)/dpdk/rte" /dev/hugepages/rtemap_* 2>/dev/null || true
}

print_quick_install_dpdk_verification_guidance() {
    cat <<EOF

CELEOS USRP verification
========================
Complete step 4 with 04_install_celeos.sh and --usrp-dpdk to verify changes
EOF
}

prompt_restart_celeos_container_after_check() {
    local answer
    local selection
    local selected=""
    local index
    local count
    local containers=()

    interactive_prompt_available || return 0

    if ! have_cmd docker; then
        warn "docker is not installed or not in PATH; cannot restart a CELEOS container."
        return 0
    fi

    mapfile -t containers < <(celeos_named_containers)
    count="${#containers[@]}"
    if [ "$count" -eq 0 ]; then
        echo "No running containers with 'celeos' in the name were found."
        return 0
    fi

    printf "Restart a CELEOS container now? [y/N]: " >&2
    if ! read -r answer; then
        die "Input ended while reading CELEOS restart confirmation."
    fi
    echo >&2

    case "$answer" in
        y|Y|yes|YES|Yes)
            ;;
        *)
            return 0
            ;;
    esac

    echo
    echo "CELEOS containers:"
    index=1
    for selected in "${containers[@]}"; do
        printf '  %d) %s\n' "$index" "$selected"
        index=$((index + 1))
    done

    while true; do
        printf "Select CELEOS container [1-%d] or enter container name [%s]: " "$count" "${containers[0]}" >&2
        if ! read -r selection; then
            die "Input ended while reading CELEOS container selection."
        fi
        echo >&2

        if [ -z "$selection" ]; then
            selected="${containers[0]}"
            break
        fi
        if [[ "$selection" =~ ^[0-9]+$ ]] && [ "$selection" -ge 1 ] && [ "$selection" -le "$count" ]; then
            selected="${containers[$((selection - 1))]}"
            break
        fi
        if [ -n "$selection" ]; then
            selected="$selection"
            break
        fi
    done

    echo "Restarting CELEOS container '$selected'..."
    docker restart "$selected" >/dev/null || die "Failed to restart CELEOS container '$selected'."
    echo "CELEOS container '$selected' restarted."

    check_usrp_visibility_in_celeos_container "$selected" dpdk
}

run_post_reboot_check() {
    local failed=0

    echo
    echo "Post-reboot DPDK check"
    echo "======================"

    check_service_active || failed=1
    echo
    check_pci_driver_bound || failed=1
    echo
    check_vfio_group_bound || failed=1
    echo
    check_dummy_iface_addr || failed=1

    echo
    if [ "$failed" -eq 0 ]; then
        echo "Post-reboot DPDK check: OK"
        print_quick_install_dpdk_verification_guidance
        return 0
    fi

    echo "Post-reboot DPDK check: FAILED"
    return 1
}

print_vfio_iommu_readiness() {
    local group_count
    local iommu_group
    local expected_args
    local args_status="missing"
    local vfio_status="not checked"

    [ "$TARGET_DRIVER" = "vfio-pci" ] || return 0

    group_count="$(iommu_group_count)"
    iommu_group="$(pci_iommu_group "$PCI")"
    expected_args="$(iommu_kernel_args 2>/dev/null || true)"
    if iommu_kernel_args_present; then
        args_status="present"
    fi
    if [ -n "$iommu_group" ]; then
        if vfio_group_device_exists "$iommu_group"; then
            vfio_status="/dev/vfio/$iommu_group present"
        else
            vfio_status="/dev/vfio/$iommu_group missing"
        fi
    fi

    cat <<EOF

VFIO/IOMMU readiness
====================
IOMMU groups: ${group_count:-0}
Selected PCI IOMMU group: ${iommu_group:-none}
IOMMU kernel args: $args_status${expected_args:+ (expected: $expected_args)}
VFIO device: $vfio_status
EOF

    print_vfio_group_members

    if ! vfio_iommu_active_for_pci "$PCI"; then
        if [ "$APPLY" -eq 1 ]; then
            cat <<EOF

vfio-pci requires the recommended IOMMU boot args before runtime binding can be validated.
Current --apply run has not installed the IOMMU grub drop-in yet.
Installation happens after running-container checks and final confirmation succeed.
After the grub drop-in is installed, reboot.
After reboot, the enabled $SERVICE_NAME should apply the runtime setup at boot.
After reboot, check correct state with:
  bash $SCRIPT_NAME --check
EOF
        else
            cat <<EOF

vfio-pci requires the recommended IOMMU boot args before runtime binding can be validated.
Run with --apply to install the IOMMU grub drop-in, then reboot.
After reboot, the enabled $SERVICE_NAME should apply the runtime setup at boot.
After reboot, check correct state with:
  bash $SCRIPT_NAME --check
EOF
        fi
    fi
    return 0
}

print_vfio_group_members() {
    local member
    local current_driver
    local iface
    local role
    local action

    [ "$TARGET_DRIVER" = "vfio-pci" ] || return 0
    [ -n "$PCI" ] || return 0
    refresh_vfio_group_values

    echo
    echo "VFIO IOMMU group members"
    echo "------------------------"
    VFIO_GROUP_MEMBERS_PRINTED=1
    while IFS= read -r member; do
        [ -n "$member" ] || continue
        current_driver="$(pci_driver_name "$member")"
        iface="$(iface_for_pci "$member")"
        if pci_is_bridge "$member"; then
            role="bridge"
            action="leave"
        elif [ "$member" = "$PCI" ]; then
            role="selected"
            action="bind to vfio-pci"
        else
            role="group-member"
            case " $VFIO_GROUP_PCI " in
                *" $member "*) action="bind to vfio-pci" ;;
                *) action="leave" ;;
            esac
        fi
        printf '  %s driver=%s iface=%s role=%s action=%s\n' \
            "$member" \
            "${current_driver:-none}" \
            "${iface:-none}" \
            "$role" \
            "$action"
    done < <(pci_iommu_group_members "$PCI")
}

print_selected_values() {
    refresh_vfio_group_values
    cat <<EOF

Selected network USRP DPDK values
=================================
PCI="$PCI"
IFACE="$IFACE"
TARGET_DRIVER="$TARGET_DRIVER"
VFIO_GROUP_PCI="$VFIO_GROUP_PCI"
VFIO_GROUP_RESTORE_DRIVERS="$VFIO_GROUP_RESTORE_DRIVERS"
HUGEPAGES="$HUGEPAGES"
DPDK_MAC="$DPDK_MAC"
DPDK_IPV4="$DPDK_IPV4"
USRP_IP="$USRP_IP"
USRP_MGMT_IP="$USRP_MGMT_IP"
USRP_TYPE="$USRP_TYPE"
DUMMY_IFACE="$DUMMY_IFACE"
EOF
}

print_plan() {
    print_selected_values
    cat <<EOF

Host files to be applied by --apply
===================================
$CONFIG_PATH
$UHD_CONFIG_PATH
$HELPER_PATH
$SERVICE_PATH
EOF
    print_dpdk_pmd_package_plan
    print_vfio_iommu_readiness
}

print_configured_applied_status() {
    local config_ok=0
    local service_ok=0
    local driver_ok=0
    local dummy_ok=0
    local configured="no"
    local applied="no"
    local service_state="unknown"
    local selected_driver
    local dummy_ipv4s
    local mismatches=()
    local key
    local expected
    local actual

    echo
    echo "Configured/applied status"
    echo "========================="

    if [ -r "$CONFIG_PATH" ]; then
        for key in PCI TARGET_DRIVER DPDK_IPV4 DUMMY_IFACE; do
            expected="${!key}"
            actual="$(read_config_value "$key" "$CONFIG_PATH")"
            if [ "$actual" != "$expected" ]; then
                mismatches+=("$key")
            fi
        done
        if [ "${#mismatches[@]}" -eq 0 ]; then
            config_ok=1
            echo "Host config: configured at $CONFIG_PATH"
        else
            echo "Host config: present at $CONFIG_PATH but differs in ${mismatches[*]}"
        fi
    else
        echo "Host config: missing at $CONFIG_PATH"
    fi

    if have_cmd systemctl; then
        service_state="$(systemctl is-enabled "$SERVICE_NAME" 2>/dev/null || true)"
        [ -n "$service_state" ] || service_state="unknown"
    fi
    echo "Service enabled: $service_state"
    [ "$service_state" = "enabled" ] && service_ok=1

    if [ "$config_ok" -eq 1 ] && [ "$service_ok" -eq 1 ]; then
        configured="yes"
    fi
    echo "Configured: $configured"

    selected_driver="$(pci_driver_name "$PCI")"
    echo "Selected PCI driver: $selected_driver (expected $TARGET_DRIVER)"
    [ "$selected_driver" = "$TARGET_DRIVER" ] && driver_ok=1

    dummy_ipv4s="$(iface_ipv4_addresses "$DUMMY_IFACE")"
    if printf '%s\n' "$dummy_ipv4s" | grep -Fq "$DPDK_IPV4"; then
        dummy_ok=1
        echo "Dummy interface: $DUMMY_IFACE has $DPDK_IPV4"
    else
        echo "Dummy interface: $DUMMY_IFACE missing $DPDK_IPV4"
    fi

    if [ "$driver_ok" -eq 1 ] && [ "$dummy_ok" -eq 1 ]; then
        applied="yes"
    fi
    echo "Applied now: $applied"
}

print_view() {
    print_selected_values
    print_vfio_iommu_readiness
    print_configured_applied_status
    echo
    echo "No host changes were made."
}

render_config() {
    refresh_vfio_group_values
    cat <<EOF
PCI="$PCI"
IFACE="$IFACE"
HUGEPAGES="$HUGEPAGES"
TARGET_DRIVER="$TARGET_DRIVER"
VFIO_GROUP_PCI="$VFIO_GROUP_PCI"
VFIO_GROUP_RESTORE_DRIVERS="$VFIO_GROUP_RESTORE_DRIVERS"
DPDK_MAC="$DPDK_MAC"
DPDK_IPV4="$DPDK_IPV4"
USRP_IP="$USRP_IP"
USRP_MGMT_IP="$USRP_MGMT_IP"
USRP_TYPE="$USRP_TYPE"
DUMMY_IFACE="$DUMMY_IFACE"
EOF
}

render_uhd_config() {
    cat <<EOF
[use_dpdk=1]
dpdk_mtu=$UHD_DPDK_MTU
dpdk_corelist=$UHD_DPDK_CORELIST
dpdk_num_mbufs=$UHD_DPDK_NUM_MBUFS
dpdk_mbuf_cache_size=$UHD_DPDK_MBUF_CACHE_SIZE
EOF
    if [ -n "$UHD_DPDK_DRIVER" ]; then
        printf 'dpdk_driver=%s\n' "$UHD_DPDK_DRIVER"
    fi
    cat <<EOF
dpdk_log_level=$UHD_DPDK_LOG_LEVEL

[dpdk_mac=$DPDK_MAC]
dpdk_lcore=$UHD_DPDK_LCORE
dpdk_ipv4=$DPDK_IPV4
dpdk_num_desc=$UHD_DPDK_NUM_DESC
EOF
}

render_helper() {
    cat <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

CONFIG="/etc/celeos-dpdk-usrp.conf"
LEGACY_CONFIG="/etc/celeos-dpdk-x300.conf"
if [ ! -r "$CONFIG" ] && [ -r "$LEGACY_CONFIG" ]; then
    CONFIG="$LEGACY_CONFIG"
fi
if [ ! -r "$CONFIG" ]; then
    echo "Missing $CONFIG" >&2
    exit 1
fi

# shellcheck disable=SC1090
source "$CONFIG"

: "${PCI:?}"
: "${HUGEPAGES:?}"
: "${TARGET_DRIVER:?}"
: "${DPDK_IPV4:?}"
: "${DUMMY_IFACE:?}"
VFIO_GROUP_PCI="${VFIO_GROUP_PCI:-$PCI}"

pci_current_driver() {
    local pci_addr="$1"

    if [ -e "/sys/bus/pci/devices/$pci_addr/driver" ]; then
        basename "$(readlink -f "/sys/bus/pci/devices/$pci_addr/driver")"
    fi
}

iface_for_pci() {
    local pci_addr="$1"
    local iface_path
    local pci

    for iface_path in /sys/class/net/*; do
        [ -e "$iface_path/device" ] || continue
        pci="$(basename "$(readlink -f "$iface_path/device" 2>/dev/null || true)")"
        if [ "$pci" = "$pci_addr" ]; then
            basename "$iface_path"
            return 0
        fi
    done
    return 0
}

bind_pci_to_target_driver() {
    local pci_addr="$1"
    local current_driver
    local vendor
    local device
    local bind_error

    current_driver="$(pci_current_driver "$pci_addr")"

    if [ "$current_driver" != "$TARGET_DRIVER" ]; then
        if [ -e "/sys/bus/pci/devices/$pci_addr/driver/unbind" ]; then
            echo "$pci_addr" >"/sys/bus/pci/devices/$pci_addr/driver/unbind"
        fi

        vendor="$(cat "/sys/bus/pci/devices/$pci_addr/vendor")"
        device="$(cat "/sys/bus/pci/devices/$pci_addr/device")"
        if [ -e "/sys/bus/pci/drivers/$TARGET_DRIVER/new_id" ]; then
            echo "${vendor#0x} ${device#0x}" >"/sys/bus/pci/drivers/$TARGET_DRIVER/new_id" 2>/dev/null || true
        fi

        current_driver="$(pci_current_driver "$pci_addr")"
        if [ "$current_driver" != "$TARGET_DRIVER" ]; then
            bind_error="$(mktemp)"
            if ! echo "$pci_addr" >"/sys/bus/pci/drivers/$TARGET_DRIVER/bind" 2>"$bind_error"; then
                current_driver="$(pci_current_driver "$pci_addr")"
                if [ "$current_driver" != "$TARGET_DRIVER" ]; then
                    cat "$bind_error" >&2
                    rm -f "$bind_error"
                    exit 1
                fi
            fi
            rm -f "$bind_error"
        fi
    else
        echo "$pci_addr is already bound to $TARGET_DRIVER"
    fi
}

sysctl -w "vm.nr_hugepages=$HUGEPAGES"
sysctl -w "kernel.sched_rt_runtime_us=-1"
cat >/etc/sysctl.d/99-celeos-dpdk-usrp.conf <<EOF_CONF
vm.nr_hugepages=$HUGEPAGES
kernel.sched_rt_runtime_us=-1
EOF_CONF

for governor in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -w "$governor" ] && echo performance >"$governor" || true
done

modprobe "$TARGET_DRIVER"

for bind_pci in $VFIO_GROUP_PCI; do
    bind_iface="$(iface_for_pci "$bind_pci")"
    if [ -n "$bind_iface" ] && ip link show "$bind_iface" >/dev/null 2>&1; then
        ip link set "$bind_iface" down || true
    fi
    bind_pci_to_target_driver "$bind_pci"
done

if ! ip link show "$DUMMY_IFACE" >/dev/null 2>&1; then
    ip link add "$DUMMY_IFACE" type dummy
fi
ip addr flush dev "$DUMMY_IFACE" || true
ip addr add "$DPDK_IPV4" dev "$DUMMY_IFACE"
ip link set "$DUMMY_IFACE" up
EOF
}

render_service() {
    cat <<'EOF'
[Unit]
Description=Prepare CELEOS network USRP UHD DPDK host runtime
DefaultDependencies=no
Wants=systemd-udev-settle.service
After=local-fs.target sysinit.target systemd-modules-load.service
After=systemd-udev-settle.service
Before=docker.service

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/celeos-dpdk-setup
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
}

render_iommu_grub_dropin() {
    local args

    args="$(iommu_kernel_args)" || die "Cannot determine Intel/AMD CPU vendor for IOMMU grub args"
    cat <<EOF
GRUB_CMDLINE_LINUX_DEFAULT="\${GRUB_CMDLINE_LINUX_DEFAULT} $args"
EOF
}

write_rendered_tree() {
    local root="$1"
    local config_file="$root$CONFIG_PATH"
    local uhd_config_file="$root$UHD_CONFIG_PATH"
    local helper_file="$root$HELPER_PATH"
    local service_file="$root$SERVICE_PATH"
    local grub_dropin_file="$root$IOMMU_GRUB_DROPIN_PATH"

    mkdir -p "$(dirname "$config_file")" "$(dirname "$uhd_config_file")" "$(dirname "$helper_file")" "$(dirname "$service_file")"
    render_config >"$config_file"
    render_uhd_config >"$uhd_config_file"
    render_helper >"$helper_file"
    render_service >"$service_file"
    chmod 0644 "$config_file" "$uhd_config_file" "$service_file"
    chmod 0755 "$helper_file"

    if vfio_iommu_setup_needed; then
        mkdir -p "$(dirname "$grub_dropin_file")"
        render_iommu_grub_dropin >"$grub_dropin_file"
        chmod 0644 "$grub_dropin_file"
    fi
}

run_or_print() {
    if [ "$DRY_RUN" -eq 1 ]; then
        printf '+'
        printf ' %q' "$@"
        printf '\n'
        return 0
    fi
    "$@"
}

cleanup_install_temp() {
    if [ -n "${INSTALL_TEMP_DIR:-}" ]; then
        rm -rf "$INSTALL_TEMP_DIR"
        INSTALL_TEMP_DIR=""
    fi
}

disable_legacy_services() {
    local sudo_cmd=("$@")
    local legacy_service

    have_cmd systemctl || return
    for legacy_service in "${LEGACY_SERVICE_NAMES[@]}"; do
        if systemctl list-unit-files "$legacy_service" --no-legend 2>/dev/null | grep -q "$legacy_service"; then
            if ! run_or_print "${sudo_cmd[@]}" systemctl disable "$legacy_service"; then
                warn "Could not disable legacy $legacy_service. Disable it manually to avoid duplicate DPDK binding at boot."
            fi
        fi
    done
}

verify_post_apply() {
    local service_state="unknown"
    local selected_driver="unknown"
    local iommu_group
    local vfio_status="not checked"

    echo
    echo "Post-apply verification"
    echo "======================="

    [ -r "$CONFIG_PATH" ] && echo "Config: installed at $CONFIG_PATH" || echo "Config: missing at $CONFIG_PATH"
    [ -r "$UHD_CONFIG_PATH" ] && echo "UHD config: installed at $UHD_CONFIG_PATH" || echo "UHD config: missing at $UHD_CONFIG_PATH"
    if have_cmd systemctl; then
        service_state="$(systemctl is-enabled "$SERVICE_NAME" 2>/dev/null || true)"
    fi
    echo "Service enabled: ${service_state:-unknown}"

    if vfio_iommu_setup_needed; then
        [ -r "$IOMMU_GRUB_DROPIN_PATH" ] && echo "IOMMU grub drop-in: installed at $IOMMU_GRUB_DROPIN_PATH" || echo "IOMMU grub drop-in: missing"
        if iommu_kernel_args_present; then
            echo "Current boot IOMMU args: present"
        else
            echo "Current boot IOMMU args: missing until reboot"
        fi
    fi

    selected_driver="$(pci_driver_name "$PCI")"
    echo "Selected PCI driver: $selected_driver"

    if [ "$TARGET_DRIVER" = "vfio-pci" ]; then
        echo "IOMMU groups: $(iommu_group_count)"
        iommu_group="$(pci_iommu_group "$PCI")"
        echo "Selected PCI IOMMU group: ${iommu_group:-none}"
        if [ -n "$iommu_group" ]; then
            if vfio_group_device_exists "$iommu_group"; then
                vfio_status="/dev/vfio/$iommu_group present"
            else
                vfio_status="/dev/vfio/$iommu_group missing"
            fi
        fi
        echo "VFIO device: $vfio_status"
    fi

    if ! vfio_iommu_setup_needed; then
        [ "$selected_driver" = "$TARGET_DRIVER" ] || die "Post-apply verification failed: $PCI is bound to $selected_driver, expected $TARGET_DRIVER"
        if ! ip link show "$DUMMY_IFACE" >/dev/null 2>&1; then
            die "Post-apply verification failed: $DUMMY_IFACE is missing"
        fi
        echo "Dummy interface: $DUMMY_IFACE present"
    fi
}

prompt_reboot_after_iommu_install() {
    local sudo_cmd=("$@")
    local answer

    echo
    echo "IOMMU grub config was installed by --apply. Reboot before validating vfio-pci runtime binding."
    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        echo "Non-interactive mode: reboot was not started."
        return
    fi

    printf "The computer will now reboot. Proceed? [y/N]: " >&2
    read -r answer
    case "$answer" in
        y|Y|yes|YES|Yes)
            echo "Rebooting now."
            run_or_print "${sudo_cmd[@]}" systemctl reboot
            ;;
        *)
            echo "Reboot skipped. Reboot before validating vfio-pci runtime binding."
            ;;
    esac
}

install_rendered_files() {
    local sudo_cmd=()
    local iommu_setup_needed=0

    validate_required_values

    if [ "$(id -u)" -ne 0 ]; then
        have_cmd sudo || die "sudo is required for --apply when not running as root"
        sudo_cmd=(sudo)
    fi

    INSTALL_TEMP_DIR="$(mktemp -d)"
    trap cleanup_install_temp EXIT
    write_rendered_tree "$INSTALL_TEMP_DIR"
    if vfio_iommu_setup_needed; then
        iommu_setup_needed=1
    fi

    run_or_print "${sudo_cmd[@]}" install -m 0644 "$INSTALL_TEMP_DIR$CONFIG_PATH" "$CONFIG_PATH"
    run_or_print "${sudo_cmd[@]}" install -D -m 0644 "$INSTALL_TEMP_DIR$UHD_CONFIG_PATH" "$UHD_CONFIG_PATH"
    run_or_print "${sudo_cmd[@]}" rm -f "$HELPER_PATH"
    run_or_print "${sudo_cmd[@]}" install -m 0755 "$INSTALL_TEMP_DIR$HELPER_PATH" "$HELPER_PATH"
    run_or_print "${sudo_cmd[@]}" install -m 0644 "$INSTALL_TEMP_DIR$SERVICE_PATH" "$SERVICE_PATH"
    if [ "$iommu_setup_needed" -eq 1 ]; then
        have_cmd update-grub || die "update-grub is required to install the IOMMU grub drop-in"
        run_or_print "${sudo_cmd[@]}" install -D -m 0644 "$INSTALL_TEMP_DIR$IOMMU_GRUB_DROPIN_PATH" "$IOMMU_GRUB_DROPIN_PATH"
        run_or_print "${sudo_cmd[@]}" update-grub
    fi
    run_or_print "${sudo_cmd[@]}" systemctl daemon-reload
    disable_legacy_services "${sudo_cmd[@]}"
    run_or_print "${sudo_cmd[@]}" systemctl enable "$SERVICE_NAME"

    if [ "$iommu_setup_needed" -eq 0 ]; then
        run_or_print "${sudo_cmd[@]}" systemctl start "$SERVICE_NAME"
    else
        echo "Installed boot-persistent setup. The service was enabled but not started now because vfio-pci requires an IOMMU reboot first."
    fi

    verify_post_apply

    cleanup_install_temp
    trap - EXIT

    if [ "$iommu_setup_needed" -eq 1 ]; then
        prompt_reboot_after_iommu_install "${sudo_cmd[@]}"
    fi
}

running_celeos_containers() {
    have_cmd docker || return 0
    docker ps --format '{{.Names}}' 2>/dev/null | grep -Ei '^celeos($|[-_])' || true
}

guard_running_celeos() {
    local action="${1:-applying the DPDK settings}"
    local running
    local answer
    local containers=()

    running="$(running_celeos_containers)"
    if [ -z "$running" ]; then
        return
    fi
    mapfile -t containers <<<"$running"

    echo
    warn "Running CELEOS container(s) detected:"
    echo "$running" | sed 's/^/  /'

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        die "Running CELEOS containers must be stopped before --apply can continue. Rerun interactively to confirm stopping them."
    fi

    printf "These containers will be stopped before %s. Continue? [y/N]: " "$action" >&2
    if ! read -r answer; then
        die "Input ended while reading CELEOS container stop confirmation."
    fi
    echo >&2

    case "$answer" in
        y|Y|yes|YES|Yes)
            echo "Stopping CELEOS container(s)..."
            docker stop "${containers[@]}" >/dev/null || die "Failed to stop running CELEOS container(s)."
            STOPPED_CELEOS_CONTAINERS=("${containers[@]}")
            echo "CELEOS container(s) stopped."
            ;;
        *)
            die "Aborted by user."
            ;;
    esac
}

restart_stopped_celeos_containers() {
    local visibility_mode="${1:-}"
    local containers=("${STOPPED_CELEOS_CONTAINERS[@]}")
    local container

    [ "${#containers[@]}" -gt 0 ] || return 0
    STOPPED_CELEOS_CONTAINERS=()

    if ! have_cmd docker; then
        warn "docker is not installed or not in PATH; cannot restart stopped CELEOS container(s)."
        return 0
    fi

    echo "Starting CELEOS container(s) again..."
    if docker start "${containers[@]}" >/dev/null; then
        echo "CELEOS container(s) started."
        if [ -n "$visibility_mode" ]; then
            for container in "${containers[@]}"; do
                check_usrp_visibility_in_celeos_container "$container" "$visibility_mode"
            done
        fi
    else
        warn "Failed to start stopped CELEOS container(s): ${containers[*]}"
    fi
}

start_existing_celeos_container_for_visibility_check() {
    local visibility_mode="$1"
    local selected
    local containers=()

    if ! have_cmd docker; then
        if [ "$visibility_mode" = "dpdk" ]; then
            warn "docker is not installed or not in PATH; running host UHD DPDK verification instead."
            check_usrp_visibility_from_host_dpdk
        else
            warn "docker is not installed or not in PATH; cannot start a CELEOS container for verification."
        fi
        return 0
    fi

    mapfile -t containers < <(all_celeos_containers)
    if [ "${#containers[@]}" -eq 0 ]; then
        if [ "$visibility_mode" = "dpdk" ]; then
            warn "No CELEOS container was found; running host UHD DPDK verification instead."
            check_usrp_visibility_from_host_dpdk
        else
            warn "No CELEOS container was found; skipping container UHD verification."
        fi
        return 0
    fi

    selected="$(preferred_celeos_container "${containers[@]}")"
    [ -n "$selected" ] || return 0

    echo "Starting CELEOS container '$selected' for verification..."
    docker start "$selected" >/dev/null || die "Failed to start CELEOS container '$selected'."
    echo "CELEOS container '$selected' started."
    check_usrp_visibility_in_celeos_container "$selected" "$visibility_mode"
}

prepare_root_cmd() {
    ROOT_CMD=()
    if [ "$(id -u)" -ne 0 ]; then
        if [ "$DRY_RUN" -eq 0 ]; then
            have_cmd sudo || die "sudo is required when not running as root"
        fi
        ROOT_CMD=(sudo)
    fi
}

run_root_optional() {
    local description="$1"
    shift

    if ! run_or_print "${ROOT_CMD[@]}" "$@"; then
        warn "$description failed; continuing."
    fi
}

run_root_shell() {
    local script="$1"

    if [ "$DRY_RUN" -eq 1 ]; then
        printf '+'
        if [ "${#ROOT_CMD[@]}" -gt 0 ]; then
            printf ' %s' "${ROOT_CMD[@]}"
        fi
        printf " sh -c '%s'\n" "$script"
        return 0
    fi

    "${ROOT_CMD[@]}" sh -c "$script"
}

disable_service_now() {
    local service="$1"

    if [ "$DRY_RUN" -eq 0 ] && ! have_cmd systemctl; then
        warn "systemctl is not installed or not in PATH; cannot disable $service."
        return
    fi
    run_root_optional "Disabling $service" systemctl disable --now "$service"
}

disable_legacy_service_now() {
    local service="$1"

    have_cmd systemctl || return
    if systemctl list-unit-files "$service" --no-legend 2>/dev/null | grep -q "$service"; then
        disable_service_now "$service"
    fi
}

confirm_disable_dpdk() {
    local answer
    local interface_label
    local current_driver

    [ "$DISABLE_DPDK" -eq 1 ] || return
    [ "$DRY_RUN" -eq 0 ] || return

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        die "--disable-dpdk requires interactive confirmation before rebinding $PCI to $KERNEL_DRIVER."
    fi

    interface_label="${IFACE:-unknown interface}"
    current_driver="$(pci_driver_name "$PCI")"

    echo
    cat <<EOF
############################ WARNING ############################
Are you sure you want to disable CELEOS DPDK on interface $interface_label / PCI $PCI?
This will stop and disable $SERVICE_NAME.
This will rebind the PCI function from $current_driver to $KERNEL_DRIVER.
If $DPDK_IPV4 is configured, it will be moved from ${DUMMY_IFACE:-the dummy route interface} back to ${IFACE:-the restored NIC interface when it can be detected}.
#################################################################
EOF
    printf "Proceed? [y/N]: " >&2
    if ! read -r answer; then
        die "Input ended while reading DPDK disable confirmation."
    fi
    echo >&2

    case "$answer" in
        y|Y|yes|YES|Yes)
            ;;
        *)
            die "Aborted by user."
            ;;
    esac
}

disable_dpdk_runtime() {
    local current_driver
    local legacy_service
    local iface_after_bind
    local restore_pci
    local restore_driver
    local restore_bind_driver

    validate_disable_values
    refresh_vfio_group_values
    prepare_root_cmd

    current_driver="$(pci_driver_name "$PCI")"

    echo
    echo "Disabling CELEOS DPDK service and restoring Ubuntu kernel NIC driver..."
    disable_service_now "$SERVICE_NAME"
    for legacy_service in "${LEGACY_SERVICE_NAMES[@]}"; do
        disable_legacy_service_now "$legacy_service"
    done

    for restore_pci in ${VFIO_GROUP_PCI:-$PCI}; do
        [ -n "$restore_pci" ] || continue
        restore_driver="$(restore_driver_for_pci "$restore_pci")"
        if [ -z "$restore_driver" ]; then
            warn "Could not determine regular Ubuntu kernel driver for $restore_pci; skipping automatic rebind."
            continue
        fi
        run_or_print "${ROOT_CMD[@]}" modprobe "$restore_driver"
        restore_bind_driver="$(pci_driver_bind_name "$restore_driver")"
        current_driver="$(pci_driver_name "$restore_pci")"
        if [ "$current_driver" = "$restore_driver" ] || [ "$current_driver" = "$restore_bind_driver" ]; then
            echo "$restore_pci is already bound to $current_driver"
        else
            run_root_shell "if [ -e /sys/bus/pci/devices/$restore_pci/driver/unbind ]; then echo $restore_pci > /sys/bus/pci/devices/$restore_pci/driver/unbind; fi"
            run_root_shell "echo $restore_pci > /sys/bus/pci/drivers/$restore_bind_driver/bind"
        fi
    done

    if [ -z "$IFACE" ]; then
        iface_after_bind="$(iface_for_pci "$PCI")"
        IFACE="$iface_after_bind"
    fi

    if [ -n "$DUMMY_IFACE" ]; then
        run_root_shell "if ip link show $DUMMY_IFACE >/dev/null 2>&1; then ip link delete $DUMMY_IFACE; fi"
    fi

    if [ -n "$DPDK_IPV4" ] && [ -n "$IFACE" ]; then
        run_root_shell "ip link set $IFACE up; if ! ip -o -4 addr show dev $IFACE 2>/dev/null | grep -Fq $DPDK_IPV4; then ip addr add $DPDK_IPV4 dev $IFACE; fi; ip link set $IFACE up"
    elif [ -n "$DPDK_IPV4" ]; then
        warn "Could not determine Linux interface for $PCI; assign $DPDK_IPV4 manually after the kernel driver is bound."
    fi

    run_root_optional "Removing CELEOS DPDK sysctl drop-in" rm -f /etc/sysctl.d/99-celeos-dpdk-usrp.conf

    echo "CELEOS DPDK disabled for $PCI."
    if [ "$DRY_RUN" -eq 1 ]; then
        echo
        echo "No host changes were made."
    fi
}

confirm_apply() {
    local answer
    local interface_label

    if [ "$APPLY" -eq 0 ]; then
        return
    fi

    interface_label="${IFACE:-PCI $PCI}"
    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        die "--apply requires interactive confirmation before binding $interface_label for USRP $USRP_IP to target driver $TARGET_DRIVER."
    fi

    echo
    echo "About to install host DPDK files under /etc, /usr/local/sbin, and /etc/systemd/system."
    echo "The systemd service will be enabled and started now when runtime binding is possible."
    echo
    cat <<EOF
############################ WARNING ############################
Are you sure you want to apply the USRP interface configuration above?
Make sure $interface_label is not being used for remote SSH access.
Make sure you have physical access to this machine for recovery, if required.
#################################################################
EOF
    printf "Proceed? [y/N]: " >&2
    if ! read -r answer; then
        die "Input ended while reading apply confirmation."
    fi
    echo >&2
    case "$answer" in
        y|Y|yes|YES|Yes)
            ;;
        *)
            die "Aborted by user."
            ;;
    esac
}

confirm_vfio_group_binding() {
    local endpoints=()
    local risks
    local answer

    [ "$APPLY" -eq 1 ] || return 0
    [ "$TARGET_DRIVER" = "vfio-pci" ] || return 0
    refresh_vfio_group_values
    read -r -a endpoints <<<"$VFIO_GROUP_PCI"
    [ "${#endpoints[@]}" -gt 1 ] || return 0

    if [ "$BIND_VFIO_GROUP" -eq 1 ]; then
        echo "VFIO group binding was pre-approved by --bind-vfio-group."
        return 0
    fi

    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        die "vfio-pci requires binding all endpoint functions in the selected IOMMU group. Re-run with --bind-vfio-group after confirming the sibling interfaces are not used for management."
    fi

    echo
    warn "vfio-pci requires all endpoint functions in IOMMU group $(pci_iommu_group "$PCI") to be bound to vfio-pci or unbound."
    if [ "$VFIO_GROUP_MEMBERS_PRINTED" -eq 0 ]; then
        print_vfio_group_members
    fi
    risks="$(vfio_group_binding_risks)"
    if [ -n "$risks" ]; then
        echo
        warn "Potential management/interface risks:"
        printf '%s\n' "$risks" | sed 's/^/  /'
    fi

    printf "Bind the VFIO group endpoint functions listed above? [y/N]: " >&2
    if ! read -r answer; then
        die "Input ended while reading VFIO group binding confirmation."
    fi
    echo >&2
    case "$answer" in
        y|Y|yes|YES|Yes)
            ;;
        *)
            die "Aborted by user."
            ;;
    esac
}

require_safe_vfio_group_for_apply() {
    local risks
    local iommu_group

    [ "$APPLY" -eq 1 ] || return 0
    [ "$TARGET_DRIVER" = "vfio-pci" ] || return 0

    risks="$(vfio_group_safety_risks 0)"
    [ -z "$risks" ] && return 0

    iommu_group="$(pci_iommu_group "$PCI")"
    {
        echo "Refusing vfio-pci for unsafe IOMMU group ${iommu_group:-unknown}."
        echo "The group contains endpoint functions that cannot be safely rebound by default:"
        printf '%s\n' "$risks" | sed 's/^/  /'
        echo "Use uio_pci_generic or igb_uio, move the USRP NIC to an isolated slot/group, or remove management/storage/USB endpoints from the selected IOMMU group."
    } >&2
    exit 1
}

apply_selected_settings() {
    local apply_reboot_needed=0

    validate_required_values
    refresh_vfio_group_values
    require_safe_vfio_group_for_apply
    if vfio_iommu_setup_needed; then
        apply_reboot_needed=1
    fi
    require_dpdk_pmd_package_resolved_for_apply
    require_dpdk_ring_mempool_package_resolved_for_apply
    if [ "$NON_INTERACTIVE" -eq 1 ]; then
        ensure_dpdk_pmd_package_for_apply
        ensure_dpdk_ring_mempool_package_for_apply
    fi
    confirm_vfio_group_binding
    guard_running_celeos

    confirm_apply
    ensure_dpdk_pmd_package_for_apply
    ensure_dpdk_ring_mempool_package_for_apply
    install_rendered_files
    if [ "$apply_reboot_needed" -eq 0 ]; then
        if [ "${#STOPPED_CELEOS_CONTAINERS[@]}" -gt 0 ]; then
            restart_stopped_celeos_containers
        fi
        print_quick_install_dpdk_verification_guidance
    fi
}

verify_rendered_tree() {
    local root="$1"

    [ -s "$root$CONFIG_PATH" ] || die "Rendered config is missing"
    [ -s "$root$UHD_CONFIG_PATH" ] || die "Rendered UHD config is missing"
    [ -x "$root$HELPER_PATH" ] || die "Rendered helper is missing or not executable"
    [ -s "$root$SERVICE_PATH" ] || die "Rendered service is missing"
    if vfio_iommu_setup_needed; then
        [ -s "$root$IOMMU_GRUB_DROPIN_PATH" ] || die "Rendered IOMMU grub drop-in is missing"
    fi
}

main() {
    parse_args "$@"
    print_mode

    if [ "$DISABLE_DPDK" -eq 1 ]; then
        collect_disable_values
        validate_disable_values
        print_disable_plan
        if [ "$DRY_RUN" -eq 0 ]; then
            confirm_disable_dpdk
            guard_running_celeos "disabling DPDK"
            if [ "${#STOPPED_CELEOS_CONTAINERS[@]}" -gt 0 ]; then
                trap restart_stopped_celeos_containers EXIT
            fi
        fi
        disable_dpdk_runtime
        if [ "${#STOPPED_CELEOS_CONTAINERS[@]}" -gt 0 ]; then
            restart_stopped_celeos_containers no-dpdk
        elif [ "$DRY_RUN" -eq 0 ]; then
            start_existing_celeos_container_for_visibility_check no-dpdk
        fi
        trap - EXIT
        return
    fi

    if [ "$CHECK" -eq 1 ]; then
        load_check_values
        run_post_reboot_check
        return
    fi

    if [ "$VIEW" -eq 0 ]; then
        probe_host
    fi
    collect_values

    if [ "$VIEW" -eq 1 ]; then
        validate_required_values
        print_view
        return
    fi

    print_plan

    if [ "$DRY_RUN" -eq 1 ]; then
        local missing
        missing="$(missing_values)"
        if [ -n "$missing" ]; then
            echo
            echo "Missing values for install/render: $missing"
            echo "Provide them with flags or rerun interactively before using --apply."
        else
            validate_required_values
        fi
        if [ "$PROMPT_APPLY_AFTER_PROBE" -eq 1 ] && [ -z "$missing" ]; then
            APPLY=1
            DRY_RUN=0
            apply_selected_settings
            return
        fi

        echo
        if [ "$HOST_UHD_TOOLS_INSTALLED" -eq 1 ]; then
            echo "UHD host tools were installed for discovery; no DPDK host changes were made."
        else
            echo "No host changes were made."
        fi
        echo "Run again with --apply to install, or --view to inspect selected values and current status."
        return
    fi

    apply_selected_settings
}

main "$@"
