#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  02_usrp_setup.sh [--iface IFACE] [--ip HOST_IP] [--cidr 24] [--mtu 9000] [--probe USRP_IP]

Purpose:
  Configure a host Ethernet/SFP interface for direct connectivity to networked
  USRPs such as X300/X310/N3xx/X4xx.

Defaults:
  Netmask prompt default: 24
  MTU prompt default: 9000
  Without --dry-run, prints the planned commands and asks before applying.
  If uhd_find_devices is missing, prompts at startup before configuration.

Examples:
  # Inspect commands for a typical X300 10GbE/SFP link.
  ./02_usrp_setup.sh --iface enp1s0 --ip 192.168.30.1 --probe 192.168.30.2

  # Preview, then confirm a typical X300 1GbE link setup.
  ./02_usrp_setup.sh --iface eno2 --ip 192.168.10.1 --mtu 1500 --probe 192.168.10.2

  # Preview, then confirm without deleting other addresses already on the interface.
  ./02_usrp_setup.sh --iface enp1s0 --ip 192.168.117.1 --keep-existing

Options:
  -i, --iface IFACE       Network interface to configure. If omitted, choose from an interactive list.
  -a, --ip HOST_IP        Host-side IPv4 address to assign. If omitted, prompt interactively.
  -p, --cidr CIDR         IPv4 netmask/prefix length. If omitted, prompt interactively. Prompt default: 24.
  -m, --mtu MTU           Interface MTU. If omitted, prompt interactively. Prompt default: 9000.
      --probe USRP_IP     Target USRP/device IPv4 to ping after setup. If omitted, prompt interactively.
      --list-interfaces   Show interface state, carrier, addresses, and NIC hardware, then exit.
      --keep-existing     Do not flush existing global IPv4 addresses first.
      --dry-run           Print commands only and skip the final apply confirmation.
  -h, --help              Show this help.
USAGE
}

die() {
  echo "ERROR: $*" >&2
  exit 1
}

warn() {
  echo "WARNING: $*" >&2
}

installer_euid() {
  if [[ -n ${PYTEST_CURRENT_TEST:-} && -n ${CELEOS_INSTALL_TEST_EUID:-} ]]; then
    printf '%s' "$CELEOS_INSTALL_TEST_EUID"
  else
    printf '%s' "$EUID"
  fi
}

require_root() {
  if [[ "$(installer_euid)" -ne 0 ]]; then
    echo "ERROR: This script must be run as root. Please use sudo." >&2
    exit 1
  fi
}

require_root

have_cmd() {
  command -v "$1" >/dev/null 2>&1
}

join_cmd() {
  local first=1
  for arg in "$@"; do
    if (( first )); then
      first=0
    else
      printf ' '
    fi
    printf '%s' "$arg"
  done
}

run_cmd() {
  if (( dry_run )); then
    printf 'DRY-RUN: '
    join_cmd "$@"
    printf '\n'
  else
    "$@"
  fi
}

run_ip() {
  if (( EUID == 0 )); then
    run_cmd ip "$@"
  else
    run_cmd sudo ip "$@"
  fi
}

run_nmcli() {
  if (( EUID == 0 )); then
    run_cmd nmcli "$@"
  else
    run_cmd sudo nmcli "$@"
  fi
}

install_uhd_host_tools() {
  local sudo_cmd=()

  have_cmd apt-get || die "apt-get is required to install $HOST_UHD_PACKAGE on this Ubuntu host."
  if (( EUID != 0 )); then
    have_cmd sudo || die "sudo is required to install $HOST_UHD_PACKAGE."
    sudo_cmd=(sudo)
  fi

  echo "Installing UHD host tools package '$HOST_UHD_PACKAGE' for network USRP discovery."
  "${sudo_cmd[@]}" apt-get update
  "${sudo_cmd[@]}" apt-get install -y "$HOST_UHD_PACKAGE"
}

format_kib_size() {
  local kib=$1
  local whole
  local tenths

  if [[ ! $kib =~ ^[0-9]+$ ]]; then
    printf 'unknown'
    return
  fi

  if (( kib >= 1048576 )); then
    whole=$((kib / 1048576))
    tenths=$(((kib % 1048576) * 10 / 1048576))
    printf '%d.%d GiB' "$whole" "$tenths"
  elif (( kib >= 1024 )); then
    whole=$((kib / 1024))
    tenths=$(((kib % 1024) * 10 / 1024))
    printf '%d.%d MiB' "$whole" "$tenths"
  else
    printf '%d KiB' "$kib"
  fi
}

estimate_uhd_host_tools_disk_space() {
  local line
  local estimate

  if ! have_cmd apt-get; then
    printf 'unknown'
    return
  fi

  while IFS= read -r line; do
    case "$line" in
      "After this operation, "*" of additional disk space will be used.")
        estimate=${line#After this operation, }
        estimate=${estimate% of additional disk space will be used.}
        printf '%s' "${estimate:-unknown}"
        return
        ;;
    esac
  done < <(apt-get -s install "$HOST_UHD_PACKAGE" 2>/dev/null || true)

  if have_cmd apt-cache; then
    while IFS= read -r line; do
      case "$line" in
        "Installed-Size: "*)
          estimate=${line#Installed-Size: }
          format_kib_size "$estimate"
          return
          ;;
      esac
    done < <(apt-cache show "$HOST_UHD_PACKAGE" 2>/dev/null || true)
  fi

  printf 'unknown'
}

prepare_uhd_find_devices() {
  local answer
  local estimate

  if have_cmd uhd_find_devices; then
    return 0
  fi

  echo "uhd_find_devices not found in PATH."
  if (( dry_run_only )); then
    echo "Dry-run mode will not install $HOST_UHD_PACKAGE."
    return 0
  fi

  estimate="$(estimate_uhd_host_tools_disk_space)"
  printf "Would you like to install minimal UHD tools for USRP discovery so this script can validate the configuration it creates? Estimated additional disk space: %s. [y/N]: " "$estimate" >&2
  if ! read -r answer; then
    die "Input ended while reading UHD tools installation confirmation."
  fi
  echo >&2
  case "$answer" in
    y|Y|yes|YES|Yes)
      ;;
    *)
      echo "Skipping UHD host tools installation."
      return 0
      ;;
  esac

  install_uhd_host_tools
  have_cmd uhd_find_devices || die "$HOST_UHD_PACKAGE installation completed, but uhd_find_devices is still not in PATH."
  echo "Installed UHD host tools; uhd_find_devices is now available."
}

run_uhd_find_devices() {
  local output
  local status

  if ! have_cmd uhd_find_devices; then
    echo "Skipping uhd_find_devices validation because uhd_find_devices is not available."
    return 0
  fi

  echo "Running UHD discovery against target USRP $probe_ip..."
  if (( dry_run )); then
    run_cmd uhd_find_devices --args "addr=$probe_ip"
    return 0
  fi

  if output="$(uhd_find_devices --args "addr=$probe_ip" 2>&1)"; then
    status=0
  else
    status=$?
  fi
  printf '%s\n' "$output"

  if (( status != 0 )); then
    return "$status"
  fi
  if [[ $output == *"No UHD Devices Found"* ]]; then
    return 1
  fi
  return 0
}

networkmanager_connection_for_iface() {
  local iface_name=$1
  local connection

  have_cmd nmcli || return 1
  if ! connection="$(nmcli -t -g GENERAL.CONNECTION device show "$iface_name" 2>/dev/null)"; then
    return 1
  fi
  connection="${connection%%$'\n'*}"
  case "$connection" in
    ""|"--")
      return 1
      ;;
  esac
  printf '%s' "$connection"
}

networkmanager_connection_exists() {
  local connection=$1

  have_cmd nmcli || return 1
  nmcli connection show "$connection" >/dev/null 2>&1
}

apply_usrp_networkmanager_config() {
  local connection

  have_cmd nmcli || return 1

  if connection="$(networkmanager_connection_for_iface "$iface")"; then
    if (( dry_run )); then
      echo "Would persist USRP interface configuration with NetworkManager connection '$connection'."
    else
      echo "Persisting USRP interface configuration with NetworkManager connection '$connection'."
    fi
  else
    connection="celeos-usrp-$iface"
    if networkmanager_connection_exists "$connection"; then
      if (( dry_run )); then
        echo "Would reuse NetworkManager connection '$connection' for $iface."
      else
        echo "Reusing NetworkManager connection '$connection' for $iface."
      fi
    else
      if (( dry_run )); then
        echo "Would create NetworkManager connection '$connection' for $iface."
      else
        echo "Created NetworkManager connection '$connection' for $iface."
      fi
      if ! run_nmcli connection add type ethernet ifname "$iface" con-name "$connection"; then
        return 1
      fi
    fi
  fi

  if ! run_nmcli connection modify "$connection" \
    ipv4.method manual \
    ipv4.addresses "$host_ip/$cidr" \
    ipv4.gateway "" \
    ipv4.dns "" \
    ipv4.never-default yes \
    ipv6.method disabled \
    802-3-ethernet.mtu "$mtu" \
    connection.autoconnect yes; then
    return 1
  fi

  run_nmcli connection up "$connection" ifname "$iface"
}

apply_usrp_runtime_ip_config() {
  if (( flush_existing )); then
    run_ip addr flush dev "$iface" scope global
  fi
  run_ip addr add "$host_ip/$cidr" dev "$iface"
  run_ip link set dev "$iface" mtu "$mtu"
  run_ip link set dev "$iface" up
}

iface_has_configured_ipv4() {
  local output

  output="$(ip -o -4 addr show dev "$iface" 2>/dev/null || true)"
  if [[ $output == *"$host_ip/$cidr"* ]]; then
    return 0
  fi
  output="$(ip -brief addr show dev "$iface" 2>/dev/null || true)"
  [[ $output == *"$host_ip/$cidr"* ]]
}

wait_for_configured_ipv4() {
  local attempt

  (( dry_run )) && return 0
  for attempt in 1 2 3 4 5; do
    if iface_has_configured_ipv4; then
      return 0
    fi
    have_cmd sleep && sleep 1
  done

  warn "$iface does not show $host_ip/$cidr after configuration."
  return 1
}

configure_usrp_interface_address() {
  if have_cmd nmcli; then
    if apply_usrp_networkmanager_config; then
      return 0
    fi
    warn "NetworkManager persistence failed for $iface."
    return 1
  fi

  warn "NetworkManager/nmcli is not available for $iface; applying runtime-only IP configuration that may not persist after reconnect or reboot."
  apply_usrp_runtime_ip_config
}

configure_usrp_interface() {
  local validation_failed=0

  if ! configure_usrp_interface_address; then
    validation_failed=1
  fi
  if ! wait_for_configured_ipv4; then
    validation_failed=1
  fi
  if [[ -n $probe_ip ]]; then
    if ! run_cmd ping -c 3 -I "$iface" "$probe_ip"; then
      validation_failed=1
    fi
    if ! run_uhd_find_devices; then
      validation_failed=1
    fi
  fi

  return "$validation_failed"
}

warn_usrp_not_visible() {
  cat <<EOF
############################ WARNING ############################
USRP $probe_ip is not visible on interface $iface.
Check that the USRP is powered on and physically connected to this machine.
Check that the host IP address, target USRP address, netmask, and selected interface match.
#################################################################
EOF
}

confirm_apply() {
  local answer

  cat <<EOF
############################ WARNING ############################
Are you sure you want to apply the USRP interface configuration above?
Make sure $iface is not being used for remote SSH access.
Make sure you have physical access to this machine for recovery, if required.
#################################################################
EOF
  printf "Proceed? [y/N]: " >&2
  if ! read -r answer; then
    die "Input ended while reading apply confirmation."
  fi
  echo >&2
  case "$answer" in
    y|Y|yes|YES|Yes)
      ;;
    *)
      die "Aborted by user."
      ;;
  esac
}

is_ipv4() {
  local ip=$1 part
  [[ $ip =~ ^[0-9]+(\.[0-9]+){3}$ ]] || return 1
  IFS=. read -r -a parts <<<"$ip"
  for part in "${parts[@]}"; do
    [[ $part =~ ^[0-9]+$ ]] || return 1
    (( part >= 0 && part <= 255 )) || return 1
  done
}

suggest_host_ipv4() {
  local target_ip=$1
  local o1
  local o2
  local o3
  local o4
  local host_octet=10

  IFS=. read -r o1 o2 o3 o4 <<<"$target_ip"
  if [[ $o4 = "10" ]]; then
    host_octet=11
  fi
  printf '%s.%s.%s.%s\n' "$o1" "$o2" "$o3" "$host_octet"
}

list_ip_a_interfaces() {
  ip a | awk -F': ' '
    /^[0-9]+: / {
      name = $2
      sub(/@.*/, "", name)
      if (name != "lo") {
        print name
      }
    }
  '
}

interface_joined_ipv4s() {
  local iface=$1
  ip -o -4 addr show dev "$iface" 2>/dev/null | awk '
    {
      value = value ? value "," $4 : $4
    }
    END {
      print value ? value : "-"
    }
  '
}

interface_joined_ipv6s() {
  local iface=$1
  ip -o -6 addr show dev "$iface" 2>/dev/null | awk '
    {
      value = value ? value "," $4 : $4
    }
    END {
      print value ? value : "-"
    }
  '
}

interface_flags() {
  local iface=$1
  local flags
  flags="$(ip -o link show dev "$iface" 2>/dev/null | sed -n 's/.*<\([^>]*\)>.*/\1/p' | head -n 1)"
  printf '%s\n' "${flags:--}"
}

interface_operstate() {
  local iface=$1
  local value
  value="$(cat "$net_sys_class_dir/$iface/operstate" 2>/dev/null || true)"
  printf '%s\n' "${value:-unknown}"
}

interface_carrier() {
  local iface=$1
  local value
  value="$(cat "$net_sys_class_dir/$iface/carrier" 2>/dev/null || true)"
  case "$value" in
    1) printf 'yes\n' ;;
    0) printf 'no\n' ;;
    *) printf 'unknown\n' ;;
  esac
}

interface_pci_addr() {
  local iface=$1
  local device_path="$net_sys_class_dir/$iface/device"
  local resolved
  local basename

  if [[ ! -e $device_path ]]; then
    printf -- '-\n'
    return
  fi

  resolved="$(readlink -f "$device_path" 2>/dev/null || true)"
  basename="${resolved##*/}"
  if [[ $basename =~ ^[[:xdigit:]]{4}:[[:xdigit:]]{2}:[[:xdigit:]]{2}\.[[:xdigit:]]$ ]]; then
    printf '%s\n' "$basename"
  else
    printf -- '-\n'
  fi
}

interface_hardware() {
  local iface=$1
  local pci=$2
  local output

  if [[ $pci = "-" ]]; then
    printf 'virtual/no-pci\n'
    return
  fi

  if ! command -v lspci >/dev/null 2>&1; then
    printf 'lspci unavailable\n'
    return
  fi

  output="$(lspci -D -s "$pci" 2>/dev/null | sed -E 's/^[^[:space:]]+[[:space:]]+//' || true)"
  printf '%s\n' "${output:-unknown}"
}

print_interface_inventory() {
  local iface
  local state
  local carrier
  local flags
  local ipv4s
  local ipv6s
  local pci
  local hardware
  local -a interfaces=()

  mapfile -t interfaces < <(list_ip_a_interfaces)
  ((${#interfaces[@]} > 0)) || die "No non-loopback interfaces found from ip a"

  echo "Available network interfaces:"
  for iface in "${interfaces[@]}"; do
    state="$(interface_operstate "$iface")"
    carrier="$(interface_carrier "$iface")"
    flags="$(interface_flags "$iface")"
    ipv4s="$(interface_joined_ipv4s "$iface")"
    ipv6s="$(interface_joined_ipv6s "$iface")"
    pci="$(interface_pci_addr "$iface")"
    hardware="$(interface_hardware "$iface" "$pci")"
    echo "----------------------------------------"
    printf 'IFACE:    %s\n' "$iface"
    printf 'STATE:    %s\n' "$state"
    printf 'CARRIER:  %s\n' "$carrier"
    printf 'FLAGS:    %s\n' "$flags"
    printf 'IPV4:     %s\n' "$ipv4s"
    printf 'IPV6:     %s\n' "$ipv6s"
    printf 'PCI:      %s\n' "$pci"
    printf 'HARDWARE: %s\n' "$hardware"
  done
  echo "----------------------------------------"
}

choose_iface_interactively() {
  local selection
  local state
  local -a interfaces=()

  mapfile -t interfaces < <(list_ip_a_interfaces)
  ((${#interfaces[@]} > 0)) || die "No non-loopback interfaces found from ip a"

  print_interface_inventory
  echo
  echo "Choose an interface number:"
  for index in "${!interfaces[@]}"; do
    state="$(interface_operstate "${interfaces[$index]}")"
    printf '%d) %s (state: %s)\n' "$((index + 1))" "${interfaces[$index]}" "$state"
  done

  printf 'Pick interface number: ' >&2
  IFS= read -r selection || die "No interface selection provided"
  [[ $selection =~ ^[0-9]+$ ]] || die "Invalid selection: $selection"
  (( selection >= 1 && selection <= ${#interfaces[@]} )) || die "Selection out of range: $selection"

  iface="${interfaces[$((selection - 1))]}"
  echo "Selected interface: $iface"
}

choose_host_ip_interactively() {
  local suggested_ip=${1:-}
  local selection

  if [[ -n $suggested_ip ]]; then
    printf "Host IPv4 address (must match USRP's subnet) [%s]: " "$suggested_ip" >&2
  else
    printf "Host IPv4 address (must match USRP's subnet): " >&2
  fi
  IFS= read -r selection || die "No host IPv4 address provided"
  if [[ -n $selection ]]; then
    host_ip=$selection
  else
    host_ip=$suggested_ip
  fi
  [[ -n $host_ip ]] || die "Host IPv4 address cannot be empty"
}

choose_cidr_interactively() {
  local selection

  printf 'Netmask [24]: ' >&2
  IFS= read -r selection || die "No netmask provided"
  if [[ -z $selection ]]; then
    cidr=24
  else
    cidr=$selection
  fi
}

choose_mtu_interactively() {
  local selection

  printf 'MTU (1Gbps links require 1500, 10Gbps links require 9000) [9000]: ' >&2
  IFS= read -r selection || die "No MTU provided"
  if [[ -z $selection ]]; then
    mtu=9000
  else
    mtu=$selection
  fi
}

choose_target_usrp_interactively() {
  printf 'target USRP address: ' >&2
  IFS= read -r probe_ip || die "No target USRP address provided"
  [[ -n $probe_ip ]] || die "Target USRP address cannot be empty"
  is_ipv4 "$probe_ip" || die "Invalid target USRP IPv4 address: $probe_ip"
  probe_set=1
}

iface=""
host_ip=""
cidr=""
mtu=""
probe_ip=""
probe_set=0
dry_run=1
dry_run_only=0
flush_existing=1
list_interfaces_only=0
net_sys_class_dir="${CELEOS_NET_SYS_CLASS_DIR:-/sys/class/net}"
HOST_UHD_PACKAGE="${CELEOS_USRP_SETUP_UHD_HOST_PACKAGE:-${CELEOS_DPDK_SETUP_UHD_HOST_PACKAGE:-uhd-host}}"

while (( $# )); do
  case "$1" in
    -i|--iface)
      [[ $# -ge 2 ]] || die "$1 requires a value"
      iface=$2
      shift 2
      ;;
    -a|--ip)
      [[ $# -ge 2 ]] || die "$1 requires a value"
      host_ip=$2
      shift 2
      ;;
    -p|--cidr|--prefix)
      [[ $# -ge 2 ]] || die "$1 requires a value"
      cidr=$2
      shift 2
      ;;
    -m|--mtu)
      [[ $# -ge 2 ]] || die "$1 requires a value"
      mtu=$2
      shift 2
      ;;
    --probe)
      [[ $# -ge 2 ]] || die "$1 requires a value"
      probe_ip=$2
      probe_set=1
      shift 2
      ;;
    --keep-existing)
      flush_existing=0
      shift
      ;;
    --list-interfaces)
      list_interfaces_only=1
      shift
      ;;
    --dry-run)
      dry_run=1
      dry_run_only=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Unknown argument: $1"
      ;;
  esac
done

command -v ip >/dev/null 2>&1 || die "ip command not found; install iproute2"
if (( list_interfaces_only )); then
  print_interface_inventory
  exit 0
fi
prepare_uhd_find_devices
if [[ -z $iface ]]; then
  choose_iface_interactively
fi
if (( ! probe_set )); then
  choose_target_usrp_interactively
fi
if [[ -n $probe_ip ]]; then
  is_ipv4 "$probe_ip" || die "Invalid target USRP IPv4 address: $probe_ip"
fi
if [[ -z $host_ip ]]; then
  choose_host_ip_interactively "$(suggest_host_ipv4 "$probe_ip")"
fi
if [[ -z $cidr ]]; then
  choose_cidr_interactively
fi
if [[ -z $mtu ]]; then
  choose_mtu_interactively
fi

[[ $iface =~ ^[A-Za-z0-9_.:-]+$ ]] || die "Invalid interface name: $iface"
is_ipv4 "$host_ip" || die "Invalid host IPv4 address: $host_ip"
[[ $cidr =~ ^[0-9]+$ ]] || die "Netmask must be numeric: $cidr"
(( cidr >= 0 && cidr <= 32 )) || die "Netmask must be between 0 and 32: $cidr"
[[ $mtu =~ ^[0-9]+$ ]] || die "MTU must be numeric: $mtu"
(( mtu >= 576 && mtu <= 65535 )) || die "MTU must be between 576 and 65535: $mtu"
ip link show dev "$iface" >/dev/null 2>&1 || die "Interface not found: $iface"

echo "Planned USRP interface configuration for $iface:"
configure_usrp_interface

if (( dry_run_only )); then
  echo "Dry run only. No host changes made."
  exit 0
fi

echo
confirm_apply

dry_run=0

echo "Configuring $iface for USRP connectivity..."
validation_failed=0
if ! configure_usrp_interface; then
  validation_failed=1
fi

echo
echo "Interface state:"
ip -brief addr show dev "$iface"
ip link show dev "$iface"

if (( validation_failed )); then
  echo
  warn_usrp_not_visible
  die "USRP discovery validation failed."
fi
