#!/bin/bash

# Function to display usage
usage() {
    echo "Step 4: CELEOS container install/start"
    echo "Usage: $0 [--persistent_folder <path>] [--image <image_name>] [--version <tag>] [--container_name <name>] [--backend_port <port>] [--frontend_port <port>] [--disable_persistent_configs] [--usrp-dpdk] [--check-usrp] [--skip-usrp-check] [--allow-dpdk-mismatch] [--verbose]"
    echo "  --persistent_folder <path>: Custom folder path for persistent data (default: /persistent_celeos)"
    echo "  --image <image_name>: Custom Docker image name (default: auto-detected based on platform)"
    echo "  --version <tag>: Docker image tag/version (default: latest)"
    echo "  --container_name <name>: Custom Docker container name (default: celeos)"
    echo "  --backend_port <port>: Backend port number (default: 3001)"
    echo "  --frontend_port <port>: Frontend port number (default: 8000)"
    echo "  --gpu <device>: GPU device(s) to expose with Docker --gpus (default: Docker nvidia runtime; e.g. 'all' or 'device=0')"
    echo "  --disable_persistent_configs: Disable mounting persistent configs folder"
    echo "  --usrp-dpdk: Configure the network USRP DPDK runtime and mount UHD DPDK config; --usrp-dpdk requires step 3 (03_dpdk_setup.sh --apply) to be complete first"
    echo "  --check-usrp: Run uhd_find_devices inside the CELEOS container; enabled by default after install"
    echo "  --skip-usrp-check: Skip post-install uhd_find_devices; intended for CI deploys that only need API readiness"
    echo "  --allow-dpdk-mismatch: Continue when host DPDK state and requested container mode differ"
    echo "  --verbose: Enable verbose output (set -ex)"
    exit 1
}

installer_euid() {
    if [ -n "${PYTEST_CURRENT_TEST:-}" ] && [ -n "${CELEOS_INSTALL_TEST_EUID:-}" ]; then
        printf '%s' "$CELEOS_INSTALL_TEST_EUID"
    else
        printf '%s' "$EUID"
    fi
}

require_root() {
    if [ "$(installer_euid)" -ne 0 ]; then
        echo "ERROR: This script must be run as root. Please use sudo." >&2
        exit 1
    fi
}

require_root

# Parse command line arguments
persistent_folder=""
image=""
version=""
container_name=""
backend_port=""
frontend_port=""
disable_persistent_configs=""
gpu_device=""
usrp_dpdk="false"
legacy_x300_dpdk="false"
check_usrp="false"
check_usrp_explicit="false"
check_usrp_disabled="false"
allow_dpdk_mismatch="false"
verbose=""
while [[ $# -gt 0 ]]; do
    case $1 in
        --persistent_folder)
            persistent_folder="$2"
            shift 2
            ;;
        --image)
            image="$2"
            shift 2
            ;;
        --version)
            version="$2"
            shift 2
            ;;
        --container_name)
            container_name="$2"
            shift 2
            ;;
        --backend_port)
            backend_port="$2"
            shift 2
            ;;
        --frontend_port)
            frontend_port="$2"
            shift 2
            ;;
        --disable_persistent_configs)
            disable_persistent_configs="true"
            shift
            ;;
        --usrp-dpdk)
            usrp_dpdk="true"
            shift
            ;;
        --check-usrp)
            check_usrp="true"
            check_usrp_explicit="true"
            check_usrp_disabled="false"
            shift
            ;;
        --check-usrp-discovery)
            echo "WARNING: --check-usrp-discovery is deprecated; use --check-usrp."
            check_usrp="true"
            check_usrp_explicit="true"
            check_usrp_disabled="false"
            shift
            ;;
        --skip-usrp-check)
            check_usrp="false"
            check_usrp_explicit="false"
            check_usrp_disabled="true"
            shift
            ;;
        --allow-dpdk-mismatch)
            allow_dpdk_mismatch="true"
            shift
            ;;
        --x300-dpdk)
            usrp_dpdk="true"
            legacy_x300_dpdk="true"
            shift
            ;;
        --gpu)
            gpu_device="$2"
            shift 2
            ;;
        --verbose)
            verbose="true"
            shift
            ;;
        -h|--help)
            usage
            ;;
        --*)
            echo "Error: Unknown flag '$1'"
            echo "Run '$0 --help' for usage information."
            exit 1
            ;;
        *)
            echo "Warning: Unknown argument '$1' ignored."
            shift
            ;;
    esac
done

# Enable the USRP discovery check by default after step 4 installs.
if [ "$check_usrp" != "true" ] && [ "$check_usrp_disabled" != "true" ]; then
    check_usrp="true"
fi

# Enable verbose mode if requested
if [ "$verbose" = "true" ]; then
    set -ex
fi

HOST_USRP_DPDK_CONFIG="${CELEOS_USRP_DPDK_HOST_CONFIG:-/etc/celeos-dpdk-usrp.conf}"
HOST_USRP_DPDK_LEGACY_CONFIG="${CELEOS_USRP_DPDK_LEGACY_HOST_CONFIG:-/etc/celeos-dpdk-x300.conf}"
HOST_USRP_DPDK_CONFIG_LOADED="false"

load_usrp_dpdk_host_config() {
    local host_usrp_dpdk_config="$HOST_USRP_DPDK_CONFIG"

    if [ "$usrp_dpdk" != "true" ]; then
        return
    fi

    if [ ! -r "$host_usrp_dpdk_config" ] && [ -r "$HOST_USRP_DPDK_LEGACY_CONFIG" ]; then
        host_usrp_dpdk_config="$HOST_USRP_DPDK_LEGACY_CONFIG"
    fi

    if [ -r "$host_usrp_dpdk_config" ]; then
        echo "Loading network USRP DPDK host config from '$host_usrp_dpdk_config'."
        # shellcheck disable=SC1090
        source "$host_usrp_dpdk_config"
        HOST_USRP_DPDK_CONFIG_LOADED="true"
    fi
}

validate_usrp_dpdk_config_values() {
    local missing=()

    if [ "$usrp_dpdk" != "true" ]; then
        return
    fi

    [ -n "$CELEOS_USRP_DPDK_MAC" ] || missing+=("CELEOS_USRP_DPDK_MAC/DPDK_MAC")
    [ -n "$CELEOS_USRP_DPDK_HOST_IPV4" ] || missing+=("CELEOS_USRP_DPDK_HOST_IPV4/DPDK_IPV4")
    [ -n "$CELEOS_USRP_DPDK_USRP_IP" ] || missing+=("CELEOS_USRP_DPDK_USRP_IP/USRP_IP")

    if [ "${#missing[@]}" -gt 0 ]; then
        echo "ERROR: --usrp-dpdk is missing required host-specific DPDK value(s): ${missing[*]}"
        echo "Did you complete step 3 with 03_dpdk_setup.sh --apply?"
        echo "Expected host config: $HOST_USRP_DPDK_CONFIG"
        echo "Or set CELEOS_USRP_DPDK_MAC, CELEOS_USRP_DPDK_HOST_IPV4, and CELEOS_USRP_DPDK_USRP_IP explicitly."
        exit 1
    fi

    if [ -n "${CELEOS_USRP_DPDK_USRP_MGMT_IP:-}" ] && [[ ! "$CELEOS_USRP_DPDK_USRP_MGMT_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        echo "ERROR: CELEOS_USRP_DPDK_USRP_MGMT_IP must look like 192.168.40.10"
        exit 1
    fi
    if [ -n "${CELEOS_USRP_DPDK_USRP_TYPE:-}" ] && [[ ! "$CELEOS_USRP_DPDK_USRP_TYPE" =~ ^[A-Za-z0-9_:-]+$ ]]; then
        echo "ERROR: CELEOS_USRP_DPDK_USRP_TYPE contains unsupported characters"
        exit 1
    fi
}

load_usrp_dpdk_host_config

read_usrp_dpdk_config_value() {
    local config_file="$1"
    local key="$2"

    [ -r "$config_file" ] || return
    awk -v key="$key" '
        $0 ~ "^[[:space:]]*" key "[[:space:]]*=" {
            value = $0
            sub(/^[^=]*=/, "", value)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
            if (value ~ /^".*"$/ || value ~ /^'\''.*'\''$/) {
                value = substr(value, 2, length(value) - 2)
            }
            print value
            exit
        }
    ' "$config_file"
}

select_usrp_dpdk_host_config_for_alignment() {
    if [ -r "$HOST_USRP_DPDK_CONFIG" ]; then
        printf '%s\n' "$HOST_USRP_DPDK_CONFIG"
    elif [ -r "$HOST_USRP_DPDK_LEGACY_CONFIG" ]; then
        printf '%s\n' "$HOST_USRP_DPDK_LEGACY_CONFIG"
    fi
}

is_usrp_dpdk_binding_driver() {
    case "$1" in
        vfio-pci|uio_pci_generic|igb_uio)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

pci_driver_for_alignment() {
    local pci_addr="$1"

    if [ -z "$pci_addr" ]; then
        return
    fi

    if [ -e "/sys/bus/pci/devices/$pci_addr/driver" ]; then
        basename "$(readlink -f "/sys/bus/pci/devices/$pci_addr/driver")"
    fi
}

systemd_usrp_dpdk_service_is_active() {
    command -v systemctl >/dev/null 2>&1 || return 1
    systemctl is-active --quiet celeos-dpdk-setup.service >/dev/null 2>&1
}

usrp_dpdk_dummy_iface_has_ipv4() {
    local dummy_iface="$1"
    local dpdk_ipv4="$2"

    [ -n "$dummy_iface" ] || return 1
    [ -n "$dpdk_ipv4" ] || return 1
    command -v ip >/dev/null 2>&1 || return 1
    ip -o -brief addr show "$dummy_iface" 2>/dev/null | grep -Fq "$dpdk_ipv4"
}

detect_usrp_dpdk_host_state() {
    local host_config
    local pci_addr
    local pci_driver
    local dummy_iface
    local dpdk_ipv4

    if systemd_usrp_dpdk_service_is_active; then
        printf 'active\n'
        return
    fi

    host_config="$(select_usrp_dpdk_host_config_for_alignment)"
    if [ -n "$host_config" ]; then
        pci_addr="$(read_usrp_dpdk_config_value "$host_config" "PCI")"
        pci_driver="$(pci_driver_for_alignment "$pci_addr")"
        if is_usrp_dpdk_binding_driver "$pci_driver"; then
            printf 'active\n'
            return
        fi

        dummy_iface="$(read_usrp_dpdk_config_value "$host_config" "DUMMY_IFACE")"
        dpdk_ipv4="$(read_usrp_dpdk_config_value "$host_config" "DPDK_IPV4")"
        if usrp_dpdk_dummy_iface_has_ipv4 "$dummy_iface" "$dpdk_ipv4"; then
            printf 'active\n'
            return
        fi
    fi

    printf 'inactive\n'
}

print_usrp_dpdk_alignment_details() {
    local host_config
    local pci_addr
    local pci_driver
    local dummy_iface
    local dpdk_ipv4

    host_config="$(select_usrp_dpdk_host_config_for_alignment)"

    echo "Detected host DPDK state:"
    if systemd_usrp_dpdk_service_is_active; then
        echo "  service: celeos-dpdk-setup.service active"
    else
        echo "  service: celeos-dpdk-setup.service inactive or unavailable"
    fi

    if [ -n "$host_config" ]; then
        pci_addr="$(read_usrp_dpdk_config_value "$host_config" "PCI")"
        dummy_iface="$(read_usrp_dpdk_config_value "$host_config" "DUMMY_IFACE")"
        dpdk_ipv4="$(read_usrp_dpdk_config_value "$host_config" "DPDK_IPV4")"
        pci_driver="$(pci_driver_for_alignment "$pci_addr")"

        echo "  config: $host_config"
        echo "  PCI: ${pci_addr:-unknown}"
        echo "  PCI driver: ${pci_driver:-unknown}"
        echo "  DPDK IPv4: ${dpdk_ipv4:-unknown} on ${dummy_iface:-unknown}"
    else
        echo "  config: missing ($HOST_USRP_DPDK_CONFIG)"
    fi
}

print_quick_install_rerun_with_usrp_dpdk() {
    echo "  bash Docker/installation/04_install_celeos.sh \\"
    echo "    --persistent_folder \"$FOLDER_PATH\" \\"
    echo "    --image \"$IMAGE_NAME\" \\"
    echo "    --container_name \"$CONTAINER_NAME\" \\"
    echo "    --backend_port \"$BACKEND_PORT\" \\"
    echo "    --frontend_port \"$FRONTEND_PORT\" \\"
    if [ -n "$GPU_DEVICE" ]; then
        echo "    --gpu \"$GPU_DEVICE\" \\"
    fi
    if [ "$disable_persistent_configs" = "true" ]; then
        echo "    --disable_persistent_configs \\"
    fi
    echo "    --usrp-dpdk"
}

validate_usrp_dpdk_host_mode_alignment() {
    local host_state

    host_state="$(detect_usrp_dpdk_host_state)"

    if [ "$host_state" = "active" ] && [ "$usrp_dpdk" != "true" ]; then
        if [ "$allow_dpdk_mismatch" = "true" ]; then
            echo "WARNING: Host DPDK setup is active, but --usrp-dpdk was not requested."
            echo "Continuing because --allow-dpdk-mismatch was provided."
            return
        fi

        echo "ERROR: Host DPDK setup is active, but 04_install_celeos.sh was started without --usrp-dpdk."
        echo
        print_usrp_dpdk_alignment_details
        echo
        echo "Run:"
        print_quick_install_rerun_with_usrp_dpdk
        echo
        echo "Or disable host DPDK first:"
        echo "  sudo bash Docker/installation/03_dpdk_setup.sh --disable-dpdk"
        echo
        echo "Use --allow-dpdk-mismatch only if this mismatch is intentional."
        exit 1
    fi

    if [ "$host_state" != "active" ] && [ "$usrp_dpdk" = "true" ]; then
        if [ "$allow_dpdk_mismatch" = "true" ]; then
            echo "WARNING: --usrp-dpdk was requested, but host DPDK setup is not active."
            echo "Continuing because --allow-dpdk-mismatch was provided."
            return
        fi

        echo "ERROR: Host DPDK setup is not active, but 04_install_celeos.sh was started with --usrp-dpdk."
        echo
        print_usrp_dpdk_alignment_details
        echo
        echo "Complete step 3 first:"
        echo "  sudo bash Docker/installation/03_dpdk_setup.sh --apply"
        echo
        echo "Then rerun step 4:"
        print_quick_install_rerun_with_usrp_dpdk
        echo
        echo "Use --allow-dpdk-mismatch only if this mismatch is intentional."
        exit 1
    fi
}

append_csv_arg() {
    local existing="$1"
    local next="$2"

    if [ -n "$existing" ]; then
        printf '%s,%s' "$existing" "$next"
    else
        printf '%s' "$next"
    fi
}

build_usrp_dpdk_uhd_args() {
    local args=""

    if [ -n "$CELEOS_USRP_DPDK_USRP_TYPE" ]; then
        args="$(append_csv_arg "$args" "type=$CELEOS_USRP_DPDK_USRP_TYPE")"
    fi
    args="$(append_csv_arg "$args" "use_dpdk=1")"
    if [ -n "$CELEOS_USRP_DPDK_USRP_MGMT_IP" ]; then
        args="$(append_csv_arg "$args" "mgmt_addr=$CELEOS_USRP_DPDK_USRP_MGMT_IP")"
    fi
    args="$(append_csv_arg "$args" "addr=$CELEOS_USRP_DPDK_USRP_IP")"

    printf '%s' "$args"
}

usrp_dpdk_discovery_output_matches() {
    local output="$1"

    printf '%s\n' "$output" | grep -Fq "$CELEOS_USRP_DPDK_USRP_IP" && return 0
    [ -n "$CELEOS_USRP_DPDK_USRP_MGMT_IP" ] && printf '%s\n' "$output" | grep -Fq "$CELEOS_USRP_DPDK_USRP_MGMT_IP"
}

check_usrp_in_container() {
    local args=()
    local output
    local status=0
    local docker_cmd=()

    if ! command -v docker >/dev/null 2>&1; then
        echo "ERROR: docker is not installed or not in PATH; cannot check USRP discovery inside '$CONTAINER_NAME'."
        exit 1
    fi

    if [ -z "$(docker ps -q -f name=^${CONTAINER_NAME}$ 2>/dev/null)" ]; then
        echo "ERROR: CELEOS container '$CONTAINER_NAME' is not running."
        exit 1
    fi

    if [ "$usrp_dpdk" = "true" ]; then
        args=(--args "$(build_usrp_dpdk_uhd_args)")
    fi

    echo "Checking USRP discovery inside CELEOS container '$CONTAINER_NAME'..."
    docker_cmd=(sudo docker exec "$CONTAINER_NAME" timeout -k 5s 30s uhd_find_devices "${args[@]}")
    if [ "${#args[@]}" -gt 0 ]; then
        echo "+ sudo docker exec $CONTAINER_NAME timeout -k 5s 30s uhd_find_devices --args ${args[1]}"
    else
        echo "+ sudo docker exec $CONTAINER_NAME timeout -k 5s 30s uhd_find_devices"
    fi
    output="$("${docker_cmd[@]}" 2>&1)" || status=$?

    [ -n "$output" ] && echo "$output"

    if [ "$usrp_dpdk" = "true" ]; then
        if usrp_dpdk_discovery_output_matches "$output"; then
            echo "PASS: USRP $CELEOS_USRP_DPDK_USRP_IP is visible inside CELEOS container '$CONTAINER_NAME'."
            return
        fi
        if [ "$status" -ne 0 ]; then
            if printf '%s\n' "$output" | grep -Eq 'Cannot open /dev/vfio/[0-9]+: Device or resource busy|Failed to open VFIO group'; then
                echo "ERROR: The USRP DPDK VFIO device is busy. Stop any other UHD/DPDK process using the selected NIC, then rerun this check."
            fi
            echo "ERROR: USRP discovery failed inside CELEOS container '$CONTAINER_NAME'."
        else
            echo "ERROR: USRP discovery did not report $CELEOS_USRP_DPDK_USRP_IP inside CELEOS container '$CONTAINER_NAME'."
        fi
        exit 1
    fi

    if [ "$status" -ne 0 ]; then
        echo "ERROR: USRP discovery failed inside CELEOS container '$CONTAINER_NAME'."
        exit 1
    fi
    if printf '%s\n' "$output" | grep -Fq "No UHD Devices Found"; then
        echo "ERROR: USRP discovery did not report any UHD devices inside CELEOS container '$CONTAINER_NAME'."
        exit 1
    fi
    echo "PASS: uhd_find_devices completed inside CELEOS container '$CONTAINER_NAME'."
}

# Apply default values using parameter expansion
FOLDER_PATH="${persistent_folder:-/persistent_celeos}"
DEV_OPTIONS_PERSISTENT_PATH="$FOLDER_PATH/config/development_options.cfg"
version="${version}"
CONTAINER_NAME="${container_name:-celeos}"
BACKEND_PORT="${backend_port:-3001}"
FRONTEND_PORT="${frontend_port:-8000}"
GPU_DEVICE="${gpu_device:-}"
GPU_DOCKER_ARGS=()
if [ -n "$GPU_DEVICE" ] && [ "$GPU_DEVICE" != "none" ]; then
    GPU_DOCKER_ARGS=(--gpus "$GPU_DEVICE")
fi
GENERIC_HUGEPAGES="${CELEOS_GENERIC_HUGEPAGES:-128}"
CELEOS_USRP_DPDK_HUGEPAGES="${CELEOS_USRP_DPDK_HUGEPAGES:-${CELEOS_X300_DPDK_HUGEPAGES:-${HUGEPAGES:-512}}}"
CELEOS_USRP_DPDK_MTU="${CELEOS_USRP_DPDK_MTU:-${CELEOS_X300_DPDK_MTU:-9000}}"
CELEOS_USRP_DPDK_CORELIST="${CELEOS_USRP_DPDK_CORELIST:-${CELEOS_X300_DPDK_CORELIST:-4,5}}"
CELEOS_USRP_DPDK_NUM_MBUFS="${CELEOS_USRP_DPDK_NUM_MBUFS:-${CELEOS_X300_DPDK_NUM_MBUFS:-8192}}"
CELEOS_USRP_DPDK_MBUF_CACHE_SIZE="${CELEOS_USRP_DPDK_MBUF_CACHE_SIZE:-${CELEOS_X300_DPDK_MBUF_CACHE_SIZE:-64}}"
CELEOS_USRP_DPDK_DRIVER="${CELEOS_USRP_DPDK_DRIVER:-${CELEOS_X300_DPDK_DRIVER:-/usr/local/lib/uhd-dpdk-pmds}}"
CELEOS_USRP_DPDK_LOG_LEVEL="${CELEOS_USRP_DPDK_LOG_LEVEL:-${CELEOS_X300_DPDK_LOG_LEVEL:-lib.eal:info}}"
CELEOS_USRP_DPDK_MAC="${CELEOS_USRP_DPDK_MAC:-${CELEOS_X300_DPDK_MAC:-${DPDK_MAC:-}}}"
CELEOS_USRP_DPDK_LCORE="${CELEOS_USRP_DPDK_LCORE:-${CELEOS_X300_DPDK_LCORE:-5}}"
CELEOS_USRP_DPDK_HOST_IPV4="${CELEOS_USRP_DPDK_HOST_IPV4:-${CELEOS_X300_DPDK_HOST_IPV4:-${DPDK_IPV4:-}}}"
CELEOS_USRP_DPDK_USRP_IP="${CELEOS_USRP_DPDK_USRP_IP:-${CELEOS_X300_DPDK_USRP_IP:-${USRP_IP:-}}}"
CELEOS_USRP_DPDK_USRP_MGMT_IP="${CELEOS_USRP_DPDK_USRP_MGMT_IP:-${CELEOS_X300_DPDK_USRP_MGMT_IP:-${USRP_MGMT_IP:-}}}"
CELEOS_USRP_DPDK_USRP_TYPE="${CELEOS_USRP_DPDK_USRP_TYPE:-${CELEOS_X300_DPDK_USRP_TYPE:-${USRP_TYPE:-}}}"
CELEOS_USRP_DPDK_LINK_TIMEOUT="${CELEOS_USRP_DPDK_LINK_TIMEOUT:-${CELEOS_X300_DPDK_LINK_TIMEOUT:-8000}}"
CELEOS_USRP_DPDK_NUM_DESC="${CELEOS_USRP_DPDK_NUM_DESC:-${CELEOS_X300_DPDK_NUM_DESC:-4096}}"
USRP_DPDK_UHD_CONFIG_HOST="${CELEOS_USRP_DPDK_UHD_CONFIG_HOST:-${CELEOS_X300_DPDK_UHD_CONFIG_HOST:-$FOLDER_PATH/config/uhd-dpdk-network-usrp.conf}}"
HUGEPAGES_SYSCTL_VALUE="$GENERIC_HUGEPAGES"
if [ "$usrp_dpdk" = "true" ]; then
    HUGEPAGES_SYSCTL_VALUE="$CELEOS_USRP_DPDK_HUGEPAGES"
fi
validate_usrp_dpdk_config_values

# Set IMAGE_NAME - use custom image if provided, otherwise auto-detect based on platform
if [ -n "$image" ]; then
    # If custom image already contains a tag (has :), check for version conflict
    if [[ "$image" == *":"* ]]; then
        if [ -n "$version" ]; then
            echo "ERROR: --version provided, but --image already contains image tag"
            exit 1
        else
            IMAGE_NAME="$image"
        fi
    else
        IMAGE_NAME="$image:${version:-latest}"
    fi
elif [ -f /proc/device-tree/model ] && grep -qi jetson /proc/device-tree/model 2>/dev/null; then
    IMAGE_NAME="reg.lasting.space/celeos/celeos-release-jetson:${version:-latest}"
else
    IMAGE_NAME="reg.lasting.space/celeos/celeos-release:${version:-latest}"
fi
validate_usrp_dpdk_host_mode_alignment

echo -e "\n============= installation parameters ============="
echo "FOLDER_PATH:    $FOLDER_PATH"
echo "DEV_OPTIONS:    $DEV_OPTIONS_PERSISTENT_PATH"
echo "CONTAINER_NAME: $CONTAINER_NAME"
echo "IMAGE:          $IMAGE_NAME"
echo "BACKEND_PORT:   $BACKEND_PORT"
echo "FRONTEND_PORT:  $FRONTEND_PORT"
echo "GPU_DEVICE:     ${GPU_DEVICE:-Docker nvidia runtime default}"
echo "USRP_DPDK:      $usrp_dpdk"
if [ "$usrp_dpdk" = "true" ]; then
    echo "USRP_DPDK_UHD:  $USRP_DPDK_UHD_CONFIG_HOST"
    echo "USRP_DPDK_IP:   $CELEOS_USRP_DPDK_USRP_IP"
    if [ -n "$CELEOS_USRP_DPDK_USRP_MGMT_IP" ]; then
        echo "USRP_DPDK_MGMT: $CELEOS_USRP_DPDK_USRP_MGMT_IP"
    fi
    if [ -n "$CELEOS_USRP_DPDK_USRP_TYPE" ]; then
        echo "USRP_DPDK_TYPE: $CELEOS_USRP_DPDK_USRP_TYPE"
    fi
    if [ "$legacy_x300_dpdk" = "true" ]; then
        echo "LEGACY_X300_DPDK_ALIAS: true"
    fi
fi
echo -e "===================================================\n"

# Create the folder path if it doesn't exist
echo "Checking if the folder path exists..."
if [ ! -d "$FOLDER_PATH" ]; then
    echo "Folder path '$FOLDER_PATH' does not exist. Creating it now."
    mkdir -p "$FOLDER_PATH"
fi

check_docker_login() {
    local registry="$1"

    if docker-credential-$(docker system info --format '{{.SecurityOptions}}' | grep -o 'name=[^,]*' | cut -d= -f2 | head -1) list 2>/dev/null | grep -q "$registry" || \
       grep -q "$registry" ~/.docker/config.json 2>/dev/null || \
       sudo grep -q "$registry" /root/.docker/config.json 2>/dev/null; then
        return 0
    else
        return 1
    fi
}

prompt_docker_login() {
    local registry="$1"

    echo "========================================"
    echo "Docker Registry Authentication Required"
    echo "========================================"
    echo "You need to authenticate with the registry: $registry"
    echo "Please enter your credentials:"

    read -p "Username: " username
    read -s -p "Password: " password
    echo ""

    echo "Attempting to login to $registry..."
    if echo "$password" | sudo docker login "$registry" -u "$username" --password-stdin; then
        echo "Successfully logged into $registry"
        return 0
    else
        echo "Failed to login to $registry"
        echo "Please check your credentials and try again."
        return 1
    fi
}

ensure_persistent_development_options() {
    local source_file="$1"
    local container_name="$2"
    local source_dir
    local seed_container

    if [ -s "$source_file" ]; then
        echo "Persistent development options already exist at '$source_file'. Keeping existing contents."
        return
    fi

    source_dir="$(dirname "$source_file")"
    sudo mkdir -p "$source_dir"

    if [ -n "$(docker ps -a -q -f name=^${container_name}$)" ]; then
        echo "Creating persistent development options from existing container '$container_name'..."
        if sudo docker cp "${container_name}:/repo/config/development_options.cfg" "$source_file"; then
            return
        fi
        echo "WARNING: Failed to copy /repo/config/development_options.cfg from existing container '$container_name'. Falling back to image defaults."
    fi

    echo "Creating persistent development options from image defaults..."
    if ! seed_container="$(sudo docker create "$IMAGE_NAME")"; then
        echo "ERROR: Failed to create a temporary container from image '$IMAGE_NAME'."
        exit 1
    fi
    if ! sudo docker cp "${seed_container}:/repo/config/development_options.cfg" "$source_file"; then
        sudo docker rm "$seed_container" >/dev/null 2>&1 || true
        echo "ERROR: Failed to copy /repo/config/development_options.cfg from image '$IMAGE_NAME'."
        exit 1
    fi
    sudo docker rm "$seed_container" >/dev/null 2>&1 || true
}

render_usrp_dpdk_uhd_config() {
    cat <<EOF
[use_dpdk=1]
dpdk_mtu=${CELEOS_USRP_DPDK_MTU}
dpdk_corelist=${CELEOS_USRP_DPDK_CORELIST}
dpdk_num_mbufs=${CELEOS_USRP_DPDK_NUM_MBUFS}
dpdk_mbuf_cache_size=${CELEOS_USRP_DPDK_MBUF_CACHE_SIZE}
dpdk_driver=${CELEOS_USRP_DPDK_DRIVER}
dpdk_log_level=${CELEOS_USRP_DPDK_LOG_LEVEL}

[dpdk_mac=${CELEOS_USRP_DPDK_MAC}]
dpdk_lcore=${CELEOS_USRP_DPDK_LCORE}
dpdk_ipv4=${CELEOS_USRP_DPDK_HOST_IPV4}
dpdk_num_desc=${CELEOS_USRP_DPDK_NUM_DESC}
EOF
}

write_usrp_dpdk_uhd_config() {
    local target_file="$1"
    local target_dir
    target_dir="$(dirname "$target_file")"

    sudo mkdir -p "$target_dir"
    render_usrp_dpdk_uhd_config | sudo tee "$target_file" >/dev/null
    sudo chmod 0644 "$target_file"
    echo "Installed network USRP UHD DPDK config at '$target_file'."
}

prepare_usrp_dpdk_install() {
    local live_hugepages

    if [ "$usrp_dpdk" != "true" ]; then
        return
    fi

    echo "Preparing network USRP DPDK host runtime..."
    write_usrp_dpdk_uhd_config "$USRP_DPDK_UHD_CONFIG_HOST"

    if [ ! -x /usr/local/sbin/celeos-dpdk-setup ]; then
        echo "ERROR: --usrp-dpdk requires /usr/local/sbin/celeos-dpdk-setup on this host."
        echo "Install the persistent network USRP DPDK host setup before using this install mode."
        exit 1
    fi

    sudo /usr/local/sbin/celeos-dpdk-setup
    sudo sysctl vm.nr_hugepages="$HUGEPAGES_SYSCTL_VALUE" 2>/dev/null || true
    live_hugepages="$(cat /proc/sys/vm/nr_hugepages 2>/dev/null || true)"
    if [ "$live_hugepages" != "$HUGEPAGES_SYSCTL_VALUE" ]; then
        echo "ERROR: expected vm.nr_hugepages=$HUGEPAGES_SYSCTL_VALUE after network USRP DPDK setup, got '${live_hugepages:-unknown}'."
        exit 1
    fi

    if ! grep -Eq '^\[use_dpdk=1\]|^use_dpdk=1$' "$USRP_DPDK_UHD_CONFIG_HOST"; then
        echo "ERROR: generated network USRP UHD config is missing use_dpdk=1: $USRP_DPDK_UHD_CONFIG_HOST"
        exit 1
    fi
}

install_usrp_dpdk_uhd_config_in_container() {
    if [ "$usrp_dpdk" != "true" ]; then
        return
    fi

    echo "Installing network USRP UHD DPDK config into container runtime lookup paths..."
    if ! sudo docker exec "$CONTAINER_NAME" test -s /etc/uhd/uhd.conf 2>/dev/null; then
        echo "Container /etc/uhd/uhd.conf is missing; copying generated network USRP UHD config into container."
        sudo docker exec "$CONTAINER_NAME" mkdir -p /etc/uhd
        sudo docker cp "$USRP_DPDK_UHD_CONFIG_HOST" "$CONTAINER_NAME:/etc/uhd/uhd.conf"
    fi
    sudo docker exec "$CONTAINER_NAME" bash -lc '
set -eu
test -s /etc/uhd/uhd.conf
grep -Eq "^\[use_dpdk=1\]|^use_dpdk=1$" /etc/uhd/uhd.conf
mkdir -p /root/.config/uhd /root/.uhd
cp /etc/uhd/uhd.conf /root/.config/uhd.conf
cp /etc/uhd/uhd.conf /root/.config/uhd/uhd.conf
cp /etc/uhd/uhd.conf /root/.uhd/uhd.conf
for config_file in /etc/uhd/uhd.conf /root/.config/uhd.conf /root/.config/uhd/uhd.conf /root/.uhd/uhd.conf; do
    echo "--- ${config_file}"
    grep -nE "use_dpdk|dpdk_|\[dpdk_mac" "${config_file}"
done
'
}

install_usrp_dpdk_iova_pa_preload_in_container() {
    if [ "$usrp_dpdk" != "true" ]; then
        return
    fi

    echo "Installing DPDK EAL IOVA PA preload shim for network USRP DPDK..."
    sudo docker exec "$CONTAINER_NAME" bash -lc '
set -eu
command -v gcc >/dev/null || {
    echo "ERROR: gcc is required in the CELEOS container to build /usr/local/lib/celeos-rte-iova-pa.so."
    exit 1
}
mkdir -p /usr/local/src /usr/local/lib
'
    sudo docker exec -i "$CONTAINER_NAME" tee /usr/local/src/celeos-rte-iova-pa.c >/dev/null <<'EOF'
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int (*rte_eal_init_fn)(int argc, char **argv);

int rte_eal_init(int argc, char **argv)
{
    static rte_eal_init_fn real_rte_eal_init = NULL;
    if (real_rte_eal_init == NULL) {
        real_rte_eal_init = (rte_eal_init_fn)dlsym(RTLD_NEXT, "rte_eal_init");
        if (real_rte_eal_init == NULL) {
            fprintf(stderr, "celeos-rte-iova-pa: dlsym rte_eal_init failed: %s\n", dlerror());
            return -1;
        }
    }

    for (int i = 0; i < argc; ++i) {
        if (argv[i] != NULL && strcmp(argv[i], "--iova-mode") == 0) {
            return real_rte_eal_init(argc, argv);
        }
    }

    char **patched_argv = (char **)calloc((size_t)argc + 3U, sizeof(char *));
    if (patched_argv == NULL) {
        fprintf(stderr, "celeos-rte-iova-pa: argv allocation failed\n");
        return real_rte_eal_init(argc, argv);
    }

    for (int i = 0; i < argc; ++i) {
        patched_argv[i] = argv[i];
    }
    patched_argv[argc] = "--iova-mode";
    patched_argv[argc + 1] = "pa";
    patched_argv[argc + 2] = NULL;

    fprintf(stderr, "celeos-rte-iova-pa: forcing DPDK EAL --iova-mode pa\n");
    int ret = real_rte_eal_init(argc + 2, patched_argv);
    free(patched_argv);
    return ret;
}
EOF
    sudo docker exec "$CONTAINER_NAME" gcc -shared -fPIC -O2 -Wall -Wextra -o /usr/local/lib/celeos-rte-iova-pa.so /usr/local/src/celeos-rte-iova-pa.c -ldl
    sudo docker exec "$CONTAINER_NAME" test -x /usr/local/lib/celeos-rte-iova-pa.so
}

install_usrp_dpdk_init_usrp_aslr_wrapper_in_container() {
    if [ "$usrp_dpdk" != "true" ]; then
        return
    fi

    if sudo docker exec "$CONTAINER_NAME" grep -q "CELEOS_INIT_USRP_DPDK_IOVA_PA" /repo/web_api/control/device.js 2>/dev/null; then
        echo "Container API supports CELEOS_INIT_USRP_DPDK_IOVA_PA; no legacy init_usrp wrapper needed."
        return
    fi

    echo "Installing legacy init_usrp ASLR/IOVA wrapper for network USRP DPDK..."
    sudo docker exec "$CONTAINER_NAME" bash -lc 'test -x /usr/bin/taskset && test -x /usr/bin/setarch'
    sudo docker exec -i "$CONTAINER_NAME" tee /usr/local/sbin/taskset >/dev/null <<'EOF'
#!/usr/bin/env bash
set -e

for arg in "$@"; do
    if [ "$arg" = "/repo/processing/build/init_usrp" ]; then
        arch="$(uname -m)"
        export LD_PRELOAD="/usr/local/lib/celeos-rte-iova-pa.so${LD_PRELOAD:+:$LD_PRELOAD}"
        exec /usr/bin/setarch "$arch" -R /usr/bin/taskset "$@"
    fi
done

exec /usr/bin/taskset "$@"
EOF
    sudo docker exec "$CONTAINER_NAME" chmod 0755 /usr/local/sbin/taskset
    sudo docker exec "$CONTAINER_NAME" bash -lc 'mkdir -p /usr/local/bin && ln -sf /usr/local/sbin/taskset /usr/local/bin/taskset'
    sudo docker exec "$CONTAINER_NAME" bash -lc '
set -eu
resolved="$(PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin command -v taskset)"
if [ "$resolved" != "/usr/local/sbin/taskset" ]; then
    echo "ERROR: expected taskset wrapper at /usr/local/sbin/taskset, got ${resolved:-not found}."
    exit 1
fi
taskset --help >/dev/null
'
}

patch_usrp_dpdk_sdr_args_in_container() {
    if [ "$usrp_dpdk" != "true" ]; then
        return
    fi

    echo "Installing network USRP DPDK SDR args into container config..."
    sudo docker exec -i \
        -e CELEOS_USRP_DPDK_USRP_IP="$CELEOS_USRP_DPDK_USRP_IP" \
        -e CELEOS_USRP_DPDK_USRP_MGMT_IP="$CELEOS_USRP_DPDK_USRP_MGMT_IP" \
        -e CELEOS_USRP_DPDK_USRP_TYPE="$CELEOS_USRP_DPDK_USRP_TYPE" \
        -e CELEOS_USRP_DPDK_LINK_TIMEOUT="$CELEOS_USRP_DPDK_LINK_TIMEOUT" \
        "$CONTAINER_NAME" bash -s <<'EOF'
set -eu
device_type="${CELEOS_USRP_DPDK_USRP_TYPE:-x300}"
desired_args="args = type=${device_type}"
if [ -n "${CELEOS_USRP_DPDK_USRP_MGMT_IP:-}" ]; then
    desired_args="${desired_args},mgmt_addr=${CELEOS_USRP_DPDK_USRP_MGMT_IP}"
fi
desired_args="${desired_args},addr=${CELEOS_USRP_DPDK_USRP_IP},use_dpdk=1,dpdk_link_timeout=${CELEOS_USRP_DPDK_LINK_TIMEOUT}"
config_files=""
add_config_file() {
    case " $config_files " in
        *" $1 "*) return ;;
    esac
    config_files="${config_files}${config_files:+ }$1"
}

if [ -r /repo/web_api/configs/model.json ] && command -v python3 >/dev/null 2>&1; then
    model_config_files="$(python3 -c '
import json
import re
from pathlib import Path

path = Path("/repo/web_api/configs/model.json")
try:
    model = json.loads(path.read_text())
except Exception:
    raise SystemExit(0)

for usrp in model.get("connected_usrps", []):
    name = str(usrp.get("name", "")).strip().split("-", 1)[0]
    if re.fullmatch(r"[A-Za-z0-9_]+", name or ""):
        print(f"/repo/config/{name}/sdr.cfg")
')"
    if [ -n "$model_config_files" ]; then
        while IFS= read -r model_config_file; do
            [ -n "$model_config_file" ] && add_config_file "$model_config_file"
        done <<MODEL_CONFIGS
$model_config_files
MODEL_CONFIGS
    fi
fi
case "$device_type" in
    x4xx) add_config_file "/repo/config/x440/sdr.cfg" ;;
    "")
        ;;
    *)
        if printf '%s' "$device_type" | grep -Eq '^[A-Za-z0-9_]+$'; then
            add_config_file "/repo/config/${device_type}/sdr.cfg"
        fi
        ;;
esac
add_config_file "/repo/config/x300/sdr.cfg"
add_config_file "/repo/config/_runtime_sdr_configs/sdr_0.cfg"

for config_file in $config_files; do
    [ -f "$config_file" ] || continue
    tmp_file="${config_file}.tmp.$$"
    awk -v desired_args="$desired_args" '
        /^[[:space:]]*args[[:space:]]*=/ && replaced == 0 {
            print desired_args
            replaced = 1
            next
        }
        { print }
        END {
            if (replaced == 0) {
                print desired_args
            }
        }
    ' "$config_file" > "$tmp_file"
    mv "$tmp_file" "$config_file"
    echo "--- ${config_file}"
    grep -nE "^[[:space:]]*args[[:space:]]*=" "$config_file"
done
EOF
}

if [ "$check_usrp_explicit" = "true" ] && command -v docker >/dev/null 2>&1 && [ -n "$(docker ps -q -f name=^${CONTAINER_NAME}$ 2>/dev/null)" ]; then
    if [ "$usrp_dpdk" = "true" ]; then
        write_usrp_dpdk_uhd_config "$USRP_DPDK_UHD_CONFIG_HOST"
        install_usrp_dpdk_uhd_config_in_container
        install_usrp_dpdk_iova_pa_preload_in_container
        install_usrp_dpdk_init_usrp_aslr_wrapper_in_container
        patch_usrp_dpdk_sdr_args_in_container
    fi
    check_usrp_in_container
    exit 0
fi

# Check if Docker is already installed
if command -v docker >/dev/null 2>&1; then
    echo "Docker is already installed. Version: $(docker --version)"
    echo "Skipping Docker installation..."
else
    echo "Docker not found. Installing Docker..."

    # Update and install prerequisites
    echo "Updating and installing prerequisites..."
    sudo apt-get update
    sudo apt-get install -y \
        apt-transport-https \
        ca-certificates \
        curl \
        gnupg \
        lsb-release \
        cgroup-tools

    # Add Docker's official GPG key
    echo "Adding Docker's official GPG key..."
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor --yes -o /usr/share/keyrings/docker-archive-keyring.gpg

    # Add Docker APT repository
    echo "Adding Docker APT repository..."
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
      $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

    # Install Docker
    echo "Installing Docker..."
    sudo apt-get update
    sudo apt-get install -y docker-ce docker-ce-cli containerd.io

    echo "Docker installation completed."
fi

# Check if Docker group exists, if not, create it
echo "Checking if Docker group exists..."
if ! getent group docker > /dev/null; then
    echo "Creating Docker group..."
    sudo groupadd docker
fi

# Add the current user to the Docker group
echo "Adding the current user to the Docker group..."
sudo usermod -aG docker $USER

# Check Docker service status
echo "Checking Docker service status..."
if ! sudo systemctl is-active --quiet docker; then
    echo "Docker service failed to start. Checking logs..."
    sudo systemctl status docker
    sudo journalctl -u docker.service
    exit 1
fi

# Only check Docker registry authentication if image is from reg.lasting.space
if [[ "$IMAGE_NAME" == reg.lasting.space* ]]; then
    REGISTRY_URL="reg.lasting.space"
    echo "Checking Docker registry authentication..."
    if ! check_docker_login "$REGISTRY_URL"; then
        echo "Not authenticated with registry: $REGISTRY_URL"

        login_attempts=0
        max_attempts=3

        while [ $login_attempts -lt $max_attempts ]; do
            if prompt_docker_login "$REGISTRY_URL"; then
                break
            else
                login_attempts=$((login_attempts + 1))
                if [ $login_attempts -lt $max_attempts ]; then
                    echo "Login attempt $login_attempts failed. $((max_attempts - login_attempts)) attempts remaining."
                    echo ""
                else
                    echo "Maximum login attempts exceeded. Exiting."
                    exit 1
                fi
            fi
        done
    else
        echo "Already authenticated with registry: $REGISTRY_URL"
    fi
else
    echo "Using local image, skipping registry authentication..."
fi

DOCKER_RESTART_NEEDED=false

# Install the NVIDIA Container Toolkit
if ! dpkg -l | grep -q nvidia-container-toolkit; then
    echo "Setting up the NVIDIA Container Toolkit repository..."
    curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor --yes -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg \
      && curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
        sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
        sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
    echo "Updating the package list from the repository..."
    sudo apt-get update
    echo "Installing the NVIDIA Container Toolkit..."
    sudo apt-get install -y nvidia-container-toolkit
else
    echo "NVIDIA Container Toolkit already installed, skipping..."
fi

# Function to add or replace a configuration
add_or_replace_sysctl_conf() {
  local key="$1"
  local value="$2"
  local file="/etc/sysctl.conf"

  # If the key exists, replace its value. Otherwise, append the key-value pair.
  if grep -q "^${key}=" "${file}"; then
    sudo sed -i "s|^${key}=.*|${key}=${value}|" "${file}"
  else
    echo "${key}=${value}" | sudo tee -a "${file}"
  fi
}

# Apply system configurations
echo "Applying system configurations..."

add_or_replace_sysctl_conf "net.core.somaxconn" "1024"
add_or_replace_sysctl_conf "net.ipv4.tcp_tw_reuse" "1"
add_or_replace_sysctl_conf "net.core.wmem_max" "500000000"
add_or_replace_sysctl_conf "net.core.rmem_max" "500000000"
add_or_replace_sysctl_conf "vm.nr_hugepages" "$HUGEPAGES_SYSCTL_VALUE"

# Function to add or replace a limit configuration
add_or_replace_limit_conf() {
  local key="$1"
  local type="$2"
  local value="$3"
  local file="/etc/security/limits.d/99-custom-limits.conf"

  # Check if the key and type exist and replace the value, otherwise append the key-type-value pair.
  if grep -q "^${key} ${type} " "${file}"; then
    sudo sed -i "s|^${key} ${type} .*|${key} ${type} ${value}|" "${file}"
  else
    echo "${key} ${type} ${value}" | sudo tee -a "${file}"
  fi
}

# Apply limit configurations
echo "Applying limit configurations..."

add_or_replace_limit_conf "*" "soft nofile" "1048576"
add_or_replace_limit_conf "*" "hard nofile" "1048576"
add_or_replace_limit_conf "*" "soft nproc" "4194304"
add_or_replace_limit_conf "*" "hard nproc" "4194304"

echo "Limit configurations applied successfully."

# Apply sysctl configurations
echo "Applying sysctl configurations..."
if sudo sysctl -p 2>/dev/null; then
  echo "System configurations applied successfully."
else
  echo "Some system configurations could not be applied, but continuing installation..."
  echo "This is typically not critical for Docker container operation."
  # Apply only the configurations we set, ignoring others
  sudo sysctl net.core.somaxconn=1024 2>/dev/null || true
  sudo sysctl net.ipv4.tcp_tw_reuse=1 2>/dev/null || true
  sudo sysctl net.core.wmem_max=500000000 2>/dev/null || true
  sudo sysctl net.core.rmem_max=500000000 2>/dev/null || true
  sudo sysctl vm.nr_hugepages="$HUGEPAGES_SYSCTL_VALUE" 2>/dev/null || true
fi

# Only rewrite daemon.json if Docker isn't already set up with the nvidia runtime.
# Checks: toolkit package installed AND Docker's live default runtime is "nvidia".
echo "Checking Docker nvidia runtime configuration..."
if dpkg -l | grep -q nvidia-container-toolkit && \
   [ "$(docker info --format '{{.DefaultRuntime}}' 2>/dev/null)" = "nvidia" ]; then
    echo "Docker already configured with nvidia runtime. Skipping daemon.json rewrite and restart."
else
    echo "Overwriting Docker daemon.json configuration..."
    sudo tee /etc/docker/daemon.json <<EOF
{
  "storage-driver": "overlay2",
  "default-runtime": "nvidia",
  "runtimes":
  {
    "nvidia":
    {
      "path": "/usr/bin/nvidia-container-runtime",
      "runtimeArgs": []
    }
  }
}
EOF
    DOCKER_RESTART_NEEDED=true
fi

# Restart Docker only if configuration changed
if [ "$DOCKER_RESTART_NEEDED" = true ]; then
    RUNNING_COUNT=$(docker ps -q 2>/dev/null | wc -l)
    if [ "$RUNNING_COUNT" -gt 0 ]; then
        echo ""
        echo "WARNING: $RUNNING_COUNT other container(s) are currently running."
        echo "Restarting Docker will briefly interrupt ALL running containers."
        echo "Containers with a restart policy will recover automatically."
        read -p "Proceed with Docker restart? [Y/n] " confirm
        if [[ "$confirm" =~ ^[Nn] ]]; then
            echo "Skipping Docker restart. You will need to restart Docker manually later:"
            echo "  sudo systemctl restart docker"
        else
            echo "Restarting Docker to apply configuration changes..."
            sudo systemctl restart docker
        fi
    else
        echo "Restarting Docker to apply configuration changes..."
        sudo systemctl restart docker
    fi
else
    echo "No Docker configuration changes needed, skipping restart."
fi

# Check Docker service status
echo "Checking Docker service status..."
if ! sudo systemctl is-active --quiet docker; then
    echo "Docker service failed to start after configuration changes. Checking logs..."
    sudo systemctl status docker
    sudo journalctl -u docker.service
    exit 1
fi

# Pull the image only if it's from reg.lasting.space registry
if [[ "$IMAGE_NAME" == reg.lasting.space* ]]; then
    echo "Pulling Docker image from registry..."
    sudo docker pull "$IMAGE_NAME"
    if [ $? -ne 0 ]; then
        echo "Failed to pull Docker image '$IMAGE_NAME' from registry."
        echo "Please check your registry credentials and network connectivity."
        exit 1
    fi
else
    echo "Using local Docker image '$IMAGE_NAME' (not pulling from registry)..."
    # Verify the local image exists
    if ! docker image inspect "$IMAGE_NAME" >/dev/null 2>&1; then
        echo "ERROR: Local image '$IMAGE_NAME' not found."
        echo "Please build or pull the image first, or specify a registry image starting with 'reg.lasting.space'."
        exit 1
    fi
fi

# Get the number of available CPUs
NUM_CPUS=$(nproc --all)
CPUS="0-$((NUM_CPUS-1))"

# Get the total system memory in GB, rounded down
TOTAL_MEM_MB=$(free -m | awk '/^Mem:/{print $2}')
TOTAL_MEM_GB=$((TOTAL_MEM_MB / 1024))
MEMORY="${TOTAL_MEM_GB}g"

# development_options.cfg is always persistent so local tuning survives upgrades.
ensure_persistent_development_options "$DEV_OPTIONS_PERSISTENT_PATH" "$CONTAINER_NAME"
DEV_OPTIONS_MOUNT_OPTION="--mount type=bind,source=$DEV_OPTIONS_PERSISTENT_PATH,target=/repo/config/development_options.cfg"

# Check if the container is running
if [ "$(docker ps -a -q -f name=^${CONTAINER_NAME}$)" ]; then
    echo "Stopping and removing the container '$CONTAINER_NAME'..."
    docker stop $CONTAINER_NAME
    docker rm $CONTAINER_NAME
else
    echo "Container '$CONTAINER_NAME' is not running."
fi

prepare_usrp_dpdk_install

# Run the Docker container with the specified settings
echo "Running the Docker container with the specified settings..."

# Prepare config directory mount option based on disable_persistent_configs flag
if [ "$disable_persistent_configs" = "true" ]; then
    MOUNT_OPTION=""
else
    MOUNT_OPTION="--mount type=bind,source=$FOLDER_PATH,target=/repo/web_api/configs/"
fi

USRP_DPDK_MOUNT_OPTION=""
USRP_DPDK_ENV_OPTIONS=""
if [ "$usrp_dpdk" = "true" ]; then
    USRP_DPDK_MOUNT_OPTION="--mount type=bind,source=$USRP_DPDK_UHD_CONFIG_HOST,target=/etc/uhd/uhd.conf,readonly"
    USRP_DPDK_ENV_OPTIONS="-e CELEOS_REQUIRE_USRP_DPDK=1 -e CELEOS_FORCE_UHD_DPDK=1 -e CELEOS_UHD_CPU_FORMAT=sc16 -e CELEOS_SDR_BENCHMARK_BRIDGE=1 -e CELEOS_SDR_BENCHMARK_CUDA_KERNEL=1 -e CELEOS_SDR_BENCHMARK_CUDA_KERNEL_MODE=legacy_add_delay -e CELEOS_INIT_USRP_PROCESS_RT=1 -e CELEOS_INIT_USRP_DISABLE_ASLR=1 -e CELEOS_INIT_USRP_DPDK_IOVA_PA=1 -e CELEOS_RTE_IOVA_PA_PRELOAD=/usr/local/lib/celeos-rte-iova-pa.so -e CELEOS_RT_PRIORITY=80 -e UHD_CONFIG_FILE=/etc/uhd/uhd.conf"
    if [ "$legacy_x300_dpdk" = "true" ]; then
        USRP_DPDK_ENV_OPTIONS="$USRP_DPDK_ENV_OPTIONS -e CELEOS_REQUIRE_X300_DPDK=1"
    fi
fi

if ! container_id="$(sudo docker run -d $MOUNT_OPTION $DEV_OPTIONS_MOUNT_OPTION $USRP_DPDK_MOUNT_OPTION \
           --restart unless-stopped \
           -v /dev:/dev \
           --ulimit nofile=1048576:1048576 \
           --ulimit nproc=4194304:4194304 \
           --cpuset-cpus="$CPUS" \
           --memory="$MEMORY" \
           --memory-swap="$MEMORY" \
           --privileged \
           "${GPU_DOCKER_ARGS[@]}" \
           --network host \
           -v /etc/localtime:/etc/localtime:ro \
           -v /etc/timezone:/etc/timezone:ro \
           $USRP_DPDK_ENV_OPTIONS \
           -e BACKEND_PORT="$BACKEND_PORT" \
           -e FRONTEND_PORT="$FRONTEND_PORT" \
            --name "$CONTAINER_NAME" \
           "$IMAGE_NAME" 2>&1)"; then
    [ -n "$container_id" ] && echo "$container_id"
    echo "ERROR: Failed to start CELEOS container '$CONTAINER_NAME' from image '$IMAGE_NAME'."
    exit 1
fi
echo "$container_id"

if ! sudo docker inspect -f '{{.State.Running}}' "$CONTAINER_NAME" 2>/dev/null | grep -qx true; then
    echo "ERROR: CELEOS container '$CONTAINER_NAME' was created but is not running."
    sudo docker ps -a -f "name=^${CONTAINER_NAME}$" --format '  {{.ID}} {{.Names}} {{.Status}}' 2>/dev/null || true
    exit 1
fi

install_usrp_dpdk_uhd_config_in_container
install_usrp_dpdk_iova_pa_preload_in_container
install_usrp_dpdk_init_usrp_aslr_wrapper_in_container
patch_usrp_dpdk_sdr_args_in_container

if [ "$check_usrp" = "true" ]; then
    check_usrp_in_container
    exit 0
fi

echo "Installation, configuration, and container run from image '$IMAGE_NAME' complete."
