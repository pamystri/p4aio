'use client';

import { useEffect, useState } from 'react';
import { Alert, Button, Card, CardContent, Divider, FormControlLabel, Grid, Stack, Switch, TextField, Typography } from '@mui/material';
import SaveRounded from '@mui/icons-material/SaveRounded';
import { PageHeader } from '@/components/common/page-header';
import { apiBaseUrl, apiKey } from '@/core/api/client';
import { useLive } from '@/core/live/live-context';

export function SettingsView() {
  const [url, setUrl] = useState(''); const [key, setKey] = useState(''); const [saved, setSaved] = useState(false); const { autoRefresh, setAutoRefresh } = useLive();
  useEffect(() => { setUrl(apiBaseUrl()); setKey(apiKey()); }, []);
  const save = () => { localStorage.setItem('monitor.apiUrl', url.replace(/\/$/, '')); if (key) localStorage.setItem('monitor.apiKey', key); else localStorage.removeItem('monitor.apiKey'); setSaved(true); window.setTimeout(() => location.reload(), 600); };
  return <><PageHeader eyebrow="Local preferences" title="Settings" description="Configure this browser's connection to the locally hosted monitoring service." /><Grid container spacing={2}><Grid size={{ xs: 12, lg: 7 }}><Card><CardContent><Typography variant="h2">Backend connection</Typography><Typography variant="body2" color="text.secondary" mt={.5}>Values are stored only in this browser. Credentials are never included in exports.</Typography><Stack spacing={2} mt={2.5}><TextField label="REST API URL" value={url} onChange={(event) => setUrl(event.target.value)} placeholder="http://monitor.local/api/v1" fullWidth helperText="Use the local reverse-proxy URL in production." /><TextField label="API key" value={key} onChange={(event) => setKey(event.target.value)} type="password" fullWidth autoComplete="off" helperText="Leave empty when backend authentication is disabled." />{saved && <Alert severity="success">Saved. Reconnecting to the local service…</Alert>}<Button variant="contained" startIcon={<SaveRounded />} onClick={save} sx={{ alignSelf: 'flex-start' }}>Save and reconnect</Button></Stack></CardContent></Card></Grid><Grid size={{ xs: 12, lg: 5 }}><Card><CardContent><Typography variant="h2">Display and refresh</Typography><Divider sx={{ my: 2 }} /><FormControlLabel control={<Switch checked={autoRefresh} onChange={(_, checked) => setAutoRefresh(checked)} />} label="Automatically refresh operational data" /><Typography variant="caption" color="text.secondary" display="block" mt={1}>Live WebSocket notifications trigger immediate refreshes. The timer provides resilience if the live connection is interrupted.</Typography></CardContent></Card></Grid></Grid></>;
}
