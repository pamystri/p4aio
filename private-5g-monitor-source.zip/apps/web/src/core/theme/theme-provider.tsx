'use client';

import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { alpha, createTheme, CssBaseline, ThemeProvider } from '@mui/material';

type ThemeMode = 'light' | 'dark';
const ModeContext = createContext<{ mode: ThemeMode; toggle: () => void } | null>(null);

export function MonitorThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<ThemeMode>('dark');
  useEffect(() => { setMode((localStorage.getItem('monitor.theme') as ThemeMode | null) ?? 'dark'); }, []);
  const toggle = () => setMode((current) => { const next = current === 'dark' ? 'light' : 'dark'; localStorage.setItem('monitor.theme', next); return next; });
  const theme = useMemo(() => createTheme({
    palette: {
      mode,
      primary: { main: '#20bad8', light: '#77dff2', dark: '#087f9b' },
      secondary: { main: '#8b78f6' },
      success: { main: '#29c485' }, warning: { main: '#f5aa46' }, error: { main: '#ef5b72' },
      background: mode === 'dark' ? { default: '#07111f', paper: '#0d1a2b' } : { default: '#f3f6fa', paper: '#ffffff' },
      divider: mode === 'dark' ? 'rgba(142,174,207,.14)' : 'rgba(21,50,78,.12)',
    },
    typography: {
      fontFamily: 'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      h1: { fontSize: '1.75rem', fontWeight: 760, letterSpacing: '-0.035em' },
      h2: { fontSize: '1.15rem', fontWeight: 700 },
      button: { textTransform: 'none', fontWeight: 650 },
      overline: { fontWeight: 700, letterSpacing: '.1em' },
    },
    shape: { borderRadius: 12 },
    components: {
      MuiCard: { styleOverrides: { root: { backgroundImage: 'none', border: `1px solid ${mode === 'dark' ? 'rgba(142,174,207,.13)' : 'rgba(21,50,78,.1)'}`, boxShadow: mode === 'dark' ? '0 16px 50px rgba(0,0,0,.14)' : '0 12px 36px rgba(34,65,96,.07)' } } },
      MuiPaper: { styleOverrides: { root: { backgroundImage: 'none' } } },
      MuiButton: { styleOverrides: { root: { borderRadius: 9 } } },
      MuiChip: { styleOverrides: { root: { fontWeight: 650 } } },
      MuiTableCell: { styleOverrides: { root: { borderColor: mode === 'dark' ? 'rgba(142,174,207,.1)' : 'rgba(21,50,78,.09)' }, head: { fontSize: '.72rem', textTransform: 'uppercase', letterSpacing: '.07em', color: mode === 'dark' ? '#8da6be' : '#60758a', fontWeight: 750 } } },
      MuiTooltip: { styleOverrides: { tooltip: { background: alpha(mode === 'dark' ? '#18304a' : '#102a43', .96), fontSize: '.75rem' } } },
    },
  }), [mode]);
  return <ModeContext.Provider value={{ mode, toggle }}><ThemeProvider theme={theme}><CssBaseline />{children}</ThemeProvider></ModeContext.Provider>;
}

export function useThemeMode() {
  const context = useContext(ModeContext);
  if (!context) throw new Error('useThemeMode must be used in MonitorThemeProvider');
  return context;
}
