'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from './client';
import { useLive } from '@/core/live/live-context';

export function useApi<T>(path: string | null) {
  const { generation } = useLive();
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(Boolean(path));
  useEffect(() => {
    if (!path) { setLoading(false); return; }
    const controller = new AbortController(); setLoading(true);
    void apiFetch<T>(path, controller.signal).then((value) => { setData(value); setError(null); }).catch((reason: unknown) => { if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Unable to load data'); }).finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [path, generation]);
  return { data, error, loading };
}
