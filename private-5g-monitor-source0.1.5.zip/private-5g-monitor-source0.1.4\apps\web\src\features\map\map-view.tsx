'use client';

import dynamic from 'next/dynamic';
import { Box, Card, Chip, Grid, Stack, Typography } from '@mui/material';
import { PageHeader } from '@/components/common/page-header';
import { StatePanel } from '@/components/common/state-panel';
import { StatusBadge } from '@/components/common/status-badge';
import { useApi } from '@/core/api/use-api';
import type { CollectorStatus, LocationEstimate, Metric, Page, RadioTarget, Site } from '@/core/api/types';
const NetworkMap = dynamic(() => import('./network-map').then((module) => module.NetworkMap), { ssr: false });

export function MapView() {
  const sites = useApi<Page<Site>>('/sites?limit=100'); const locations = useApi<LocationEstimate[]>('/locations/current'); const collectors = useApi<CollectorStatus[]>('/collectors/status'); const targets = useApi<RadioTarget[]>('/radio-targets'); const metrics = useApi<Page<Metric>>('/metrics/current?limit=1000');
  const error = sites.error ?? locations.error ?? collectors.error ?? targets.error ?? metrics.error; const loading = sites.loading || locations.loading || collectors.loading || targets.loading || metrics.loading;
  return <><PageHeader eyebrow="Location intelligence" title="Network map" description="Configured sites and algorithm-neutral UE position estimates with confidence and serving-cell context." actions={<Chip variant="outlined" color="secondary" label={`${locations.data?.length ?? 0} estimated UEs`} />} /><Grid container spacing={2}><Grid size={{ xs: 12, xl: 9 }}><Card sx={{ overflow: 'hidden' }}><StatePanel loading={loading} error={error}><Box sx={{ height: { xs: 520, lg: 680 } }}><NetworkMap sites={sites.data?.items ?? []} locations={locations.data ?? []} collectors={collectors.data ?? []} targets={targets.data ?? []} metrics={metrics.data?.items ?? []} /></Box></StatePanel></Card></Grid><Grid size={{ xs: 12, xl: 3 }}><Card sx={{ p: 2, height: '100%' }}><Typography variant="h2">Position estimates</Typography><Typography variant="caption" color="text.secondary">Latest location per UE</Typography><Stack spacing={1.1} sx={{ mt: 2, maxHeight: 610, overflow: "auto" }}>{locations.data?.map((location) => <Box key={location.id} sx={{ p: 1.25, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}><Stack direction="row" sx={{ justifyContent: "space-between" }}><Typography sx={{ fontFamily: "monospace", fontSize: 12, fontWeight: 750 }}>{location.pseudonym}</Typography><StatusBadge status={location.confidence !== null && location.confidence >= .7 ? 'high confidence' : 'estimated'} /></Stack><Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: .6 }}>{location.servingCellName ?? 'Serving cell unavailable'} · ±{Math.round(location.horizontalAccuracyM)} m</Typography><Typography variant="caption" color="text.secondary">{location.method} · {new Date(location.estimatedAt).toLocaleTimeString()}</Typography></Box>)}</Stack></Card></Grid></Grid></>;
}
