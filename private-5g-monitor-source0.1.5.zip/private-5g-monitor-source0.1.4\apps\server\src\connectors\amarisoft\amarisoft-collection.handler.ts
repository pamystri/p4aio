import { Inject, Injectable, OnModuleInit } from '@nestjs/common';
import { PinoLogger } from 'nestjs-pino';
import type { DuePollTask } from '@application/scheduler/poll-schedule.repository';
import {
  COLLECTION_REPOSITORY,
  type CollectionRepository,
} from '@application/collection/collection.repository';
import { SECRET_RESOLVER, type SecretResolver } from '@application/secrets/secret-resolver';
import type { PollTaskHandler } from '@app/scheduler/poll-task-handler.registry';
import { PollTaskHandlerRegistry } from '@app/scheduler/poll-task-handler.registry';
import { ConnectorRegistryService } from '@app/plugins/connector-registry.service';
import { LiveGateway } from '@app/live/live.gateway';
import { AmarisoftConnectorError } from '@amarisoft/amarisoft.errors';
import { LocationEstimationService } from '@app/location/location-estimation.service';

/** Bridges generic scheduled jobs to the registered Amarisoft connector. */
@Injectable()
export class AmarisoftCollectionHandler implements PollTaskHandler, OnModuleInit {
  readonly id = 'amarisoft-collector';
  private readonly operations = new Set(['ue_get', 'stats']);

  constructor(
    @Inject(COLLECTION_REPOSITORY) private readonly collections: CollectionRepository,
    @Inject(SECRET_RESOLVER) private readonly secrets: SecretResolver,
    private readonly handlers: PollTaskHandlerRegistry,
    private readonly connectors: ConnectorRegistryService,
    private readonly live: LiveGateway,
    private readonly locations: LocationEstimationService,
    private readonly logger: PinoLogger,
  ) {
    this.logger.setContext(AmarisoftCollectionHandler.name);
  }

  onModuleInit(): void {
    this.handlers.register(this);
  }

  supports(task: DuePollTask): boolean {
    return task.connectorKey === 'amarisoft' && this.operations.has(task.logicalOperation);
  }

  async execute(task: DuePollTask, signal: AbortSignal): Promise<void> {
    const target = await this.collections.getTarget(task.radioTargetId);
    if (!target) throw new Error(`Radio target ${task.radioTargetId} no longer exists`);
    const connector = this.connectors.resolve(target.connectorKey);
    if (connector.manifest.version !== target.connectorVersion) {
      throw new Error(
        `Target requires connector ${target.connectorKey}@${target.connectorVersion}, ` +
          `but ${connector.manifest.version} is loaded`,
      );
    }

    const runId = await this.collections.startRun(task, target);
    let session: Awaited<ReturnType<typeof connector.openSession>> | undefined;
    try {
      const credentials = await this.secrets.resolve(target.secretReference);
      session = await connector.openSession({
        targetId: target.id,
        host: target.host,
        port: target.port,
        configuration: target.configuration,
        secretReference: target.secretReference,
        credentials,
      });
      const envelope = await session.execute({
        collectionRunId: runId,
        logicalOperation: task.logicalOperation,
        deadline: new Date(Date.now() + task.timeoutMs),
        signal,
      });
      await this.collections.completeRun(runId, target, envelope);
      if (task.logicalOperation === 'ue_get') {
        try {
          await this.locations.estimateForTarget(target.id, envelope.observedAt);
        } catch (error) {
          this.logger.error(
            { targetId: target.id, collectionRunId: runId, err: error },
            'Location estimation failed after a committed collection run',
          );
        }
      }
      this.live.publish('collection.completed', {
        collectionRunId: runId,
        targetId: target.id,
        operation: task.logicalOperation,
        observedAt: envelope.observedAt.toISOString(),
        observationCount: envelope.observations.length,
        eventCount: envelope.events.length,
        warningCount: envelope.warnings.length,
      });
      this.live.publish('metrics.updated', {
        collectionRunId: runId,
        targetId: target.id,
        observedAt: envelope.observedAt.toISOString(),
        metricCount: envelope.observations.length,
      });
      if (envelope.events.length > 0) {
        this.live.publish('alarms.updated', {
          collectionRunId: runId,
          targetId: target.id,
          eventCount: envelope.events.length,
        });
      }
      this.logger.info(
        {
          collectionRunId: runId,
          targetId: target.id,
          operation: task.logicalOperation,
          observationCount: envelope.observations.length,
          eventCount: envelope.events.length,
        },
        'Amarisoft poll committed',
      );
    } catch (error) {
      const failure = this.failure(error);
      await this.collections.failRun(runId, failure);
      this.live.publish('collection.completed', {
        collectionRunId: runId,
        targetId: target.id,
        operation: task.logicalOperation,
        status: 'failed',
      });
      this.live.publish('alarms.updated', {
        collectionRunId: runId,
        targetId: target.id,
        eventCount: 1,
      });
      throw error;
    } finally {
      await session?.close();
    }
  }

  private failure(error: unknown): { category: string; code: string; message: string } {
    if (error instanceof AmarisoftConnectorError) {
      return {
        category: error.category,
        code: error.name,
        message: error.message,
      };
    }
    return {
      category: 'internal',
      code: error instanceof Error ? error.name : 'UnknownError',
      message: error instanceof Error ? error.message : 'Unknown collection failure',
    };
  }
}
