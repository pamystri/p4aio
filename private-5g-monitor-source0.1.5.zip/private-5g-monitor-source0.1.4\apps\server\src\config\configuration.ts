import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { load } from 'js-yaml';
import { z } from 'zod';

const configurationSchema = z
  .object({
    application: z.object({
      name: z.string().min(1),
      environment: z.enum(['development', 'test', 'production']),
    }),
    server: z.object({
      host: z.string().min(1),
      port: z.coerce.number().int().min(1).max(65535),
      globalPrefix: z.string().min(1),
      corsOrigins: z.array(z.string().url()),
      shutdownGraceMs: z.coerce.number().int().positive(),
    }),
    database: z.object({
      url: z.string().min(1).startsWith('postgresql://'),
    }),
    logging: z.object({
      level: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace']),
      pretty: z.coerce.boolean(),
    }),
    authentication: z
      .object({
        mode: z.enum(['disabled', 'api-key']),
        apiKey: z.string(),
      })
      .superRefine((value, context) => {
        if (value.mode === 'api-key' && value.apiKey.length < 32) {
          context.addIssue({
            code: 'custom',
            path: ['apiKey'],
            message: 'API_AUTH_KEY must contain at least 32 characters in api-key mode',
          });
        }
      }),
    scheduler: z.object({
      enabled: z.coerce.boolean(),
      tickMs: z.coerce.number().int().min(250),
      maxConcurrency: z.coerce.number().int().min(1).max(20),
      staleRunAfterMs: z.coerce.number().int().positive(),
    }),
    privacy: z.object({
      pseudonymKey: z.string().min(32),
    }),
    location: z.object({
      enabled: z.coerce.boolean(),
      evidenceMaxAgeMs: z.coerce.number().int().min(1000).max(300000),
      timingAdvanceMetersPerUnit: z.coerce.number().positive().max(1000),
      referencePathLossDb: z.coerce.number().min(0).max(200),
      pathLossExponent: z.coerce.number().min(1).max(8),
      minimumRangeM: z.coerce.number().min(0).max(10000),
      maximumRangeM: z.coerce.number().positive().max(100000),
      minimumAccuracyM: z.coerce.number().positive().max(100000),
    }),
    connectors: z.object({
      amarisoft: z.object({
        connectTimeoutMs: z.coerce.number().int().min(250),
        requestTimeoutMs: z.coerce.number().int().min(250),
        heartbeatIntervalMs: z.coerce.number().int().min(1000),
        heartbeatTimeoutMs: z.coerce.number().int().min(250),
        reconnectMinMs: z.coerce.number().int().min(100),
        reconnectMaxMs: z.coerce.number().int().min(100),
        maxRetries: z.coerce.number().int().min(0).max(10),
      }),
    }),
    websocket: z.object({
      path: z.string().startsWith('/'),
      corsOrigins: z.array(z.string().url()),
    }),
  })
  .superRefine((value, context) => {
    if (value.application.environment === 'production' && value.authentication.mode === 'disabled') {
      context.addIssue({
        code: 'custom',
        path: ['authentication', 'mode'],
        message: 'Authentication cannot be disabled in production',
      });
    }
    if (value.application.environment === 'production' && value.logging.pretty) {
      context.addIssue({
        code: 'custom',
        path: ['logging', 'pretty'],
        message: 'Pretty logging must be disabled in production',
      });
    }
    if (
      value.connectors.amarisoft.reconnectMaxMs < value.connectors.amarisoft.reconnectMinMs
    ) {
      context.addIssue({
        code: 'custom',
        path: ['connectors', 'amarisoft', 'reconnectMaxMs'],
        message: 'reconnectMaxMs must be greater than or equal to reconnectMinMs',
      });
    }
    if (value.location.maximumRangeM <= value.location.minimumRangeM) {
      context.addIssue({
        code: 'custom',
        path: ['location', 'maximumRangeM'],
        message: 'maximumRangeM must be greater than minimumRangeM',
      });
    }
  });

export type AppConfiguration = z.infer<typeof configurationSchema>;

function interpolateEnvironment(source: string): string {
  return source.replace(
    /\$\{([A-Z][A-Z0-9_]*)(?::-([^}]*))?\}/g,
    (_match: string, variable: string, fallback: string | undefined) => {
      const value = process.env[variable] ?? fallback;
      if (value === undefined) {
        throw new Error(`Required environment variable ${variable} is not set`);
      }
      return value;
    },
  );
}

export function loadYamlConfiguration(): AppConfiguration {
  const configPath = resolve(process.cwd(), process.env.CONFIG_FILE ?? 'config/default.yaml');
  const interpolated = interpolateEnvironment(readFileSync(configPath, 'utf8'));
  const parsed = load(interpolated);
  const result = configurationSchema.safeParse(parsed);

  if (!result.success) {
    throw new Error(`Invalid configuration in ${configPath}: ${z.prettifyError(result.error)}`);
  }

  return result.data;
}
