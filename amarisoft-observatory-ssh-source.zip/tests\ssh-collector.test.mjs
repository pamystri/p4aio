import assert from "node:assert/strict";
import test from "node:test";
import { buildRemoteCommand, normalizeSettings, shellQuote } from "../ssh-collector/collector.mjs";

test("quotes remote shell arguments safely", () => {
  assert.equal(shellQuote("a'b"), `'a'\"'\"'b'`);
});

test("normalizes SSH and polling settings", () => {
  const result = normalizeSettings({
    poll_interval_seconds: 5,
    target: "gnb",
    command: '{"message":"ue_get","stats":true}',
    ssh_host: "192.168.1.60",
    ssh_user: "amarisoft",
    ssh_port: 22,
    remote_ws_path: "/opt/amarisoft/ws.js",
  }, {});
  assert.equal(result.host, "192.168.1.60");
  assert.equal(result.command.message, "ue_get");
  assert.match(buildRemoteCommand(result), /ue_get/);
});

test("rejects unsafe SSH destinations", () => {
  assert.throws(() => normalizeSettings({
    command: '{"message":"ue_get"}',
    ssh_host: "-oProxyCommand=bad",
  }, {}), /Invalid GNB_SSH_HOST/);
});
