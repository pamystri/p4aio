import { env } from "cloudflare:workers";

type Bindings = {
  DB: D1Database;
  GNB_SSH_HOST?: string;
  GNB_SSH_PORT?: string;
  GNB_SSH_USER?: string;
  AMARISOFT_WS_PATH?: string;
};

export async function GET() {
  const bindings = env as unknown as Bindings;
  const value = await bindings.DB.prepare("SELECT * FROM settings WHERE id=1").first();
  return Response.json(value ?? {
    poll_interval_seconds: 5,
    target: "gnb",
    command: '{"message":"ue_get","stats":true}',
    transport: "ssh",
    ssh_host: bindings.GNB_SSH_HOST ?? "",
    ssh_port: Number(bindings.GNB_SSH_PORT ?? 22),
    ssh_user: bindings.GNB_SSH_USER ?? "root",
    remote_ws_path: bindings.AMARISOFT_WS_PATH ?? "./ws.js",
    request_timeout_ms: 8000,
    max_retries: 3,
  });
}

export async function PUT(request: Request) {
  const bindings = env as unknown as Bindings;
  const body = await request.json() as {
    intervalSeconds?: number;
    target?: string;
    command?: Record<string, unknown>;
    sshHost?: string;
    sshPort?: number;
    sshUser?: string;
    remoteWsPath?: string;
    requestTimeoutMs?: number;
    maxRetries?: number;
    latitude?: number;
    longitude?: number;
    siteName?: string;
  };

  const interval = clampInteger(body.intervalSeconds, 1, 3600, 5);
  const target = body.target === "enb" ? "enb" : "gnb";
  const command = body.command && typeof body.command.message === "string" ? body.command : { message: "ue_get", stats: true };
  const sshHost = String(body.sshHost ?? bindings.GNB_SSH_HOST ?? "").trim();
  const sshPort = clampInteger(body.sshPort, 1, 65535, 22);
  const sshUser = String(body.sshUser ?? bindings.GNB_SSH_USER ?? "root").trim();
  const remoteWsPath = String(body.remoteWsPath ?? bindings.AMARISOFT_WS_PATH ?? "./ws.js").trim();
  const requestTimeoutMs = clampInteger(body.requestTimeoutMs, 1000, 120000, 8000);
  const maxRetries = clampInteger(body.maxRetries, 0, 10, 3);

  if (sshHost && !/^[a-zA-Z0-9._:-]+$/.test(sshHost)) return Response.json({ error: "invalid_ssh_host" }, { status: 400 });
  if (!/^[a-zA-Z0-9._-]+$/.test(sshUser)) return Response.json({ error: "invalid_ssh_user" }, { status: 400 });

  await bindings.DB.prepare(
    "INSERT INTO settings (id,poll_interval_seconds,target,command,transport,ssh_host,ssh_port,ssh_user,remote_ws_path,request_timeout_ms,max_retries,updated_at) VALUES (1,?,?,?,'ssh',?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET poll_interval_seconds=excluded.poll_interval_seconds,target=excluded.target,command=excluded.command,transport='ssh',ssh_host=excluded.ssh_host,ssh_port=excluded.ssh_port,ssh_user=excluded.ssh_user,remote_ws_path=excluded.remote_ws_path,request_timeout_ms=excluded.request_timeout_ms,max_retries=excluded.max_retries,updated_at=excluded.updated_at",
  ).bind(interval, target, JSON.stringify(command), sshHost, sshPort, sshUser, remoteWsPath, requestTimeoutMs, maxRetries, Date.now()).run();

  if (typeof body.latitude === "number" && Number.isFinite(body.latitude) && typeof body.longitude === "number" && Number.isFinite(body.longitude)) {
    await bindings.DB.prepare("INSERT INTO site_locations (name,latitude,longitude,sector_azimuths,updated_at) VALUES (?,?,?,?,?)")
      .bind(body.siteName ?? "Amarisoft site", body.latitude, body.longitude, JSON.stringify([0, 120, 240]), Date.now()).run();
  }

  return Response.json({
    ok: true,
    transport: "ssh",
    pollIntervalSeconds: interval,
    target,
    command,
    sshHost,
    sshPort,
    sshUser,
    remoteWsPath,
    requestTimeoutMs,
    maxRetries,
  });
}

function clampInteger(value: unknown, min: number, max: number, fallback: number) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(min, Math.min(max, Math.floor(number))) : fallback;
}
