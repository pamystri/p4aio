import assert from "node:assert/strict";
import test from "node:test";
import { parseAmarisoftPayload } from "../lib/amarisoft-parser.ts";

test("parses UE and cell records while preserving unknown fields", () => {
  const result=parseAmarisoftPayload({message:"ue_get",cells:[{cell_id:1,rat:"nr"}],ue_list:[{ran_ue_id:47,cell_id:1,dl_bitrate:"120.5",cqi:14,vendor_future_field:"kept"}]});
  assert.equal(result.cells[0].cell_id,"1");
  assert.equal(result.ues[0].ue_id,"47");
  assert.equal(result.ues[0].dl_bitrate,120.5);
  assert.equal(result.ues[0].vendor_future_field,"kept");
});
test("handles sparse and nested responses",()=>{
  const result=parseAmarisoftPayload({data:{ue_list_nr:[{rnti:"0x4a",serving_cell_id:"03",pusch_snr:null}]}});
  assert.equal(result.ues.length,1); assert.equal(result.ues[0].cell_id,"03"); assert.equal(result.cells[0].cell_id,"03");
});
test("rejects malformed top-level responses",()=>assert.throws(()=>parseAmarisoftPayload("not json"),/JSON object/));
