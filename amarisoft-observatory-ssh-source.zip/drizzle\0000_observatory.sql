CREATE TABLE `poll_runs` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`started_at` integer NOT NULL,`completed_at` integer,`target` text NOT NULL,`command` text NOT NULL,`source_host` text,`status` text NOT NULL,`attempt_count` integer DEFAULT 1 NOT NULL,`duration_ms` integer,`error_type` text,`error_message` text);
--> statement-breakpoint
CREATE INDEX `poll_runs_started_idx` ON `poll_runs` (`started_at`);
--> statement-breakpoint
CREATE INDEX `poll_runs_status_idx` ON `poll_runs` (`status`);
--> statement-breakpoint
CREATE TABLE `raw_payloads` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`run_id` integer NOT NULL,`captured_at` integer NOT NULL,`source_command` text NOT NULL,`payload` text NOT NULL,`parser_version` text NOT NULL,FOREIGN KEY (`run_id`) REFERENCES `poll_runs`(`id`) ON UPDATE no action ON DELETE cascade);
--> statement-breakpoint
CREATE INDEX `raw_payload_run_idx` ON `raw_payloads` (`run_id`);
--> statement-breakpoint
CREATE INDEX `raw_payload_time_idx` ON `raw_payloads` (`captured_at`);
--> statement-breakpoint
CREATE TABLE `cells` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`external_id` text NOT NULL,`label` text,`rat` text,`first_seen_at` integer NOT NULL,`last_seen_at` integer NOT NULL,`latest_state` text);
--> statement-breakpoint
CREATE UNIQUE INDEX `cells_external_id_unique` ON `cells` (`external_id`);
--> statement-breakpoint
CREATE INDEX `cells_last_seen_idx` ON `cells` (`last_seen_at`);
--> statement-breakpoint
CREATE TABLE `ues` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`external_id` text NOT NULL,`first_seen_at` integer NOT NULL,`last_seen_at` integer NOT NULL,`serving_cell_id` text,`connected` integer DEFAULT true NOT NULL,`latest_state` text);
--> statement-breakpoint
CREATE UNIQUE INDEX `ues_external_id_unique` ON `ues` (`external_id`);
--> statement-breakpoint
CREATE INDEX `ues_last_seen_idx` ON `ues` (`last_seen_at`);
--> statement-breakpoint
CREATE INDEX `ues_cell_idx` ON `ues` (`serving_cell_id`);
--> statement-breakpoint
CREATE TABLE `cell_metrics_timeseries` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`run_id` integer NOT NULL,`captured_at` integer NOT NULL,`cell_id` text NOT NULL,`dl_bitrate` real,`ul_bitrate` real,`dl_tx` real,`ul_tx` real,`dl_err` real,`ul_err` real,`dl_retx` real,`ul_retx` real,`connected_ues` integer,`extra` text,FOREIGN KEY (`run_id`) REFERENCES `poll_runs`(`id`) ON UPDATE no action ON DELETE cascade);
--> statement-breakpoint
CREATE INDEX `cell_metrics_time_idx` ON `cell_metrics_timeseries` (`captured_at`);
--> statement-breakpoint
CREATE INDEX `cell_metrics_cell_time_idx` ON `cell_metrics_timeseries` (`cell_id`,`captured_at`);
--> statement-breakpoint
CREATE INDEX `cell_metrics_run_idx` ON `cell_metrics_timeseries` (`run_id`);
--> statement-breakpoint
CREATE TABLE `ue_metrics_timeseries` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`run_id` integer NOT NULL,`captured_at` integer NOT NULL,`ue_id` text NOT NULL,`cell_id` text,`dl_bitrate` real,`ul_bitrate` real,`dl_tx` real,`ul_tx` real,`dl_err` real,`ul_err` real,`dl_retx` real,`ul_retx` real,`pusch_snr` real,`epre` real,`ul_phr` real,`ul_path_loss` real,`p_ue` real,`ul_rank` real,`dl_mcs` real,`ul_mcs` real,`ul_n_layer` real,`turbo_decoder_min` real,`turbo_decoder_avg` real,`turbo_decoder_max` real,`cqi` real,`ri` real,`initial_ta` real,`ue_ul_bwp_id` text,`ul_bwp_id` text,`ue_dl_bwp_id` text,`dl_bwp_id` text,`latitude` real,`longitude` real,`location_accuracy` text,`extra` text,FOREIGN KEY (`run_id`) REFERENCES `poll_runs`(`id`) ON UPDATE no action ON DELETE cascade);
--> statement-breakpoint
CREATE INDEX `ue_metrics_time_idx` ON `ue_metrics_timeseries` (`captured_at`);
--> statement-breakpoint
CREATE INDEX `ue_metrics_ue_time_idx` ON `ue_metrics_timeseries` (`ue_id`,`captured_at`);
--> statement-breakpoint
CREATE INDEX `ue_metrics_cell_time_idx` ON `ue_metrics_timeseries` (`cell_id`,`captured_at`);
--> statement-breakpoint
CREATE INDEX `ue_metrics_run_idx` ON `ue_metrics_timeseries` (`run_id`);
--> statement-breakpoint
CREATE TABLE `site_locations` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`name` text NOT NULL,`latitude` real NOT NULL,`longitude` real NOT NULL,`sector_azimuths` text,`updated_at` integer NOT NULL);
--> statement-breakpoint
CREATE TABLE `settings` (`id` integer PRIMARY KEY DEFAULT 1 NOT NULL,`poll_interval_seconds` integer DEFAULT 5 NOT NULL,`target` text DEFAULT 'gnb' NOT NULL,`command` text DEFAULT '{"message":"ue_get","stats":true}' NOT NULL,`agent_base_url` text,`request_timeout_ms` integer DEFAULT 8000 NOT NULL,`max_retries` integer DEFAULT 3 NOT NULL,`updated_at` integer NOT NULL);
