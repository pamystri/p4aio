import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

export default function Loading() {
  return <main style={{ padding: 40 }} role="status" aria-label="Loading Observatory"><Skeleton count={8} height={72} baseColor="#111820" highlightColor="#1d2833" /></main>;
}
