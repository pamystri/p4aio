INSERT OR IGNORE INTO site_locations (id,name,latitude,longitude,sector_azimuths,updated_at) VALUES (1,'London Lab',51.5074,-0.1278,'[0,120,240]',strftime('%s','now')*1000);
--> statement-breakpoint
INSERT OR IGNORE INTO settings (id,poll_interval_seconds,target,command,agent_base_url,request_timeout_ms,max_retries,updated_at) VALUES (1,5,'gnb','{"message":"ue_get","stats":true}',NULL,8000,3,strftime('%s','now')*1000);
