import { env } from "cloudflare:workers";
export async function GET() {
  const latest = await (env as unknown as {DB:D1Database}).DB.prepare("SELECT status,completed_at,duration_ms,attempt_count,error_message FROM poll_runs ORDER BY started_at DESC LIMIT 1").first<Record<string,unknown>>();
  const age = latest?.completed_at ? Date.now()-Number(latest.completed_at) : null;
  return Response.json({ status: latest?.status === "success" && age !== null && age < 120_000 ? "healthy" : latest ? "degraded" : "waiting", lastPoll: latest ?? null, ageMs: age });
}
