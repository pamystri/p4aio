export const PARSER_VERSION = "1.0.0";

export type JsonRecord = Record<string, unknown>;
export type ParsedSample = {
  cells: Array<JsonRecord & { cell_id: string }>;
  ues: Array<JsonRecord & { ue_id: string; cell_id?: string }>;
  metadata: JsonRecord;
};

const KNOWN_CONTAINER_KEYS = new Set(["cells", "cell_list", "ues", "ue_list", "ue_list_lte", "ue_list_nr", "users", "data"]);
const UE_ID_KEYS = ["ue_id", "ran_ue_id", "enb_ue_id", "gnb_ue_id", "rnti", "mme_ue_id"];
const CELL_ID_KEYS = ["cell_id", "cell", "serving_cell_id", "nr_cell_id", "enb_cell_id"];
const NUMERIC_FIELDS = new Set([
  "dl_bitrate","ul_bitrate","dl_tx","ul_tx","dl_err","ul_err","dl_retx","ul_retx",
  "pusch_snr","epre","ul_phr","ul_path_loss","p_ue","ul_rank","dl_mcs","ul_mcs",
  "ul_n_layer","turbo_decoder_min","turbo_decoder_avg","turbo_decoder_max","cqi","ri",
  "initial_ta","latitude","longitude","lat","lon",
]);

export function parseAmarisoftPayload(input: unknown): ParsedSample {
  if (!isRecord(input)) throw new TypeError("Amarisoft response must be a JSON object");
  const root = coerceNumbers(input);
  const candidates: JsonRecord[] = [];
  walk(root, (value, key) => {
    if (KNOWN_CONTAINER_KEYS.has(key) && Array.isArray(value)) {
      for (const item of value) if (isRecord(item)) candidates.push(coerceNumbers(item));
    }
  });
  if (candidates.length === 0) walk(root, value => { if (isRecord(value) && hasAnyKey(value, [...UE_ID_KEYS, ...CELL_ID_KEYS])) candidates.push(coerceNumbers(value)); });

  const ues: ParsedSample["ues"] = [];
  const cellsById = new Map<string, ParsedSample["cells"][number]>();
  for (const record of candidates) {
    const ueId = firstString(record, UE_ID_KEYS);
    const cellId = firstString(record, CELL_ID_KEYS);
    if (ueId) ues.push({ ...record, ue_id: ueId, ...(cellId ? { cell_id: cellId } : {}) });
    else if (cellId) cellsById.set(cellId, { ...(cellsById.get(cellId) ?? {}), ...record, cell_id: cellId });
  }
  for (const ue of ues) {
    if (ue.cell_id && !cellsById.has(ue.cell_id)) cellsById.set(ue.cell_id, { cell_id: ue.cell_id });
  }
  return { cells: [...cellsById.values()], ues, metadata: pickMetadata(root) };
}

function walk(value: unknown, visit: (value: unknown, key: string) => void, key = ""): void {
  visit(value, key);
  if (Array.isArray(value)) value.forEach(item => walk(item, visit, key));
  else if (isRecord(value)) Object.entries(value).forEach(([k, v]) => walk(v, visit, k));
}
function isRecord(value: unknown): value is JsonRecord { return typeof value === "object" && value !== null && !Array.isArray(value); }
function hasAnyKey(record: JsonRecord, keys: string[]) { return keys.some(key => record[key] !== undefined); }
function firstString(record: JsonRecord, keys: string[]) {
  for (const key of keys) if (record[key] !== undefined && record[key] !== null) return String(record[key]);
}
function coerceNumbers<T extends JsonRecord>(record: T): T {
  return Object.fromEntries(Object.entries(record).map(([key, value]) => {
    if (isRecord(value)) return [key, coerceNumbers(value)];
    if (Array.isArray(value)) return [key, value.map(v => isRecord(v) ? coerceNumbers(v) : v)];
    if (NUMERIC_FIELDS.has(key) && typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) return [key, Number(value)];
    return [key, value];
  })) as T;
}
function pickMetadata(root: JsonRecord): JsonRecord {
  return Object.fromEntries(Object.entries(root).filter(([key, value]) => !KNOWN_CONTAINER_KEYS.has(key) && !Array.isArray(value) && !isRecord(value)));
}
