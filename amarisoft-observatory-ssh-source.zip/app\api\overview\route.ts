import { env } from "cloudflare:workers";

export async function GET() {
  const db = (env as unknown as { DB: D1Database }).DB;
  const [health, summary, cells, ues] = await Promise.all([
    db.prepare("SELECT status, completed_at, duration_ms, error_message FROM poll_runs ORDER BY started_at DESC LIMIT 1").first(),
    db.prepare("SELECT COUNT(DISTINCT ue_id) connected_users, COUNT(DISTINCT cell_id) active_cells, SUM(dl_bitrate) dl_bitrate, SUM(ul_bitrate) ul_bitrate, AVG(cqi) avg_cqi, AVG(pusch_snr) avg_snr, SUM(dl_retx)+SUM(ul_retx) retransmissions FROM ue_metrics_timeseries WHERE captured_at=(SELECT MAX(captured_at) FROM ue_metrics_timeseries)").first(),
    db.prepare("SELECT external_id cell_id, label, rat, last_seen_at, latest_state FROM cells ORDER BY external_id").all(),
    db.prepare("SELECT external_id ue_id, serving_cell_id cell_id, last_seen_at, latest_state FROM ues WHERE connected=1 ORDER BY external_id").all(),
  ]);
  return Response.json({ health, summary, cells: cells.results, ues: ues.results });
}
