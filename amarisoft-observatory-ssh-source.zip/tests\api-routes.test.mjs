import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const routes=["ingest","overview","history","settings","health","export"];
for(const route of routes)test(`defines ${route} endpoint`,async()=>{
  const source=await readFile(new URL(`../app/api/${route}/route.ts`,import.meta.url),"utf8");
  assert.match(source,/export async function (GET|POST|PUT)/);
});
