ALTER TABLE `settings` ADD COLUMN `transport` text DEFAULT 'ssh' NOT NULL;
--> statement-breakpoint
ALTER TABLE `settings` ADD COLUMN `ssh_host` text;
--> statement-breakpoint
ALTER TABLE `settings` ADD COLUMN `ssh_port` integer DEFAULT 22 NOT NULL;
--> statement-breakpoint
ALTER TABLE `settings` ADD COLUMN `ssh_user` text DEFAULT 'root' NOT NULL;
--> statement-breakpoint
ALTER TABLE `settings` ADD COLUMN `remote_ws_path` text DEFAULT './ws.js' NOT NULL;
--> statement-breakpoint
UPDATE `settings` SET `transport`='ssh';
