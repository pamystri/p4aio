import { env } from "cloudflare:workers";

export async function GET(request: Request) {
  const url=new URL(request.url); const from=Number(url.searchParams.get("from")??Date.now()-3600000); const to=Number(url.searchParams.get("to")??Date.now());
  const result=await (env as unknown as {DB:D1Database}).DB.prepare("SELECT captured_at,ue_id,cell_id,dl_bitrate,ul_bitrate,dl_retx,ul_retx,pusch_snr,ul_path_loss,dl_mcs,ul_mcs,cqi,ri FROM ue_metrics_timeseries WHERE captured_at BETWEEN ? AND ? ORDER BY captured_at").bind(from,to).all<Record<string,unknown>>();
  const columns=["captured_at","ue_id","cell_id","dl_bitrate","ul_bitrate","dl_retx","ul_retx","pusch_snr","ul_path_loss","dl_mcs","ul_mcs","cqi","ri"];
  const csv=[columns.join(","),...result.results.map(row=>columns.map(c=>csvValue(row[c])).join(","))].join("\n");
  return new Response(csv,{headers:{"content-type":"text/csv; charset=utf-8","content-disposition":`attachment; filename="amarisoft-metrics-${new Date().toISOString().slice(0,10)}.csv"`}});
}
function csvValue(value:unknown){const text=value==null?"":String(value);return /[",\n]/.test(text)?`"${text.replaceAll('"','""')}"`:text}
