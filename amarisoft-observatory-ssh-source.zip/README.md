# Amarisoft Observatory — SSH edition

Amarisoft Observatory collects gNB/eNB telemetry over SSH, stores raw and normalized samples, and displays live and historical radio KPIs.

Nothing is installed on the gNB. The collector runs on the Observatory Linux server, opens a restricted SSH connection to the gNB, executes the existing `ws.js` command, and sends the JSON response to Observatory through the local ingestion endpoint.

## Architecture

```text
gNB / eNB host                         Observatory Linux server
┌───────────────────────┐             ┌────────────────────────────────┐
│ OpenSSH               │◀── SSH ─────│ SSH collector (5s scheduler)   │
│ ./ws.js gnb '{...}'   │             │          │                     │
│ No Node agent         │             │          ▼ localhost           │
└───────────────────────┘             │ /api/ingest → D1/SQLite        │
                                      │ REST API → web dashboard       │
                                      └────────────────────────────────┘
```

The browser never receives the SSH private key. The key exists only on the Observatory server.

## Requirements

### Observatory server

- Linux
- Node.js 22.13 or newer
- OpenSSH client
- Network access to the gNB SSH port

### gNB

- OpenSSH server
- Existing Amarisoft `ws.js`
- A user permitted to execute `ws.js`

No Node.js installation, HTTP service, or Observatory agent is required on the gNB.

## 1. Install Observatory

Extract the source archive on the Observatory machine:

```bash
sudo mkdir -p /opt/amarisoft-observatory
sudo chown "$USER":"$USER" /opt/amarisoft-observatory
cd /opt/amarisoft-observatory
unzip amarisoft-observatory-ssh-source.zip
```

Install dependencies:

```bash
nvm install 22
nvm use 22
npm ci
```

Configure the local Worker variables:

```bash
cp .dev.vars.example .dev.vars
nano .dev.vars
```

Set a long random `INGEST_TOKEN`. The same value must later be used by the SSH collector.

Create the local database:

```bash
npm run db:local:init
```

Start the dashboard:

```bash
npm run dev
```

The development server listens on all interfaces on port `3000`:

```text
http://127.0.0.1:3000
http://<OBSERVATORY_LAN_IP>:3000
```

Verify the listener:

```bash
sudo ss -ltnp | grep ':3000'
```

It should show `0.0.0.0:3000`.

## 2. Create a restricted SSH key

On the Observatory server:

```bash
sudo mkdir -p /etc/observatory
sudo ssh-keygen -t ed25519 -f /etc/observatory/gnb_ed25519 -N ""
```

Install the public key for the selected gNB user:

```bash
ssh-copy-id -i /etc/observatory/gnb_ed25519.pub amarisoft@192.168.1.60
```

Accept and verify the gNB host key interactively once:

```bash
ssh -i /etc/observatory/gnb_ed25519 amarisoft@192.168.1.60 true
```

Do not disable host-key checking.

Test `ws.js` through SSH:

```bash
ssh -i /etc/observatory/gnb_ed25519 amarisoft@192.168.1.60 \
  "/opt/amarisoft/ws.js gnb '{\"message\":\"ue_get\",\"stats\":true}'"
```

The command must print valid JSON only.

## 3. Configure persistent SSH connections

Copy the supplied example:

```bash
sudo cp ssh-collector/ssh-config.example /etc/observatory/ssh_config
sudo nano /etc/observatory/ssh_config
sudo chmod 600 /etc/observatory/ssh_config
sudo chmod 600 /etc/observatory/gnb_ed25519
```

`ControlMaster` and `ControlPersist` reuse a single SSH connection. This avoids a complete SSH handshake every five seconds.

## 4. Configure the SSH collector

```bash
cp .env.ssh.example .env.ssh
nano .env.ssh
```

Example:

```dotenv
OBSERVATORY_URL=http://127.0.0.1:3000
INGEST_TOKEN=the-same-value-from-.dev.vars
GNB_SSH_KEY=/etc/observatory/gnb_ed25519
GNB_SSH_CONFIG=/etc/observatory/ssh_config
GNB_SSH_HOST=192.168.1.60
GNB_SSH_PORT=22
GNB_SSH_USER=amarisoft
AMARISOFT_WS_PATH=/opt/amarisoft/ws.js
```

Start it:

```bash
node --env-file=.env.ssh ssh-collector/collector.mjs
```

Successful collection prints:

```text
2026-07-28T12:00:00.000Z SSH poll succeeded
```

## 5. Configure through the web UI

Open **Settings** and configure:

- Poll interval in seconds
- gNB hostname or IP
- SSH port and username
- `ws.js` path
- `gnb` or `enb` target
- Amarisoft JSON command
- Command timeout and exponential-backoff stages
- Site name, latitude and longitude

The SSH key path is intentionally not editable or returned to the browser.

The collector reads these settings before every poll, so interval and command changes take effect without restarting it.

## Run the collector with systemd

Create a service user if needed:

```bash
sudo useradd --system --home /opt/amarisoft-observatory --shell /usr/sbin/nologin observatory
```

Create its environment file:

```bash
sudo mkdir -p /etc/amarisoft-observatory
sudo cp .env.ssh.example /etc/amarisoft-observatory/ssh-collector.env
sudo nano /etc/amarisoft-observatory/ssh-collector.env
sudo chmod 600 /etc/amarisoft-observatory/ssh-collector.env
```

Ensure the service user can read the private key:

```bash
sudo chown observatory:observatory /etc/observatory/gnb_ed25519
sudo chmod 600 /etc/observatory/gnb_ed25519
```

Check the Node.js path:

```bash
command -v node
```

If it is not `/usr/bin/node`, update `ExecStart` in the supplied service file.

Install and start the service:

```bash
sudo cp deploy/amarisoft-observatory-ssh-collector.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now amarisoft-observatory-ssh-collector
sudo journalctl -u amarisoft-observatory-ssh-collector -f
```

## Environment reference

| Variable | Location | Purpose |
|---|---|---|
| `INGEST_TOKEN` | Web and collector | Authenticates local ingestion |
| `OBSERVATORY_URL` | Collector | Usually `http://127.0.0.1:3000` |
| `GNB_SSH_KEY` | Collector | Private-key path on Observatory |
| `GNB_SSH_CONFIG` | Collector | Optional persistent SSH configuration |
| `GNB_SSH_HOST` | Collector | Initial/fallback gNB host |
| `GNB_SSH_PORT` | Collector | Initial/fallback SSH port |
| `GNB_SSH_USER` | Collector | Initial/fallback SSH user |
| `AMARISOFT_WS_PATH` | Collector | Initial/fallback remote `ws.js` path |

## Data and API

- `POST /api/ingest` authenticates, parses and stores SSH-collected samples.
- `GET /api/overview` returns health, summary, cell and UE state.
- `GET /api/history?from=&to=&cell=&ue=` returns filtered time series.
- `GET /api/export?from=&to=` exports CSV.
- `GET /api/health` reports the last successful collection.
- `GET|PUT /api/settings` manages SSH, command, interval and location settings.

`raw_payloads` preserves the complete Amarisoft response. Normalized history is stored in `cell_metrics_timeseries` and `ue_metrics_timeseries`. Unknown vendor fields remain in `extra` JSON.

## Tests

```bash
npm test
```

Tests cover:

- Amarisoft parser resilience
- SSH command quoting and configuration validation
- API route contracts

## Troubleshooting

### SSH collector reports authentication failure

```bash
ssh -vvv -i /etc/observatory/gnb_ed25519 amarisoft@192.168.1.60 true
```

### `ws.js` returns non-JSON output

Run the exact SSH test command manually. Remove login banners or diagnostic text written to standard output; send diagnostics to standard error.

### Dashboard is only listening on localhost

The included `npm run dev` uses:

```bash
vite --host 0.0.0.0 --port 3000
```

Confirm with:

```bash
sudo ss -ltnp | grep ':3000'
```

### Existing installation

Apply the SSH transport migration after replacing the source:

```bash
npx wrangler d1 execute observatory-local --local --file=drizzle/0002_ssh_transport.sql
```

Do not rerun migration `0002` if it has already succeeded.
