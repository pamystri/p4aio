import { execFile } from "node:child_process";
import { pathToFileURL } from "node:url";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

export function shellQuote(value) {
  return `'${String(value).replaceAll("'", `'\"'\"'`)}'`;
}

export function normalizeSettings(raw, environment) {
  const target = raw.target === "enb" ? "enb" : "gnb";
  let command;
  try {
    command = typeof raw.command === "string" ? JSON.parse(raw.command) : raw.command;
  } catch {
    throw new Error("The saved Amarisoft command is not valid JSON");
  }
  if (!command || typeof command.message !== "string") throw new Error("The Amarisoft command must contain a message");

  const host = String(raw.ssh_host || environment.GNB_SSH_HOST || "");
  const user = String(raw.ssh_user || environment.GNB_SSH_USER || "root");
  const port = Number(raw.ssh_port || environment.GNB_SSH_PORT || 22);
  const wsPath = String(raw.remote_ws_path || environment.AMARISOFT_WS_PATH || "./ws.js");
  const intervalSeconds = Math.max(1, Math.min(3600, Number(raw.poll_interval_seconds || 5)));
  const timeoutMs = Math.max(1000, Math.min(120000, Number(raw.request_timeout_ms || 8000)));
  const maxRetries = Math.max(0, Math.min(10, Number(raw.max_retries || 3)));

  if (!/^[a-zA-Z0-9._:-]+$/.test(host)) throw new Error("Invalid GNB_SSH_HOST");
  if (!/^[a-zA-Z0-9._-]+$/.test(user)) throw new Error("Invalid GNB_SSH_USER");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid GNB_SSH_PORT");

  return { target, command, host, user, port, wsPath, intervalSeconds, timeoutMs, maxRetries };
}

export function buildRemoteCommand(settings) {
  return [
    shellQuote(settings.wsPath),
    shellQuote(settings.target),
    shellQuote(JSON.stringify(settings.command)),
  ].join(" ");
}

export function loadEnvironment(environment = process.env) {
  const observatoryUrl = String(environment.OBSERVATORY_URL || "http://127.0.0.1:3000").replace(/\/$/, "");
  const ingestToken = environment.INGEST_TOKEN;
  const identityFile = environment.GNB_SSH_KEY;
  if (!ingestToken) throw new Error("INGEST_TOKEN is required");
  if (!identityFile) throw new Error("GNB_SSH_KEY is required");
  return { observatoryUrl, ingestToken, identityFile, sshConfig: environment.GNB_SSH_CONFIG || "", environment };
}

export async function pollOnce(runtime, dependencies = {}) {
  const fetcher = dependencies.fetcher || fetch;
  const executor = dependencies.executor || execFileAsync;
  const settingsResponse = await fetcher(`${runtime.observatoryUrl}/api/settings`);
  if (!settingsResponse.ok) throw new Error(`Settings API returned HTTP ${settingsResponse.status}`);
  const settings = normalizeSettings(await settingsResponse.json(), runtime.environment || process.env);

  const sshArgs = [];
  if (runtime.sshConfig) sshArgs.push("-F", runtime.sshConfig);
  sshArgs.push(
    "-p", String(settings.port),
    "-i", runtime.identityFile,
    "-o", "BatchMode=yes",
    "-o", "ConnectTimeout=5",
    "-o", "ServerAliveInterval=15",
    `${settings.user}@${settings.host}`,
    buildRemoteCommand(settings),
  );

  const started = Date.now();
  const { stdout, stderr } = await executor("ssh", sshArgs, {
    timeout: settings.timeoutMs,
    maxBuffer: 10 * 1024 * 1024,
  });
  if (stderr?.trim()) console.warn(stderr.trim());

  let payload;
  try {
    payload = JSON.parse(stdout);
  } catch {
    throw new Error("ws.js returned malformed JSON over SSH");
  }

  const ingestResponse = await fetcher(`${runtime.observatoryUrl}/api/ingest`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${runtime.ingestToken}`,
    },
    body: JSON.stringify({
      payload,
      source: {
        host: settings.host,
        target: settings.target,
        command: settings.command.message,
        transport: "ssh",
        duration_ms: Date.now() - started,
        captured_at: new Date().toISOString(),
      },
    }),
  });
  if (!ingestResponse.ok) throw new Error(`Ingest API returned HTTP ${ingestResponse.status}`);
  return { intervalSeconds: settings.intervalSeconds, maxRetries: settings.maxRetries };
}

export async function start(environment = process.env) {
  const runtime = loadEnvironment(environment);
  let consecutiveFailures = 0;
  let intervalSeconds = 5;
  let maxRetries = 3;

  const run = async () => {
    try {
      const result = await pollOnce(runtime);
      intervalSeconds = result.intervalSeconds;
      maxRetries = result.maxRetries;
      consecutiveFailures = 0;
      console.log(`${new Date().toISOString()} SSH poll succeeded`);
    } catch (error) {
      consecutiveFailures++;
      console.error(`${new Date().toISOString()} SSH poll failed:`, error instanceof Error ? error.message : error);
    } finally {
      const exponent = Math.min(consecutiveFailures, maxRetries);
      const delaySeconds = Math.min(60, intervalSeconds * 2 ** exponent);
      setTimeout(run, delaySeconds * 1000);
    }
  };

  await run();
}

const invokedPath = process.argv[1] ? pathToFileURL(process.argv[1]).href : "";
if (import.meta.url === invokedPath) {
  start().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
}
