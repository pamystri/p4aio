import { env } from "cloudflare:workers";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const from = Number(url.searchParams.get("from") ?? Date.now() - 60 * 60_000);
  const to = Number(url.searchParams.get("to") ?? Date.now());
  const cell = url.searchParams.get("cell");
  const ue = url.searchParams.get("ue");
  const db = (env as unknown as { DB: D1Database }).DB;
  let sql = "SELECT captured_at,ue_id,cell_id,dl_bitrate,ul_bitrate,dl_retx,ul_retx,pusch_snr,ul_path_loss,dl_mcs,ul_mcs,cqi,ri FROM ue_metrics_timeseries WHERE captured_at BETWEEN ? AND ?";
  const values: unknown[] = [from, to];
  if (cell) { sql += " AND cell_id=?"; values.push(cell); }
  if (ue) { sql += " AND ue_id=?"; values.push(ue); }
  sql += " ORDER BY captured_at ASC LIMIT 10000";
  const result = await db.prepare(sql).bind(...values).all();
  return Response.json({ from, to, count: result.results.length, samples: result.results });
}
