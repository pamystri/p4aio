import type { Metadata } from "next";
import Dashboard from "./Dashboard";

export const metadata: Metadata = {
  title: "Overview · Amarisoft Observatory",
  description: "Live and historical radio access network telemetry.",
};

export default function Home() {
  return <Dashboard />;
}
