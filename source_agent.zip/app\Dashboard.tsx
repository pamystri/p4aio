"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type Page = "Overview" | "Live metrics" | "Map" | "Historical analytics" | "Settings";
type MetricKey = "dl" | "ul" | "users" | "cqi" | "snr" | "retx";
type Series = { label: string; color: string; values: number[] };

const nav: { label: Page; glyph: string }[] = [
  { label: "Overview", glyph: "⌂" },
  { label: "Live metrics", glyph: "ϟ" },
  { label: "Map", glyph: "⌖" },
  { label: "Historical analytics", glyph: "⌁" },
  { label: "Settings", glyph: "⚙" },
];

const labels = ["11:42", "11:46", "11:50", "11:54", "11:58", "12:02", "12:06", "12:10", "12:14", "12:18", "12:22", "12:26"];
const baseSeries: Record<MetricKey, Series[]> = {
  dl: [{ label: "Downlink", color: "#58e7b1", values: [342, 410, 382, 523, 465, 594, 552, 614, 570, 638, 602, 626] }, { label: "Uplink", color: "#8aa8ff", values: [74, 82, 78, 109, 92, 114, 101, 126, 118, 132, 119, 123] }],
  ul: [{ label: "Uplink", color: "#8aa8ff", values: [74, 82, 78, 109, 92, 114, 101, 126, 118, 132, 119, 123] }],
  users: [{ label: "Connected UEs", color: "#e5c07b", values: [19, 20, 20, 22, 21, 23, 24, 23, 25, 24, 24, 24] }],
  cqi: [{ label: "Average CQI", color: "#b8a1ff", values: [11.2, 11.8, 12.1, 11.9, 12.6, 12.4, 12.9, 12.7, 13.1, 12.8, 12.7, 12.8] }],
  snr: [{ label: "PUSCH SNR", color: "#58e7b1", values: [17, 18.2, 17.8, 19, 18.6, 19.4, 20.1, 19.6, 20.4, 19.8, 20.2, 19.8] }, { label: "Path loss", color: "#ef8f9c", values: [93, 92, 94, 91, 90, 92, 89, 90, 88, 89, 87, 88] }],
  retx: [{ label: "DL retransmissions", color: "#ef8f9c", values: [103, 92, 114, 81, 88, 74, 93, 69, 78, 71, 66, 72] }, { label: "UL retransmissions", color: "#e5c07b", values: [42, 38, 44, 31, 35, 29, 34, 28, 32, 30, 27, 31] }],
};

const ues = [
  { id: "UE-0047", cell: "Cell 01", rat: "5G SA", dl: "82.4", ul: "16.8", cqi: 15, mcs: "24 / 18", snr: "24.6", state: "Active" },
  { id: "UE-0028", cell: "Cell 01", rat: "5G SA", dl: "61.8", ul: "12.1", cqi: 13, mcs: "21 / 17", snr: "21.3", state: "Active" },
  { id: "UE-0052", cell: "Cell 02", rat: "5G SA", dl: "45.1", ul: "8.9", cqi: 11, mcs: "18 / 14", snr: "17.4", state: "Active" },
  { id: "UE-0013", cell: "Cell 03", rat: "LTE", dl: "32.7", ul: "6.2", cqi: 10, mcs: "16 / 12", snr: "14.8", state: "Active" },
  { id: "UE-0034", cell: "Cell 02", rat: "5G SA", dl: "28.4", ul: "5.8", cqi: 9, mcs: "14 / 11", snr: "12.9", state: "Degraded" },
  { id: "UE-0009", cell: "Cell 03", rat: "LTE", dl: "18.2", ul: "4.4", cqi: 8, mcs: "12 / 10", snr: "11.2", state: "Active" },
];

function LineChart({ series, compact = false }: { series: Series[]; compact?: boolean }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const el = canvas.current;
    if (!el) return;
    const ratio = window.devicePixelRatio || 1;
    const rect = el.getBoundingClientRect();
    el.width = rect.width * ratio; el.height = rect.height * ratio;
    const ctx = el.getContext("2d"); if (!ctx) return;
    ctx.scale(ratio, ratio);
    const w = rect.width, h = rect.height, pad = compact ? 5 : 28;
    ctx.strokeStyle = "rgba(255,255,255,.07)"; ctx.lineWidth = 1;
    for (let i = 1; i < 5; i++) { const y = pad + (h - pad * 2) * i / 5; ctx.beginPath(); ctx.moveTo(pad, y); ctx.lineTo(w - pad, y); ctx.stroke(); }
    const values = series.flatMap(s => s.values); const min = Math.min(...values) * .88; const max = Math.max(...values) * 1.08;
    series.forEach(s => {
      ctx.beginPath(); ctx.strokeStyle = s.color; ctx.lineWidth = compact ? 2 : 2.5; ctx.lineJoin = "round";
      s.values.forEach((v, i) => { const x = pad + i * (w - pad * 2) / (s.values.length - 1); const y = pad + (max - v) * (h - pad * 2) / (max - min); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
      ctx.stroke();
      if (!compact) { const grad = ctx.createLinearGradient(0, pad, 0, h); grad.addColorStop(0, s.color + "28"); grad.addColorStop(1, s.color + "00"); ctx.lineTo(w - pad, h - pad); ctx.lineTo(pad, h - pad); ctx.fillStyle = grad; ctx.fill(); }
    });
  }, [series, compact]);
  return <canvas className={compact ? "spark" : "chart-canvas"} ref={canvas} role="img" aria-label={`Chart for ${series.map(s => s.label).join(" and ")}`} />;
}

function MetricCard({ label, value, unit, delta, tone, series }: { label: string; value: string; unit?: string; delta: string; tone: string; series: Series[] }) {
  return <article className="metric-card">
    <div className="metric-top"><span className="eyebrow">{label}</span><span className="live-dot" /></div>
    <div className="metric-value">{value}<small>{unit}</small></div>
    <div className="metric-foot"><span className={delta.startsWith("+") ? "good" : delta === "Healthy" ? "good" : ""}>{delta}</span><div style={{ "--spark": tone } as React.CSSProperties}><LineChart series={series} compact /></div></div>
  </article>;
}

function MiniMap({ full = false }: { full?: boolean }) {
  return <div className={`network-map ${full ? "map-full" : ""}`}>
    <div className="map-road r1" /><div className="map-road r2" /><div className="map-road r3" />
    <div className="sector s1" /><div className="sector s2" /><div className="sector s3" />
    <button className="gnb-marker" aria-label="London Lab gNB"><span>◎</span><b>London Lab</b><small>3 cells · healthy</small></button>
    {[["u1","UE-0047","Exact"],["u2","UE-0028","Estimated"],["u3","UE-0052","Estimated"],["u4","UE-0013","Estimated"],["u5","UE-0034","Estimated"],["u6","UE-0009","Estimated"]].map(([c,id,confidence]) =>
      <button key={c} className={`ue-marker ${c}`} aria-label={`${id}, ${confidence} location`} title={`${id} · ${confidence} location`}>•</button>
    )}
    <div className="map-controls"><button aria-label="Zoom in">+</button><button aria-label="Zoom out">−</button></div>
    <div className="map-legend"><span><i className="exact" /> Exact</span><span><i /> Estimated by sector</span></div>
  </div>;
}

export default function Dashboard() {
  const [page, setPage] = useState<Page>("Overview");
  const [metric, setMetric] = useState<MetricKey>("dl");
  const [range, setRange] = useState("Last 60 minutes");
  const [query, setQuery] = useState("");
  const [cell, setCell] = useState("All cells");
  const [interval, setIntervalValue] = useState(5);
  const [saved, setSaved] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [summary, setSummary] = useState({ connectedUsers: 24, activeCells: 3, dlBitrate: 626, ulBitrate: 123, avgCqi: 12.8, avgSnr: 19.8, retransmissions: 103 });
  const filtered = useMemo(() => ues.filter(u => (cell === "All cells" || u.cell === cell) && Object.values(u).join(" ").toLowerCase().includes(query.toLowerCase())), [cell, query]);
  const title = page === "Overview" ? "Network overview" : page;

  useEffect(() => {
    let active = true;
    async function refresh() {
      try {
        const response = await fetch("/api/overview");
        if (!response.ok) return;
        const body = await response.json() as { summary?: Record<string, unknown> };
        const s = body.summary;
        if (active && s && s.connected_users !== null) setSummary({
          connectedUsers: Number(s.connected_users), activeCells: Number(s.active_cells), dlBitrate: Number(s.dl_bitrate ?? 0),
          ulBitrate: Number(s.ul_bitrate ?? 0), avgCqi: Number(s.avg_cqi ?? 0), avgSnr: Number(s.avg_snr ?? 0), retransmissions: Number(s.retransmissions ?? 0),
        });
      } catch {}
    }
    void refresh(); const timer = setInterval(refresh, Math.max(1, interval) * 1000);
    return () => { active = false; clearInterval(timer); };
  }, [interval]);

  function exportCsv() {
    const rows = [["UE","Cell","RAT","DL Mbps","UL Mbps","CQI","MCS","SNR dB","State"], ...filtered.map(u => Object.values(u).map(String))];
    const blob = new Blob([rows.map(r => r.join(",")).join("\n")], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "amarisoft-ue-metrics.csv"; a.click(); URL.revokeObjectURL(a.href);
  }

  return <div className={theme === "light" ? "app theme-light" : "app"}>
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark">A</span><div><b>AMARISOFT</b><small>OBSERVATORY</small></div></div>
      <nav aria-label="Main navigation">{nav.map(n => <button key={n.label} className={page === n.label ? "active" : ""} onClick={() => setPage(n.label)}><span>{n.glyph}</span>{n.label}</button>)}</nav>
      <div className="sidebar-bottom">
        <div className="site-card"><span className="status-orb">◉</span><div><b>London Lab</b><small>Amarisoft gNB · Online</small></div><button>⋮</button></div>
        <div className="poll-mini"><span><i /> Polling healthy</span><b>Last poll 2s ago</b></div>
        <button className="theme-toggle" onClick={() => setTheme(t => t === "dark" ? "light" : "dark")}>{theme === "dark" ? "☼ Light theme" : "☾ Dark theme"}</button>
      </div>
    </aside>
    <main>
      <header className="topbar">
        <div><p>RADIO ACCESS NETWORK</p><h1>{title}</h1></div>
        <div className="top-actions"><div className="health-pill"><i /> Live <span>•</span> 2 sec ago</div><button className="icon-button" aria-label="Notifications">♧<sup>2</sup></button><div className="avatar">PM</div></div>
      </header>

      {page !== "Settings" && <div className="filterbar">
        <select value={range} onChange={e => setRange(e.target.value)} aria-label="Time range"><option>Last 60 minutes</option><option>Last 24 hours</option><option>Last 7 days</option></select>
        <select value={cell} onChange={e => setCell(e.target.value)} aria-label="Cell filter"><option>All cells</option><option>Cell 01</option><option>Cell 02</option><option>Cell 03</option></select>
        <span className="timezone">UTC+1 · London</span><button className="export" onClick={exportCsv}>↓ Export CSV</button>
      </div>}

      <div className="content">
        {page === "Overview" && <>
          <section className="metrics-grid">
            <MetricCard label="Connected users" value={String(summary.connectedUsers)} delta="+3 since 11:30" tone="#e5c07b" series={baseSeries.users} />
            <MetricCard label="Downlink throughput" value={summary.dlBitrate.toFixed(0)} unit="Mbps" delta="+8.2% vs prior hour" tone="#58e7b1" series={baseSeries.dl.slice(0,1)} />
            <MetricCard label="Uplink throughput" value={summary.ulBitrate.toFixed(0)} unit="Mbps" delta="+3.7% vs prior hour" tone="#8aa8ff" series={baseSeries.ul} />
            <MetricCard label="Active cells" value={String(summary.activeCells)} delta="Healthy" tone="#58e7b1" series={[{...baseSeries.users[0], values:[3,3,3,3,3,3,3,3,3,3,3,3]}]} />
          </section>
          <section className="overview-grid">
            <article className="panel throughput-panel">
              <div className="panel-head"><div><span className="eyebrow">NETWORK THROUGHPUT</span><h2>Traffic volume</h2></div><div className="legend"><span><i style={{background:"#58e7b1"}} />Downlink</span><span><i style={{background:"#8aa8ff"}} />Uplink</span></div></div>
              <div className="chart-summary"><b>749<small> Mbps total</small></b><span className="good">↑ 7.4%</span></div>
              <LineChart series={baseSeries.dl} />
              <div className="x-axis">{labels.filter((_,i)=>i%2===0).map(l=><span key={l}>{l}</span>)}</div>
            </article>
            <article className="panel"><div className="panel-head"><div><span className="eyebrow">SITE LOCATION</span><h2>London Lab</h2></div><button className="text-button" onClick={() => setPage("Map")}>Open map ↗</button></div><MiniMap /></article>
          </section>
          <section className="radio-grid">
            <article className="panel radio-card"><span className="eyebrow">RADIO QUALITY</span><div className="radio-stats"><div><b>{summary.avgCqi.toFixed(1)}</b><span>Average CQI</span><small className="good">↑ 0.6</small></div><div><b>{summary.avgSnr.toFixed(1)}<small> dB</small></b><span>Average SNR</span><small className="good">↑ 1.2 dB</small></div><div><b>{summary.retransmissions.toFixed(0)}</b><span>Retransmissions</span><small>0.8% of packets</small></div></div></article>
            <article className="panel cell-health"><div className="panel-head"><div><span className="eyebrow">CELL HEALTH</span><h2>All sectors operational</h2></div><span className="healthy-label">● 3 / 3 healthy</span></div>
              {[["Cell 01","n78 · 100 MHz","246 / 48 Mbps","15 users","92%"],["Cell 02","n78 · 100 MHz","218 / 42 Mbps","6 users","81%"],["Cell 03","B3 · 20 MHz","162 / 33 Mbps","3 users","64%"]].map(r=><div className="cell-row" key={r[0]}><span className="cell-icon">◈</span><div><b>{r[0]}</b><small>{r[1]}</small></div><div className="cell-bar"><i style={{width:r[4]}} /></div><b>{r[2]}</b><span>{r[3]}</span></div>)}
            </article>
          </section>
          <UeTable data={filtered} query={query} setQuery={setQuery} onAll={() => setPage("Live metrics")} />
        </>}

        {page === "Live metrics" && <>
          <section className="live-hero panel"><div><span className="eyebrow">STREAMING NOW</span><h2>Live radio metrics</h2><p>Samples refresh every {interval} seconds from <code>ue_get</code>.</p></div><div className="pulse-ring"><i /></div></section>
          <section className="metrics-grid compact-metrics">
            <MetricCard label="Average CQI" value="12.8" delta="+0.6 over 1h" tone="#b8a1ff" series={baseSeries.cqi} />
            <MetricCard label="PUSCH SNR" value="19.8" unit="dB" delta="+1.2 dB over 1h" tone="#58e7b1" series={baseSeries.snr.slice(0,1)} />
            <MetricCard label="DL retransmissions" value="72" delta="-14.3% over 1h" tone="#ef8f9c" series={baseSeries.retx.slice(0,1)} />
            <MetricCard label="Average DL MCS" value="18.6" delta="+1.1 over 1h" tone="#8aa8ff" series={baseSeries.cqi} />
          </section>
          <article className="panel analytics-panel"><div className="panel-head"><div><span className="eyebrow">LIVE SERIES</span><h2>Metric explorer</h2></div><div className="metric-tabs">{(["dl","users","cqi","snr","retx"] as MetricKey[]).map(m=><button key={m} className={metric===m?"active":""} onClick={()=>setMetric(m)}>{m.toUpperCase()}</button>)}</div></div><LineChart series={baseSeries[metric]} /></article>
          <UeTable data={filtered} query={query} setQuery={setQuery} />
        </>}

        {page === "Map" && <><section className="map-header"><div><span className="eyebrow">LOCATION INTELLIGENCE</span><h2>Site & connected users</h2><p>UE positions without coordinates are estimated within their serving sector.</p></div><div className="playback"><button>◀</button><input type="range" min="0" max="100" defaultValue="100" aria-label="Location history playback" /><button>▶</button><span>12:26:42</span></div></section><MiniMap full /><section className="map-detail-grid"><article className="panel"><span className="eyebrow">SITE</span><h2>London Lab</h2><dl><div><dt>Coordinates</dt><dd>51.5074, −0.1278</dd></div><div><dt>Target</dt><dd>gnb</dd></div><div><dt>Cells</dt><dd>3 active</dd></div><div><dt>Last update</dt><dd>2 seconds ago</dd></div></dl></article><article className="panel"><span className="eyebrow">LOCATION CONFIDENCE</span><h2>1 exact · 23 estimated</h2><p>Estimated markers use configured site coordinates, serving cell sector, path loss and timing advance. They are clearly differentiated from source-provided coordinates.</p></article></section></>}

        {page === "Historical analytics" && <><section className="analytics-intro"><div><span className="eyebrow">HISTORICAL ANALYTICS</span><h2>Explore network behavior</h2><p>Compare KPIs across cells and any retained time range.</p></div><div className="metric-tabs">{(["dl","users","cqi","snr","retx"] as MetricKey[]).map(m=><button key={m} className={metric===m?"active":""} onClick={()=>setMetric(m)}>{m.toUpperCase()}</button>)}</div></section><article className="panel analytics-panel"><div className="panel-head"><div><span className="eyebrow">{range.toUpperCase()}</span><h2>{baseSeries[metric].map(s=>s.label).join(" & ")}</h2></div><div className="legend">{baseSeries[metric].map(s=><span key={s.label}><i style={{background:s.color}} />{s.label}</span>)}</div></div><LineChart series={baseSeries[metric]} /><div className="x-axis">{labels.filter((_,i)=>i%2===0).map(l=><span key={l}>{l}</span>)}</div></article><section className="history-cards"><article className="panel"><span className="eyebrow">PEAK</span><b>762 Mbps</b><p>at 12:18 · Cell 01</p></article><article className="panel"><span className="eyebrow">95TH PERCENTILE</span><b>684 Mbps</b><p>combined downlink</p></article><article className="panel"><span className="eyebrow">SAMPLE COVERAGE</span><b>99.8%</b><p>717 of 720 polls</p></article></section></>}

        {page === "Settings" && <Settings interval={interval} setIntervalValue={setIntervalValue} saved={saved} setSaved={setSaved} />}
      </div>
    </main>
  </div>;
}

function UeTable({ data, query, setQuery, onAll }: { data: typeof ues; query: string; setQuery: (s:string)=>void; onAll?:()=>void }) {
  return <article className="panel table-panel"><div className="panel-head"><div><span className="eyebrow">CONNECTED USERS</span><h2>Current UE state</h2></div><div className="table-actions"><label>⌕<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Filter UEs…" /></label>{onAll && <button className="text-button" onClick={onAll}>View all 24 →</button>}</div></div><div className="table-wrap"><table><thead><tr><th>UE ID</th><th>Serving cell</th><th>RAT</th><th>DL Mbps</th><th>UL Mbps</th><th>CQI</th><th>MCS DL / UL</th><th>SNR dB</th><th>Status</th></tr></thead><tbody>{data.map(u=><tr key={u.id}><td><b>{u.id}</b></td><td>{u.cell}</td><td><span className="rat">{u.rat}</span></td><td>{u.dl}</td><td>{u.ul}</td><td><span className={`quality q${Math.min(3,Math.ceil(u.cqi/5))}`}>{u.cqi}</span></td><td>{u.mcs}</td><td>{u.snr}</td><td><span className={u.state==="Active"?"state":"state warn"}><i />{u.state}</span></td></tr>)}</tbody></table>{data.length===0&&<div className="empty">No UEs match this filter.</div>}</div></article>;
}

function Settings({ interval, setIntervalValue, saved, setSaved }: { interval:number; setIntervalValue:(n:number)=>void; saved:boolean; setSaved:(b:boolean)=>void }) {
  const [target,setTarget]=useState("gnb"); const [command,setCommand]=useState('{"message":"ue_get","stats":true}'); const [agentUrl,setAgentUrl]=useState("https://gnb-agent.example.net"); const [latitude,setLatitude]=useState("51.5074"); const [longitude,setLongitude]=useState("-0.1278"); const [siteName,setSiteName]=useState("London Lab"); const [saveError,setSaveError]=useState("");
  async function save(e:React.FormEvent){e.preventDefault();setSaveError("");try{const response=await fetch("/api/settings",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({intervalSeconds:interval,target,command:JSON.parse(command),agentBaseUrl:agentUrl,latitude:Number(latitude),longitude:Number(longitude),siteName})});if(!response.ok)throw new Error("The remote agent could not be updated");setSaved(true);setTimeout(()=>setSaved(false),2500)}catch(error){setSaveError(error instanceof Error?error.message:"Settings could not be saved")}}
  return <div className="settings-layout"><section><span className="eyebrow">COLLECTION SETTINGS</span><h2>Amarisoft connection</h2><p>Changes apply to the polling worker without discarding historical samples.</p></section><form className="panel settings-form" onSubmit={save}>
    <div className="form-section"><div><b>Polling schedule</b><p>How often Observatory requests a fresh sample.</p></div><label>Interval in seconds<input type="number" min="1" max="3600" value={interval} onChange={e=>setIntervalValue(Math.max(1,Number(e.target.value)))} /></label></div>
    <div className="form-section"><div><b>Remote gNB agent</b><p>The secured Node API running beside Amarisoft and its query payload.</p></div><div className="form-fields"><label>Target<select value={target} onChange={e=>setTarget(e.target.value)}><option>gnb</option><option>enb</option></select></label><label>Command payload<textarea value={command} onChange={e=>setCommand(e.target.value)} rows={3} /></label><label>Agent base URL<input value={agentUrl} onChange={e=>setAgentUrl(e.target.value)} /></label><label>Timeout<input defaultValue="8000" /><small>milliseconds</small></label></div></div>
    <div className="form-section"><div><b>Site coordinates</b><p>Used for the gNB marker and estimated UE sectors.</p></div><div className="coordinate-grid"><label>Latitude<input value={latitude} onChange={e=>setLatitude(e.target.value)} /></label><label>Longitude<input value={longitude} onChange={e=>setLongitude(e.target.value)} /></label><label>Site name<input value={siteName} onChange={e=>setSiteName(e.target.value)} /></label></div></div>
    <div className="form-section"><div><b>Reliability</b><p>Temporary failures retry with exponential backoff.</p></div><div className="coordinate-grid"><label>Maximum retries<input type="number" defaultValue="3" /></label><label>Base backoff<input defaultValue="1000" /><small>milliseconds</small></label></div></div>
    <div className="form-footer"><div className={saveError?"connection-error":"connection-ok"}>{saveError?saveError:<><i /> Connection healthy · last response 2s ago</>}</div><button className="primary" type="submit">{saved?"✓ Saved":"Save settings"}</button></div>
  </form></div>;
}
