# gNB agent

Run this small API on the host that has `ws.js`. Node.js 22 can execute the TypeScript file directly:

```bash
AGENT_TOKEN="replace-with-a-long-random-secret" \
AMARISOFT_WS_PATH="/root/amarisoft/ws.js" \
ALLOWED_TARGETS="gnb,enb" \
node --experimental-strip-types server.ts
```

Expose port `8788` only to the Observatory backend (VPN, private tunnel, or firewall allow-list recommended). The dashboard calls `POST /v1/amarisoft/query` with a bearer token; arbitrary executables and arbitrary targets are never accepted.
