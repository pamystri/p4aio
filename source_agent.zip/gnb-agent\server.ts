import { createServer } from "node:http";
import { execFile } from "node:child_process";
import { hostname } from "node:os";
import { promisify } from "node:util";
import { PollScheduler } from "../lib/poll-scheduler.ts";

const execFileAsync = promisify(execFile);
const port = Number(process.env.PORT ?? 8788);
const token = process.env.AGENT_TOKEN;
const wsPath = process.env.AMARISOFT_WS_PATH ?? "./ws.js";
const timeoutMs = Number(process.env.COMMAND_TIMEOUT_MS ?? 8000);
const allowedTargets = new Set((process.env.ALLOWED_TARGETS ?? "gnb,enb").split(",").map(v => v.trim()));
const observatoryIngestUrl = process.env.OBSERVATORY_INGEST_URL;
const ingestToken = process.env.OBSERVATORY_INGEST_TOKEN;
let pollTarget = process.env.AMARISOFT_TARGET ?? "gnb";
let pollCommand = JSON.parse(process.env.AMARISOFT_COMMAND ?? '{"message":"ue_get","stats":true}');

if (!token) throw new Error("AGENT_TOKEN is required");

async function executeQuery(target: string, command: Record<string, unknown>) {
  if (!allowedTargets.has(target)) throw new Error("invalid_target");
  const started = Date.now();
  const { stdout, stderr } = await execFileAsync(wsPath, [target, JSON.stringify(command)], { timeout: timeoutMs, maxBuffer: 10 * 1024 * 1024 });
  if (stderr.trim()) console.warn(stderr.trim());
  let payload: unknown;
  try { payload = JSON.parse(stdout); } catch { throw new Error("malformed_amarisoft_response"); }
  return { payload, source: { host: hostname(), target, command: command.message, duration_ms: Date.now() - started, captured_at: new Date().toISOString() } };
}

const scheduler = new PollScheduler(async () => {
  if (!observatoryIngestUrl || !ingestToken) return;
  const sample = await executeQuery(pollTarget, pollCommand);
  const result = await fetch(observatoryIngestUrl, { method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${ingestToken}` }, body: JSON.stringify(sample) });
  if (!result.ok) throw new Error(`ingest_failed_${result.status}`);
}, Number(process.env.POLL_INTERVAL_SECONDS ?? 5));
if (observatoryIngestUrl && ingestToken) scheduler.start();

createServer(async (request, response) => {
  response.setHeader("content-type", "application/json");
  if (request.url === "/health") return send(response, 200, { status: "ok", host: hostname(), polling: scheduler.getState(), timestamp: new Date().toISOString() });
  if (request.headers.authorization !== `Bearer ${token}`) return send(response, 401, { error: "unauthorized" });
  try {
    if (request.url === "/v1/poller/settings" && request.method === "GET") return send(response, 200, { ...scheduler.getState(), target: pollTarget, command: pollCommand });
    if (request.url === "/v1/poller/settings" && request.method === "PUT") {
      const body = JSON.parse(await readBody(request)) as { intervalSeconds?: number; target?: string; command?: Record<string, unknown> };
      if (body.target) { if (!allowedTargets.has(body.target)) return send(response, 400, { error: "invalid_target" }); pollTarget = body.target; }
      if (body.command) { if (typeof body.command.message !== "string") return send(response, 400, { error: "invalid_command" }); pollCommand = body.command; }
      if (body.intervalSeconds !== undefined) scheduler.setInterval(body.intervalSeconds);
      return send(response, 200, { ...scheduler.getState(), target: pollTarget, command: pollCommand });
    }
    if (request.method !== "POST" || request.url !== "/v1/amarisoft/query") return send(response, 404, { error: "not_found" });
    const body = JSON.parse(await readBody(request)) as { target?: string; command?: Record<string, unknown> };
    if (!body.target || !allowedTargets.has(body.target)) return send(response, 400, { error: "invalid_target" });
    if (!body.command || typeof body.command.message !== "string") return send(response, 400, { error: "invalid_command" });
    return send(response, 200, await executeQuery(body.target, body.command));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return send(response, message.includes("timed out") ? 504 : 502, { error: "command_failed", message });
  }
}).listen(port, "0.0.0.0", () => console.log(`Amarisoft gNB agent listening on :${port}`));

function send(response: import("node:http").ServerResponse, status: number, body: unknown) { response.writeHead(status); response.end(JSON.stringify(body)); }
async function readBody(request: import("node:http").IncomingMessage) {
  let body = ""; for await (const chunk of request) { body += chunk; if (body.length > 64 * 1024) throw new Error("request_too_large"); } return body;
}
