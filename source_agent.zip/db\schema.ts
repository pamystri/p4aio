import { index, integer, real, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const pollRuns = sqliteTable("poll_runs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  startedAt: integer("started_at", { mode: "timestamp_ms" }).notNull(),
  completedAt: integer("completed_at", { mode: "timestamp_ms" }),
  target: text("target").notNull(),
  command: text("command").notNull(),
  sourceHost: text("source_host"),
  status: text("status", { enum: ["running", "success", "failed"] }).notNull(),
  attemptCount: integer("attempt_count").notNull().default(1),
  durationMs: integer("duration_ms"),
  errorType: text("error_type"),
  errorMessage: text("error_message"),
}, (t) => [index("poll_runs_started_idx").on(t.startedAt), index("poll_runs_status_idx").on(t.status)]);

export const rawPayloads = sqliteTable("raw_payloads", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  runId: integer("run_id").notNull().references(() => pollRuns.id, { onDelete: "cascade" }),
  capturedAt: integer("captured_at", { mode: "timestamp_ms" }).notNull(),
  sourceCommand: text("source_command").notNull(),
  payload: text("payload", { mode: "json" }).notNull(),
  parserVersion: text("parser_version").notNull(),
}, (t) => [index("raw_payload_run_idx").on(t.runId), index("raw_payload_time_idx").on(t.capturedAt)]);

export const cells = sqliteTable("cells", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  externalId: text("external_id").notNull(),
  label: text("label"),
  rat: text("rat"),
  firstSeenAt: integer("first_seen_at", { mode: "timestamp_ms" }).notNull(),
  lastSeenAt: integer("last_seen_at", { mode: "timestamp_ms" }).notNull(),
  latestState: text("latest_state", { mode: "json" }),
}, (t) => [uniqueIndex("cells_external_id_unique").on(t.externalId), index("cells_last_seen_idx").on(t.lastSeenAt)]);

export const ues = sqliteTable("ues", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  externalId: text("external_id").notNull(),
  firstSeenAt: integer("first_seen_at", { mode: "timestamp_ms" }).notNull(),
  lastSeenAt: integer("last_seen_at", { mode: "timestamp_ms" }).notNull(),
  servingCellId: text("serving_cell_id"),
  connected: integer("connected", { mode: "boolean" }).notNull().default(true),
  latestState: text("latest_state", { mode: "json" }),
}, (t) => [uniqueIndex("ues_external_id_unique").on(t.externalId), index("ues_last_seen_idx").on(t.lastSeenAt), index("ues_cell_idx").on(t.servingCellId)]);

export const cellMetrics = sqliteTable("cell_metrics_timeseries", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  runId: integer("run_id").notNull().references(() => pollRuns.id, { onDelete: "cascade" }),
  capturedAt: integer("captured_at", { mode: "timestamp_ms" }).notNull(),
  cellId: text("cell_id").notNull(),
  dlBitrate: real("dl_bitrate"), ulBitrate: real("ul_bitrate"),
  dlTx: real("dl_tx"), ulTx: real("ul_tx"), dlErr: real("dl_err"), ulErr: real("ul_err"),
  dlRetx: real("dl_retx"), ulRetx: real("ul_retx"),
  connectedUes: integer("connected_ues"),
  extra: text("extra", { mode: "json" }),
}, (t) => [index("cell_metrics_time_idx").on(t.capturedAt), index("cell_metrics_cell_time_idx").on(t.cellId, t.capturedAt), index("cell_metrics_run_idx").on(t.runId)]);

export const ueMetrics = sqliteTable("ue_metrics_timeseries", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  runId: integer("run_id").notNull().references(() => pollRuns.id, { onDelete: "cascade" }),
  capturedAt: integer("captured_at", { mode: "timestamp_ms" }).notNull(),
  ueId: text("ue_id").notNull(), cellId: text("cell_id"),
  dlBitrate: real("dl_bitrate"), ulBitrate: real("ul_bitrate"),
  dlTx: real("dl_tx"), ulTx: real("ul_tx"), dlErr: real("dl_err"), ulErr: real("ul_err"),
  dlRetx: real("dl_retx"), ulRetx: real("ul_retx"),
  puschSnr: real("pusch_snr"), epre: real("epre"), ulPhr: real("ul_phr"), ulPathLoss: real("ul_path_loss"),
  pUe: real("p_ue"), ulRank: real("ul_rank"), dlMcs: real("dl_mcs"), ulMcs: real("ul_mcs"),
  ulLayerCount: real("ul_n_layer"), turboDecoderMin: real("turbo_decoder_min"),
  turboDecoderAvg: real("turbo_decoder_avg"), turboDecoderMax: real("turbo_decoder_max"),
  cqi: real("cqi"), ri: real("ri"), initialTa: real("initial_ta"),
  ueUlBwpId: text("ue_ul_bwp_id"), ulBwpId: text("ul_bwp_id"),
  ueDlBwpId: text("ue_dl_bwp_id"), dlBwpId: text("dl_bwp_id"),
  latitude: real("latitude"), longitude: real("longitude"),
  locationAccuracy: text("location_accuracy", { enum: ["exact", "estimated", "unknown"] }),
  extra: text("extra", { mode: "json" }),
}, (t) => [index("ue_metrics_time_idx").on(t.capturedAt), index("ue_metrics_ue_time_idx").on(t.ueId, t.capturedAt), index("ue_metrics_cell_time_idx").on(t.cellId, t.capturedAt), index("ue_metrics_run_idx").on(t.runId)]);

export const siteLocations = sqliteTable("site_locations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(), latitude: real("latitude").notNull(), longitude: real("longitude").notNull(),
  sectorAzimuths: text("sector_azimuths", { mode: "json" }),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull(),
});

export const settings = sqliteTable("settings", {
  id: integer("id").primaryKey().default(1),
  pollIntervalSeconds: integer("poll_interval_seconds").notNull().default(5),
  target: text("target").notNull().default("gnb"),
  command: text("command").notNull().default('{"message":"ue_get","stats":true}'),
  agentBaseUrl: text("agent_base_url"),
  requestTimeoutMs: integer("request_timeout_ms").notNull().default(8000),
  maxRetries: integer("max_retries").notNull().default(3),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull(),
});
