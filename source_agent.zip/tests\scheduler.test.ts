import assert from "node:assert/strict";
import test from "node:test";
import { PollScheduler } from "../lib/poll-scheduler.ts";

test("normalizes interval and exposes health state",()=>{
  const scheduler=new PollScheduler(async()=>{},0); assert.equal(scheduler.getState().intervalSeconds,1);
  scheduler.setInterval(7.9); assert.equal(scheduler.getState().intervalSeconds,7);
  scheduler.stop(); assert.equal(scheduler.getState().running,false);
});
