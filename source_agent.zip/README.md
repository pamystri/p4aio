# Amarisoft Observatory

A full-stack monitoring dashboard for Amarisoft gNB/eNB installations. A small, dependency-free Node agent runs on the Amarisoft host, executes `ws.js`, and sends samples to the Observatory web backend. Observatory preserves the original payload and normalized cell/UE time series in a relational database.

## Architecture

```text
Amarisoft host                         Observatory
┌─────────────────────────┐           ┌─────────────────────────────┐
│ ws.js ← Node gNB agent  │── HTTPS ─▶│ ingest/query API → D1/SQLite│
│ scheduler + retry health│◀ settings │ REST API → dashboard        │
└─────────────────────────┘           └─────────────────────────────┘
```

The gNB agent is the only component that needs access to `ws.js`. It accepts a narrow authenticated API rather than arbitrary shell commands. It can either answer on-demand queries or poll on its own schedule and push samples to `/api/ingest`.

## Quick start

### 1. Observatory dashboard

Copy `.env.example` to `.env.local`, set the gNB agent URL and secrets, then:

```bash
npm ci
npm run dev
```

Open the local URL printed by the development server. Local persistence uses the platform's D1-compatible SQLite database. The checked-in migrations create all tables and seed the site location/settings; the interface displays realistic demo telemetry until real samples arrive.

### 2. gNB agent

Copy `gnb-agent/server.ts` and `lib/poll-scheduler.ts` to the Amarisoft host (preserving the relative folders), then run with Node.js 22:

```bash
AGENT_TOKEN="long-random-agent-secret" \
AMARISOFT_WS_PATH="/root/amarisoft/ws.js" \
AMARISOFT_TARGET="gnb" \
POLL_INTERVAL_SECONDS="5" \
OBSERVATORY_INGEST_URL="https://your-observatory.example/api/ingest" \
OBSERVATORY_INGEST_TOKEN="long-random-ingest-secret" \
node --experimental-strip-types gnb-agent/server.ts
```

The agent invokes the equivalent of:

```bash
./ws.js gnb '{"message":"ue_get","stats":true}'
```

Use a VPN/private tunnel or firewall allow-list for port 8788. Keep both tokens out of source control.

## Configuration

`POLL_INTERVAL_SECONDS` supplies the initial interval. Settings in the web UI are forwarded to the agent at runtime through `PUT /v1/poller/settings`. The minimum is one second. A poll never overlaps the previous run; failures back off exponentially up to 60 seconds and resume automatically.

Important settings:

| Variable | Purpose | Default |
|---|---|---|
| `AGENT_BASE_URL` | Public/private HTTPS address of the gNB agent | required |
| `AGENT_TOKEN` | Dashboard-to-agent bearer token | required |
| `INGEST_TOKEN` | Agent-to-dashboard bearer token | required |
| `AMARISOFT_WS_PATH` | `ws.js` path on the gNB | `./ws.js` |
| `AMARISOFT_TARGET` | `gnb` or `enb` | `gnb` |
| `POLL_INTERVAL_SECONDS` | Sampling period | `5` |
| `COMMAND_TIMEOUT_MS` | Maximum `ws.js` runtime | `8000` |

## API

- `POST /api/ingest` validates and stores a raw agent envelope plus normalized metrics.
- `GET /api/overview` returns latest health, summaries, cells and UEs.
- `GET /api/history?from=&to=&cell=&ue=` returns filtered time-series samples.
- `GET /api/export?from=&to=` streams CSV.
- `GET /api/health` reports collector freshness and the last error.
- `GET|PUT /api/settings` reads or updates the database and live agent schedule.
- Agent: `POST /v1/amarisoft/query`, `GET|PUT /v1/poller/settings`, and `GET /health`.

## Data model

`poll_runs` records timing, attempts and errors. `raw_payloads` preserves the exact vendor response. `cells` and `ues` hold latest state, while `cell_metrics_timeseries` and `ue_metrics_timeseries` hold history. `site_locations` stores configured coordinates. Unknown Amarisoft keys remain in each row's `extra` JSON so new firmware fields are not lost.

The parser accepts alternate UE/cell identifiers, nested containers, numeric strings, sparse records and unknown future fields. Precise UE coordinates are used when supplied; otherwise the UI labels the sector-based position as estimated.

## Tests

```bash
npm test
npm run build
```

Tests cover parser resilience, scheduler configuration and the presence of the key API contracts.
