import { env } from "cloudflare:workers";

type Bindings = { DB:D1Database; AGENT_BASE_URL?:string; AGENT_TOKEN?:string };

export async function GET() {
  const bindings = env as unknown as Bindings;
  const value = await bindings.DB.prepare("SELECT * FROM settings WHERE id=1").first();
  return Response.json(value ?? { poll_interval_seconds: 5, target: "gnb", command: '{"message":"ue_get","stats":true}', agent_base_url: bindings.AGENT_BASE_URL ?? null, request_timeout_ms: 8000, max_retries: 3 });
}

export async function PUT(request: Request) {
  const bindings = env as unknown as Bindings;
  const body = await request.json() as { intervalSeconds?:number; target?:string; command?:Record<string,unknown>; agentBaseUrl?:string; latitude?:number; longitude?:number; siteName?:string };
  const interval = Math.max(1, Math.min(3600, Math.floor(Number(body.intervalSeconds ?? 5))));
  const target = body.target === "enb" ? "enb" : "gnb";
  const command = body.command && typeof body.command.message === "string" ? body.command : { message: "ue_get", stats: true };
  const agentBaseUrl = body.agentBaseUrl ?? bindings.AGENT_BASE_URL ?? "";
  if (agentBaseUrl && bindings.AGENT_TOKEN) {
    const response = await fetch(`${agentBaseUrl.replace(/\/$/,"")}/v1/poller/settings`, { method:"PUT", headers:{"content-type":"application/json",authorization:`Bearer ${bindings.AGENT_TOKEN}`}, body:JSON.stringify({ intervalSeconds:interval,target,command }) });
    if (!response.ok) return Response.json({ error:"agent_update_failed", status:response.status }, { status:502 });
  }
  await bindings.DB.prepare("INSERT INTO settings (id,poll_interval_seconds,target,command,agent_base_url,request_timeout_ms,max_retries,updated_at) VALUES (1,?,?,?,?,8000,3,?) ON CONFLICT(id) DO UPDATE SET poll_interval_seconds=excluded.poll_interval_seconds,target=excluded.target,command=excluded.command,agent_base_url=excluded.agent_base_url,updated_at=excluded.updated_at")
    .bind(interval,target,JSON.stringify(command),agentBaseUrl,Date.now()).run();
  if (typeof body.latitude === "number" && Number.isFinite(body.latitude) && typeof body.longitude === "number" && Number.isFinite(body.longitude)) {
    await bindings.DB.prepare("INSERT INTO site_locations (name,latitude,longitude,sector_azimuths,updated_at) VALUES (?,?,?,?,?)").bind(body.siteName ?? "Amarisoft site",body.latitude,body.longitude,JSON.stringify([0,120,240]),Date.now()).run();
  }
  return Response.json({ ok:true, pollIntervalSeconds:interval, target, command, agentBaseUrl });
}
