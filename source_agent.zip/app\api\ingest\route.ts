import { env } from "cloudflare:workers";
import { parseAmarisoftPayload, PARSER_VERSION } from "../../../lib/amarisoft-parser";

type Env = { DB: D1Database; INGEST_TOKEN?: string };
const metricKeys = ["dl_bitrate","ul_bitrate","dl_tx","ul_tx","dl_err","ul_err","dl_retx","ul_retx"] as const;
const ueKeys = ["pusch_snr","epre","ul_phr","ul_path_loss","p_ue","ul_rank","dl_mcs","ul_mcs","ul_n_layer","turbo_decoder_min","turbo_decoder_avg","turbo_decoder_max","cqi","ri","initial_ta"] as const;

export async function POST(request: Request) {
  const bindings = env as unknown as Env;
  if (bindings.INGEST_TOKEN && request.headers.get("authorization") !== `Bearer ${bindings.INGEST_TOKEN}`) return Response.json({ error: "unauthorized" }, { status: 401 });
  const started = Date.now();
  try {
    const envelope = await request.json() as { payload?: unknown; source?: Record<string, unknown> };
    if (envelope.payload === undefined) return Response.json({ error: "payload_required" }, { status: 400 });
    const parsed = parseAmarisoftPayload(envelope.payload);
    const capturedAt = Date.parse(String(envelope.source?.captured_at ?? "")) || Date.now();
    const target = String(envelope.source?.target ?? "gnb");
    const command = String(envelope.source?.command ?? "ue_get");
    const run = await bindings.DB.prepare("INSERT INTO poll_runs (started_at, completed_at, target, command, source_host, status, attempt_count, duration_ms) VALUES (?, ?, ?, ?, ?, 'success', 1, ?) RETURNING id")
      .bind(started, Date.now(), target, command, String(envelope.source?.host ?? ""), Number(envelope.source?.duration_ms ?? Date.now() - started)).first<{id:number}>();
    if (!run) throw new Error("Could not create poll run");
    const statements = [
      bindings.DB.prepare("INSERT INTO raw_payloads (run_id, captured_at, source_command, payload, parser_version) VALUES (?, ?, ?, ?, ?)").bind(run.id, capturedAt, command, JSON.stringify(envelope.payload), PARSER_VERSION),
      ...parsed.cells.flatMap(cell => {
        const id = String(cell.cell_id);
        const extras = omit(cell, ["cell_id", ...metricKeys]);
        return [
          bindings.DB.prepare("INSERT INTO cells (external_id, label, rat, first_seen_at, last_seen_at, latest_state) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(external_id) DO UPDATE SET label=excluded.label, rat=excluded.rat, last_seen_at=excluded.last_seen_at, latest_state=excluded.latest_state").bind(id, stringOrNull(cell.label ?? cell.name), stringOrNull(cell.rat), capturedAt, capturedAt, JSON.stringify(cell)),
          bindings.DB.prepare("INSERT INTO cell_metrics_timeseries (run_id, captured_at, cell_id, dl_bitrate, ul_bitrate, dl_tx, ul_tx, dl_err, ul_err, dl_retx, ul_retx, connected_ues, extra) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").bind(run.id,capturedAt,id,...metricKeys.map(k=>numberOrNull(cell[k])),numberOrNull(cell.connected_ues),JSON.stringify(extras)),
        ];
      }),
      ...parsed.ues.flatMap(ue => {
        const id = String(ue.ue_id); const cellId = stringOrNull(ue.cell_id);
        const extras = omit(ue, ["ue_id","cell_id",...metricKeys,...ueKeys]);
        return [
          bindings.DB.prepare("INSERT INTO ues (external_id, first_seen_at, last_seen_at, serving_cell_id, connected, latest_state) VALUES (?, ?, ?, ?, 1, ?) ON CONFLICT(external_id) DO UPDATE SET last_seen_at=excluded.last_seen_at, serving_cell_id=excluded.serving_cell_id, connected=1, latest_state=excluded.latest_state").bind(id,capturedAt,capturedAt,cellId,JSON.stringify(ue)),
          bindings.DB.prepare("INSERT INTO ue_metrics_timeseries (run_id,captured_at,ue_id,cell_id,dl_bitrate,ul_bitrate,dl_tx,ul_tx,dl_err,ul_err,dl_retx,ul_retx,pusch_snr,epre,ul_phr,ul_path_loss,p_ue,ul_rank,dl_mcs,ul_mcs,ul_n_layer,turbo_decoder_min,turbo_decoder_avg,turbo_decoder_max,cqi,ri,initial_ta,ue_ul_bwp_id,ul_bwp_id,ue_dl_bwp_id,dl_bwp_id,latitude,longitude,location_accuracy,extra) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
            .bind(run.id,capturedAt,id,cellId,...metricKeys.map(k=>numberOrNull(ue[k])),...ueKeys.map(k=>numberOrNull(ue[k])),stringOrNull(ue.ue_ul_bwp_id),stringOrNull(ue.ul_bwp_id),stringOrNull(ue.ue_dl_bwp_id),stringOrNull(ue.dl_bwp_id),numberOrNull(ue.latitude ?? ue.lat),numberOrNull(ue.longitude ?? ue.lon),ue.latitude !== undefined || ue.lat !== undefined ? "exact" : "estimated",JSON.stringify(extras)),
        ];
      }),
    ];
    await bindings.DB.batch(statements);
    return Response.json({ runId: run.id, capturedAt, cells: parsed.cells.length, ues: parsed.ues.length });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    try { await bindings.DB.prepare("INSERT INTO poll_runs (started_at, completed_at, target, command, status, error_type, error_message) VALUES (?, ?, 'unknown', 'unknown', 'failed', 'ingest', ?)").bind(started,Date.now(),message.slice(0,1000)).run(); } catch {}
    return Response.json({ error: "ingest_failed", message }, { status: 422 });
  }
}

function numberOrNull(value: unknown) { const n = Number(value); return value === null || value === undefined || !Number.isFinite(n) ? null : n; }
function stringOrNull(value: unknown) { return value === null || value === undefined ? null : String(value); }
function omit(value: Record<string, unknown>, keys: readonly string[]) { const blocked=new Set(keys); return Object.fromEntries(Object.entries(value).filter(([k])=>!blocked.has(k))); }
