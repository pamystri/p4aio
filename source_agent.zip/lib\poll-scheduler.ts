export type SchedulerState = {
  running: boolean; intervalSeconds: number; consecutiveFailures: number;
  lastStartedAt?: string; lastSucceededAt?: string; lastError?: string;
};

export class PollScheduler {
  private timer?: ReturnType<typeof setTimeout>;
  private stopped = true;
  private state: SchedulerState;
  private task: () => Promise<void>;
  private maxBackoffSeconds: number;

  constructor(task: () => Promise<void>, intervalSeconds: number, maxBackoffSeconds = 60) {
    this.task = task;
    this.maxBackoffSeconds = maxBackoffSeconds;
    this.state = { running: false, intervalSeconds: Math.max(1, intervalSeconds), consecutiveFailures: 0 };
  }
  start() { if (!this.stopped) return; this.stopped = false; this.schedule(0); }
  stop() { this.stopped = true; if (this.timer) clearTimeout(this.timer); this.timer = undefined; }
  setInterval(seconds: number) { this.state.intervalSeconds = Math.max(1, Math.floor(seconds)); if (!this.stopped) { if (this.timer) clearTimeout(this.timer); this.schedule(0); } }
  getState(): SchedulerState { return { ...this.state }; }
  private schedule(delayMs: number) { if (!this.stopped) this.timer = setTimeout(() => void this.run(), delayMs); }
  private async run() {
    if (this.state.running || this.stopped) return;
    this.state.running = true; this.state.lastStartedAt = new Date().toISOString();
    try {
      await this.task(); this.state.consecutiveFailures = 0; this.state.lastSucceededAt = new Date().toISOString(); this.state.lastError = undefined;
    } catch (error) {
      this.state.consecutiveFailures++; this.state.lastError = error instanceof Error ? error.message : String(error);
    } finally {
      this.state.running = false;
      const backoff = Math.min(this.maxBackoffSeconds, this.state.intervalSeconds * 2 ** this.state.consecutiveFailures);
      this.schedule((this.state.consecutiveFailures ? backoff : this.state.intervalSeconds) * 1000);
    }
  }
}
