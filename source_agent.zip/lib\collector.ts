import { parseAmarisoftPayload, PARSER_VERSION } from "./amarisoft-parser";

export type CollectorConfig = {
  agentBaseUrl: string; agentToken: string; target: string; command: Record<string, unknown>;
  timeoutMs: number; maxRetries: number; baseBackoffMs?: number;
};

export async function collectFromAgent(config: CollectorConfig, fetcher: typeof fetch = fetch) {
  let lastError: Error | undefined;
  for (let attempt = 1; attempt <= config.maxRetries + 1; attempt++) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), config.timeoutMs);
    try {
      const response = await fetcher(`${config.agentBaseUrl.replace(/\/$/, "")}/v1/amarisoft/query`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${config.agentToken}` },
        body: JSON.stringify({ target: config.target, command: config.command }),
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`gNB agent returned HTTP ${response.status}`);
      const envelope = await response.json() as { payload?: unknown; source?: Record<string, unknown> };
      if (envelope.payload === undefined) throw new Error("gNB agent response is missing payload");
      return { raw: envelope.payload, parsed: parseAmarisoftPayload(envelope.payload), source: envelope.source ?? {}, attempts: attempt, parserVersion: PARSER_VERSION };
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      if (attempt <= config.maxRetries) await new Promise(resolve => setTimeout(resolve, (config.baseBackoffMs ?? 500) * 2 ** (attempt - 1)));
    } finally { clearTimeout(timeout); }
  }
  throw lastError ?? new Error("Collector failed");
}
