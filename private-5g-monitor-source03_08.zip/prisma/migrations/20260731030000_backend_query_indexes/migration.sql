CREATE INDEX "radio_observation_metric_definition_id_observed_at_idx"
  ON "radio_observation"("metric_definition_id", "observed_at" DESC);

CREATE INDEX "radio_observation_observed_at_brin_idx"
  ON "radio_observation" USING BRIN ("observed_at") WITH (pages_per_range = 32);

CREATE INDEX "domain_event_occurred_at_brin_idx"
  ON "domain_event" USING BRIN ("occurred_at") WITH (pages_per_range = 32);

CREATE INDEX "collection_run_radio_target_id_status_started_at_idx"
  ON "collection_run"("radio_target_id", "status", "started_at" DESC);

ALTER TABLE "domain_event" ALTER COLUMN "raw_observation_id" DROP NOT NULL;
