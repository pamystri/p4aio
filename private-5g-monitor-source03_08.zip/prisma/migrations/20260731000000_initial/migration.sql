CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TYPE "ConnectorStatus" AS ENUM ('INSTALLED', 'ENABLED', 'DISABLED', 'INCOMPATIBLE');
CREATE TYPE "CollectionRunStatus" AS ENUM ('QUEUED', 'RUNNING', 'SUCCEEDED', 'PARTIAL', 'FAILED', 'CANCELLED', 'INTERRUPTED');
CREATE TYPE "ParseStatus" AS ENUM ('UNPARSED', 'PARSED', 'PARTIAL', 'FAILED');
CREATE TYPE "MetricValueType" AS ENUM ('DOUBLE', 'INTEGER', 'BOOLEAN', 'TEXT', 'JSON');

CREATE TABLE "site" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "name" TEXT NOT NULL,
  "slug" TEXT NOT NULL,
  "time_zone" TEXT NOT NULL,
  "latitude" DOUBLE PRECISION,
  "longitude" DOUBLE PRECISION,
  "altitude_m" DOUBLE PRECISION,
  "attributes" JSONB NOT NULL DEFAULT '{}',
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "site_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "site_latitude_check" CHECK ("latitude" IS NULL OR "latitude" BETWEEN -90 AND 90),
  CONSTRAINT "site_longitude_check" CHECK ("longitude" IS NULL OR "longitude" BETWEEN -180 AND 180)
);

CREATE TABLE "connector_installation" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "connector_key" TEXT NOT NULL,
  "version" TEXT NOT NULL,
  "sdk_version" TEXT NOT NULL,
  "manifest" JSONB NOT NULL,
  "package_checksum" TEXT NOT NULL,
  "status" "ConnectorStatus" NOT NULL DEFAULT 'INSTALLED',
  "installed_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "connector_installation_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "radio_target" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "site_id" UUID NOT NULL,
  "connector_installation_id" UUID NOT NULL,
  "name" TEXT NOT NULL,
  "management_host" TEXT NOT NULL,
  "management_port" INTEGER NOT NULL,
  "enabled" BOOLEAN NOT NULL DEFAULT false,
  "config" JSONB NOT NULL DEFAULT '{}',
  "secret_ref" TEXT,
  "config_version" INTEGER NOT NULL DEFAULT 1,
  "last_success_at" TIMESTAMPTZ(6),
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "radio_target_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "radio_target_port_check" CHECK ("management_port" BETWEEN 1 AND 65535),
  CONSTRAINT "radio_target_config_version_check" CHECK ("config_version" > 0)
);

CREATE TABLE "cell" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "radio_target_id" UUID NOT NULL,
  "vendor_cell_key" TEXT NOT NULL,
  "display_name" TEXT NOT NULL,
  "technology" TEXT NOT NULL,
  "nci" DECIMAL(20,0),
  "pci" INTEGER,
  "arfcn" INTEGER,
  "band" TEXT,
  "latitude" DOUBLE PRECISION,
  "longitude" DOUBLE PRECISION,
  "altitude_m" DOUBLE PRECISION,
  "antenna_height_m" DOUBLE PRECISION,
  "azimuth_deg" DOUBLE PRECISION,
  "beamwidth_deg" DOUBLE PRECISION,
  "attributes" JSONB NOT NULL DEFAULT '{}',
  "first_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "last_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "cell_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "cell_latitude_check" CHECK ("latitude" IS NULL OR "latitude" BETWEEN -90 AND 90),
  CONSTRAINT "cell_longitude_check" CHECK ("longitude" IS NULL OR "longitude" BETWEEN -180 AND 180),
  CONSTRAINT "cell_azimuth_check" CHECK ("azimuth_deg" IS NULL OR "azimuth_deg" >= 0 AND "azimuth_deg" < 360),
  CONSTRAINT "cell_beamwidth_check" CHECK ("beamwidth_deg" IS NULL OR "beamwidth_deg" > 0 AND "beamwidth_deg" <= 360)
);

CREATE TABLE "ue" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "pseudonym" TEXT NOT NULL,
  "identity_type" TEXT NOT NULL,
  "identity_fingerprint" BYTEA,
  "identity_ciphertext" BYTEA,
  "attributes" JSONB NOT NULL DEFAULT '{}',
  "first_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "last_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ue_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "poll_schedule" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "radio_target_id" UUID NOT NULL,
  "logical_operation" TEXT NOT NULL,
  "interval_ms" INTEGER NOT NULL,
  "timeout_ms" INTEGER NOT NULL,
  "jitter_percent" DOUBLE PRECISION NOT NULL DEFAULT 10,
  "priority" INTEGER NOT NULL DEFAULT 100,
  "enabled" BOOLEAN NOT NULL DEFAULT false,
  "next_due_at" TIMESTAMPTZ(6) NOT NULL,
  "version" INTEGER NOT NULL DEFAULT 1,
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "poll_schedule_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "poll_schedule_interval_check" CHECK ("interval_ms" >= 250),
  CONSTRAINT "poll_schedule_timeout_check" CHECK ("timeout_ms" > 0),
  CONSTRAINT "poll_schedule_jitter_check" CHECK ("jitter_percent" BETWEEN 0 AND 50)
);

CREATE TABLE "collection_run" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "poll_schedule_id" UUID,
  "radio_target_id" UUID NOT NULL,
  "logical_operation" TEXT NOT NULL,
  "nominal_due_at" TIMESTAMPTZ(6),
  "started_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "finished_at" TIMESTAMPTZ(6),
  "status" "CollectionRunStatus" NOT NULL DEFAULT 'QUEUED',
  "attempt" INTEGER NOT NULL DEFAULT 1,
  "connector_key" TEXT NOT NULL,
  "connector_version" TEXT NOT NULL,
  "parser_version" TEXT,
  "config_version" INTEGER NOT NULL,
  "error_category" TEXT,
  "error_code" TEXT,
  "error_message_redacted" TEXT,
  "timings" JSONB NOT NULL DEFAULT '{}',
  CONSTRAINT "collection_run_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "collection_run_attempt_check" CHECK ("attempt" > 0)
);

CREATE TABLE "raw_observation" (
  "id" BIGSERIAL NOT NULL,
  "collection_run_id" UUID NOT NULL,
  "radio_target_id" UUID NOT NULL,
  "logical_operation" TEXT NOT NULL,
  "sequence_no" INTEGER NOT NULL DEFAULT 0,
  "observed_at" TIMESTAMPTZ(6) NOT NULL,
  "received_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "payload" JSONB NOT NULL,
  "payload_sha256" BYTEA NOT NULL,
  "payload_bytes" INTEGER NOT NULL,
  "content_schema_version" TEXT,
  "parser_version" TEXT,
  "parse_status" "ParseStatus" NOT NULL DEFAULT 'UNPARSED',
  "parse_diagnostics" JSONB NOT NULL DEFAULT '{}',
  CONSTRAINT "raw_observation_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "raw_observation_size_check" CHECK ("payload_bytes" >= 0),
  CONSTRAINT "raw_observation_sequence_check" CHECK ("sequence_no" >= 0)
);

CREATE TABLE "metric_definition" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "namespace" TEXT NOT NULL,
  "key" TEXT NOT NULL,
  "display_name" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "entity_type" TEXT NOT NULL,
  "semantic_type" TEXT NOT NULL,
  "value_type" "MetricValueType" NOT NULL,
  "unit" TEXT NOT NULL,
  "aggregation" TEXT NOT NULL,
  "allowed_dimensions" JSONB NOT NULL DEFAULT '{}',
  "canonical" BOOLEAN NOT NULL DEFAULT true,
  "definition_version" INTEGER NOT NULL DEFAULT 1,
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "deprecated_at" TIMESTAMPTZ(6),
  CONSTRAINT "metric_definition_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "metric_definition_version_check" CHECK ("definition_version" > 0)
);

CREATE TABLE "radio_observation" (
  "id" BIGSERIAL NOT NULL,
  "observed_at" TIMESTAMPTZ(6) NOT NULL,
  "metric_definition_id" UUID NOT NULL,
  "radio_target_id" UUID NOT NULL,
  "cell_id" UUID,
  "ue_id" UUID,
  "raw_observation_id" BIGINT NOT NULL,
  "collection_run_id" UUID NOT NULL,
  "value_double" DOUBLE PRECISION,
  "value_integer" BIGINT,
  "value_boolean" BOOLEAN,
  "value_text" TEXT,
  "value_json" JSONB,
  "dimensions" JSONB NOT NULL DEFAULT '{}',
  "dimension_hash" BYTEA NOT NULL,
  "quality_flags" INTEGER NOT NULL DEFAULT 0,
  "parser_version" TEXT NOT NULL,
  CONSTRAINT "radio_observation_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "radio_observation_one_value_check" CHECK (
    num_nonnulls("value_double", "value_integer", "value_boolean", "value_text", "value_json") = 1
  )
);

CREATE TABLE "location_estimate" (
  "id" BIGSERIAL NOT NULL,
  "estimated_at" TIMESTAMPTZ(6) NOT NULL,
  "ue_id" UUID NOT NULL,
  "serving_cell_id" UUID,
  "latitude" DOUBLE PRECISION NOT NULL,
  "longitude" DOUBLE PRECISION NOT NULL,
  "altitude_m" DOUBLE PRECISION,
  "horizontal_accuracy_m" DOUBLE PRECISION NOT NULL,
  "confidence" DOUBLE PRECISION,
  "method" TEXT NOT NULL,
  "evidence_window_start" TIMESTAMPTZ(6) NOT NULL,
  "evidence_window_end" TIMESTAMPTZ(6) NOT NULL,
  "algorithm_version" TEXT NOT NULL,
  "configuration_version" INTEGER NOT NULL,
  "quality_flags" INTEGER NOT NULL DEFAULT 0,
  "details" JSONB NOT NULL DEFAULT '{}',
  CONSTRAINT "location_estimate_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "location_estimate_latitude_check" CHECK ("latitude" BETWEEN -90 AND 90),
  CONSTRAINT "location_estimate_longitude_check" CHECK ("longitude" BETWEEN -180 AND 180),
  CONSTRAINT "location_estimate_accuracy_check" CHECK ("horizontal_accuracy_m" >= 0),
  CONSTRAINT "location_estimate_confidence_check" CHECK ("confidence" IS NULL OR "confidence" BETWEEN 0 AND 1),
  CONSTRAINT "location_estimate_window_check" CHECK ("evidence_window_end" >= "evidence_window_start")
);

CREATE TABLE "location_evidence" (
  "location_estimate_id" BIGINT NOT NULL,
  "radio_observation_id" BIGINT NOT NULL,
  "evidence_role" TEXT NOT NULL,
  "weight" DOUBLE PRECISION,
  CONSTRAINT "location_evidence_pkey" PRIMARY KEY ("location_estimate_id", "radio_observation_id")
);

CREATE TABLE "user_account" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "username" TEXT NOT NULL,
  "password_hash" TEXT,
  "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "user_account_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "audit_event" (
  "id" BIGSERIAL NOT NULL,
  "occurred_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "actor_id" UUID,
  "action" TEXT NOT NULL,
  "resource_type" TEXT NOT NULL,
  "resource_id" TEXT,
  "result" TEXT NOT NULL,
  "correlation_id" TEXT,
  "details" JSONB NOT NULL DEFAULT '{}',
  CONSTRAINT "audit_event_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "site_slug_key" ON "site"("slug");
CREATE UNIQUE INDEX "connector_installation_connector_key_version_key" ON "connector_installation"("connector_key", "version");
CREATE UNIQUE INDEX "radio_target_site_id_name_key" ON "radio_target"("site_id", "name");
CREATE INDEX "radio_target_enabled_site_id_idx" ON "radio_target"("enabled", "site_id");
CREATE INDEX "radio_target_connector_installation_id_idx" ON "radio_target"("connector_installation_id");
CREATE UNIQUE INDEX "cell_radio_target_id_vendor_cell_key_key" ON "cell"("radio_target_id", "vendor_cell_key");
CREATE INDEX "cell_nci_idx" ON "cell"("nci");
CREATE INDEX "cell_radio_target_id_last_seen_at_idx" ON "cell"("radio_target_id", "last_seen_at" DESC);
CREATE UNIQUE INDEX "ue_pseudonym_key" ON "ue"("pseudonym");
CREATE UNIQUE INDEX "ue_identity_type_identity_fingerprint_key" ON "ue"("identity_type", "identity_fingerprint");
CREATE INDEX "ue_last_seen_at_idx" ON "ue"("last_seen_at" DESC);
CREATE UNIQUE INDEX "poll_schedule_radio_target_id_logical_operation_key" ON "poll_schedule"("radio_target_id", "logical_operation");
CREATE INDEX "poll_schedule_enabled_next_due_at_priority_idx" ON "poll_schedule"("enabled", "next_due_at", "priority" DESC);
CREATE INDEX "collection_run_radio_target_id_started_at_idx" ON "collection_run"("radio_target_id", "started_at" DESC);
CREATE INDEX "collection_run_status_started_at_idx" ON "collection_run"("status", "started_at" DESC);
CREATE INDEX "collection_run_poll_schedule_id_nominal_due_at_idx" ON "collection_run"("poll_schedule_id", "nominal_due_at" DESC);
CREATE UNIQUE INDEX "raw_observation_collection_run_id_sequence_no_key" ON "raw_observation"("collection_run_id", "sequence_no");
CREATE INDEX "raw_observation_radio_target_id_observed_at_idx" ON "raw_observation"("radio_target_id", "observed_at" DESC);
CREATE INDEX "raw_observation_collection_run_id_idx" ON "raw_observation"("collection_run_id");
CREATE UNIQUE INDEX "metric_definition_namespace_key_definition_version_key" ON "metric_definition"("namespace", "key", "definition_version");
CREATE INDEX "metric_definition_entity_type_canonical_idx" ON "metric_definition"("entity_type", "canonical");
CREATE INDEX "radio_observation_ue_id_metric_definition_id_observed_at_idx" ON "radio_observation"("ue_id", "metric_definition_id", "observed_at" DESC);
CREATE INDEX "radio_observation_cell_id_metric_definition_id_observed_at_idx" ON "radio_observation"("cell_id", "metric_definition_id", "observed_at" DESC);
CREATE INDEX "radio_observation_radio_target_id_observed_at_idx" ON "radio_observation"("radio_target_id", "observed_at" DESC);
CREATE INDEX "radio_observation_raw_observation_id_idx" ON "radio_observation"("raw_observation_id");
CREATE INDEX "location_estimate_ue_id_estimated_at_idx" ON "location_estimate"("ue_id", "estimated_at" DESC);
CREATE INDEX "location_estimate_serving_cell_id_estimated_at_idx" ON "location_estimate"("serving_cell_id", "estimated_at" DESC);
CREATE INDEX "location_evidence_radio_observation_id_idx" ON "location_evidence"("radio_observation_id");
CREATE UNIQUE INDEX "user_account_username_key" ON "user_account"("username");
CREATE INDEX "audit_event_occurred_at_idx" ON "audit_event"("occurred_at" DESC);
CREATE INDEX "audit_event_resource_type_resource_id_occurred_at_idx" ON "audit_event"("resource_type", "resource_id", "occurred_at" DESC);

ALTER TABLE "radio_target" ADD CONSTRAINT "radio_target_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "site"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "radio_target" ADD CONSTRAINT "radio_target_connector_installation_id_fkey" FOREIGN KEY ("connector_installation_id") REFERENCES "connector_installation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "cell" ADD CONSTRAINT "cell_radio_target_id_fkey" FOREIGN KEY ("radio_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "poll_schedule" ADD CONSTRAINT "poll_schedule_radio_target_id_fkey" FOREIGN KEY ("radio_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "collection_run" ADD CONSTRAINT "collection_run_poll_schedule_id_fkey" FOREIGN KEY ("poll_schedule_id") REFERENCES "poll_schedule"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "collection_run" ADD CONSTRAINT "collection_run_radio_target_id_fkey" FOREIGN KEY ("radio_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "raw_observation" ADD CONSTRAINT "raw_observation_collection_run_id_fkey" FOREIGN KEY ("collection_run_id") REFERENCES "collection_run"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "raw_observation" ADD CONSTRAINT "raw_observation_radio_target_id_fkey" FOREIGN KEY ("radio_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "radio_observation" ADD CONSTRAINT "radio_observation_metric_definition_id_fkey" FOREIGN KEY ("metric_definition_id") REFERENCES "metric_definition"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "radio_observation" ADD CONSTRAINT "radio_observation_radio_target_id_fkey" FOREIGN KEY ("radio_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "radio_observation" ADD CONSTRAINT "radio_observation_cell_id_fkey" FOREIGN KEY ("cell_id") REFERENCES "cell"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "radio_observation" ADD CONSTRAINT "radio_observation_ue_id_fkey" FOREIGN KEY ("ue_id") REFERENCES "ue"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "radio_observation" ADD CONSTRAINT "radio_observation_raw_observation_id_fkey" FOREIGN KEY ("raw_observation_id") REFERENCES "raw_observation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "radio_observation" ADD CONSTRAINT "radio_observation_collection_run_id_fkey" FOREIGN KEY ("collection_run_id") REFERENCES "collection_run"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "location_estimate" ADD CONSTRAINT "location_estimate_ue_id_fkey" FOREIGN KEY ("ue_id") REFERENCES "ue"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "location_estimate" ADD CONSTRAINT "location_estimate_serving_cell_id_fkey" FOREIGN KEY ("serving_cell_id") REFERENCES "cell"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "location_evidence" ADD CONSTRAINT "location_evidence_location_estimate_id_fkey" FOREIGN KEY ("location_estimate_id") REFERENCES "location_estimate"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "location_evidence" ADD CONSTRAINT "location_evidence_radio_observation_id_fkey" FOREIGN KEY ("radio_observation_id") REFERENCES "radio_observation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
