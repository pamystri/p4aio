ALTER TABLE "metric_definition"
  ADD COLUMN "source_json_path" TEXT NOT NULL DEFAULT '$',
  ADD COLUMN "category" TEXT NOT NULL DEFAULT 'legacy',
  ADD COLUMN "display_type" TEXT NOT NULL DEFAULT 'number';

ALTER TABLE "metric_definition"
  ALTER COLUMN "source_json_path" DROP DEFAULT,
  ALTER COLUMN "category" DROP DEFAULT,
  ALTER COLUMN "display_type" DROP DEFAULT;

CREATE TABLE "domain_event" (
  "id" BIGSERIAL NOT NULL,
  "occurred_at" TIMESTAMPTZ(6) NOT NULL,
  "event_type" TEXT NOT NULL,
  "category" TEXT NOT NULL,
  "severity" TEXT NOT NULL,
  "entity_type" TEXT NOT NULL,
  "message" TEXT NOT NULL,
  "details" JSONB NOT NULL DEFAULT '{}',
  "radio_target_id" UUID NOT NULL,
  "cell_id" UUID,
  "ue_id" UUID,
  "raw_observation_id" BIGINT NOT NULL,
  "collection_run_id" UUID NOT NULL,
  "parser_version" TEXT NOT NULL,
  CONSTRAINT "domain_event_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "domain_event_severity_check" CHECK ("severity" IN ('info', 'warning', 'error', 'critical'))
);

CREATE INDEX "domain_event_radio_target_id_occurred_at_idx" ON "domain_event"("radio_target_id", "occurred_at" DESC);
CREATE INDEX "domain_event_ue_id_occurred_at_idx" ON "domain_event"("ue_id", "occurred_at" DESC);
CREATE INDEX "domain_event_cell_id_occurred_at_idx" ON "domain_event"("cell_id", "occurred_at" DESC);
CREATE INDEX "domain_event_event_type_occurred_at_idx" ON "domain_event"("event_type", "occurred_at" DESC);

ALTER TABLE "domain_event" ADD CONSTRAINT "domain_event_radio_target_id_fkey" FOREIGN KEY ("radio_target_id") REFERENCES "radio_target"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "domain_event" ADD CONSTRAINT "domain_event_cell_id_fkey" FOREIGN KEY ("cell_id") REFERENCES "cell"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "domain_event" ADD CONSTRAINT "domain_event_ue_id_fkey" FOREIGN KEY ("ue_id") REFERENCES "ue"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "domain_event" ADD CONSTRAINT "domain_event_raw_observation_id_fkey" FOREIGN KEY ("raw_observation_id") REFERENCES "raw_observation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "domain_event" ADD CONSTRAINT "domain_event_collection_run_id_fkey" FOREIGN KEY ("collection_run_id") REFERENCES "collection_run"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
