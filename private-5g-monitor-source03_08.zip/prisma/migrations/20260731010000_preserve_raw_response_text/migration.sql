ALTER TABLE "raw_observation"
ADD COLUMN "payload_text" TEXT;

UPDATE "raw_observation"
SET "payload_text" = "payload"::TEXT
WHERE "payload_text" IS NULL;

ALTER TABLE "raw_observation"
ALTER COLUMN "payload_text" SET NOT NULL;
