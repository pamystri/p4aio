# Metrics Parsing Framework

## Purpose and flow

The parsing layer converts a correlated Amarisoft Remote API response into vendor-neutral metrics and events. It never mutates the payload. Exact WebSocket text and complete JSON are always persisted, so unknown vendor fields remain available even though normalized storage uses an explicit allow-list.

```text
WebSocket response -> command-specific parser -> metric registry
  -> canonical metrics/events -> one PostgreSQL transaction
     (raw response + definitions + observations + events + poll metadata)
```

Generic contracts live in `packages/connector-sdk/src/metrics.ts`:

- `MetricParser<TContext>` is the parser extension point.
- `MetricRegistry` validates uniqueness and required metadata.
- `RegistryObservationFactory` creates canonical observations from registered definitions.
- `MetricParseResult` carries observations, events, and non-fatal warnings.

## Registry contract

Every metric defines a stable name, description, unit, source JSON path, category, aggregation type, display type, entity scope, semantic type, and definition version. Definitions travel with observations. The PostgreSQL repository upserts them without metric-specific branches, so new metrics do not require database-logic changes.

## Entity normalization

- Site metrics are scoped as `site`; the site is obtained through `radio_target.site_id`.
- Radio metrics use the monitored target.
- Cell metrics resolve the vendor `cell_id` into a cell unique to the target.
- UE metrics resolve `ran_ue_id`, `enb_ue_id`, or `ue_id` through the existing HMAC-pseudonymized UE identity. IMSI is not emitted as a plaintext metric.
- Every observation links back to the raw response and collection run.

`collection_run` stores operation, target, schedule, status, attempts, versions, timestamps, duration, and metric/event counts. Structured response `events` are stored in `domain_event` with links to the run, raw response, target, and optional cell or UE.

## Amarisoft modules

`UeGetParser` handles DL/UL bitrate, CQI, DL/UL MCS, PUSCH SNR, timing advance, path loss, PHR, retransmissions, HARQ, RI, uplink rank, MIMO layers, traffic/error counters, EPRE, UE power, cell identifiers, and privacy-safe UE identifiers.

`StatsParser` handles registered site, radio, and cell statistics. It deliberately does not flatten arbitrary numeric fields, preventing accidental schema growth when Amarisoft adds fields.

## Extension procedure

To add a metric:

1. Add its complete definition to `amarisoft-metric.registry.ts`.
2. Add its source-field mapping to the relevant parser.
3. Add a fixture asserting value, scope, dimensions, and metadata.

No Prisma schema, repository, service, or API changes are needed.

To add an Amarisoft command, create its parser and small command module, register the module/capability in the connector composition root, and add fixtures. Transport, scheduling, retry, raw storage, and persistence are reused.

## Failure behavior and tests

Missing optional and unknown fields are ignored. Malformed known structures produce bounded warnings. A parser exception marks the run partial but retains the raw response. Tests cover registry validation, UE/site/radio/cell metrics, unknown fields, events, UE identity protection, timestamps, exact raw text, poll metadata, reconnect/retry, and authentication.
