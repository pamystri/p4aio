export const SECRET_RESOLVER = Symbol('SECRET_RESOLVER');

export interface SecretResolver {
  resolve(reference: string | undefined): Promise<Readonly<Record<string, string>>>;
}
