import type {
  ConnectorCollectionEnvelope,
  ConnectorManifest,
  JsonValue,
} from '@connector-sdk/index';
import type { DuePollTask } from '@application/scheduler/poll-schedule.repository';

export const COLLECTION_REPOSITORY = Symbol('COLLECTION_REPOSITORY');

export interface CollectionTarget {
  id: string;
  host: string;
  port: number;
  connectorKey: string;
  connectorVersion: string;
  configuration: Readonly<Record<string, JsonValue>>;
  secretReference?: string;
  configVersion: number;
}

export interface CollectionFailure {
  category: string;
  code: string;
  message: string;
}

export interface CollectionRepository {
  ensureConnectorInstallation(manifest: ConnectorManifest): Promise<void>;
  getTarget(id: string): Promise<CollectionTarget | null>;
  startRun(task: DuePollTask, target: CollectionTarget): Promise<string>;
  completeRun(runId: string, target: CollectionTarget, envelope: ConnectorCollectionEnvelope): Promise<void>;
  failRun(runId: string, failure: CollectionFailure): Promise<void>;
}
