import type { CreateSite, Site } from '@domain/site';

export const SITE_REPOSITORY = Symbol('SITE_REPOSITORY');

export interface SitePage {
  items: Site[];
  nextCursor: string | null;
}

export interface SiteRepository {
  create(input: CreateSite): Promise<Site>;
  findById(id: string): Promise<Site | null>;
  list(limit: number, cursor?: string, search?: string, sort?: 'asc' | 'desc'): Promise<SitePage>;
}
