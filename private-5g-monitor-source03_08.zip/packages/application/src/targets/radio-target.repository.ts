import type { JsonValue } from '@connector-sdk/index';

export const RADIO_TARGET_REPOSITORY = Symbol('RADIO_TARGET_REPOSITORY');

export interface CreateRadioTarget {
  siteId: string;
  connectorKey: string;
  connectorVersion: string;
  name: string;
  managementHost: string;
  managementPort: number;
  enabled: boolean;
  configuration: Readonly<Record<string, JsonValue>>;
  secretReference?: string;
}

export interface RadioTargetSummary {
  id: string;
  siteId: string;
  siteName: string;
  connectorKey: string;
  connectorVersion: string;
  name: string;
  managementHost: string;
  managementPort: number;
  enabled: boolean;
  hasSecret: boolean;
  lastSuccessAt: Date | null;
}

export interface PollingUpdate {
  targetId: string;
  logicalOperation: string;
  intervalMs: number;
  timeoutMs: number;
  priority: number;
  enabled: boolean;
}

export interface RadioTargetRepository {
  create(input: CreateRadioTarget): Promise<RadioTargetSummary>;
  list(): Promise<RadioTargetSummary[]>;
  upsertPolling(input: PollingUpdate): Promise<void>;
}
