export const POLL_SCHEDULE_REPOSITORY = Symbol('POLL_SCHEDULE_REPOSITORY');

export interface DuePollTask {
  scheduleId: string;
  radioTargetId: string;
  connectorKey: string;
  connectorVersion: string;
  logicalOperation: string;
  nominalDueAt: Date;
  intervalMs: number;
  timeoutMs: number;
  priority: number;
}

export interface PollScheduleRepository {
  claimDue(now: Date, limit: number, excludedTargetIds: readonly string[]): Promise<DuePollTask[]>;
}
