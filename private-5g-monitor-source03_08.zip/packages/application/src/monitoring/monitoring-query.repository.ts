export const MONITORING_QUERY_REPOSITORY = Symbol('MONITORING_QUERY_REPOSITORY');

export type SortDirection = 'asc' | 'desc';
export interface PageRequest { limit: number; cursor?: string; sort: SortDirection }
export interface Page<T> { items: T[]; nextCursor: string | null }
export interface EntityFilters extends PageRequest { siteId?: string; targetId?: string; search?: string }
export interface TimeRange { from: Date; to: Date }
export interface MetricFilters extends PageRequest, TimeRange {
  siteId?: string; targetId?: string; cellId?: string; ueId?: string; metric?: string;
}
export interface AggregateMetricFilters extends Omit<MetricFilters, 'cursor'> {
  bucket: 'minute' | 'hour' | 'day'; aggregation: 'avg' | 'sum' | 'min' | 'max';
}
export interface AlarmFilters extends PageRequest, TimeRange {
  siteId?: string; targetId?: string; severity?: 'warning' | 'error' | 'critical'; currentOnly: boolean;
}

export interface CellView { id: string; targetId: string; siteId: string; vendorCellKey: string; displayName: string; technology: string; pci: number | null; arfcn: number | null; lastSeenAt: Date }
export interface UeView { id: string; pseudonym: string; firstSeenAt: Date; lastSeenAt: Date }
export interface MetricView { id: string; observedAt: Date; metric: string; entityType: string; targetId: string; cellId: string | null; ueId: string | null; unit: string; value: number | string | boolean | object; dimensions: object }
export interface AggregatedMetricView { bucket: Date; metric: string; unit: string; value: number; sampleCount: number }
export interface AlarmView { id: string; occurredAt: Date; type: string; category: string; severity: string; entityType: string; targetId: string; cellId: string | null; ueId: string | null; message: string; details: object }
export interface CollectorStatusView { targetId: string; targetName: string; enabled: boolean; lastSuccessAt: Date | null; lastRunStatus: string | null; lastRunAt: Date | null; schedules: Array<{ operation: string; enabled: boolean; intervalMs: number; nextDueAt: Date }> }
export interface LocationView { id: string; ueId: string; pseudonym: string; estimatedAt: Date; latitude: number; longitude: number; altitudeM: number | null; horizontalAccuracyM: number; confidence: number | null; method: string; algorithmVersion: string; servingCellId: string | null; servingCellName: string | null; siteId: string | null; details: object }

export interface MonitoringQueryRepository {
  listCells(filters: EntityFilters): Promise<Page<CellView>>;
  getCell(id: string): Promise<CellView | null>;
  listUes(filters: EntityFilters): Promise<Page<UeView>>;
  getUe(id: string): Promise<UeView | null>;
  currentMetrics(filters: Omit<MetricFilters, 'from' | 'to'>): Promise<Page<MetricView>>;
  historicalMetrics(filters: MetricFilters): Promise<Page<MetricView>>;
  aggregateMetrics(filters: AggregateMetricFilters): Promise<AggregatedMetricView[]>;
  alarms(filters: AlarmFilters): Promise<Page<AlarmView>>;
  collectorStatus(siteId?: string, targetId?: string): Promise<CollectorStatusView[]>;
  currentLocations(siteId?: string, targetId?: string, limit?: number): Promise<LocationView[]>;
  statistics(siteId?: string, targetId?: string): Promise<Record<string, number>>;
}
