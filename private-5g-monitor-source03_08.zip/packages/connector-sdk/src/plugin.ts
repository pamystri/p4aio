export interface PluginManifest {
  id: string;
  displayName: string;
  version: string;
  sdkVersion: string;
  description: string;
  checksum?: string;
}

export interface PlatformPlugin {
  readonly manifest: PluginManifest;
  initialize(): Promise<void>;
  shutdown(): Promise<void>;
}
