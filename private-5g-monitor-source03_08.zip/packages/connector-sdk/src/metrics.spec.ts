import { MetricRegistry, RegistryObservationFactory, type MetricDefinitionDescriptor } from './index';

const definition: MetricDefinitionDescriptor = {
  name: 'radio.ue.test',
  description: 'Test metric',
  unit: 'dB',
  sourceJsonPath: '$.ue_list[*].test',
  category: 'test',
  aggregationType: 'avg',
  displayType: 'decibel',
  entityType: 'ue',
  semanticType: 'gauge',
  definitionVersion: 1,
};

describe('MetricRegistry', () => {
  it('registers and resolves complete immutable definitions', () => {
    const registry = new MetricRegistry([definition]);
    expect(registry.get('radio.ue.test')).toEqual(definition);
    expect(Object.isFrozen(registry.get('radio.ue.test'))).toBe(true);
  });

  it('rejects duplicates and incomplete metadata', () => {
    expect(() => new MetricRegistry([definition, definition])).toThrow('Duplicate');
    expect(() => new MetricRegistry([{ ...definition, sourceJsonPath: 'ue.test' }])).toThrow('JSON path');
  });

  it('filters definitions by entity scope', () => {
    const registry = new MetricRegistry([definition, { ...definition, name: 'radio.site.test', entityType: 'site' }]);
    expect(registry.forEntity('site').map((item) => item.name)).toEqual(['radio.site.test']);
  });

  it('creates an observation using registry metadata as the authority', () => {
    const factory = new RegistryObservationFactory(new MetricRegistry([definition]));
    expect(factory.create({
      metricName: definition.name,
      observedAt: new Date(0),
      externalEntityId: 'ue-1',
      value: 12,
    })).toEqual(expect.objectContaining({
      metricKey: definition.name,
      definition,
      unit: 'dB',
      entityType: 'ue',
      semanticType: 'gauge',
    }));
  });
});
