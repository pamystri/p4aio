import type {
  CanonicalMetricObservation,
  JsonPrimitive,
  JsonValue,
  MetricDefinitionDescriptor,
  MetricEntityType,
} from './connector';

/** Generic command-parser contract. Vendor commands provide independent implementations. */
export interface MetricParser<TContext> {
  parse(payload: JsonValue, context: TContext): MetricParseResult;
}

/** Creates canonical observations from registry entries so parsers never duplicate metadata. */
export class RegistryObservationFactory {
  constructor(private readonly registry: MetricRegistry) {}

  create(input: {
    metricName: string;
    observedAt: Date;
    externalEntityId: string;
    value: CanonicalMetricObservation['value'];
    dimensions?: Readonly<Record<string, JsonPrimitive>>;
    qualityFlags?: number;
  }): CanonicalMetricObservation {
    const definition = this.registry.get(input.metricName);
    return {
      metricKey: definition.name,
      definition,
      unit: definition.unit,
      semanticType: definition.semanticType,
      observedAt: input.observedAt,
      entityType: definition.entityType,
      externalEntityId: input.externalEntityId,
      value: input.value,
      dimensions: input.dimensions ?? {},
      qualityFlags: input.qualityFlags ?? 0,
    };
  }
}

export interface MetricParseResult {
  observations: readonly import('./connector').CanonicalMetricObservation[];
  events: readonly import('./connector').CanonicalEvent[];
  warnings: readonly string[];
}

/** Validated, read-only catalog used by parsers and database persistence. */
export class MetricRegistry {
  private readonly definitions = new Map<string, MetricDefinitionDescriptor>();

  constructor(definitions: readonly MetricDefinitionDescriptor[] = []) {
    for (const definition of definitions) this.register(definition);
  }

  register(definition: MetricDefinitionDescriptor): void {
    this.validate(definition);
    if (this.definitions.has(definition.name)) {
      throw new Error(`Duplicate metric definition ${definition.name}`);
    }
    this.definitions.set(definition.name, Object.freeze({ ...definition }));
  }

  get(name: string): MetricDefinitionDescriptor {
    const definition = this.definitions.get(name);
    if (!definition) throw new Error(`Unknown metric ${name}`);
    return definition;
  }

  forEntity(entityType: MetricEntityType): readonly MetricDefinitionDescriptor[] {
    return [...this.definitions.values()].filter((item) => item.entityType === entityType);
  }

  all(): readonly MetricDefinitionDescriptor[] {
    return [...this.definitions.values()];
  }

  private validate(definition: MetricDefinitionDescriptor): void {
    if (!/^[a-z][a-z0-9_.]*$/.test(definition.name)) throw new Error(`Invalid metric name ${definition.name}`);
    if (!definition.description.trim()) throw new Error(`Metric ${definition.name} needs a description`);
    if (!definition.unit.trim()) throw new Error(`Metric ${definition.name} needs a unit`);
    if (!definition.sourceJsonPath.startsWith('$')) throw new Error(`Metric ${definition.name} needs a JSON path`);
    if (!definition.category.trim()) throw new Error(`Metric ${definition.name} needs a category`);
    if (!Number.isInteger(definition.definitionVersion) || definition.definitionVersion < 1) {
      throw new Error(`Metric ${definition.name} has an invalid definition version`);
    }
  }
}
