import { Injectable } from '@nestjs/common';
import type { Prisma, Site as PrismaSite } from '@prisma/client';
import type { SiteRepository, SitePage } from '@application/sites/site.repository';
import type { CreateSite, Site } from '@domain/site';
import { PrismaService } from '@persistence/prisma/prisma.service';

@Injectable()
export class PrismaSiteRepository implements SiteRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(input: CreateSite): Promise<Site> {
    const site = await this.prisma.site.create({
      data: {
        name: input.name,
        slug: input.slug,
        timeZone: input.timeZone,
        latitude: input.latitude,
        longitude: input.longitude,
        altitudeM: input.altitudeM,
        attributes: (input.attributes ?? {}) as Prisma.InputJsonValue,
      },
    });
    return this.map(site);
  }

  async findById(id: string): Promise<Site | null> {
    const site = await this.prisma.site.findUnique({ where: { id } });
    return site ? this.map(site) : null;
  }

  async list(limit: number, cursor?: string, search?: string, sort: 'asc' | 'desc' = 'asc'): Promise<SitePage> {
    const rows = await this.prisma.site.findMany({
      where: search ? { OR: [{ name: { contains: search, mode: 'insensitive' } }, { slug: { contains: search, mode: 'insensitive' } }] } : {},
      take: limit + 1,
      orderBy: { id: sort },
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    });
    const hasNext = rows.length > limit;
    const items = (hasNext ? rows.slice(0, limit) : rows).map((site) => this.map(site));
    return { items, nextCursor: hasNext ? items.at(-1)?.id ?? null : null };
  }

  private map(site: PrismaSite): Site {
    return {
      id: site.id,
      name: site.name,
      slug: site.slug,
      timeZone: site.timeZone,
      latitude: site.latitude,
      longitude: site.longitude,
      altitudeM: site.altitudeM,
      attributes: site.attributes as Record<string, unknown>,
      createdAt: site.createdAt,
      updatedAt: site.updatedAt,
    };
  }
}
