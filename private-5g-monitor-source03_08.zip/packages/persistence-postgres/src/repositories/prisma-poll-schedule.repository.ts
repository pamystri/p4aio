import { Injectable } from '@nestjs/common';
import type {
  DuePollTask,
  PollScheduleRepository,
} from '@application/scheduler/poll-schedule.repository';
import { PrismaService } from '@persistence/prisma/prisma.service';

@Injectable()
export class PrismaPollScheduleRepository implements PollScheduleRepository {
  constructor(private readonly prisma: PrismaService) {}

  async claimDue(
    now: Date,
    limit: number,
    excludedTargetIds: readonly string[],
  ): Promise<DuePollTask[]> {
    return this.prisma.$transaction(async (transaction) => {
      const due = await transaction.pollSchedule.findMany({
        where: {
          enabled: true,
          nextDueAt: { lte: now },
          ...(excludedTargetIds.length > 0
            ? { radioTargetId: { notIn: [...excludedTargetIds] } }
            : {}),
          radioTarget: { enabled: true },
        },
        orderBy: [{ priority: 'desc' }, { nextDueAt: 'asc' }],
        distinct: ['radioTargetId'],
        take: limit,
        include: {
          radioTarget: { include: { connectorInstallation: true } },
        },
      });

      for (const schedule of due) {
        const jitterRange = (schedule.intervalMs * schedule.jitterPercent) / 100;
        const jitter = Math.round((Math.random() * 2 - 1) * jitterRange);
        const nextDueAt = new Date(now.getTime() + schedule.intervalMs + jitter);
        await transaction.pollSchedule.update({
          where: { id: schedule.id },
          data: { nextDueAt },
        });
      }

      return due.map((schedule) => ({
        scheduleId: schedule.id,
        radioTargetId: schedule.radioTargetId,
        connectorKey: schedule.radioTarget.connectorInstallation.connectorKey,
        connectorVersion: schedule.radioTarget.connectorInstallation.version,
        logicalOperation: schedule.logicalOperation,
        nominalDueAt: schedule.nextDueAt,
        intervalMs: schedule.intervalMs,
        timeoutMs: schedule.timeoutMs,
        priority: schedule.priority,
      }));
    });
  }
}
