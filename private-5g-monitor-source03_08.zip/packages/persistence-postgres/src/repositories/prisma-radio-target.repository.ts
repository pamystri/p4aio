import { Injectable } from '@nestjs/common';
import type { Prisma } from '@prisma/client';
import type {
  CreateRadioTarget,
  PollingUpdate,
  RadioTargetRepository,
  RadioTargetSummary,
} from '@application/targets/radio-target.repository';
import { PrismaService } from '@persistence/prisma/prisma.service';

@Injectable()
export class PrismaRadioTargetRepository implements RadioTargetRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(input: CreateRadioTarget): Promise<RadioTargetSummary> {
    const connector = await this.prisma.connectorInstallation.findUniqueOrThrow({
      where: {
        connectorKey_version: {
          connectorKey: input.connectorKey,
          version: input.connectorVersion,
        },
      },
    });
    const target = await this.prisma.radioTarget.create({
      data: {
        siteId: input.siteId,
        connectorInstallationId: connector.id,
        name: input.name,
        managementHost: input.managementHost,
        managementPort: input.managementPort,
        enabled: input.enabled,
        config: input.configuration as Prisma.InputJsonValue,
        secretRef: input.secretReference,
      },
      include: { site: true, connectorInstallation: true },
    });
    return this.map(target);
  }

  async list(): Promise<RadioTargetSummary[]> {
    const targets = await this.prisma.radioTarget.findMany({
      include: { site: true, connectorInstallation: true },
      orderBy: [{ site: { name: 'asc' } }, { name: 'asc' }],
    });
    return targets.map((target) => this.map(target));
  }

  async upsertPolling(input: PollingUpdate): Promise<void> {
    await this.prisma.pollSchedule.upsert({
      where: {
        radioTargetId_logicalOperation: {
          radioTargetId: input.targetId,
          logicalOperation: input.logicalOperation,
        },
      },
      create: {
        radioTargetId: input.targetId,
        logicalOperation: input.logicalOperation,
        intervalMs: input.intervalMs,
        timeoutMs: input.timeoutMs,
        priority: input.priority,
        enabled: input.enabled,
        nextDueAt: new Date(Date.now() + input.intervalMs),
      },
      update: {
        intervalMs: input.intervalMs,
        timeoutMs: input.timeoutMs,
        priority: input.priority,
        enabled: input.enabled,
        nextDueAt: new Date(Date.now() + input.intervalMs),
        version: { increment: 1 },
      },
    });
  }

  private map(target: {
    id: string;
    siteId: string;
    name: string;
    managementHost: string;
    managementPort: number;
    enabled: boolean;
    secretRef: string | null;
    lastSuccessAt: Date | null;
    site: { name: string };
    connectorInstallation: { connectorKey: string; version: string };
  }): RadioTargetSummary {
    return {
      id: target.id,
      siteId: target.siteId,
      siteName: target.site.name,
      connectorKey: target.connectorInstallation.connectorKey,
      connectorVersion: target.connectorInstallation.version,
      name: target.name,
      managementHost: target.managementHost,
      managementPort: target.managementPort,
      enabled: target.enabled,
      hasSecret: target.secretRef !== null,
      lastSuccessAt: target.lastSuccessAt,
    };
  }
}
