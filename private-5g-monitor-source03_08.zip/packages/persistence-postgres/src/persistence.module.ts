import { Global, Module } from '@nestjs/common';
import { SITE_REPOSITORY } from '@application/sites/site.repository';
import { PrismaService } from '@persistence/prisma/prisma.service';
import { PrismaSiteRepository } from '@persistence/repositories/prisma-site.repository';
import { PrismaPollScheduleRepository } from '@persistence/repositories/prisma-poll-schedule.repository';
import { POLL_SCHEDULE_REPOSITORY } from '@application/scheduler/poll-schedule.repository';
import { COLLECTION_REPOSITORY } from '@application/collection/collection.repository';
import { PrismaCollectionRepository } from '@persistence/repositories/prisma-collection.repository';
import { RADIO_TARGET_REPOSITORY } from '@application/targets/radio-target.repository';
import { PrismaRadioTargetRepository } from '@persistence/repositories/prisma-radio-target.repository';
import { MONITORING_QUERY_REPOSITORY } from '@application/monitoring/monitoring-query.repository';
import { PrismaMonitoringQueryRepository } from '@persistence/repositories/prisma-monitoring-query.repository';

@Global()
@Module({
  providers: [
    PrismaService,
    { provide: SITE_REPOSITORY, useClass: PrismaSiteRepository },
    { provide: POLL_SCHEDULE_REPOSITORY, useClass: PrismaPollScheduleRepository },
    { provide: COLLECTION_REPOSITORY, useClass: PrismaCollectionRepository },
    { provide: RADIO_TARGET_REPOSITORY, useClass: PrismaRadioTargetRepository },
    { provide: MONITORING_QUERY_REPOSITORY, useClass: PrismaMonitoringQueryRepository },
  ],
  exports: [
    PrismaService,
    SITE_REPOSITORY,
    POLL_SCHEDULE_REPOSITORY,
    COLLECTION_REPOSITORY,
    RADIO_TARGET_REPOSITORY,
    MONITORING_QUERY_REPOSITORY,
  ],
})
export class PersistenceModule {}
