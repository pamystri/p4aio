export interface Site {
  id: string;
  name: string;
  slug: string;
  timeZone: string;
  latitude: number | null;
  longitude: number | null;
  altitudeM: number | null;
  attributes: Readonly<Record<string, unknown>>;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateSite {
  name: string;
  slug: string;
  timeZone: string;
  latitude?: number;
  longitude?: number;
  altitudeM?: number;
  attributes?: Readonly<Record<string, unknown>>;
}
