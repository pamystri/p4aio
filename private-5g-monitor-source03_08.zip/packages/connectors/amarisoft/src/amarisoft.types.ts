import type {
  CanonicalEvent,
  CanonicalMetricObservation,
  JsonValue,
} from '@connector-sdk/index';

export interface AmarisoftLogger {
  debug(context: Readonly<Record<string, unknown>>, message: string): void;
  info(context: Readonly<Record<string, unknown>>, message: string): void;
  warn(context: Readonly<Record<string, unknown>>, message: string): void;
  error(context: Readonly<Record<string, unknown>>, message: string): void;
}

export interface AmarisoftResponseFrame {
  rawText: string;
  payload: JsonValue;
  receivedAt: Date;
}

export interface AmarisoftParserContext {
  targetId: string;
  observedAt: Date;
}

export interface AmarisoftParseResult {
  observations: readonly CanonicalMetricObservation[];
  events: readonly CanonicalEvent[];
  warnings: readonly string[];
}

export interface AmarisoftCommandModule {
  readonly logicalOperation: 'ue_get' | 'stats' | string;
  createRequest(configuration: AmarisoftTargetConfiguration): Readonly<Record<string, JsonValue>>;
  parse(payload: JsonValue, context: AmarisoftParserContext): AmarisoftParseResult;
}

export interface AmarisoftTargetConfiguration {
  transport: 'ws' | 'wss';
  path: string;
  origin?: string;
  tlsRejectUnauthorized: boolean;
  ueGet: { stats: boolean };
  stats: { samples: boolean; rf: boolean };
}

export interface AmarisoftConnectionPolicy {
  connectTimeoutMs: number;
  requestTimeoutMs: number;
  heartbeatIntervalMs: number;
  heartbeatTimeoutMs: number;
  reconnectMinMs: number;
  reconnectMaxMs: number;
  maxRetries: number;
}

export interface AmarisoftConnectionHealthSnapshot {
  state: 'disconnected' | 'connecting' | 'ready' | 'reconnecting' | 'closed';
  connectedAt: Date | null;
  lastMessageAt: Date | null;
  lastPongAt: Date | null;
  consecutiveFailures: number;
  lastError: string | null;
}
