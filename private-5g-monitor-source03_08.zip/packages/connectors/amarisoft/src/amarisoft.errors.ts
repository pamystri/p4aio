/** Canonical connector failure carrying retry guidance for the scheduler/collector. */
export class AmarisoftConnectorError extends Error {
  constructor(
    message: string,
    readonly category:
      | 'configuration'
      | 'authentication'
      | 'connectivity'
      | 'timeout'
      | 'protocol'
      | 'vendor-response'
      | 'shutdown',
    readonly retryable: boolean,
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = AmarisoftConnectorError.name;
  }
}
