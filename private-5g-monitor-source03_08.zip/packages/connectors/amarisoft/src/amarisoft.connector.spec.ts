import { createHmac } from 'node:crypto';
import type { AddressInfo } from 'node:net';
import { WebSocketServer } from 'ws';
import type { JsonValue } from '@connector-sdk/index';
import { AmarisoftConnector } from './amarisoft.connector';
import type { AmarisoftConnectionPolicy, AmarisoftLogger } from './amarisoft.types';

const logger: AmarisoftLogger = {
  debug: jest.fn(),
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
};

const policy: AmarisoftConnectionPolicy = {
  connectTimeoutMs: 1000,
  requestTimeoutMs: 500,
  heartbeatIntervalMs: 100,
  heartbeatTimeoutMs: 100,
  reconnectMinMs: 10,
  reconnectMaxMs: 50,
  maxRetries: 1,
};

describe('AmarisoftConnector', () => {
  let server: WebSocketServer;
  let connector: AmarisoftConnector;

  afterEach(async () => {
    await connector?.shutdown();
    await new Promise<void>((resolve) => server?.close(() => resolve()));
  });

  it('correlates ue_get and preserves the exact response text', async () => {
    server = new WebSocketServer({ host: '127.0.0.1', port: 0 });
    await new Promise<void>((resolve) => server.once('listening', resolve));
    server.on('connection', (socket) => {
      socket.send('{"message":"ready","type":"ENB","name":"ENB","version":"test"}');
      socket.on('message', (data) => {
        const request = JSON.parse(data.toString()) as { message_id: string; message: string };
        expect(request.message).toBe('ue_get');
        const response = `  {"message":"ue_get", "message_id":"${request.message_id}", "future_vendor_field":99, "ue_list":[{"ran_ue_id":7,"cells":[{"cell_id":1,"initial_ta":6,"ul_path_loss":61.6}]}]}  `;
        socket.send(response);
      });
    });

    connector = new AmarisoftConnector(policy, logger);
    await connector.initialize();
    const session = await connector.openSession({
      targetId: 'target-1',
      host: '127.0.0.1',
      port: (server.address() as AddressInfo).port,
      configuration: {} as Readonly<Record<string, JsonValue>>,
    });
    const envelope = await session.execute({
      collectionRunId: 'run-1',
      logicalOperation: 'ue_get',
      deadline: new Date(Date.now() + 2000),
      signal: new AbortController().signal,
    });

    expect(envelope.rawPayloadText.startsWith('  {')).toBe(true);
    expect(envelope.rawPayloadText.endsWith('  ')).toBe(true);
    expect(envelope.observations).toEqual(
      expect.arrayContaining([expect.objectContaining({ metricKey: 'radio.ue.initial_ta', value: 6 })]),
    );
    expect(envelope.rawPayloadBytes).toBe(Buffer.byteLength(envelope.rawPayloadText));
    expect((envelope.rawPayload as { readonly future_vendor_field: number }).future_vendor_field).toBe(99);
    expect(envelope.observations.some((item) => item.metricKey.includes('future'))).toBe(false);
  });

  it('reconnects and retries a read-only request after a dropped connection', async () => {
    let connectionCount = 0;
    server = new WebSocketServer({ host: '127.0.0.1', port: 0 });
    await new Promise<void>((resolve) => server.once('listening', resolve));
    server.on('connection', (socket) => {
      connectionCount += 1;
      socket.send('{"message":"ready","type":"ENB","name":"ENB","version":"test"}');
      socket.on('message', (data) => {
        if (connectionCount === 1) {
          socket.close(1011, 'test disconnect');
          return;
        }
        const request = JSON.parse(data.toString()) as { message_id: string };
        socket.send(
          JSON.stringify({ message: 'stats', message_id: request.message_id, cpu: { load: 5 } }),
        );
      });
    });

    connector = new AmarisoftConnector(policy, logger);
    const session = await connector.openSession({
      targetId: 'target-2',
      host: '127.0.0.1',
      port: (server.address() as AddressInfo).port,
      configuration: {} as Readonly<Record<string, JsonValue>>,
    });
    const envelope = await session.execute({
      collectionRunId: 'run-2',
      logicalOperation: 'stats',
      deadline: new Date(Date.now() + 3000),
      signal: new AbortController().signal,
    });

    expect(connectionCount).toBeGreaterThanOrEqual(2);
    expect(envelope.observations[0]).toEqual(
      expect.objectContaining({ metricKey: 'radio.site.cpu_load', value: 5 }),
    );
  });

  it('answers the documented Amarisoft authentication challenge', async () => {
    const password = 'test-password';
    const challenge = 'server-challenge';
    server = new WebSocketServer({ host: '127.0.0.1', port: 0 });
    await new Promise<void>((resolve) => server.once('listening', resolve));
    server.on('connection', (socket) => {
      socket.send(
        JSON.stringify({ message: 'authenticate', type: 'ENB', name: 'ENB', challenge }),
      );
      socket.on('message', (data) => {
        const request = JSON.parse(data.toString()) as {
          message: string;
          message_id: string;
          res?: string;
        };
        if (request.message === 'authenticate') {
          expect(request.res).toBe(
            createHmac('sha256', challenge).update(`ENB:${password}:ENB`).digest('hex'),
          );
          socket.send(
            JSON.stringify({ message: 'authenticate', message_id: request.message_id, ready: true }),
          );
          return;
        }
        socket.send(JSON.stringify({ message: 'stats', message_id: request.message_id, cpu: { load: 3 } }));
      });
    });

    connector = new AmarisoftConnector(policy, logger);
    const session = await connector.openSession({
      targetId: 'target-auth',
      host: '127.0.0.1',
      port: (server.address() as AddressInfo).port,
      configuration: {} as Readonly<Record<string, JsonValue>>,
      credentials: { password },
    });
    const envelope = await session.execute({
      collectionRunId: 'run-auth',
      logicalOperation: 'stats',
      deadline: new Date(Date.now() + 2000),
      signal: new AbortController().signal,
    });
    expect(envelope.observations[0]).toEqual(expect.objectContaining({ value: 3 }));
    expect(envelope.pollMetadata.attemptCount).toBe(1);
  });
});
