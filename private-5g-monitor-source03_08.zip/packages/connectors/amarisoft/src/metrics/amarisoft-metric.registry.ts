import { MetricRegistry, type MetricDefinitionDescriptor } from '@connector-sdk/index';

const ue = (definition: Omit<MetricDefinitionDescriptor, 'entityType' | 'definitionVersion'>): MetricDefinitionDescriptor => ({
  ...definition,
  entityType: 'ue',
  definitionVersion: 2,
});

const definitions: readonly MetricDefinitionDescriptor[] = [
  ue({ name: 'radio.ue.dl_bitrate', description: 'UE downlink throughput', unit: 'bit/s', sourceJsonPath: '$.ue_list[*].cells[*].dl_bitrate', category: 'throughput', aggregationType: 'avg', displayType: 'bitrate', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.ul_bitrate', description: 'UE uplink throughput', unit: 'bit/s', sourceJsonPath: '$.ue_list[*].cells[*].ul_bitrate', category: 'throughput', aggregationType: 'avg', displayType: 'bitrate', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.cqi', description: 'Channel Quality Indicator reported for the UE', unit: '1', sourceJsonPath: '$.ue_list[*].cells[*].cqi', category: 'radio-quality', aggregationType: 'avg', displayType: 'number', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.dl_mcs', description: 'Downlink modulation and coding scheme index', unit: '1', sourceJsonPath: '$.ue_list[*].cells[*].dl_mcs', category: 'radio-quality', aggregationType: 'avg', displayType: 'number', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.ul_mcs', description: 'Uplink modulation and coding scheme index', unit: '1', sourceJsonPath: '$.ue_list[*].cells[*].ul_mcs', category: 'radio-quality', aggregationType: 'avg', displayType: 'number', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.pusch_snr', description: 'PUSCH signal-to-noise ratio', unit: 'dB', sourceJsonPath: '$.ue_list[*].cells[*].pusch_snr', category: 'location-evidence', aggregationType: 'avg', displayType: 'decibel', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.initial_ta', description: 'Initial timing advance reported for the UE', unit: 'TA', sourceJsonPath: '$.ue_list[*].cells[*].initial_ta', category: 'location-evidence', aggregationType: 'last', displayType: 'number', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.ul_path_loss', description: 'Estimated uplink propagation path loss', unit: 'dB', sourceJsonPath: '$.ue_list[*].cells[*].ul_path_loss', category: 'location-evidence', aggregationType: 'avg', displayType: 'decibel', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.ul_phr', description: 'Uplink power headroom report', unit: 'dB', sourceJsonPath: '$.ue_list[*].cells[*].ul_phr', category: 'power', aggregationType: 'avg', displayType: 'decibel', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.dl_retx', description: 'Downlink retransmission count', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].dl_retx', category: 'reliability', aggregationType: 'delta', displayType: 'counter', semanticType: 'counter' }),
  ue({ name: 'radio.ue.ul_retx', description: 'Uplink retransmission count', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].ul_retx', category: 'reliability', aggregationType: 'delta', displayType: 'counter', semanticType: 'counter' }),
  ue({ name: 'radio.ue.dl_harq', description: 'Downlink HARQ transmission count', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].dl_harq', category: 'reliability', aggregationType: 'delta', displayType: 'counter', semanticType: 'counter' }),
  ue({ name: 'radio.ue.ul_harq', description: 'Uplink HARQ transmission count', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].ul_harq', category: 'reliability', aggregationType: 'delta', displayType: 'counter', semanticType: 'counter' }),
  ue({ name: 'radio.ue.ri', description: 'Downlink rank indicator', unit: '1', sourceJsonPath: '$.ue_list[*].cells[*].ri', category: 'radio-quality', aggregationType: 'avg', displayType: 'number', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.ul_rank', description: 'Uplink transmission rank', unit: '1', sourceJsonPath: '$.ue_list[*].cells[*].ul_rank', category: 'radio-quality', aggregationType: 'avg', displayType: 'number', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.dl_layers', description: 'Number of active downlink MIMO layers', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].dl_n_layer', category: 'radio-quality', aggregationType: 'avg', displayType: 'number', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.ul_layers', description: 'Number of active uplink MIMO layers', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].ul_n_layer', category: 'radio-quality', aggregationType: 'avg', displayType: 'number', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.dl_tx', description: 'Downlink transmission count', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].dl_tx', category: 'traffic', aggregationType: 'delta', displayType: 'counter', semanticType: 'counter' }),
  ue({ name: 'radio.ue.ul_tx', description: 'Uplink transmission count', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].ul_tx', category: 'traffic', aggregationType: 'delta', displayType: 'counter', semanticType: 'counter' }),
  ue({ name: 'radio.ue.dl_err', description: 'Downlink transmission error count', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].dl_err', category: 'reliability', aggregationType: 'delta', displayType: 'counter', semanticType: 'counter' }),
  ue({ name: 'radio.ue.ul_err', description: 'Uplink transmission error count', unit: 'count', sourceJsonPath: '$.ue_list[*].cells[*].ul_err', category: 'reliability', aggregationType: 'delta', displayType: 'counter', semanticType: 'counter' }),
  ue({ name: 'radio.ue.epre', description: 'Estimated received power per resource element', unit: 'dBm', sourceJsonPath: '$.ue_list[*].cells[*].epre', category: 'location-evidence', aggregationType: 'avg', displayType: 'decibel', semanticType: 'gauge' }),
  ue({ name: 'radio.ue.p_ue', description: 'Estimated UE transmit power', unit: 'dBm', sourceJsonPath: '$.ue_list[*].cells[*].p_ue', category: 'power', aggregationType: 'avg', displayType: 'decibel', semanticType: 'gauge' }),
  { name: 'radio.cell.identifier', description: 'Vendor cell identifier', unit: '1', sourceJsonPath: '$.ue_list[*].cells[*].cell_id', category: 'identity', aggregationType: 'last', displayType: 'identifier', entityType: 'cell', semanticType: 'state', definitionVersion: 2 },
  { name: 'radio.site.cpu_load', description: 'gNB host CPU load', unit: '%', sourceJsonPath: '$.cpu.load', category: 'system', aggregationType: 'avg', displayType: 'percentage', entityType: 'site', semanticType: 'gauge', definitionVersion: 2 },
  { name: 'radio.site.memory_used', description: 'gNB host memory usage', unit: 'byte', sourceJsonPath: '$.memory.used', category: 'system', aggregationType: 'avg', displayType: 'number', entityType: 'site', semanticType: 'gauge', definitionVersion: 2 },
  { name: 'radio.target.ue_count', description: 'Connected UE count', unit: 'count', sourceJsonPath: '$.ue_count', category: 'capacity', aggregationType: 'avg', displayType: 'number', entityType: 'radio', semanticType: 'gauge', definitionVersion: 2 },
  { name: 'radio.cell.dl_bitrate', description: 'Aggregate cell downlink throughput', unit: 'bit/s', sourceJsonPath: '$.cells[*].dl_bitrate', category: 'throughput', aggregationType: 'avg', displayType: 'bitrate', entityType: 'cell', semanticType: 'gauge', definitionVersion: 2 },
  { name: 'radio.cell.ul_bitrate', description: 'Aggregate cell uplink throughput', unit: 'bit/s', sourceJsonPath: '$.cells[*].ul_bitrate', category: 'throughput', aggregationType: 'avg', displayType: 'bitrate', entityType: 'cell', semanticType: 'gauge', definitionVersion: 2 },
  { name: 'radio.cell.ue_count', description: 'Connected UE count for a cell', unit: 'count', sourceJsonPath: '$.cells[*].ue_count', category: 'capacity', aggregationType: 'avg', displayType: 'number', entityType: 'cell', semanticType: 'gauge', definitionVersion: 2 },
];

export const amarisoftMetricRegistry = new MetricRegistry(definitions);
