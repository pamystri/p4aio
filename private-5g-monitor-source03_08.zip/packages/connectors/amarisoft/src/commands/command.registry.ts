import type { AmarisoftCommandModule } from '../amarisoft.types';

/** Resolves a logical operation without central vendor command conditionals. */
export class AmarisoftCommandRegistry {
  private readonly modules: Map<string, AmarisoftCommandModule>;

  constructor(modules: readonly AmarisoftCommandModule[]) {
    this.modules = new Map();
    for (const module of modules) {
      if (this.modules.has(module.logicalOperation)) {
        throw new Error(`Duplicate Amarisoft command module ${module.logicalOperation}`);
      }
      this.modules.set(module.logicalOperation, module);
    }
  }

  resolve(logicalOperation: string): AmarisoftCommandModule {
    const module = this.modules.get(logicalOperation);
    if (!module) throw new Error(`Unsupported Amarisoft operation ${logicalOperation}`);
    return module;
  }

  operations(): string[] {
    return [...this.modules.keys()].sort();
  }
}
