import type { JsonValue } from '@connector-sdk/index';
import type {
  AmarisoftCommandModule,
  AmarisoftParserContext,
  AmarisoftTargetConfiguration,
} from '../amarisoft.types';
import { UeGetParser } from '../parsers/ue-get.parser';

/** Owns the `ue_get` request shape and its matching response parser. */
export class UeGetCommandModule implements AmarisoftCommandModule {
  readonly logicalOperation = 'ue_get';
  private readonly parser = new UeGetParser();

  createRequest(configuration: AmarisoftTargetConfiguration): Readonly<Record<string, JsonValue>> {
    return { message: 'ue_get', stats: configuration.ueGet.stats };
  }

  parse(payload: JsonValue, context: AmarisoftParserContext) {
    return this.parser.parse(payload, context);
  }
}
