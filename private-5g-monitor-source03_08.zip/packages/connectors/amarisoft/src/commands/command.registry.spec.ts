import type { AmarisoftCommandModule } from '../amarisoft.types';
import { AmarisoftCommandRegistry } from './command.registry';

const moduleFor = (logicalOperation: string): AmarisoftCommandModule => ({
  logicalOperation,
  createRequest: () => ({ message: logicalOperation }),
  parse: () => ({ observations: [], events: [], warnings: [] }),
});

describe('AmarisoftCommandRegistry', () => {
  it('accepts a new self-contained command parser module without transport changes', () => {
    const registry = new AmarisoftCommandRegistry([moduleFor('future_command')]);
    expect(registry.resolve('future_command').createRequest({
      transport: 'ws',
      path: '/',
      tlsRejectUnauthorized: true,
      ueGet: { stats: true },
      stats: { samples: false, rf: false },
    })).toEqual({ message: 'future_command' });
  });

  it('rejects duplicate and unsupported command modules', () => {
    expect(() => new AmarisoftCommandRegistry([moduleFor('same'), moduleFor('same')])).toThrow('Duplicate');
    expect(() => new AmarisoftCommandRegistry([]).resolve('missing')).toThrow('Unsupported');
  });
});
