import type { JsonValue } from '@connector-sdk/index';
import type {
  AmarisoftCommandModule,
  AmarisoftParserContext,
  AmarisoftTargetConfiguration,
} from '../amarisoft.types';
import { StatsParser } from '../parsers/stats.parser';

/** Owns the `stats` request shape and its matching response parser. */
export class StatsCommandModule implements AmarisoftCommandModule {
  readonly logicalOperation = 'stats';
  private readonly parser = new StatsParser();

  createRequest(configuration: AmarisoftTargetConfiguration): Readonly<Record<string, JsonValue>> {
    return { message: 'stats', samples: configuration.stats.samples, rf: configuration.stats.rf };
  }

  parse(payload: JsonValue, context: AmarisoftParserContext) {
    return this.parser.parse(payload, context);
  }
}
