import { createHash } from 'node:crypto';
import type { AmarisoftConnectionPolicy, AmarisoftLogger } from '../amarisoft.types';
import { AmarisoftWebSocketConnection } from './amarisoft-websocket.connection';

export interface ManagedConnectionOptions {
  targetId: string;
  url: string;
  origin?: string;
  tlsRejectUnauthorized: boolean;
  password?: string;
  policy: AmarisoftConnectionPolicy;
}

interface ManagedConnection {
  fingerprint: string;
  connection: AmarisoftWebSocketConnection;
}

/** Owns at most one persistent WebSocket connection per configured target. */
export class AmarisoftConnectionManager {
  private readonly connections = new Map<string, ManagedConnection>();
  private shuttingDown = false;

  constructor(private readonly logger: AmarisoftLogger) {}

  async get(options: ManagedConnectionOptions): Promise<AmarisoftWebSocketConnection> {
    if (this.shuttingDown) throw new Error('Amarisoft connection manager is shutting down');
    const fingerprint = this.fingerprint(options);
    const existing = this.connections.get(options.targetId);
    if (existing?.fingerprint === fingerprint) return existing.connection;
    if (existing) await existing.connection.close();
    const connection = new AmarisoftWebSocketConnection(options, this.logger);
    this.connections.set(options.targetId, { fingerprint, connection });
    return connection;
  }

  health(targetId: string) {
    return this.connections.get(targetId)?.connection.health();
  }

  async closeAll(): Promise<void> {
    this.shuttingDown = true;
    await Promise.allSettled([...this.connections.values()].map(({ connection }) => connection.close()));
    this.connections.clear();
  }

  private fingerprint(options: ManagedConnectionOptions): string {
    return createHash('sha256').update(JSON.stringify(options)).digest('hex');
  }
}
