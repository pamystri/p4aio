import { StatsParser } from './stats.parser';

describe('StatsParser', () => {
  it('parses only registered site and radio statistics', () => {
    const result = new StatsParser().parse(
      { message: 'stats', utc: 1_700_000_000, cpu: { load: 12.5 }, memory: { used: 1024 }, ue_count: 4, unknown: 9 },
      { targetId: 'target-1', observedAt: new Date(0) },
    );
    expect(result.observations).toHaveLength(3);
    expect(result.observations.map((value) => value.metricKey)).toEqual([
      'radio.site.cpu_load',
      'radio.site.memory_used',
      'radio.target.ue_count',
    ]);
    expect(result.observations.some((value) => value.metricKey.includes('unknown'))).toBe(false);
    expect(result.observations[0]?.definition.sourceJsonPath).toBe('$.cpu.load');
  });

  it('normalizes cell-scoped statistics by cell identifier', () => {
    const result = new StatsParser().parse(
      { cells: [{ cell_id: 7, dl_bitrate: 8000, ul_bitrate: 2000, ignored: 5 }] },
      { targetId: 'target-1', observedAt: new Date(0) },
    );
    expect(result.observations).toEqual(expect.arrayContaining([
      expect.objectContaining({ metricKey: 'radio.cell.dl_bitrate', entityType: 'cell', externalEntityId: '7', value: 8000 }),
      expect.objectContaining({ metricKey: 'radio.cell.ul_bitrate', externalEntityId: '7', value: 2000 }),
    ]));
    expect(result.observations.some((value) => value.metricKey.includes('ignored'))).toBe(false);
  });
});
