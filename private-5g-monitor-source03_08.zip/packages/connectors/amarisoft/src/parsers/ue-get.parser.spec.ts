import type { JsonValue } from '@connector-sdk/index';
import { UeGetParser } from './ue-get.parser';

describe('UeGetParser', () => {
  it('maps location and radio metrics while ignoring unknown fields', () => {
    const payload: JsonValue = {
      message: 'ue_get',
      utc: 1_700_000_000,
      ue_list: [
        {
          ran_ue_id: 42,
          dl_bitrate: 1200,
          unknown_future_field: 99,
          cells: [
            {
              cell_id: 1,
              pusch_snr: 32.3,
              ul_path_loss: 61.6,
              initial_ta: 6,
            },
          ],
        },
      ],
    };

    const result = new UeGetParser().parse(payload, {
      targetId: 'target-1',
      observedAt: new Date(0),
    });

    expect(result.warnings).toEqual([]);
    expect(result.observations).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          metricKey: 'radio.ue.initial_ta',
          externalEntityId: 'ran_ue_id:42',
          value: 6,
          dimensions: { serving_cell_id: '1' },
        }),
        expect.objectContaining({ metricKey: 'radio.ue.ul_path_loss', value: 61.6 }),
      ]),
    );
    expect(result.observations.some((metric) => metric.metricKey.includes('unknown'))).toBe(false);
    expect(result.observations[0]?.observedAt).toEqual(new Date(1_700_000_000_000));
    expect(result.observations.find((metric) => metric.metricKey === 'radio.ue.ul_path_loss')?.definition).toEqual(
      expect.objectContaining({ category: 'location-evidence', displayType: 'decibel' }),
    );
  });

  it('does not use an IMSI as the normal external identifier', () => {
    const result = new UeGetParser().parse(
      { message: 'ue_get', ue_list: [{ imsi: '001010123456789', dl_bitrate: 1 }] },
      { targetId: 'target-1', observedAt: new Date() },
    );
    expect(result.observations).toHaveLength(0);
    expect(result.warnings[0]).toContain('without ran_ue_id');
  });

  it('extracts structured events and ignores malformed event entries', () => {
    const result = new UeGetParser().parse(
      {
        ue_list: [],
        events: [
          { type: 'ue_connected', severity: 'info', entity_type: 'ue', entity_id: 7, message: 'UE connected' },
          { message: 'missing type' },
        ],
      },
      { targetId: 'target-1', observedAt: new Date('2026-01-01T00:00:00Z') },
    );
    expect(result.events).toEqual([
      expect.objectContaining({ eventType: 'ue_connected', entityType: 'ue', externalEntityId: '7' }),
    ]);
  });
});
