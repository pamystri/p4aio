import {
  RegistryObservationFactory,
  type CanonicalMetricObservation,
  type JsonPrimitive,
  type JsonValue,
  type MetricRegistry,
} from '@connector-sdk/index';
import type { AmarisoftParseResult, AmarisoftParserContext } from '../amarisoft.types';
import { amarisoftMetricRegistry } from '../metrics/amarisoft-metric.registry';
import { parseEvents } from './event.parser';
import {
  asFiniteNumber,
  externalIdentifier,
  isJsonArray,
  isJsonRecord,
  responseObservedAt,
} from './parser.helpers';

const fields: Readonly<Record<string, string>> = {
  dl_bitrate: 'radio.ue.dl_bitrate', ul_bitrate: 'radio.ue.ul_bitrate', cqi: 'radio.ue.cqi',
  dl_mcs: 'radio.ue.dl_mcs', ul_mcs: 'radio.ue.ul_mcs', pusch_snr: 'radio.ue.pusch_snr',
  initial_ta: 'radio.ue.initial_ta', ul_path_loss: 'radio.ue.ul_path_loss', ul_phr: 'radio.ue.ul_phr',
  dl_retx: 'radio.ue.dl_retx', ul_retx: 'radio.ue.ul_retx', dl_harq: 'radio.ue.dl_harq',
  ul_harq: 'radio.ue.ul_harq', ri: 'radio.ue.ri', dl_n_layer: 'radio.ue.dl_layers',
  ul_rank: 'radio.ue.ul_rank',
  ul_n_layer: 'radio.ue.ul_layers', dl_tx: 'radio.ue.dl_tx', ul_tx: 'radio.ue.ul_tx',
  dl_err: 'radio.ue.dl_err', ul_err: 'radio.ue.ul_err', epre: 'radio.ue.epre', p_ue: 'radio.ue.p_ue',
};

/** Registry-driven parser for one `ue_get` command response. Unknown fields are intentionally skipped. */
export class UeGetParser {
  private readonly observations: RegistryObservationFactory;

  constructor(registry: MetricRegistry = amarisoftMetricRegistry) {
    this.observations = new RegistryObservationFactory(registry);
  }

  parse(payload: JsonValue, context: AmarisoftParserContext): AmarisoftParseResult {
    if (!isJsonRecord(payload)) return { observations: [], events: [], warnings: ['ue_get response is not an object'] };
    const ueList = payload['ue_list'];
    if (!isJsonArray(ueList)) return { observations: [], events: parseEvents(payload, context), warnings: ['ue_get response has no ue_list array'] };

    const observedAt = responseObservedAt(payload, context.observedAt);
    const observations: CanonicalMetricObservation[] = [];
    const warnings: string[] = [];
    for (const value of ueList) {
      if (!isJsonRecord(value)) {
        warnings.push('Ignored a non-object ue_list entry');
        continue;
      }
      const ueId = externalIdentifier(value);
      if (!ueId) {
        warnings.push('Ignored UE entry without ran_ue_id, enb_ue_id, or ue_id');
        continue;
      }
      this.appendRecordMetrics(observations, value, ueId, observedAt, {});
      const cells = value['cells'];
      if (!isJsonArray(cells)) continue;
      for (const cellValue of cells) {
        if (!isJsonRecord(cellValue)) continue;
        const rawCellId = cellValue['cell_id'];
        const cellId = typeof rawCellId === 'string' || typeof rawCellId === 'number' ? String(rawCellId) : undefined;
        const dimensions: Record<string, JsonPrimitive> = cellId ? { serving_cell_id: cellId } : {};
        this.appendRecordMetrics(observations, cellValue, ueId, observedAt, dimensions);
        if (cellId) observations.push(this.observations.create({ metricName: 'radio.cell.identifier', observedAt, externalEntityId: cellId, value: cellId }));
      }
    }
    return { observations, events: parseEvents(payload, context), warnings };
  }

  private appendRecordMetrics(
    output: CanonicalMetricObservation[],
    record: { readonly [key: string]: JsonValue },
    ueId: string,
    observedAt: Date,
    dimensions: Readonly<Record<string, JsonPrimitive>>,
  ): void {
    for (const [sourceField, metricName] of Object.entries(fields)) {
      const value = asFiniteNumber(record[sourceField]);
      if (value !== undefined) output.push(this.observations.create({ metricName, observedAt, externalEntityId: ueId, value, dimensions }));
    }
  }
}
