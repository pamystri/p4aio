import type { CanonicalEvent, JsonValue, MetricEntityType } from '@connector-sdk/index';
import type { AmarisoftParserContext } from '../amarisoft.types';
import { isJsonArray, isJsonRecord, responseObservedAt } from './parser.helpers';

/** Extracts only explicitly structured vendor events; all other fields remain in raw JSON. */
export function parseEvents(payload: JsonValue, context: AmarisoftParserContext): CanonicalEvent[] {
  if (!isJsonRecord(payload) || !isJsonArray(payload['events'])) return [];
  const output: CanonicalEvent[] = [];
  for (const candidate of payload['events']) {
    if (!isJsonRecord(candidate) || typeof candidate['type'] !== 'string') continue;
    const entityType = validEntityType(candidate['entity_type']);
    const externalId = identifier(candidate['entity_id']) ?? context.targetId;
    output.push({
      eventType: candidate['type'],
      category: typeof candidate['category'] === 'string' ? candidate['category'] : 'vendor',
      severity: validSeverity(candidate['severity']),
      occurredAt: responseObservedAt(candidate, context.observedAt),
      entityType,
      externalEntityId: externalId,
      message: typeof candidate['message'] === 'string' ? candidate['message'] : candidate['type'],
      details: recognizedDetails(candidate),
    });
  }
  return output;
}

function recognizedDetails(candidate: { readonly [key: string]: JsonValue }): Readonly<Record<string, JsonValue>> {
  const details: Record<string, JsonValue> = {};
  for (const key of ['code', 'reason']) {
    const value = candidate[key];
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      details[key] = value;
    }
  }
  return details;
}

function validEntityType(value: JsonValue | undefined): MetricEntityType {
  return value === 'site' || value === 'cell' || value === 'ue' || value === 'radio' ? value : 'radio';
}

function validSeverity(value: JsonValue | undefined): CanonicalEvent['severity'] {
  return value === 'warning' || value === 'error' || value === 'critical' ? value : 'info';
}

function identifier(value: JsonValue | undefined): string | undefined {
  return typeof value === 'string' || typeof value === 'number' ? String(value) : undefined;
}
