import { RegistryObservationFactory, type CanonicalMetricObservation, type JsonValue, type MetricRegistry } from '@connector-sdk/index';
import type { AmarisoftParseResult, AmarisoftParserContext } from '../amarisoft.types';
import { amarisoftMetricRegistry } from '../metrics/amarisoft-metric.registry';
import { parseEvents } from './event.parser';
import { asFiniteNumber, isJsonArray, isJsonRecord, responseObservedAt } from './parser.helpers';

interface StatsMapping { metric: string; path: readonly string[] }
const mappings: readonly StatsMapping[] = [
  { metric: 'radio.site.cpu_load', path: ['cpu', 'load'] },
  { metric: 'radio.site.memory_used', path: ['memory', 'used'] },
  { metric: 'radio.target.ue_count', path: ['ue_count'] },
];

/** Explicit allow-list parser for `stats`; unregistered vendor fields are ignored and remain raw. */
export class StatsParser {
  private readonly factory: RegistryObservationFactory;

  constructor(registry: MetricRegistry = amarisoftMetricRegistry) {
    this.factory = new RegistryObservationFactory(registry);
  }

  parse(payload: JsonValue, context: AmarisoftParserContext): AmarisoftParseResult {
    if (!isJsonRecord(payload)) return { observations: [], events: [], warnings: ['stats response is not an object'] };
    const observedAt = responseObservedAt(payload, context.observedAt);
    const observations: CanonicalMetricObservation[] = [];
    for (const mapping of mappings) {
      const value = asFiniteNumber(this.atPath(payload, mapping.path));
      if (value === undefined) continue;
      observations.push(this.factory.create({ metricName: mapping.metric, observedAt, externalEntityId: context.targetId, value }));
    }
    const cells = payload['cells'];
    if (isJsonArray(cells)) {
      for (const candidate of cells) {
        if (!isJsonRecord(candidate)) continue;
        const identifier = candidate['cell_id'];
        if (typeof identifier !== 'string' && typeof identifier !== 'number') continue;
        const cellId = String(identifier);
        for (const [field, metricName] of [
          ['dl_bitrate', 'radio.cell.dl_bitrate'],
          ['ul_bitrate', 'radio.cell.ul_bitrate'],
          ['ue_count', 'radio.cell.ue_count'],
        ] as const) {
          const value = asFiniteNumber(candidate[field]);
          if (value !== undefined) observations.push(this.factory.create({ metricName, observedAt, externalEntityId: cellId, value }));
        }
      }
    }
    return { observations, events: parseEvents(payload, context), warnings: [] };
  }

  private atPath(root: JsonValue, path: readonly string[]): JsonValue | undefined {
    let current: JsonValue | undefined = root;
    for (const segment of path) {
      if (!isJsonRecord(current)) return undefined;
      current = current[segment];
    }
    return current;
  }
}
