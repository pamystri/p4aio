import type { JsonValue } from '@connector-sdk/index';

export function isJsonRecord(value: JsonValue): value is { readonly [key: string]: JsonValue } {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function isJsonArray(value: JsonValue | undefined): value is readonly JsonValue[] {
  return Array.isArray(value);
}

export function asFiniteNumber(value: JsonValue | undefined): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}

export function externalIdentifier(record: { readonly [key: string]: JsonValue }): string | undefined {
  for (const field of ['ran_ue_id', 'enb_ue_id', 'ue_id']) {
    const value = record[field];
    if (typeof value === 'string' || typeof value === 'number') return `${field}:${String(value)}`;
  }
  return undefined;
}

export function responseObservedAt(
  payload: { readonly [key: string]: JsonValue },
  fallback: Date,
): Date {
  const utc = asFiniteNumber(payload['utc']);
  return utc === undefined ? fallback : new Date(utc * 1000);
}
