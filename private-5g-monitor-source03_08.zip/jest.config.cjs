module.exports = {
  moduleFileExtensions: ['js', 'json', 'ts'],
  rootDir: '.',
  testRegex: '.*\\.spec\\.ts$',
  transform: { '^.+\\.(t|j)s$': ['ts-jest', { tsconfig: 'tsconfig.json' }] },
  collectCoverageFrom: ['apps/**/*.ts', 'packages/**/*.ts', '!**/main.ts'],
  coverageDirectory: 'coverage',
  testEnvironment: 'node',
  moduleNameMapper: {
    '^@app/(.*)$': '<rootDir>/apps/server/src/$1',
    '^@domain/(.*)$': '<rootDir>/packages/domain/src/$1',
    '^@application/(.*)$': '<rootDir>/packages/application/src/$1',
    '^@connector-sdk/(.*)$': '<rootDir>/packages/connector-sdk/src/$1',
    '^@amarisoft/(.*)$': '<rootDir>/packages/connectors/amarisoft/src/$1',
    '^@persistence/(.*)$': '<rootDir>/packages/persistence-postgres/src/$1',
  },
};
