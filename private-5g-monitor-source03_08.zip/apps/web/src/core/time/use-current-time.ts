'use client';

import { useLive } from '@/core/live/live-context';

const applicationLoadedAt = Date.now();

/** Returns a render-stable clock that advances with live or scheduled refreshes. */
export function useCurrentTime(): number {
  const { lastUpdate } = useLive();
  return lastUpdate?.getTime() ?? applicationLoadedAt;
}
