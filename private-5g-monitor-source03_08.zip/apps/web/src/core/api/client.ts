import type { ProblemDetails } from './types';

const configuredBaseUrl = process.env.NEXT_PUBLIC_API_URL;

export function apiBaseUrl(): string {
  if (typeof window === 'undefined') return configuredBaseUrl ?? 'http://127.0.0.1:3000/api/v1';
  return localStorage.getItem('monitor.apiUrl') ?? configuredBaseUrl ?? `${window.location.origin}/api/v1`;
}

export function apiKey(): string {
  return typeof window === 'undefined' ? '' : localStorage.getItem('monitor.apiKey') ?? '';
}

export function queryString(values: Record<string, string | number | boolean | null | undefined>): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) if (value !== undefined && value !== null && value !== '') params.set(key, String(value));
  const text = params.toString();
  return text ? `?${text}` : '';
}

export async function apiFetch<T>(path: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(`${apiBaseUrl()}${path}`, {
    signal,
    cache: 'no-store',
    headers: { Accept: 'application/json', ...(apiKey() ? { 'x-api-key': apiKey() } : {}) },
  });
  if (!response.ok) {
    const problem = await response.json().catch(() => ({ title: response.statusText, status: response.status })) as ProblemDetails;
    throw new Error(problem.detail ?? problem.errors?.join(', ') ?? problem.title ?? `Request failed (${response.status})`);
  }
  return response.json() as Promise<T>;
}

export async function apiSend<T>(path: string, method: 'POST' | 'PUT' | 'PATCH' | 'DELETE', body?: unknown): Promise<T | undefined> {
  const response = await fetch(`${apiBaseUrl()}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...(apiKey() ? { 'x-api-key': apiKey() } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!response.ok) throw new Error((await response.json().catch(() => null) as ProblemDetails | null)?.detail ?? `Request failed (${response.status})`);
  return response.status === 204 ? undefined : response.json() as Promise<T>;
}
