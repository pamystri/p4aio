'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from './client';
import { useLive } from '@/core/live/live-context';

export function useApi<T>(path: string | null) {
  const { generation } = useLive();
  const requestKey = path === null ? null : `${generation}:${path}`;
  const [result, setResult] = useState<{ requestKey: string | null; data: T | null; error: string | null }>({ requestKey: null, data: null, error: null });
  useEffect(() => {
    if (!path || !requestKey) return;
    const controller = new AbortController();
    void apiFetch<T>(path, controller.signal)
      .then((data) => { if (!controller.signal.aborted) setResult({ requestKey, data, error: null }); })
      .catch((reason: unknown) => { if (!controller.signal.aborted) setResult({ requestKey, data: null, error: reason instanceof Error ? reason.message : 'Unable to load data' }); });
    return () => controller.abort();
  }, [path, requestKey]);
  return {
    data: result.data,
    error: result.requestKey === requestKey ? result.error : null,
    loading: requestKey !== null && result.requestKey !== requestKey,
  };
}
