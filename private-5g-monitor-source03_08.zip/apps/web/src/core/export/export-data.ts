export type ExportRow = Record<string, string | number | boolean | null | undefined>;

function download(blob: Blob, filename: string): void {
  const href = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = href; link.download = filename; link.click(); URL.revokeObjectURL(href);
}

export function exportCsv(rows: ExportRow[], filename: string): void {
  if (!rows.length) return; const headers = Object.keys(rows[0]);
  const escape = (value: unknown) => `"${String(value ?? '').replaceAll('"', '""')}"`;
  download(new Blob([[headers.join(','), ...rows.map((row) => headers.map((header) => escape(row[header])).join(','))].join('\n')], { type: 'text/csv;charset=utf-8' }), `${filename}.csv`);
}

export async function exportExcel(rows: ExportRow[], filename: string): Promise<void> {
  if (!rows.length) return; const ExcelJS = await import('exceljs'); const workbook = new ExcelJS.Workbook(); const sheet = workbook.addWorksheet('Data');
  const headers = Object.keys(rows[0]); sheet.columns = headers.map((header) => ({ header, key: header, width: Math.min(40, Math.max(12, header.length + 3)) })); rows.forEach((row) => sheet.addRow(row));
  sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } }; sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF087F9B' } }; sheet.views = [{ state: 'frozen', ySplit: 1 }];
  const buffer = await workbook.xlsx.writeBuffer(); download(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), `${filename}.xlsx`);
}

export async function exportPdf(rows: ExportRow[], filename: string, title: string): Promise<void> {
  if (!rows.length) return; const { jsPDF } = await import('jspdf'); const document = new jsPDF({ orientation: 'landscape' });
  document.setFontSize(16); document.text(title, 14, 15); document.setFontSize(8); document.setTextColor(90);
  const headers = Object.keys(rows[0]); document.text(headers.join('  |  ').slice(0, 180), 14, 24); let y = 30;
  for (const row of rows.slice(0, 120)) { document.text(headers.map((key) => String(row[key] ?? '')).join('  |  ').slice(0, 190), 14, y); y += 5; if (y > 190) { document.addPage(); y = 15; } }
  document.save(`${filename}.pdf`);
}
