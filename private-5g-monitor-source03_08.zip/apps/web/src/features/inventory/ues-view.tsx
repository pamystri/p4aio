'use client';

import { Stack, Typography } from '@mui/material';
import { PageHeader } from '@/components/common/page-header';
import { DataTable, type Column } from '@/components/tables/data-table';
import { StatusBadge } from '@/components/common/status-badge';
import { useApi } from '@/core/api/use-api';
import { useCurrentTime } from '@/core/time/use-current-time';
import type { Page, Ue } from '@/core/api/types';

export function UesView() {
  const response = useApi<Page<Ue>>('/ues?limit=1000&sort=desc'); const rows = response.data?.items ?? []; const now = useCurrentTime();
  const active = (row: Ue) => now - new Date(row.lastSeenAt).getTime() < 300_000;
  const columns: Array<Column<Ue>> = [{ key: 'ue', label: 'UE pseudonym', render: (row) => <Stack><Typography fontFamily="monospace" fontWeight={750}>{row.pseudonym}</Typography><Typography variant="caption" color="text.secondary">{row.id.slice(0, 13)}</Typography></Stack>, export: (row) => row.pseudonym }, { key: 'state', label: 'State', render: (row) => <StatusBadge status={active(row) ? 'active' : 'inactive'} />, export: (row) => active(row) ? 'active' : 'inactive' }, { key: 'first', label: 'First seen', render: (row) => new Date(row.firstSeenAt).toLocaleString(), export: (row) => row.firstSeenAt }, { key: 'last', label: 'Last seen', render: (row) => new Date(row.lastSeenAt).toLocaleString(), export: (row) => row.lastSeenAt }];
  return <><PageHeader eyebrow="User equipment" title="UEs" description="Privacy-safe device inventory. Subscriber identities never leave the backend." /><DataTable title={`${rows.filter(active).length} active of ${rows.length} known UEs`} rows={rows} columns={columns} loading={response.loading} error={response.error} searchableText={(row) => `${row.pseudonym} ${row.id}`} filename="ues" /></>;
}
