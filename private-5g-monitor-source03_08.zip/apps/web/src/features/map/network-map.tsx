'use client';

import { Fragment, useEffect } from 'react';
import L from 'leaflet';
import { Circle, MapContainer, Marker, Popup, TileLayer, useMap } from 'react-leaflet';
import type { CollectorStatus, LocationEstimate, Metric, RadioTarget, Site } from '@/core/api/types';

const siteIcon = L.divIcon({ className: 'network-marker', html: '<div class="site-pin"></div>', iconSize: [18, 18], iconAnchor: [9, 9] });
const ueIcon = L.divIcon({ className: 'network-marker', html: '<div class="ue-pin"></div>', iconSize: [14, 14], iconAnchor: [7, 7] });
const traffic = (value: number) => value > 1_000_000 ? `${(value / 1_000_000).toFixed(1)} Mb/s` : `${(value / 1000).toFixed(0)} kb/s`;

function FitBounds({ sites, locations }: { sites: Site[]; locations: LocationEstimate[] }) {
  const map = useMap();
  useEffect(() => { const points = [...sites.filter((site) => site.latitude !== null && site.longitude !== null).map((site) => [site.latitude as number, site.longitude as number] as [number, number]), ...locations.map((location) => [location.latitude, location.longitude] as [number, number])]; if (points.length) map.fitBounds(points, { padding: [42, 42], maxZoom: 16 }); }, [sites, locations, map]);
  return null;
}

export function NetworkMap({ sites, locations, collectors, targets, metrics }: { sites: Site[]; locations: LocationEstimate[]; collectors: CollectorStatus[]; targets: RadioTarget[]; metrics: Metric[] }) {
  const tileUrl = process.env.NEXT_PUBLIC_TILE_URL || 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
  const targetSite = new Map(targets.map((target) => [target.id, target.siteId]));
  return <MapContainer center={[51.505, -0.09]} zoom={13} style={{ height: '100%', minHeight: 580, width: '100%' }} zoomControl attributionControl>
    <TileLayer url={tileUrl} attribution='&copy; OpenStreetMap contributors' />
    <FitBounds sites={sites} locations={locations} />
    {sites.filter((site) => site.latitude !== null && site.longitude !== null).map((site) => {
      const targetIds = targets.filter((target) => target.siteId === site.id).map((target) => target.id); const siteCollectors = collectors.filter((item) => targetIds.includes(item.targetId));
      const userCount = locations.filter((item) => item.siteId === site.id).length; const siteMetrics = metrics.filter((item) => targetSite.get(item.targetId) === site.id);
      const dl = siteMetrics.filter((item) => item.metric.endsWith('dl_bitrate')).reduce((sum, item) => sum + (typeof item.value === 'number' ? item.value : 0), 0); const ul = siteMetrics.filter((item) => item.metric.endsWith('ul_bitrate')).reduce((sum, item) => sum + (typeof item.value === 'number' ? item.value : 0), 0);
      const healthy = siteCollectors.length > 0 && siteCollectors.every((item) => item.lastRunStatus === 'SUCCEEDED');
      return <Marker key={site.id} position={[site.latitude as number, site.longitude as number]} icon={siteIcon}><Popup><strong>{site.name}</strong><br />Status: {healthy ? 'Healthy' : 'Attention required'}<br />Connected users: {userCount}<br />Traffic: ↓ {traffic(dl)} · ↑ {traffic(ul)}<br />Health: {siteCollectors.filter((item) => item.lastRunStatus === 'SUCCEEDED').length}/{siteCollectors.length} radios</Popup></Marker>;
    })}
    {locations.map((location) => <Fragment key={location.id}><Circle center={[location.latitude, location.longitude]} radius={location.horizontalAccuracyM} pathOptions={{ color: '#8b78f6', fillColor: '#8b78f6', fillOpacity: .08, weight: 1 }} /><Marker position={[location.latitude, location.longitude]} icon={ueIcon}><Popup><strong>{location.pseudonym}</strong><br />Estimated location<br />Confidence: {location.confidence === null ? 'Not scored' : `${Math.round(location.confidence * 100)}%`}<br />Accuracy: ±{Math.round(location.horizontalAccuracyM)} m<br />Serving cell: {location.servingCellName ?? location.servingCellId ?? 'Unknown'}<br />Method: {location.method} ({location.algorithmVersion})<br />Timestamp: {new Date(location.estimatedAt).toLocaleString()}</Popup></Marker></Fragment>)}
  </MapContainer>;
}
