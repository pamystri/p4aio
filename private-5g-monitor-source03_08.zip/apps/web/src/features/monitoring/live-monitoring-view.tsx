'use client';

import { useMemo, useState } from 'react';
import { Card, CardContent, Chip, Grid, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { PageHeader } from '@/components/common/page-header';
import { StatusBadge } from '@/components/common/status-badge';
import { DataTable, type Column } from '@/components/tables/data-table';
import { EChart } from '@/components/charts/echart';
import { useApi } from '@/core/api/use-api';
import { queryString } from '@/core/api/client';
import type { Metric, Page } from '@/core/api/types';
import type { EChartsOption } from 'echarts';

const metricChoices = ['radio.ue.dl_bitrate', 'radio.ue.ul_bitrate', 'radio.ue.cqi', 'radio.ue.dl_mcs', 'radio.ue.ul_mcs', 'radio.ue.pusch_snr', 'radio.ue.ul_path_loss', 'radio.ue.initial_ta', 'radio.ue.dl_retx', 'radio.ue.ul_retx'];
const number = (value: Metric['value']) => typeof value === 'number' ? value : Number(value) || 0;

export function LiveMonitoringView() {
  const [metric, setMetric] = useState('radio.ue.dl_bitrate'); const response = useApi<Page<Metric>>(`/metrics/current${queryString({ metric, limit: 1000 })}`); const rows = useMemo(() => response.data?.items ?? [], [response.data]);
  const option = useMemo<EChartsOption>(() => ({ tooltip: { trigger: 'axis' }, grid: { left: 20, right: 15, top: 20, bottom: 55, containLabel: true }, xAxis: { type: 'category', data: rows.slice(0, 30).map((row) => row.ueId?.slice(0, 8) ?? row.cellId?.slice(0, 8) ?? 'radio'), axisLabel: { rotate: 38, color: '#7890a7' } }, yAxis: { type: 'value', axisLabel: { color: '#7890a7' }, splitLine: { lineStyle: { color: 'rgba(142,174,207,.1)' } } }, series: [{ type: 'bar', data: rows.slice(0, 30).map((row) => number(row.value)), itemStyle: { color: '#20bad8', borderRadius: [4, 4, 0, 0] } }] }), [rows]);
  const columns: Array<Column<Metric>> = [
    { key: 'time', label: 'Observed', render: (row) => new Date(row.observedAt).toLocaleTimeString(), export: (row) => row.observedAt },
    { key: 'entity', label: 'Entity', render: (row) => <Typography fontSize={13} fontWeight={650}>{(row.ueId ?? row.cellId ?? row.targetId).slice(0, 12)}</Typography>, export: (row) => row.ueId ?? row.cellId ?? row.targetId },
    { key: 'metric', label: 'Metric', render: (row) => row.metric, export: (row) => row.metric },
    { key: 'value', label: 'Value', render: (row) => <Typography fontFamily="monospace" fontWeight={700}>{String(row.value)} {row.unit}</Typography>, export: (row) => String(row.value) },
    { key: 'cell', label: 'Serving cell', render: (row) => String(row.dimensions.serving_cell_id ?? '—'), export: (row) => String(row.dimensions.serving_cell_id ?? '') },
    { key: 'state', label: 'State', render: () => <StatusBadge status="live" />, export: () => 'live' },
  ];
  return <><PageHeader eyebrow="Real-time telemetry" title="Live monitoring" description="Latest per-UE and per-cell measurements, refreshed by polling-cycle notifications." actions={<Chip color="success" variant="outlined" label="Live feed" />} />
    <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.2} mb={2}><TextField select size="small" label="Metric" value={metric} onChange={(event) => setMetric(event.target.value)} sx={{ minWidth: 270 }}>{metricChoices.map((choice) => <MenuItem key={choice} value={choice}>{choice.replace('radio.ue.', '').replaceAll('_', ' ')}</MenuItem>)}</TextField></Stack>
    <Grid container spacing={2}><Grid size={{ xs: 12, xl: 5 }}><Card><CardContent><Typography variant="h2">Current distribution</Typography><Typography variant="caption" color="text.secondary">Latest value across active entities</Typography><EChart option={option} height={315} ariaLabel={`Current ${metric} distribution`} /></CardContent></Card></Grid><Grid size={{ xs: 12, xl: 7 }}><DataTable title="Live observations" rows={rows} columns={columns} loading={response.loading} error={response.error} searchableText={(row) => `${row.metric} ${row.ueId} ${row.cellId}`} filename="live-metrics" /></Grid></Grid></>;
}
