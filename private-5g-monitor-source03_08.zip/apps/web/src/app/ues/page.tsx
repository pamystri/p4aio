import { UesView } from '@/features/inventory/ues-view';
export default function UesPage() { return <UesView />; }
