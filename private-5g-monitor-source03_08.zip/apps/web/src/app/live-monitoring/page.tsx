import { LiveMonitoringView } from '@/features/monitoring/live-monitoring-view';
export default function LiveMonitoringPage() { return <LiveMonitoringView />; }
