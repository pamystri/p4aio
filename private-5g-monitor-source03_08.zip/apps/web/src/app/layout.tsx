import type { Metadata } from 'next';
import 'leaflet/dist/leaflet.css';
import './globals.css';
import { MonitorThemeProvider } from '@/core/theme/theme-provider';
import { LiveProvider } from '@/core/live/live-context';
import { AppShell } from '@/components/layout/app-shell';

export const metadata: Metadata = { title: { default: 'Private 5G Operations', template: '%s | Private 5G Operations' }, description: 'Local private 5G network monitoring and UE location estimation dashboard', robots: { index: false, follow: false } };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><MonitorThemeProvider><LiveProvider><AppShell>{children}</AppShell></LiveProvider></MonitorThemeProvider></body></html>;
}
