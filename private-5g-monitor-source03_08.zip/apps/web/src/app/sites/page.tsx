import { SitesView } from '@/features/inventory/sites-view';
export default function SitesPage() { return <SitesView />; }
