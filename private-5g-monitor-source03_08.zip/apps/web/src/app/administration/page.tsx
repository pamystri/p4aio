import { AdministrationView } from '@/features/administration/administration-view';
export default function AdministrationPage() { return <AdministrationView />; }
