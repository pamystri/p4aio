import { CellsView } from '@/features/inventory/cells-view';
export default function CellsPage() { return <CellsView />; }
