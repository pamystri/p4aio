'use client';

import { useState, type ReactNode } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { alpha, AppBar, Avatar, Box, Chip, Divider, Drawer, IconButton, List, ListItemButton, ListItemIcon, ListItemText, Stack, Switch, Toolbar, Tooltip, Typography, useMediaQuery, useTheme } from '@mui/material';
import DashboardRounded from '@mui/icons-material/DashboardRounded';
import SensorsRounded from '@mui/icons-material/SensorsRounded';
import AnalyticsRounded from '@mui/icons-material/AnalyticsRounded';
import CellTowerRounded from '@mui/icons-material/CellTowerRounded';
import GridViewRounded from '@mui/icons-material/GridViewRounded';
import DevicesRounded from '@mui/icons-material/DevicesRounded';
import MapRounded from '@mui/icons-material/MapRounded';
import NotificationsRounded from '@mui/icons-material/NotificationsRounded';
import SettingsRounded from '@mui/icons-material/SettingsRounded';
import AdminPanelSettingsRounded from '@mui/icons-material/AdminPanelSettingsRounded';
import MenuRounded from '@mui/icons-material/MenuRounded';
import DarkModeRounded from '@mui/icons-material/DarkModeRounded';
import LightModeRounded from '@mui/icons-material/LightModeRounded';
import RefreshRounded from '@mui/icons-material/RefreshRounded';
import { useThemeMode } from '@/core/theme/theme-provider';
import { useLive } from '@/core/live/live-context';

const drawerWidth = 252;
const navigation = [
  ['Dashboard', '/', DashboardRounded], ['Live Monitoring', '/live-monitoring', SensorsRounded],
  ['Historical Analytics', '/analytics', AnalyticsRounded], ['Sites', '/sites', CellTowerRounded],
  ['Cells', '/cells', GridViewRounded], ['UEs', '/ues', DevicesRounded], ['Network Map', '/map', MapRounded],
  ['Alerts', '/alerts', NotificationsRounded], ['Settings', '/settings', SettingsRounded],
  ['Administration', '/administration', AdminPanelSettingsRounded],
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const path = usePathname(); const theme = useTheme(); const desktop = useMediaQuery(theme.breakpoints.up('lg'));
  const [open, setOpen] = useState(false); const { mode, toggle } = useThemeMode();
  const { connected, lastUpdate, refresh, autoRefresh, setAutoRefresh } = useLive();
  const drawer = <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: mode === 'dark' ? '#081524' : '#fff' }}>
    <Stack direction="row" alignItems="center" spacing={1.4} sx={{ px: 2.4, height: 72 }}>
      <Box sx={{ width: 34, height: 34, borderRadius: 2.3, display: 'grid', placeItems: 'center', color: '#06131f', fontWeight: 900, background: 'linear-gradient(135deg,#77e3f4,#1eb6d4 58%,#8b78f6)' }}>5G</Box>
      <Box><Typography fontWeight={780} letterSpacing="-.02em">Private Network</Typography><Typography variant="caption" color="text.secondary">Operations Center</Typography></Box>
    </Stack><Divider />
    <List sx={{ px: 1.4, py: 1.8 }}>
      {navigation.map(([label, href, Icon]) => { const active = href === '/' ? path === '/' : path.startsWith(href); return <ListItemButton key={href} component={Link} href={href} onClick={() => setOpen(false)} selected={active} sx={{ mb: .35, minHeight: 43, borderRadius: 2, '&.Mui-selected': { color: 'primary.light', bgcolor: alpha(theme.palette.primary.main, .13), '&:hover': { bgcolor: alpha(theme.palette.primary.main, .17) } } }}><ListItemIcon sx={{ minWidth: 38, color: active ? 'primary.main' : 'text.secondary' }}><Icon fontSize="small" /></ListItemIcon><ListItemText primary={label} primaryTypographyProps={{ fontSize: 13.5, fontWeight: active ? 700 : 560 }} /></ListItemButton>; })}
    </List>
    <Box sx={{ mt: 'auto', p: 2 }}><Box sx={{ p: 1.5, borderRadius: 2.5, bgcolor: alpha(theme.palette.primary.main, .06), border: '1px solid', borderColor: 'divider' }}><Stack direction="row" justifyContent="space-between" alignItems="center"><Typography variant="caption" color="text.secondary">Live service</Typography><Chip size="small" label={connected ? 'Connected' : 'Offline'} color={connected ? 'success' : 'error'} variant="outlined" sx={{ height: 23, fontSize: 10.5 }} /></Stack><Typography mt={1} variant="caption" display="block">{lastUpdate ? `Updated ${lastUpdate.toLocaleTimeString()}` : 'Waiting for first update'}</Typography></Box></Box>
  </Box>;
  return <Box sx={{ minHeight: '100vh' }}>
    <AppBar elevation={0} color="transparent" position="fixed" sx={{ ml: desktop ? `${drawerWidth}px` : 0, width: desktop ? `calc(100% - ${drawerWidth}px)` : '100%', borderBottom: '1px solid', borderColor: 'divider', backdropFilter: 'blur(14px)', bgcolor: alpha(theme.palette.background.default, .78) }}><Toolbar sx={{ minHeight: '64px!important', px: { xs: 1.5, md: 3 } }}>
      {!desktop && <IconButton onClick={() => setOpen(true)} aria-label="Open navigation"><MenuRounded /></IconButton>}
      <Box sx={{ flex: 1 }}><Typography variant="caption" color="text.secondary" sx={{ display: { xs: 'none', sm: 'block' } }}>LOCAL NETWORK OPERATIONS</Typography></Box>
      <Stack direction="row" alignItems="center" spacing={.5}><Tooltip title="Automatic refresh"><Stack direction="row" alignItems="center"><Typography variant="caption" color="text.secondary" sx={{ display: { xs: 'none', md: 'block' } }}>Auto</Typography><Switch size="small" checked={autoRefresh} onChange={(_, checked) => setAutoRefresh(checked)} /></Stack></Tooltip><Tooltip title="Refresh now"><IconButton onClick={refresh}><RefreshRounded fontSize="small" /></IconButton></Tooltip><Tooltip title={mode === 'dark' ? 'Light mode' : 'Dark mode'}><IconButton onClick={toggle}>{mode === 'dark' ? <LightModeRounded fontSize="small" /> : <DarkModeRounded fontSize="small" />}</IconButton></Tooltip><Avatar sx={{ width: 31, height: 31, ml: 1, bgcolor: 'secondary.main', fontSize: 12, fontWeight: 800 }}>OP</Avatar></Stack>
    </Toolbar></AppBar>
    {desktop ? <Drawer variant="permanent" sx={{ width: drawerWidth, '& .MuiDrawer-paper': { width: drawerWidth, borderRightColor: 'divider' } }}>{drawer}</Drawer> : <Drawer open={open} onClose={() => setOpen(false)} sx={{ '& .MuiDrawer-paper': { width: drawerWidth } }}>{drawer}</Drawer>}
    <Box component="main" sx={{ ml: desktop ? `${drawerWidth}px` : 0, pt: '64px', minHeight: '100vh' }}><Box sx={{ p: { xs: 2, sm: 2.5, md: 3.5 }, maxWidth: 1680, mx: 'auto' }}>{children}</Box></Box>
  </Box>;
}
