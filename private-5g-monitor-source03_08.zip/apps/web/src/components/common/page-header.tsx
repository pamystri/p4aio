import type { ReactNode } from 'react';
import { Box, Stack, Typography } from '@mui/material';

export function PageHeader({ eyebrow, title, description, actions }: { eyebrow?: string; title: string; description: string; actions?: ReactNode }) {
  return <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ xs: 'flex-start', md: 'center' }} spacing={2} mb={3}>
    <Box>{eyebrow && <Typography variant="overline" color="primary.main">{eyebrow}</Typography>}<Typography variant="h1">{title}</Typography><Typography color="text.secondary" mt={.6} maxWidth={760}>{description}</Typography></Box>{actions && <Stack direction="row" spacing={1}>{actions}</Stack>}
  </Stack>;
}
