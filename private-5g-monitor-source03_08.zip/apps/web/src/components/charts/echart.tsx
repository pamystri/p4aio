'use client';

import { useEffect, useRef } from 'react';
import type { EChartsOption } from 'echarts';

export function EChart({ option, height = 300, ariaLabel }: { option: EChartsOption; height?: number; ariaLabel: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let disposed = false; let cleanup: (() => void) | undefined;
    void import('echarts').then((echarts) => {
      if (!ref.current || disposed) return;
      const chart = echarts.init(ref.current, undefined, { renderer: 'canvas' }); chart.setOption(option);
      const resize = new ResizeObserver(() => chart.resize()); resize.observe(ref.current);
      cleanup = () => { resize.disconnect(); chart.dispose(); };
    });
    return () => { disposed = true; cleanup?.(); };
  }, [option]);
  return <div ref={ref} role="img" aria-label={ariaLabel} style={{ height, width: '100%' }} />;
}

export function timeSeriesOption(series: Array<{ name: string; data: Array<[string, number]>; color?: string }>, unit = ''): EChartsOption {
  return { animationDuration: 450, color: series.map((item) => item.color).filter(Boolean) as string[], tooltip: { trigger: 'axis', backgroundColor: 'rgba(8,21,36,.96)', borderColor: 'rgba(142,174,207,.2)', textStyle: { color: '#dce9f5' } }, legend: { top: 0, right: 8, textStyle: { color: '#8da6be' } }, grid: { top: 42, left: 12, right: 14, bottom: 24, containLabel: true }, dataZoom: [{ type: 'inside', filterMode: 'none' }], xAxis: { type: 'time', axisLine: { lineStyle: { color: 'rgba(142,174,207,.18)' } }, axisLabel: { color: '#7890a7' }, splitLine: { show: false } }, yAxis: { type: 'value', name: unit, nameTextStyle: { color: '#7890a7' }, axisLabel: { color: '#7890a7' }, splitLine: { lineStyle: { color: 'rgba(142,174,207,.09)' } } }, series: series.map((item) => ({ name: item.name, type: 'line', showSymbol: false, smooth: .26, lineStyle: { width: 2 }, areaStyle: { opacity: .06 }, data: item.data })) };
}
