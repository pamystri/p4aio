import { ConflictException } from '@nestjs/common';
import type { VendorConnector } from '@connector-sdk/index';
import { ConnectorRegistryService } from './connector-registry.service';

function fakeConnector(id: string): VendorConnector {
  return {
    manifest: {
      id,
      displayName: id,
      version: '1.0.0',
      sdkVersion: '1',
      description: 'test connector',
      kind: 'vendor-connector',
      vendor: 'test',
      configurationSchema: {},
      capabilities: [],
    },
    initialize: jest.fn().mockResolvedValue(undefined),
    shutdown: jest.fn().mockResolvedValue(undefined),
    validateConfiguration: jest.fn().mockResolvedValue(undefined),
    openSession: jest.fn(),
  };
}

describe('ConnectorRegistryService', () => {
  it('registers and resolves a connector', async () => {
    const registry = new ConnectorRegistryService();
    const connector = fakeConnector('test');
    await registry.register(connector);
    expect(registry.resolve('test')).toBe(connector);
    expect(registry.list()).toHaveLength(1);
  });

  it('rejects duplicate connector IDs', async () => {
    const registry = new ConnectorRegistryService();
    await registry.register(fakeConnector('test'));
    await expect(registry.register(fakeConnector('test'))).rejects.toBeInstanceOf(ConflictException);
  });
});
