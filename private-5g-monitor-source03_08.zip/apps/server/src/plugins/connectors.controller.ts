import { Controller, Get } from '@nestjs/common';
import { ApiOkResponse, ApiSecurity, ApiTags } from '@nestjs/swagger';
import type { ConnectorManifest } from '@connector-sdk/index';
import { ConnectorRegistryService } from './connector-registry.service';

@ApiTags('connectors')
@ApiSecurity('api-key')
@Controller('connectors')
export class ConnectorsController {
  constructor(private readonly registry: ConnectorRegistryService) {}

  @Get()
  @ApiOkResponse({ description: 'Connectors loaded into the current application process' })
  list(): ConnectorManifest[] {
    return this.registry.list();
  }
}
