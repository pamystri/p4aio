import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import type { ConnectorManifest, VendorConnector } from '@connector-sdk/index';

@Injectable()
export class ConnectorRegistryService {
  private readonly connectors = new Map<string, VendorConnector>();

  async register(connector: VendorConnector): Promise<void> {
    const key = connector.manifest.id;
    if (this.connectors.has(key)) {
      throw new ConflictException(`Connector ${key} is already registered`);
    }
    await connector.initialize();
    this.connectors.set(key, connector);
  }

  resolve(key: string): VendorConnector {
    const connector = this.connectors.get(key);
    if (!connector) throw new NotFoundException(`Connector ${key} is not registered`);
    return connector;
  }

  list(): ConnectorManifest[] {
    return [...this.connectors.values()]
      .map((connector) => connector.manifest)
      .sort((left, right) => left.id.localeCompare(right.id));
  }

  async shutdown(): Promise<void> {
    await Promise.allSettled([...this.connectors.values()].map((connector) => connector.shutdown()));
    this.connectors.clear();
  }
}
