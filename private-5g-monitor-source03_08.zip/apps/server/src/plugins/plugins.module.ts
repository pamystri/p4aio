import { Module, OnApplicationShutdown } from '@nestjs/common';
import { ConnectorRegistryService } from './connector-registry.service';
import { ConnectorsController } from './connectors.controller';

@Module({
  controllers: [ConnectorsController],
  providers: [ConnectorRegistryService],
  exports: [ConnectorRegistryService],
})
export class PluginsModule implements OnApplicationShutdown {
  constructor(private readonly registry: ConnectorRegistryService) {}

  async onApplicationShutdown(): Promise<void> {
    await this.registry.shutdown();
  }
}
