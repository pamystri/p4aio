import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { MONITORING_QUERY_REPOSITORY, type MonitoringQueryRepository } from '@application/monitoring/monitoring-query.repository';
import type { AlarmQueryDto, EntityQueryDto, HistoricalMetricQueryDto, MetricQueryDto } from './dto/monitoring-query.dto';

@Injectable()
export class MonitoringService {
  constructor(@Inject(MONITORING_QUERY_REPOSITORY) private readonly queries: MonitoringQueryRepository, private readonly config: ConfigService) {}
  cells(query: EntityQueryDto) { return this.queries.listCells(query); }
  async cell(id: string) { const value = await this.queries.getCell(id); if (!value) throw new NotFoundException(`Cell ${id} was not found`); return value; }
  ues(query: EntityQueryDto) { return this.queries.listUes(query); }
  async ue(id: string) { const value = await this.queries.getUe(id); if (!value) throw new NotFoundException(`UE ${id} was not found`); return value; }
  currentMetrics(query: MetricQueryDto) { return this.queries.currentMetrics(query); }
  historicalMetrics(query: HistoricalMetricQueryDto) {
    const range = this.range(query.from, query.to, query.aggregation ? 730 : 90);
    if (Boolean(query.aggregation) !== Boolean(query.bucket)) throw new BadRequestException('aggregation and bucket must be supplied together');
    if (query.aggregation && query.bucket) return this.queries.aggregateMetrics({ ...query, ...range, aggregation: query.aggregation, bucket: query.bucket }).then((items) => ({ items, nextCursor: null }));
    return this.queries.historicalMetrics({ ...query, ...range });
  }
  alarms(query: AlarmQueryDto, currentOnly: boolean) {
    const now = new Date(); const defaults = currentOnly ? new Date(now.getTime() - 86_400_000) : new Date(now.getTime() - 30 * 86_400_000);
    const range = this.range(query.from ?? defaults.toISOString(), query.to ?? now.toISOString(), currentOnly ? 7 : 365);
    return this.queries.alarms({ ...query, ...range, currentOnly });
  }
  collectorStatus(siteId?: string, targetId?: string) { return this.queries.collectorStatus(siteId, targetId); }
  currentLocations(siteId?: string, targetId?: string) { return this.queries.currentLocations(siteId, targetId, 1000); }
  statistics(siteId?: string, targetId?: string) { return this.queries.statistics(siteId, targetId); }
  configuration() {
    return {
      application: { name: this.config.getOrThrow<string>('application.name'), environment: this.config.getOrThrow<string>('application.environment') },
      scheduler: { enabled: this.config.getOrThrow<boolean>('scheduler.enabled'), tickMs: this.config.getOrThrow<number>('scheduler.tickMs'), maxConcurrency: this.config.getOrThrow<number>('scheduler.maxConcurrency') },
      authentication: { mode: this.config.getOrThrow<string>('authentication.mode') },
      limits: { historicalRawMaximumDays: 90, historicalAggregatedMaximumDays: 730, maximumPageSize: 1000 },
    };
  }
  private range(fromText: string, toText: string, maximumDays: number): { from: Date; to: Date } {
    const from = new Date(fromText); const to = new Date(toText);
    if (from >= to) throw new BadRequestException('from must be earlier than to');
    if (to.getTime() - from.getTime() > maximumDays * 86_400_000) throw new BadRequestException(`Time range exceeds ${maximumDays} days`);
    if (to.getTime() > Date.now() + 60_000) throw new BadRequestException('to cannot be in the future');
    return { from, to };
  }
}
