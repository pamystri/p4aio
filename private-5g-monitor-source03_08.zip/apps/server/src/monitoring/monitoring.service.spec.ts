import { BadRequestException, NotFoundException } from '@nestjs/common';
import type { ConfigService } from '@nestjs/config';
import type { MonitoringQueryRepository } from '@application/monitoring/monitoring-query.repository';
import { MonitoringService } from './monitoring.service';

describe('MonitoringService', () => {
  const queries = {
    listCells: jest.fn(), getCell: jest.fn(), listUes: jest.fn(), getUe: jest.fn(),
    currentMetrics: jest.fn(), historicalMetrics: jest.fn(), aggregateMetrics: jest.fn(),
    alarms: jest.fn(), collectorStatus: jest.fn(), currentLocations: jest.fn(), statistics: jest.fn(),
  } as jest.Mocked<MonitoringQueryRepository>;
  const values: Record<string, unknown> = {
    'application.name': 'test-monitor', 'application.environment': 'test',
    'scheduler.enabled': true, 'scheduler.tickMs': 1000, 'scheduler.maxConcurrency': 3,
    'authentication.mode': 'api-key',
  };
  const config = { getOrThrow: jest.fn((key: string) => values[key]) } as unknown as ConfigService;
  const service = new MonitoringService(queries, config);

  beforeEach(() => jest.clearAllMocks());

  it('requires aggregation and bucket together', () => {
    expect(() => service.historicalMetrics({ from: '2026-01-01T00:00:00Z', to: '2026-01-02T00:00:00Z', aggregation: 'avg', limit: 100, sort: 'desc' })).toThrow(BadRequestException);
  });

  it('rejects reversed and unbounded historical ranges', () => {
    expect(() => service.historicalMetrics({ from: '2026-01-02T00:00:00Z', to: '2026-01-01T00:00:00Z', limit: 100, sort: 'desc' })).toThrow('from must be earlier');
    expect(() => service.historicalMetrics({ from: '2025-01-01T00:00:00Z', to: '2026-01-01T00:00:00Z', limit: 100, sort: 'desc' })).toThrow('exceeds 90 days');
  });

  it('delegates validated database aggregation with a stable page envelope', async () => {
    queries.aggregateMetrics.mockResolvedValue([{ bucket: new Date('2026-01-01T00:00:00Z'), metric: 'radio.ue.cqi', unit: '1', value: 12, sampleCount: 4 }]);
    await expect(service.historicalMetrics({ from: '2026-01-01T00:00:00Z', to: '2026-01-02T00:00:00Z', aggregation: 'avg', bucket: 'hour', limit: 100, sort: 'asc' })).resolves.toEqual(expect.objectContaining({ nextCursor: null }));
    expect(queries.aggregateMetrics).toHaveBeenCalledWith(expect.objectContaining({ aggregation: 'avg', bucket: 'hour', from: expect.any(Date), to: expect.any(Date) }));
  });

  it('never exposes API keys from effective configuration', () => {
    const result = service.configuration();
    expect(result.authentication).toEqual({ mode: 'api-key' });
    expect(JSON.stringify(result)).not.toContain('apiKey');
  });

  it('returns not-found responses for missing entities', async () => {
    queries.getCell.mockResolvedValue(null);
    await expect(service.cell('00000000-0000-0000-0000-000000000000')).rejects.toBeInstanceOf(NotFoundException);
  });
});
