import { Type } from 'class-transformer';
import { IsEnum, IsISO8601, IsInt, IsOptional, IsString, IsUUID, Matches, Max, MaxLength, Min } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class PageQueryDto {
  @ApiPropertyOptional({ default: 100, minimum: 1, maximum: 1000 }) @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(1000) limit = 100;
  @ApiPropertyOptional({ enum: ['asc', 'desc'], default: 'desc' }) @IsOptional() @IsEnum(['asc', 'desc']) sort: 'asc' | 'desc' = 'desc';
}

export class EntityQueryDto extends PageQueryDto {
  @ApiPropertyOptional({ description: 'UUID cursor returned by the previous page' }) @IsOptional() @IsUUID() cursor?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() siteId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() targetId?: string;
  @ApiPropertyOptional({ maxLength: 100 }) @IsOptional() @IsString() @MaxLength(100) search?: string;
}

export class MetricQueryDto extends PageQueryDto {
  @ApiPropertyOptional() @IsOptional() @IsUUID() siteId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() targetId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() cellId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() ueId?: string;
  @ApiPropertyOptional({ example: 'radio.ue.dl_bitrate' }) @IsOptional() @Matches(/^[a-z][a-z0-9_.]{1,127}$/) metric?: string;
  @ApiPropertyOptional({ description: 'Numeric cursor returned by the previous page' }) @IsOptional() @Matches(/^\d{1,19}$/) cursor?: string;
}

export class HistoricalMetricQueryDto extends MetricQueryDto {
  @ApiProperty({ example: '2026-07-30T00:00:00Z' }) @IsISO8601({ strict: true }) from!: string;
  @ApiProperty({ example: '2026-07-31T00:00:00Z' }) @IsISO8601({ strict: true }) to!: string;
  @ApiPropertyOptional({ enum: ['avg', 'sum', 'min', 'max'] }) @IsOptional() @IsEnum(['avg', 'sum', 'min', 'max']) aggregation?: 'avg' | 'sum' | 'min' | 'max';
  @ApiPropertyOptional({ enum: ['minute', 'hour', 'day'] }) @IsOptional() @IsEnum(['minute', 'hour', 'day']) bucket?: 'minute' | 'hour' | 'day';
}

export class AlarmQueryDto extends PageQueryDto {
  @ApiPropertyOptional() @IsOptional() @IsUUID() siteId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() targetId?: string;
  @ApiPropertyOptional({ enum: ['warning', 'error', 'critical'] }) @IsOptional() @IsEnum(['warning', 'error', 'critical']) severity?: 'warning' | 'error' | 'critical';
  @ApiPropertyOptional() @IsOptional() @IsISO8601({ strict: true }) from?: string;
  @ApiPropertyOptional() @IsOptional() @IsISO8601({ strict: true }) to?: string;
  @ApiPropertyOptional({ description: 'Numeric cursor returned by the previous page' }) @IsOptional() @Matches(/^\d{1,19}$/) cursor?: string;
}

export class ScopeQueryDto {
  @ApiPropertyOptional() @IsOptional() @IsUUID() siteId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() targetId?: string;
}
