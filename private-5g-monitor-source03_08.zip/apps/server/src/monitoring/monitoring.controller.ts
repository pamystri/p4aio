import { Controller, Get, Param, ParseUUIDPipe, Query } from '@nestjs/common';
import { ApiOkResponse, ApiOperation, ApiSecurity, ApiTags } from '@nestjs/swagger';
import { AlarmQueryDto, EntityQueryDto, HistoricalMetricQueryDto, MetricQueryDto, ScopeQueryDto } from './dto/monitoring-query.dto';
import { MonitoringService } from './monitoring.service';

@ApiSecurity('api-key')
@Controller()
export class MonitoringController {
  constructor(private readonly monitoring: MonitoringService) {}

  @ApiTags('cells') @Get('cells') @ApiOkResponse({ description: 'Filtered cursor-paginated cells' }) cells(@Query() query: EntityQueryDto) { return this.monitoring.cells(query); }
  @ApiTags('cells') @Get('cells/:id') @ApiOkResponse({ description: 'Cell details' }) cell(@Param('id', new ParseUUIDPipe()) id: string) { return this.monitoring.cell(id); }
  @ApiTags('ues') @Get('ues') @ApiOkResponse({ description: 'Filtered cursor-paginated pseudonymized UEs' }) ues(@Query() query: EntityQueryDto) { return this.monitoring.ues(query); }
  @ApiTags('ues') @Get('ues/:id') @ApiOkResponse({ description: 'Pseudonymized UE details' }) ue(@Param('id', new ParseUUIDPipe()) id: string) { return this.monitoring.ue(id); }
  @ApiTags('metrics') @Get('metrics/current') @ApiOperation({ summary: 'Latest value per metric/entity/dimension combination' }) currentMetrics(@Query() query: MetricQueryDto) { return this.monitoring.currentMetrics(query); }
  @ApiTags('metrics') @Get('metrics/historical') @ApiOperation({ summary: 'Raw or database-aggregated historical metrics' }) historicalMetrics(@Query() query: HistoricalMetricQueryDto) { return this.monitoring.historicalMetrics(query); }
  @ApiTags('alarms') @Get('alarms/current') @ApiOperation({ summary: 'Latest warning-or-higher alarm per entity and type' }) currentAlarms(@Query() query: AlarmQueryDto) { return this.monitoring.alarms(query, true); }
  @ApiTags('alarms') @Get('alarms/historical') @ApiOperation({ summary: 'Historical alarms over a bounded time range' }) historicalAlarms(@Query() query: AlarmQueryDto) { return this.monitoring.alarms(query, false); }
  @ApiTags('collectors') @Get('collectors/status') @ApiOperation({ summary: 'Collector, run, and schedule status by radio' }) collectorStatus(@Query() query: ScopeQueryDto) { return this.monitoring.collectorStatus(query.siteId, query.targetId); }
  @ApiTags('locations') @Get('locations/current') @ApiOperation({ summary: 'Latest algorithm-neutral estimated position for each UE' }) currentLocations(@Query() query: ScopeQueryDto) { return this.monitoring.currentLocations(query.siteId, query.targetId); }
  @ApiTags('configuration') @Get('configuration') @ApiOperation({ summary: 'Safe effective runtime configuration; secrets are never returned' }) configuration() { return this.monitoring.configuration(); }
  @ApiTags('statistics') @Get('statistics') @ApiOperation({ summary: 'Operational inventory and health summary' }) statistics(@Query() query: ScopeQueryDto) { return this.monitoring.statistics(query.siteId, query.targetId); }
}
