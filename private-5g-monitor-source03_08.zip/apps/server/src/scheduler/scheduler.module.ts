import { Module } from '@nestjs/common';
import { PersistenceModule } from '@persistence/persistence.module';
import { PollSchedulerService } from './poll-scheduler.service';
import { PollTaskHandlerRegistry } from './poll-task-handler.registry';

@Module({
  imports: [PersistenceModule],
  providers: [PollSchedulerService, PollTaskHandlerRegistry],
  exports: [PollSchedulerService, PollTaskHandlerRegistry],
})
export class SchedulerModule {}
