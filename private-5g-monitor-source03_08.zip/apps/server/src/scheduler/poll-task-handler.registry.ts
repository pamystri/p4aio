import { ConflictException, Injectable } from '@nestjs/common';
import type { DuePollTask } from '@application/scheduler/poll-schedule.repository';

export interface PollTaskHandler {
  readonly id: string;
  supports(task: DuePollTask): boolean;
  execute(task: DuePollTask, signal: AbortSignal): Promise<void>;
}

@Injectable()
export class PollTaskHandlerRegistry {
  private readonly handlers = new Map<string, PollTaskHandler>();

  register(handler: PollTaskHandler): void {
    if (this.handlers.has(handler.id)) {
      throw new ConflictException(`Poll handler ${handler.id} is already registered`);
    }
    this.handlers.set(handler.id, handler);
  }

  find(task: DuePollTask): PollTaskHandler | undefined {
    return [...this.handlers.values()].find((handler) => handler.supports(task));
  }
}
