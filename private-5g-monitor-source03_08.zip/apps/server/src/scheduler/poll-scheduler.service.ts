import { Inject, Injectable, OnApplicationBootstrap, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PinoLogger } from 'nestjs-pino';
import {
  POLL_SCHEDULE_REPOSITORY,
  type DuePollTask,
  type PollScheduleRepository,
} from '@application/scheduler/poll-schedule.repository';
import { PollTaskHandlerRegistry } from './poll-task-handler.registry';

@Injectable()
export class PollSchedulerService implements OnApplicationBootstrap, OnModuleDestroy {
  private timer?: NodeJS.Timeout;
  private ticking = false;
  private readonly activeTargets = new Set<string>();
  private readonly activeExecutions = new Set<Promise<void>>();
  private readonly controllers = new Map<string, AbortController>();
  private lastTickAt: Date | null = null;

  constructor(
    @Inject(POLL_SCHEDULE_REPOSITORY) private readonly schedules: PollScheduleRepository,
    private readonly handlers: PollTaskHandlerRegistry,
    private readonly config: ConfigService,
    private readonly logger: PinoLogger,
  ) {
    this.logger.setContext(PollSchedulerService.name);
  }

  onApplicationBootstrap(): void {
    if (!this.config.getOrThrow<boolean>('scheduler.enabled')) return;
    const tickMs = this.config.getOrThrow<number>('scheduler.tickMs');
    this.timer = setInterval(() => void this.tick(), tickMs);
    this.timer.unref();
    void this.tick();
  }

  async onModuleDestroy(): Promise<void> {
    if (this.timer) clearInterval(this.timer);
    for (const controller of this.controllers.values()) controller.abort();
    await Promise.allSettled([...this.activeExecutions]);
  }

  health(): Readonly<Record<string, unknown>> & { ready: boolean } {
    const enabled = this.config.getOrThrow<boolean>('scheduler.enabled');
    const tickMs = this.config.getOrThrow<number>('scheduler.tickMs');
    return {
      ready:
        !enabled ||
        (this.timer !== undefined &&
          this.lastTickAt !== null &&
          Date.now() - this.lastTickAt.getTime() <= tickMs * 3),
      enabled,
      activeTargets: this.activeTargets.size,
      lastTickAt: this.lastTickAt?.toISOString() ?? null,
    };
  }

  private async tick(): Promise<void> {
    if (this.ticking) return;
    this.ticking = true;
    try {
      const capacity = Math.max(
        0,
        this.config.getOrThrow<number>('scheduler.maxConcurrency') - this.activeTargets.size,
      );
      if (capacity === 0) return;
      const tasks = await this.schedules.claimDue(
        new Date(),
        capacity,
        [...this.activeTargets],
      );
      this.lastTickAt = new Date();
      for (const task of tasks) {
        const execution = this.dispatch(task);
        this.activeExecutions.add(execution);
        void execution.then(
          () => this.activeExecutions.delete(execution),
          () => this.activeExecutions.delete(execution),
        );
      }
    } catch (error) {
      this.logger.error({ err: error }, 'Scheduler tick failed');
    } finally {
      this.ticking = false;
    }
  }

  private async dispatch(task: DuePollTask): Promise<void> {
    if (this.activeTargets.has(task.radioTargetId)) return;
    const handler = this.handlers.find(task);
    if (!handler) {
      this.logger.warn(
        { scheduleId: task.scheduleId, logicalOperation: task.logicalOperation },
        'No poll task handler is registered; schedule occurrence skipped',
      );
      return;
    }

    this.activeTargets.add(task.radioTargetId);
    const controller = new AbortController();
    this.controllers.set(task.radioTargetId, controller);
    const timeout = setTimeout(() => controller.abort(), task.timeoutMs);
    try {
      await handler.execute(task, controller.signal);
    } catch (error) {
      this.logger.error(
        { err: error, scheduleId: task.scheduleId, targetId: task.radioTargetId },
        'Scheduled poll task failed',
      );
    } finally {
      clearTimeout(timeout);
      this.controllers.delete(task.radioTargetId);
      this.activeTargets.delete(task.radioTargetId);
    }
  }
}
