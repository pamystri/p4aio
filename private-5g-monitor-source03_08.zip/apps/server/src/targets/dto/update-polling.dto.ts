import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsBoolean, IsInt, IsOptional, Max, Min } from 'class-validator';

export class UpdatePollingDto {
  @ApiProperty({ minimum: 1, maximum: 3600, example: 2 })
  @IsInt()
  @Min(1)
  @Max(3600)
  intervalSeconds!: number;

  @ApiPropertyOptional({ minimum: 250, maximum: 120000, default: 5000 })
  @IsOptional()
  @IsInt()
  @Min(250)
  @Max(120000)
  timeoutMs = 5000;

  @ApiPropertyOptional({ minimum: 1, maximum: 1000, default: 100 })
  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(1000)
  priority = 100;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  enabled = true;
}
