import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsBoolean,
  IsInt,
  IsObject,
  IsOptional,
  IsString,
  IsUUID,
  Matches,
  Max,
  MaxLength,
  Min,
} from 'class-validator';

export class CreateRadioTargetDto {
  @ApiProperty()
  @IsUUID()
  siteId!: string;

  @ApiProperty({ default: 'amarisoft' })
  @IsString()
  connectorKey = 'amarisoft';

  @ApiProperty({ example: 'Factory gNB 1' })
  @IsString()
  @MaxLength(120)
  name!: string;

  @ApiProperty({ example: '10.20.30.40' })
  @IsString()
  @MaxLength(255)
  @Matches(/^[A-Za-z0-9](?:[A-Za-z0-9.:-]*[A-Za-z0-9])?$/)
  managementHost!: string;

  @ApiProperty({ default: 9000 })
  @IsInt()
  @Min(1)
  @Max(65535)
  managementPort = 9000;

  @ApiPropertyOptional({ default: false })
  @IsOptional()
  @IsBoolean()
  enabled = false;

  @ApiPropertyOptional({ type: 'object', additionalProperties: true })
  @IsOptional()
  @IsObject()
  configuration: Record<string, unknown> = {};

  @ApiPropertyOptional({ example: 'env:AMARISOFT_GNB_1_PASSWORD' })
  @IsOptional()
  @Matches(/^env:[A-Z][A-Z0-9_]*$/)
  secretReference?: string;
}
