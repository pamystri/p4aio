import { Body, Controller, Get, HttpCode, Param, ParseUUIDPipe, Post, Put } from '@nestjs/common';
import { ApiCreatedResponse, ApiNoContentResponse, ApiOkResponse, ApiSecurity, ApiTags } from '@nestjs/swagger';
import type { RadioTargetSummary } from '@application/targets/radio-target.repository';
import { CreateRadioTargetDto } from './dto/create-radio-target.dto';
import { UpdatePollingDto } from './dto/update-polling.dto';
import { RadioTargetsService } from './radio-targets.service';

@ApiTags('radio-targets')
@ApiSecurity('api-key')
@Controller('radio-targets')
export class RadioTargetsController {
  constructor(private readonly targets: RadioTargetsService) {}

  @Post()
  @ApiCreatedResponse({ description: 'Radio target created' })
  create(@Body() input: CreateRadioTargetDto): Promise<RadioTargetSummary> {
    return this.targets.create(input);
  }

  @Get()
  @ApiOkResponse({ description: 'Configured radio targets' })
  list(): Promise<RadioTargetSummary[]> {
    return this.targets.list();
  }

  @Get(':targetId/health')
  @ApiOkResponse({ description: 'Live connector health for one radio target' })
  health(@Param('targetId', new ParseUUIDPipe()) targetId: string) {
    return this.targets.health(targetId);
  }

  @Put(':targetId/polling/:operation')
  @HttpCode(204)
  @ApiNoContentResponse({ description: 'Polling schedule updated dynamically' })
  async updatePolling(
    @Param('targetId', new ParseUUIDPipe()) targetId: string,
    @Param('operation') operation: string,
    @Body() input: UpdatePollingDto,
  ): Promise<void> {
    await this.targets.updatePolling(targetId, operation, input);
  }
}
