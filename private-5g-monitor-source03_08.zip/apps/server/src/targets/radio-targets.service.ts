import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import {
  RADIO_TARGET_REPOSITORY,
  type RadioTargetRepository,
  type RadioTargetSummary,
} from '@application/targets/radio-target.repository';
import {
  COLLECTION_REPOSITORY,
  type CollectionRepository,
} from '@application/collection/collection.repository';
import type { JsonValue } from '@connector-sdk/index';
import { ConnectorRegistryService } from '@app/plugins/connector-registry.service';
import type { CreateRadioTargetDto } from './dto/create-radio-target.dto';
import type { UpdatePollingDto } from './dto/update-polling.dto';
import { SECRET_RESOLVER, type SecretResolver } from '@application/secrets/secret-resolver';
import type { ConnectorHealth } from '@connector-sdk/index';

/** Validates target/polling changes against the loaded connector capabilities. */
@Injectable()
export class RadioTargetsService {
  constructor(
    @Inject(RADIO_TARGET_REPOSITORY) private readonly targets: RadioTargetRepository,
    @Inject(COLLECTION_REPOSITORY) private readonly collections: CollectionRepository,
    @Inject(SECRET_RESOLVER) private readonly secrets: SecretResolver,
    private readonly connectors: ConnectorRegistryService,
  ) {}

  async create(input: CreateRadioTargetDto): Promise<RadioTargetSummary> {
    const connector = this.connectors.resolve(input.connectorKey);
    const configuration = input.configuration as unknown as Readonly<Record<string, JsonValue>>;
    await connector.validateConfiguration(configuration);
    return this.targets.create({
      siteId: input.siteId,
      connectorKey: connector.manifest.id,
      connectorVersion: connector.manifest.version,
      name: input.name,
      managementHost: input.managementHost,
      managementPort: input.managementPort,
      enabled: input.enabled,
      configuration,
      secretReference: input.secretReference,
    });
  }

  list(): Promise<RadioTargetSummary[]> {
    return this.targets.list();
  }

  async health(targetId: string): Promise<ConnectorHealth> {
    const target = await this.collections.getTarget(targetId);
    if (!target) throw new NotFoundException(`Radio target ${targetId} was not found`);
    const connector = this.connectors.resolve(target.connectorKey);
    const credentials = await this.secrets.resolve(target.secretReference);
    const session = await connector.openSession({
      targetId: target.id,
      host: target.host,
      port: target.port,
      configuration: target.configuration,
      secretReference: target.secretReference,
      credentials,
    });
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
      return await session.health(controller.signal);
    } finally {
      clearTimeout(timeout);
      await session.close();
    }
  }

  async updatePolling(
    targetId: string,
    logicalOperation: string,
    input: UpdatePollingDto,
  ): Promise<void> {
    const target = await this.collections.getTarget(targetId);
    if (!target) throw new NotFoundException(`Radio target ${targetId} was not found`);
    const connector = this.connectors.resolve(target.connectorKey);
    const capability = connector.manifest.capabilities.find(
      (candidate) => candidate.logicalOperation === logicalOperation,
    );
    if (!capability) throw new BadRequestException(`Operation ${logicalOperation} is not supported`);
    const intervalMs = input.intervalSeconds * 1000;
    if (intervalMs < capability.minimumIntervalMs) {
      throw new BadRequestException(
        `Minimum interval for ${logicalOperation} is ${capability.minimumIntervalMs} ms`,
      );
    }
    await this.targets.upsertPolling({
      targetId,
      logicalOperation,
      intervalMs,
      timeoutMs: input.timeoutMs,
      priority: input.priority,
      enabled: input.enabled,
    });
  }
}
