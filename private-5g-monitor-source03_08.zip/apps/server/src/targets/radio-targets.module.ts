import { Module } from '@nestjs/common';
import { PersistenceModule } from '@persistence/persistence.module';
import { PluginsModule } from '@app/plugins/plugins.module';
import { RadioTargetsController } from './radio-targets.controller';
import { RadioTargetsService } from './radio-targets.service';

@Module({
  imports: [PersistenceModule, PluginsModule],
  controllers: [RadioTargetsController],
  providers: [RadioTargetsService],
})
export class RadioTargetsModule {}
