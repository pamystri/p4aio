import { randomUUID } from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';

export function correlationIdMiddleware(
  request: Request,
  response: Response,
  next: NextFunction,
): void {
  const existing = (request as Request & { id?: string }).id;
  const supplied = request.header('x-request-id');
  const requestId = existing ?? (supplied && supplied.length <= 128 ? supplied : randomUUID());
  response.setHeader('x-request-id', requestId);
  (request as Request & { id: string }).id = requestId;
  next();
}
