import { Body, Controller, Get, Param, ParseUUIDPipe, Post, Query } from '@nestjs/common';
import { ApiCreatedResponse, ApiOkResponse, ApiSecurity, ApiTags } from '@nestjs/swagger';
import type { Site } from '@domain/site';
import { CreateSiteDto } from './dto/create-site.dto';
import { ListSitesQueryDto } from './dto/list-sites-query.dto';
import { SitesService } from './sites.service';

@ApiTags('sites')
@ApiSecurity('api-key')
@Controller('sites')
export class SitesController {
  constructor(private readonly sites: SitesService) {}

  @Post()
  @ApiCreatedResponse({ description: 'Site created' })
  create(@Body() input: CreateSiteDto): Promise<Site> {
    return this.sites.create(input);
  }

  @Get()
  @ApiOkResponse({ description: 'Cursor-paginated site list' })
  list(@Query() query: ListSitesQueryDto) {
    return this.sites.list(query.limit, query.cursor, query.search, query.sort);
  }

  @Get(':id')
  @ApiOkResponse({ description: 'Site details' })
  get(@Param('id', new ParseUUIDPipe()) id: string): Promise<Site> {
    return this.sites.get(id);
  }
}
