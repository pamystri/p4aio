import { Module } from '@nestjs/common';
import { PersistenceModule } from '@persistence/persistence.module';
import { SitesController } from './sites.controller';
import { SitesService } from './sites.service';

@Module({
  imports: [PersistenceModule],
  controllers: [SitesController],
  providers: [SitesService],
})
export class SitesModule {}
