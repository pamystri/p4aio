import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import {
  SITE_REPOSITORY,
  type SitePage,
  type SiteRepository,
} from '@application/sites/site.repository';
import type { CreateSite, Site } from '@domain/site';

@Injectable()
export class SitesService {
  constructor(@Inject(SITE_REPOSITORY) private readonly sites: SiteRepository) {}

  create(input: CreateSite): Promise<Site> {
    return this.sites.create(input);
  }

  async get(id: string): Promise<Site> {
    const site = await this.sites.findById(id);
    if (!site) throw new NotFoundException(`Site ${id} was not found`);
    return site;
  }

  list(limit: number, cursor?: string, search?: string, sort?: 'asc' | 'desc'): Promise<SitePage> {
    return this.sites.list(limit, cursor, search, sort);
  }
}
