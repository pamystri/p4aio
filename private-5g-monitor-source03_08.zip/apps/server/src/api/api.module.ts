import { Module } from '@nestjs/common';
import { HealthModule } from '@app/health/health.module';
import { LiveModule } from '@app/live/live.module';
import { PluginsModule } from '@app/plugins/plugins.module';
import { SitesModule } from '@app/sites/sites.module';
import { RadioTargetsModule } from '@app/targets/radio-targets.module';
import { MonitoringModule } from '@app/monitoring/monitoring.module';

/** Public presentation boundary. Domain and persistence modules expose no HTTP directly. */
@Module({
  imports: [HealthModule, LiveModule, PluginsModule, SitesModule, RadioTargetsModule, MonitoringModule],
})
export class ApiModule {}
