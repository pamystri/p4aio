import { Global, Module } from '@nestjs/common';
import { SECRET_RESOLVER } from '@application/secrets/secret-resolver';
import { EnvironmentSecretResolver } from './environment-secret.resolver';

@Global()
@Module({
  providers: [{ provide: SECRET_RESOLVER, useClass: EnvironmentSecretResolver }],
  exports: [SECRET_RESOLVER],
})
export class SecretsModule {}
