import { Injectable } from '@nestjs/common';
import type { SecretResolver } from '@application/secrets/secret-resolver';

/** Minimal host secret adapter. Only `env:VARIABLE_NAME` references are accepted. */
@Injectable()
export class EnvironmentSecretResolver implements SecretResolver {
  async resolve(reference: string | undefined): Promise<Readonly<Record<string, string>>> {
    if (!reference) return {};
    if (!reference.startsWith('env:')) throw new Error('Unsupported secret provider');
    const variable = reference.slice(4);
    if (!/^[A-Z][A-Z0-9_]*$/.test(variable)) throw new Error('Invalid environment secret reference');
    const value = process.env[variable];
    if (!value) throw new Error('Configured environment secret is not available');
    return { password: value };
  }
}
