import { timingSafeEqual } from 'node:crypto';
import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Reflector } from '@nestjs/core';
import type { Request } from 'express';
import type { Socket } from 'socket.io';
import { IS_PUBLIC_KEY } from '@app/common/http/public.decorator';

@Injectable()
export class AuthenticationGuard implements CanActivate {
  constructor(private readonly reflector: Reflector, private readonly config: ConfigService) {}
  canActivate(context: ExecutionContext): boolean {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [context.getHandler(), context.getClass()]);
    if (isPublic) return true;
    if (this.config.getOrThrow<string>('authentication.mode') === 'disabled') return true;
    const supplied = this.readCredential(context);
    const configured = this.config.getOrThrow<string>('authentication.apiKey');
    if (!supplied || !this.matches(supplied, configured)) throw new UnauthorizedException('A valid API key is required');
    return true;
  }
  private readCredential(context: ExecutionContext): string | undefined {
    if (context.getType() === 'ws') {
      const auth = context.switchToWs().getClient<Socket>().handshake.auth as Record<string, unknown>;
      return typeof auth['apiKey'] === 'string' ? auth['apiKey'] : undefined;
    }
    return context.switchToHttp().getRequest<Request>().header('x-api-key');
  }
  private matches(supplied: string, configured: string): boolean {
    const left = Buffer.from(supplied); const right = Buffer.from(configured);
    return left.length === right.length && timingSafeEqual(left, right);
  }
}
