import { Module } from '@nestjs/common';
import { AuthenticationGuard } from './auth.guard';
import { WebSocketAuthenticationGuard } from './ws-auth.guard';

@Module({
  providers: [AuthenticationGuard, WebSocketAuthenticationGuard],
  exports: [AuthenticationGuard, WebSocketAuthenticationGuard],
})
export class AuthModule {}
