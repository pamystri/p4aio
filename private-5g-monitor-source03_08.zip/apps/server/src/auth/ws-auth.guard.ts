import { timingSafeEqual } from 'node:crypto';
import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { WsException } from '@nestjs/websockets';
import type { Socket } from 'socket.io';

@Injectable()
export class WebSocketAuthenticationGuard implements CanActivate {
  constructor(private readonly config: ConfigService) {}
  canActivate(context: ExecutionContext): boolean {
    if (this.config.getOrThrow<string>('authentication.mode') === 'disabled') return true;
    const client = context.switchToWs().getClient<Socket>();
    const supplied = (client.handshake.auth as Record<string, unknown>)['apiKey'];
    const configured = this.config.getOrThrow<string>('authentication.apiKey');
    if (typeof supplied !== 'string' || !this.matches(supplied, configured)) throw new WsException('Unauthorized');
    return true;
  }
  private matches(supplied: string, configured: string): boolean {
    const left = Buffer.from(supplied); const right = Buffer.from(configured);
    return left.length === right.length && timingSafeEqual(left, right);
  }
}
