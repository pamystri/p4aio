import { Controller, Get, ServiceUnavailableException } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { Public } from '@app/common/http/public.decorator';
import { PrismaService } from '@persistence/prisma/prisma.service';
import { PollSchedulerService } from '@app/scheduler/poll-scheduler.service';

@ApiTags('health')
@Controller('health')
export class HealthController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scheduler: PollSchedulerService,
  ) {}

  @Public()
  @Get('live')
  @ApiOperation({ summary: 'Process liveness check' })
  liveness(): Readonly<Record<string, unknown>> {
    return { status: 'ok', timestamp: new Date().toISOString() };
  }

  @Public()
  @Get('ready')
  @ApiOperation({ summary: 'Application readiness check' })
  async readiness(): Promise<Readonly<Record<string, unknown>>> {
    const database = await this.prisma.isHealthy();
    const scheduler = this.scheduler.health();
    const ready = database && scheduler.ready;
    const result = {
      status: ready ? 'ok' : 'unavailable',
      timestamp: new Date().toISOString(),
      checks: { database: database ? 'up' : 'down', scheduler },
    };
    if (!ready) throw new ServiceUnavailableException(result);
    return result;
  }
}
