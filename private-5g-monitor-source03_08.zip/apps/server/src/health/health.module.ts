import { Module } from '@nestjs/common';
import { PersistenceModule } from '@persistence/persistence.module';
import { SchedulerModule } from '@app/scheduler/scheduler.module';
import { HealthController } from './health.controller';

@Module({
  imports: [PersistenceModule, SchedulerModule],
  controllers: [HealthController],
})
export class HealthModule {}
