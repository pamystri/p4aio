import { MiddlewareConsumer, Module, type NestModule } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { APP_FILTER, APP_GUARD } from '@nestjs/core';
import { ScheduleModule } from '@nestjs/schedule';
import { LoggerModule } from 'nestjs-pino';
import { randomUUID } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { loadYamlConfiguration } from '@app/config/configuration';
import { AuthenticationGuard } from '@app/auth/auth.guard';
import { AuthModule } from '@app/auth/auth.module';
import { GlobalExceptionFilter } from '@app/common/http/global-exception.filter';
import { correlationIdMiddleware } from '@app/common/http/correlation-id.middleware';
import { ApiModule } from '@app/api/api.module';
import { SchedulerModule } from '@app/scheduler/scheduler.module';
import { PersistenceModule } from '@persistence/persistence.module';
import { SecretsModule } from '@app/secrets/secrets.module';
import { AmarisoftIntegrationModule } from '@app/connectors/amarisoft/amarisoft-integration.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, cache: true, load: [loadYamlConfiguration] }),
    LoggerModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        const pretty = config.getOrThrow<boolean>('logging.pretty');
        return {
          pinoHttp: {
            level: config.getOrThrow<string>('logging.level'),
            redact: {
              paths: [
                'req.headers.authorization',
                'req.headers.x-api-key',
                'req.body.password',
                'req.body.apiKey',
                '*.secret',
                '*.credentials',
              ],
              censor: '[REDACTED]',
            },
            genReqId: (request: IncomingMessage, response: ServerResponse) => {
              const header = request.headers['x-request-id'];
              const id = typeof header === 'string' && header.length <= 128 ? header : randomUUID();
              response.setHeader('x-request-id', id);
              return id;
            },
            transport: pretty
              ? { target: 'pino-pretty', options: { singleLine: true, colorize: true } }
              : undefined,
          },
        };
      },
    }),
    ScheduleModule.forRoot(),
    AuthModule,
    SecretsModule,
    PersistenceModule,
    AmarisoftIntegrationModule,
    SchedulerModule,
    ApiModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: AuthenticationGuard },
    { provide: APP_FILTER, useClass: GlobalExceptionFilter },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(correlationIdMiddleware).forRoutes('*');
  }
}
