import { Injectable } from '@nestjs/common';
import { PinoLogger } from 'nestjs-pino';
import type { AmarisoftLogger } from '@amarisoft/amarisoft.types';

/** Adapts connector-safe structured log calls to the application Pino logger. */
@Injectable()
export class AmarisoftLoggerAdapter implements AmarisoftLogger {
  constructor(private readonly logger: PinoLogger) {}

  debug(context: Readonly<Record<string, unknown>>, message: string): void {
    this.logger.debug(context, message);
  }

  info(context: Readonly<Record<string, unknown>>, message: string): void {
    this.logger.info(context, message);
  }

  warn(context: Readonly<Record<string, unknown>>, message: string): void {
    this.logger.warn(context, message);
  }

  error(context: Readonly<Record<string, unknown>>, message: string): void {
    this.logger.error(context, message);
  }
}
