import { Inject, Injectable, OnModuleInit } from '@nestjs/common';
import {
  COLLECTION_REPOSITORY,
  type CollectionRepository,
} from '@application/collection/collection.repository';
import { ConnectorRegistryService } from '@app/plugins/connector-registry.service';
import { AMARISOFT_CONNECTOR } from './amarisoft.tokens';
import type { AmarisoftConnector } from '@amarisoft/amarisoft.connector';

/** Registers the built-in connector and records its exact version in PostgreSQL. */
@Injectable()
export class AmarisoftRegistrationService implements OnModuleInit {
  constructor(
    @Inject(AMARISOFT_CONNECTOR) private readonly connector: AmarisoftConnector,
    @Inject(COLLECTION_REPOSITORY) private readonly collections: CollectionRepository,
    private readonly registry: ConnectorRegistryService,
  ) {}

  async onModuleInit(): Promise<void> {
    await this.registry.register(this.connector);
    await this.collections.ensureConnectorInstallation(this.connector.manifest);
  }
}
