import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AmarisoftConnector } from '@amarisoft/amarisoft.connector';
import type { AmarisoftConnectionPolicy } from '@amarisoft/amarisoft.types';
import { LiveModule } from '@app/live/live.module';
import { PluginsModule } from '@app/plugins/plugins.module';
import { SchedulerModule } from '@app/scheduler/scheduler.module';
import { SecretsModule } from '@app/secrets/secrets.module';
import { PersistenceModule } from '@persistence/persistence.module';
import { AmarisoftCollectionHandler } from './amarisoft-collection.handler';
import { AmarisoftLoggerAdapter } from './amarisoft-logger.adapter';
import { AmarisoftRegistrationService } from './amarisoft-registration.service';
import { AMARISOFT_CONNECTOR } from './amarisoft.tokens';

/** Nest composition boundary for the otherwise framework-neutral connector package. */
@Module({
  imports: [PersistenceModule, PluginsModule, SchedulerModule, SecretsModule, LiveModule],
  providers: [
    AmarisoftLoggerAdapter,
    {
      provide: AMARISOFT_CONNECTOR,
      inject: [ConfigService, AmarisoftLoggerAdapter],
      useFactory: (
        config: ConfigService,
        logger: AmarisoftLoggerAdapter,
      ): AmarisoftConnector => {
        const policy = config.getOrThrow<AmarisoftConnectionPolicy>('connectors.amarisoft');
        return new AmarisoftConnector(policy, logger);
      },
    },
    AmarisoftRegistrationService,
    AmarisoftCollectionHandler,
  ],
})
export class AmarisoftIntegrationModule {}
